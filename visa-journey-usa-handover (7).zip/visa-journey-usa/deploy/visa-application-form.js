/* =====================================================================
   Visa Journey USA — application form (vanilla JavaScript)
   =====================================================================

   No framework, no build step, no dependencies. Drop the file on the page
   and call:

       VisaJourneyForm.mount(document.getElementById("app"), {
         onCreateApplication: async ({ securityPrompt, securityAnswer }) => {
           const r = await fetch("/api/application", {
             method: "POST",
             headers: { "Content-Type": "application/json" },
             body: JSON.stringify({ securityPrompt, securityAnswer }),
           });
           if (!r.ok) throw new Error("create failed");
           return r.json();                       // { applicationId: "..." }
         },
         onSaveStep: async (payload) => {
           const r = await fetch("/api/application/" + payload.applicationId, {
             method: "PATCH",
             headers: { "Content-Type": "application/json" },
             body: JSON.stringify(payload),
           });
           if (!r.ok) throw new Error("save failed");   // MUST throw on failure
         },
         onSubmit: async (data) => { ... },
         onRequestResumeLink: async ({ applicationId, email }) => { ... },
       });

   Resume screen:

       VisaJourneyForm.mountResume(el, { onLookup, onResume });

   WHAT THIS DOES NOT DO
   It stores nothing. No localStorage, no sessionStorage, no cookies. Passport
   and national ID numbers must not survive on a shared or stolen device. All
   persistence goes through the callbacks above, to your server.

   STYLING
   Styles are injected once, scoped under .vj-root, and use a vj- prefix so they
   cannot collide with the surrounding site. Restyle freely but keep the
   contrast: labels are near-black on white deliberately, and errors are dark
   red. The page this replaces failed contrast and had an 8px white disclaimer.

   SECURITY REQUIREMENTS FOR THE SERVER SIDE
   See DEVELOPER-HANDOVER.md. The short version: hash the security answer with
   bcrypt or argon2, generate reference numbers from a cryptographic random
   source, rate limit both lookup and resume, and never let applicant data reach
   your logs or error tracker.
   ===================================================================== */

var VisaJourneyForm = (function () {
  "use strict";

  /* ---------------- helpers ---------------- */

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === "class") node.className = v;
        else if (k === "text") node.textContent = v;
        else if (k === "html") node.innerHTML = v;
        else if (k.slice(0, 2) === "on") node.addEventListener(k.slice(2).toLowerCase(), v);
        else node.setAttribute(k, v === true ? "" : v);
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function normaliseAnswer(v) {
    return String(v == null ? "" : v).trim().toLowerCase().replace(/\s+/g, " ");
  }

  function isBlank(v) { return v === null || v === undefined || String(v).trim() === ""; }
  function isEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || "")); }
  function toDate(v) { var d = new Date(v); return isNaN(d.getTime()) ? null : d; }
  function inFuture(v) { var d = toDate(v); return d ? d > new Date() : false; }
  function inPast(v) { var d = toDate(v); return d ? d <= new Date() : false; }

  /* PREVIEW ONLY. Real reference numbers must come from your server, which is
     the only place that can guarantee they are unique and unguessable. This
     runs only when no onCreateApplication callback is supplied. Do not ship it. */
  var ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no O/0 or I/1
  function generatePreviewId() {
    var out = "", i, bytes;
    if (window.crypto && window.crypto.getRandomValues) {
      bytes = new Uint32Array(10);
      window.crypto.getRandomValues(bytes);
      for (i = 0; i < 10; i++) out += ID_ALPHABET[bytes[i] % ID_ALPHABET.length];
    } else {
      for (i = 0; i < 10; i++) out += ID_ALPHABET[Math.floor(Math.random() * ID_ALPHABET.length)];
    }
    return out;
  }

  /* ---------------- styles ---------------- */

  var STYLE_ID = "vj-styles";
  var CSS = [
    ".vj-root{--vj-ink:#1e293b;--vj-ink-strong:#0f172a;--vj-muted:#475569;--vj-line:#cbd5e1;",
    "--vj-accent:#0f766e;--vj-accent-dark:#115e59;--vj-accent-bg:#f0fdfa;--vj-error:#b91c1c;",
    "--vj-warn:#d97706;--vj-warn-bg:#fffbeb;--vj-bg:#f1f5f9;",
    "font-family:system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;",
    "color:var(--vj-ink);background:var(--vj-bg);min-height:100%;padding-bottom:4rem;box-sizing:border-box}",
    ".vj-root *,.vj-root *:before,.vj-root *:after{box-sizing:inherit}",
    ".vj-wrap{max-width:42rem;margin:0 auto;padding:0 1rem}",
    ".vj-bar{background:#fff;border-bottom:1px solid var(--vj-line)}",
    ".vj-bar-in{max-width:42rem;margin:0 auto;padding:.75rem 1rem;display:flex;flex-wrap:wrap;gap:.75rem;justify-content:space-between;align-items:center}",
    ".vj-ref{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:1rem;font-weight:600;letter-spacing:.05em;color:var(--vj-ink-strong)}",
    ".vj-small{font-size:.875rem;color:var(--vj-muted);margin:0}",
    ".vj-progress{padding:2rem 0 1.5rem}",
    ".vj-track{height:6px;border-radius:999px;background:var(--vj-line);overflow:hidden;margin-top:.5rem}",
    ".vj-fill{height:6px;border-radius:999px;background:var(--vj-accent);transition:width .3s}",
    ".vj-card{background:#fff;border-radius:.5rem;padding:1.5rem;box-shadow:0 1px 2px rgba(0,0,0,.06)}",
    "@media(min-width:640px){.vj-card{padding:2rem}}",
    ".vj-h1{font-size:1.25rem;font-weight:600;color:var(--vj-ink-strong);margin:0 0 .25rem}",
    ".vj-field{margin-bottom:1.25rem}",
    ".vj-label{display:block;font-size:.875rem;font-weight:500;color:#1f2937;margin-bottom:.375rem}",
    ".vj-req{color:var(--vj-accent);margin-left:.25rem}",
    ".vj-hint{font-size:.875rem;color:var(--vj-muted);margin:0 0 .375rem}",
    ".vj-input,.vj-select,.vj-textarea{width:100%;border:1px solid var(--vj-line);border-radius:.375rem;",
    "padding:.625rem .75rem;font-size:1rem;font-family:inherit;color:var(--vj-ink-strong);background:#fff}",
    ".vj-input:focus,.vj-select:focus,.vj-textarea:focus{outline:none;border-color:var(--vj-accent);box-shadow:0 0 0 2px var(--vj-accent)}",
    ".vj-input[disabled],.vj-select[disabled],.vj-textarea[disabled]{background:#f1f5f9;color:#64748b}",
    ".vj-input.vj-bad,.vj-select.vj-bad,.vj-textarea.vj-bad{border-color:var(--vj-error)}",
    ".vj-err{color:var(--vj-error);font-size:.875rem;margin:.375rem 0 0}",
    ".vj-help-btn{width:1.25rem;height:1.25rem;border-radius:999px;border:1px solid #94a3b8;background:#fff;",
    "color:var(--vj-muted);font-size:.75rem;font-weight:700;cursor:pointer;line-height:1;flex:none;margin-left:.5rem}",
    ".vj-help-btn[aria-expanded='true']{background:var(--vj-accent);border-color:var(--vj-accent);color:#fff}",
    ".vj-help{background:var(--vj-accent-bg);border-left:2px solid var(--vj-accent);padding:.625rem .75rem;",
    "border-radius:.375rem;margin-bottom:.5rem}",
    ".vj-help p{margin:0;font-size:.875rem;line-height:1.6;color:#1f2937}",
    ".vj-help .vj-attrib{margin-top:.375rem;color:var(--vj-muted)}",
    ".vj-labelrow{display:flex;align-items:flex-start;margin-bottom:.375rem}",
    ".vj-labelrow .vj-label{margin-bottom:0}",
    ".vj-yesno{display:flex;gap:.75rem}",
    ".vj-yesno label{flex:1;text-align:center;border:1px solid var(--vj-line);border-radius:.375rem;",
    "padding:.625rem 1rem;cursor:pointer;background:#fff;color:var(--vj-ink-strong)}",
    ".vj-yesno label.vj-on{border-color:var(--vj-accent);background:var(--vj-accent-bg);font-weight:500}",
    ".vj-yesno input{position:absolute;opacity:0;width:1px;height:1px}",
    ".vj-check{display:flex;gap:.5rem;align-items:center;cursor:pointer;margin-top:.5rem}",
    ".vj-check span{font-size:.875rem;color:#334155}",
    ".vj-consent{display:flex;gap:.75rem;cursor:pointer;margin-bottom:1.25rem}",
    ".vj-consent span{font-size:.875rem;line-height:1.6;color:#1f2937}",
    ".vj-group{border:1px solid var(--vj-line);border-radius:.375rem;padding:1rem;margin-bottom:1.25rem}",
    ".vj-row{border-top:1px solid #e2e8f0;padding-top:1rem;margin-bottom:1rem}",
    ".vj-row:first-child{border-top:0;padding-top:0}",
    ".vj-rowhead{display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem}",
    ".vj-rowhead span{font-size:.875rem;color:var(--vj-muted)}",
    ".vj-btn{border-radius:.375rem;padding:.625rem 1.5rem;font-size:.875rem;font-weight:500;cursor:pointer;",
    "font-family:inherit;border:1px solid transparent}",
    ".vj-primary{background:var(--vj-accent);color:#fff;font-weight:700}",
    ".vj-primary:hover{background:var(--vj-accent-dark)}",
    ".vj-primary[disabled]{opacity:.6;cursor:default}",
    ".vj-ghost{background:#fff;border-color:var(--vj-accent);color:var(--vj-accent-dark)}",
    ".vj-plain{background:transparent;color:#334155}",
    ".vj-plain[disabled]{color:#94a3b8;cursor:default}",
    ".vj-link{background:none;border:0;padding:0;color:var(--vj-accent-dark);text-decoration:underline;",
    "font-size:.875rem;font-weight:500;cursor:pointer;font-family:inherit}",
    ".vj-remove{background:none;border:0;padding:0;color:var(--vj-error);text-decoration:underline;",
    "font-size:.875rem;font-weight:500;cursor:pointer;font-family:inherit}",
    ".vj-nav{display:flex;justify-content:space-between;align-items:center;gap:1rem;",
    "border-top:1px solid #e2e8f0;padding-top:1.5rem;margin-top:2rem}",
    ".vj-note{border-left:2px solid var(--vj-accent);background:var(--vj-accent-bg);padding:.625rem .75rem;",
    "border-radius:.375rem;margin-bottom:1.25rem}",
    ".vj-note p{margin:0;font-size:.875rem;line-height:1.6;color:#1f2937}",
    ".vj-warnbox{border:1px solid var(--vj-warn);background:var(--vj-warn-bg);border-radius:.375rem;",
    "padding:1rem;margin-bottom:1.25rem}",
    ".vj-warnbox p{margin:0;font-size:.875rem;line-height:1.6;color:#1f2937}",
    ".vj-warnbox p.vj-warnhead{font-weight:600;color:var(--vj-ink-strong);margin-bottom:.25rem}",
    ".vj-issued{border:2px solid var(--vj-accent);background:var(--vj-accent-bg);border-radius:.375rem;",
    "padding:1.25rem;margin-bottom:1.5rem}",
    ".vj-issued-id{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:1.5rem;font-weight:600;",
    "letter-spacing:.15em;color:var(--vj-ink-strong);margin:.75rem 0}",
    ".vj-issued-btns{display:flex;flex-wrap:wrap;gap:.75rem;margin-top:1rem}",
    ".vj-sub{margin:1.5rem 0 .75rem;font-size:.875rem;font-weight:600;color:#1f2937}",
    ".vj-review{border-top:1px solid #e2e8f0;border-bottom:1px solid #e2e8f0;margin-bottom:2rem}",
    ".vj-review div{display:flex;justify-content:space-between;gap:1rem;padding:.625rem 0;border-top:1px solid #e2e8f0}",
    ".vj-review div:first-child{border-top:0}",

    ".vj-email-ref{margin-top:1rem;padding-top:1rem;border-top:1px solid rgba(15,118,110,.25)}",
    ".vj-email-ref label{display:block;font-size:.875rem;font-weight:500;color:#1f2937;margin-bottom:.5rem}",
    ".vj-email-row{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center}",
    ".vj-email-row .vj-input{flex:1 1 14rem;min-width:0}",
    ".vj-email-row .vj-btn{flex:0 0 auto;white-space:nowrap}",
    ".vj-emailed{margin:1rem 0 0;padding-top:1rem;border-top:1px solid rgba(15,118,110,.25);",
    "font-size:.875rem;line-height:1.6;color:#134e4a}",

    ".vj-file{display:block}",
    ".vj-file-input{display:block;width:100%;border:1px dashed var(--vj-line);border-radius:.375rem;",
    "padding:.75rem;font-size:.9375rem;font-family:inherit;color:var(--vj-ink);background:#fff;cursor:pointer}",
    ".vj-file-input:focus{outline:none;border-color:var(--vj-accent);box-shadow:0 0 0 2px var(--vj-accent)}",
    ".vj-file-preview{display:flex;gap:1rem;align-items:flex-start;margin-top:.875rem;",
    "border:1px solid var(--vj-line);border-radius:.375rem;padding:.875rem;background:#f8fafc}",
    ".vj-file-preview img{width:96px;height:96px;object-fit:cover;border-radius:.25rem;",
    "border:1px solid var(--vj-line);flex:none;display:block}",
    ".vj-file-meta{min-width:0}",
    ".vj-file-name{margin:0 0 .25rem;font-size:.9375rem;font-weight:600;color:var(--vj-ink-strong);",
    "overflow-wrap:anywhere}",
    ".vj-file-remove{margin-top:.625rem;padding:.4rem .8rem;font-size:.875rem}",
    ".vj-review dt{font-size:.875rem;color:var(--vj-muted);margin:0}",
    ".vj-review dd{font-size:.875rem;color:var(--vj-ink-strong);text-align:right;margin:0}",
    ".vj-inline{display:flex;gap:.5rem;align-items:center}",
    ".vj-inline .vj-input{width:auto}",
    ".vj-ssn1{width:5rem}.vj-ssn2{width:4rem}.vj-ssn3{width:6rem}",
    ".vj-two{display:grid;grid-template-columns:2fr 1fr;gap:.75rem}",
    ".vj-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}",
  ].join("");

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  return { el: el, clear: clear, normaliseAnswer: normaliseAnswer, injectStyles: injectStyles,
           isBlank: isBlank, isEmail: isEmail, inFuture: inFuture, inPast: inPast,
           generatePreviewId: generatePreviewId };
})();


/* ---------------- DS-160 constants, taken from the live form ---------------- */

const COUNTRIES = ["AFGHANISTAN","ALBANIA","ALGERIA","AMERICAN SAMOA","ANDORRA","ANGOLA","ANGUILLA","ANTIGUA AND BARBUDA","ARGENTINA","ARMENIA","ARUBA","AUSTRALIA","AUSTRIA","AZERBAIJAN","BAHAMAS","BAHRAIN","BANGLADESH","BARBADOS","BELARUS","BELGIUM","BELIZE","BENIN","BERMUDA","BHUTAN","BOLIVIA","BONAIRE","BOSNIA-HERZEGOVINA","BOTSWANA","BRAZIL","BRITISH INDIAN OCEAN TERRITORY","BRUNEI","BULGARIA","BURKINA FASO","BURMA","BURUNDI","CAMBODIA","CAMEROON","CANADA","CABO VERDE","CAYMAN ISLANDS","CENTRAL AFRICAN REPUBLIC","CHAD","CHILE","CHINA","CHRISTMAS ISLAND","COCOS KEELING ISLANDS","COLOMBIA","COMOROS","CONGO, DEMOCRATIC REPUBLIC OF THE","CONGO, REPUBLIC OF THE","COOK ISLANDS","COSTA RICA","COTE D`IVOIRE","CROATIA","CUBA","CURACAO","CYPRUS","CZECH REPUBLIC","DENMARK","DJIBOUTI","DOMINICA","DOMINICAN REPUBLIC","ECUADOR","EGYPT","EL SALVADOR","EQUATORIAL GUINEA","ERITREA","ESTONIA","ESWATINI","ETHIOPIA","FALKLAND ISLANDS","FAROE ISLANDS","FIJI","FINLAND","FRANCE","FRENCH GUIANA","FRENCH POLYNESIA","FRENCH SOUTHERN AND ANTARCTIC TERRITORIES","GABON","GAMBIA, THE","GAZA STRIP","GEORGIA","GERMANY","GHANA","GIBRALTAR","GREECE","GREENLAND","GRENADA","GUADELOUPE","GUAM","GUATEMALA","GUINEA","GUINEA - BISSAU","GUYANA","HAITI","HEARD AND MCDONALD ISLANDS","HOLY SEE (VATICAN CITY)","HONDURAS","HONG KONG","HOWLAND ISLAND","HUNGARY","ICELAND","INDIA","INDONESIA","IRAN","IRAQ","IRELAND","ISRAEL","ITALY","JAMAICA","JAPAN","JERUSALEM","JORDAN","KAZAKHSTAN","KENYA","KIRIBATI","KOREA, DEMOCRATIC REPUBLIC OF (NORTH)","KOREA, REPUBLIC OF (SOUTH)","KOSOVO","KUWAIT","KYRGYZSTAN","LAOS","LATVIA","LEBANON","LESOTHO","LIBERIA","LIBYA","LIECHTENSTEIN","LITHUANIA","LUXEMBOURG","MACAU","MACEDONIA, NORTH","MADAGASCAR","MALAWI","MALAYSIA","MALDEN ISLAND","MALDIVES","MALI","MALTA","MARSHALL ISLANDS","MARTINIQUE","MAURITANIA","MAURITIUS","MAYOTTE","MEXICO","MICRONESIA","MIDWAY ISLANDS","MOLDOVA","MONACO","MONGOLIA","MONTENEGRO","MONTSERRAT","MOROCCO","MOZAMBIQUE","NAMIBIA","NAURU","NEPAL","NETHERLANDS","NEW CALEDONIA","NEW ZEALAND","NICARAGUA","NIGER","NIGERIA","NIUE","NORFOLK ISLAND","NORTH MARIANA ISLANDS","NORTHERN IRELAND","NORWAY","OMAN","PAKISTAN","PALAU","PALMYRA ATOLL","PANAMA","PAPUA NEW GUINEA","PARAGUAY","PERU","PHILIPPINES","PITCAIRN ISLANDS","POLAND","PORTUGAL","PUERTO RICO","QATAR","REUNION","ROMANIA","RUSSIA","RWANDA","SABA ISLAND","SAINT MARTIN","SAMOA","SAN MARINO","SAO TOME AND PRINCIPE","SAUDI ARABIA","SENEGAL","SERBIA","SEYCHELLES","SIERRA LEONE","SINGAPORE","SINT MAARTEN","SLOVAKIA","SLOVENIA","SOLOMON ISLANDS","SOMALIA","SOUTH AFRICA","SOUTH GEORGIA AND THE SOUTH SANDWICH ISLAND","SOUTH SUDAN","SPAIN","SRI LANKA","ST. EUSTATIUS","ST. HELENA","ST. KITTS AND NEVIS","ST. LUCIA","ST. PIERRE AND MIQUELON","ST. VINCENT AND THE GRENADINES","SUDAN","SURINAME","SVALBARD","SWEDEN","SWITZERLAND","SYRIA","TAIWAN","TAJIKISTAN","TANZANIA","THAILAND","TIMOR-LESTE","TOGO","TOKELAU","TONGA","TRINIDAD AND TOBAGO","TUNISIA","TURKEY","TURKMENISTAN","TURKS AND CAICOS ISLANDS","TUVALU","UGANDA","UKRAINE","UNITED ARAB EMIRATES","UNITED KINGDOM","UNITED STATES OF AMERICA","URUGUAY","UZBEKISTAN","VANUATU","VENEZUELA","VIETNAM","VIRGIN ISLANDS (U.S.)","VIRGIN ISLANDS, BRITISH","WAKE ISLAND","WALLIS AND FUTUNA ISLANDS","WEST BANK","WESTERN SAHARA","YEMEN","ZAMBIA","ZIMBABWE"];

const US_STATES = ["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","District of Columbia","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania","Puerto Rico","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"];

const OCCUPATIONS = ["AGRICULTURE","ARTIST/PERFORMER","BUSINESS","COMMUNICATIONS","COMPUTER SCIENCE","CULINARY/FOOD SERVICES","EDUCATION","ENGINEERING","GOVERNMENT","HOMEMAKER","LEGAL PROFESSION","MEDICAL/HEALTH","MILITARY","NATURAL SCIENCE","NOT EMPLOYED","PHYSICAL SCIENCES","RELIGIOUS VOCATION","RESEARCH","RETIRED","SOCIAL SCIENCE","STUDENT","OTHER"];

const NO_EMPLOYER_OCCUPATIONS = ["HOMEMAKER", "NOT EMPLOYED", "RETIRED"];

const STUDENT_OCCUPATIONS = ["STUDENT"];

const SOCIAL_PLATFORMS = ["ASK.FM","DOUBAN","FACEBOOK","FLICKR","GOOGLE+","INSTAGRAM","LINKEDIN","MYSPACE","PINTEREST","QZONE (QQ)","REDDIT","SINA WEIBO","TENCENT WEIBO","TUMBLR","TWITTER","TWOO","VINE","VKONTAKTE (VK)","YOUKU","YOUTUBE","None"];

const STAY_UNITS = ["Year(s)", "Month(s)", "Week(s)", "Day(s)", "Less than 24 hours"];

const RELATIVE_STATUS = ["US citizen", "US legal permanent resident (LPR)", "Nonimmigrant", "Other, or I do not know"];

const RELATIVE_RELATIONSHIP = ["Spouse", "Fiancé or fiancée", "Child", "Sibling"];

const SECURITY_PROMPTS = [
  "What is the given name of your mother's mother?",
  "What is the given name of your father's father?",
  "What was the name of your first pet?",
  "In what city or town was your first job?",
  "What is the name of your favourite childhood friend?",
  "What was the make and model of your first car?",
  "What is the name of the street you grew up on?",
];

const COUNTRY_CODES = {
  "AFGHANISTAN": "AFGH",
  "ALBANIA": "ALB",
  "ALGERIA": "ALGR",
  "AMERICAN SAMOA": "ASMO",
  "ANDORRA": "ANDO",
  "ANGOLA": "ANGL",
  "ANGUILLA": "ANGU",
  "ANTIGUA AND BARBUDA": "ANTI",
  "ARGENTINA": "ARG",
  "ARMENIA": "ARM",
  "ARUBA": "ARB",
  "AUSTRALIA": "ASTL",
  "AUSTRIA": "AUST",
  "AZERBAIJAN": "AZR",
  "BAHAMAS": "BAMA",
  "BAHRAIN": "BAHR",
  "BANGLADESH": "BANG",
  "BARBADOS": "BRDO",
  "BELARUS": "BYS",
  "BELGIUM": "BELG",
  "BELIZE": "BLZ",
  "BENIN": "BENN",
  "BERMUDA": "BERM",
  "BHUTAN": "BHU",
  "BOLIVIA": "BOL",
  "BONAIRE": "BON",
  "BOSNIA-HERZEGOVINA": "BIH",
  "BOTSWANA": "BOT",
  "BRAZIL": "BRZL",
  "BRITISH INDIAN OCEAN TERRITORY": "IOT",
  "BRUNEI": "BRNI",
  "BULGARIA": "BULG",
  "BURKINA FASO": "BURK",
  "BURMA": "BURM",
  "BURUNDI": "BRND",
  "CAMBODIA": "CBDA",
  "CAMEROON": "CMRN",
  "CANADA": "CAN",
  "CABO VERDE": "CAVI",
  "CAYMAN ISLANDS": "CAYI",
  "CENTRAL AFRICAN REPUBLIC": "CAFR",
  "CHAD": "CHAD",
  "CHILE": "CHIL",
  "CHINA": "CHIN",
  "CHRISTMAS ISLAND": "CHRI",
  "COCOS KEELING ISLANDS": "COCI",
  "COLOMBIA": "COL",
  "COMOROS": "COMO",
  "CONGO, DEMOCRATIC REPUBLIC OF THE": "COD",
  "CONGO, REPUBLIC OF THE": "CONB",
  "COOK ISLANDS": "CKIS",
  "COSTA RICA": "CSTR",
  "COTE D`IVOIRE": "IVCO",
  "CROATIA": "HRV",
  "CUBA": "CUBA",
  "CURACAO": "CUR",
  "CYPRUS": "CYPR",
  "CZECH REPUBLIC": "CZEC",
  "DENMARK": "DEN",
  "DJIBOUTI": "DJI",
  "DOMINICA": "DOMN",
  "DOMINICAN REPUBLIC": "DOMR",
  "ECUADOR": "ECUA",
  "EGYPT": "EGYP",
  "EL SALVADOR": "ELSL",
  "EQUATORIAL GUINEA": "EGN",
  "ERITREA": "ERI",
  "ESTONIA": "EST",
  "ESWATINI": "SZLD",
  "ETHIOPIA": "ETH",
  "FALKLAND ISLANDS": "FKLI",
  "FAROE ISLANDS": "FRO",
  "FIJI": "FIJI",
  "FINLAND": "FIN",
  "FRANCE": "FRAN",
  "FRENCH GUIANA": "FRGN",
  "FRENCH POLYNESIA": "FPOL",
  "FRENCH SOUTHERN AND ANTARCTIC TERRITORIES": "FSAT",
  "GABON": "GABN",
  "GAMBIA, THE": "GAM",
  "GAZA STRIP": "XGZ",
  "GEORGIA": "GEO",
  "GERMANY": "GER",
  "GHANA": "GHAN",
  "GIBRALTAR": "GIB",
  "GREECE": "GRC",
  "GREENLAND": "GRLD",
  "GRENADA": "GREN",
  "GUADELOUPE": "GUAD",
  "GUAM": "GUAM",
  "GUATEMALA": "GUAT",
  "GUINEA": "GNEA",
  "GUINEA - BISSAU": "GUIB",
  "GUYANA": "GUY",
  "HAITI": "HAT",
  "HEARD AND MCDONALD ISLANDS": "HMD",
  "HOLY SEE (VATICAN CITY)": "VAT",
  "HONDURAS": "HOND",
  "HONG KONG": "HNK",
  "HOWLAND ISLAND": "XHI",
  "HUNGARY": "HUNG",
  "ICELAND": "ICLD",
  "INDIA": "IND",
  "INDONESIA": "IDSA",
  "IRAN": "IRAN",
  "IRAQ": "IRAQ",
  "IRELAND": "IRE",
  "ISRAEL": "ISRL",
  "ITALY": "ITLY",
  "JAMAICA": "JAM",
  "JAPAN": "JPN",
  "JERUSALEM": "JRSM",
  "JORDAN": "JORD",
  "KAZAKHSTAN": "KAZ",
  "KENYA": "KENY",
  "KIRIBATI": "KIRI",
  "KOREA, DEMOCRATIC REPUBLIC OF (NORTH)": "PRK",
  "KOREA, REPUBLIC OF (SOUTH)": "KOR",
  "KOSOVO": "KSV",
  "KUWAIT": "KUWT",
  "KYRGYZSTAN": "KGZ",
  "LAOS": "LAOS",
  "LATVIA": "LATV",
  "LEBANON": "LEBN",
  "LESOTHO": "LES",
  "LIBERIA": "LIBR",
  "LIBYA": "LBYA",
  "LIECHTENSTEIN": "LCHT",
  "LITHUANIA": "LITH",
  "LUXEMBOURG": "LXM",
  "MACAU": "MAC",
  "MACEDONIA, NORTH": "MKD",
  "MADAGASCAR": "MADG",
  "MALAWI": "MALW",
  "MALAYSIA": "MLAS",
  "MALDEN ISLAND": "MLDI",
  "MALDIVES": "MLDV",
  "MALI": "MALI",
  "MALTA": "MLTA",
  "MARSHALL ISLANDS": "RMI",
  "MARTINIQUE": "MART",
  "MAURITANIA": "MAUR",
  "MAURITIUS": "MRTS",
  "MAYOTTE": "MYT",
  "MEXICO": "MEX",
  "MICRONESIA": "FSM",
  "MIDWAY ISLANDS": "MDWI",
  "MOLDOVA": "MLD",
  "MONACO": "MON",
  "MONGOLIA": "MONG",
  "MONTENEGRO": "MTG",
  "MONTSERRAT": "MONT",
  "MOROCCO": "MORO",
  "MOZAMBIQUE": "MOZ",
  "NAMIBIA": "NAMB",
  "NAURU": "NAU",
  "NEPAL": "NEP",
  "NETHERLANDS": "NETH",
  "NEW CALEDONIA": "NCAL",
  "NEW ZEALAND": "NZLD",
  "NICARAGUA": "NIC",
  "NIGER": "NIR",
  "NIGERIA": "NRA",
  "NIUE": "NIUE",
  "NORFOLK ISLAND": "NFK",
  "NORTH MARIANA ISLANDS": "MNP",
  "NORTHERN IRELAND": "NIRE",
  "NORWAY": "NORW",
  "OMAN": "OMAN",
  "PAKISTAN": "PKST",
  "PALAU": "PALA",
  "PALMYRA ATOLL": "PLMR",
  "PANAMA": "PAN",
  "PAPUA NEW GUINEA": "PNG",
  "PARAGUAY": "PARA",
  "PERU": "PERU",
  "PHILIPPINES": "PHIL",
  "PITCAIRN ISLANDS": "PITC",
  "POLAND": "POL",
  "PORTUGAL": "PORT",
  "PUERTO RICO": "PR",
  "QATAR": "QTAR",
  "REUNION": "REUN",
  "ROMANIA": "ROM",
  "RUSSIA": "RUS",
  "RWANDA": "RWND",
  "SABA ISLAND": "SABA",
  "SAINT MARTIN": "MAF",
  "SAMOA": "WSAM",
  "SAN MARINO": "SMAR",
  "SAO TOME AND PRINCIPE": "STPR",
  "SAUDI ARABIA": "SARB",
  "SENEGAL": "SENG",
  "SERBIA": "SBA",
  "SEYCHELLES": "SEYC",
  "SIERRA LEONE": "SLEO",
  "SINGAPORE": "SING",
  "SINT MAARTEN": "STM",
  "SLOVAKIA": "SVK",
  "SLOVENIA": "SVN",
  "SOLOMON ISLANDS": "SLMN",
  "SOMALIA": "SOMA",
  "SOUTH AFRICA": "SAFR",
  "SOUTH GEORGIA AND THE SOUTH SANDWICH ISLAND": "SGS",
  "SOUTH SUDAN": "SSDN",
  "SPAIN": "SPN",
  "SRI LANKA": "SRL",
  "ST. EUSTATIUS": "STEU",
  "ST. HELENA": "SHEL",
  "ST. KITTS AND NEVIS": "STCN",
  "ST. LUCIA": "SLCA",
  "ST. PIERRE AND MIQUELON": "SPMI",
  "ST. VINCENT AND THE GRENADINES": "STVN",
  "SUDAN": "SUDA",
  "SURINAME": "SURM",
  "SVALBARD": "SJM",
  "SWEDEN": "SWDN",
  "SWITZERLAND": "SWTZ",
  "SYRIA": "SYR",
  "TAIWAN": "TWAN",
  "TAJIKISTAN": "TJK",
  "TANZANIA": "TAZN",
  "THAILAND": "THAI",
  "TIMOR-LESTE": "TMOR",
  "TOGO": "TOGO",
  "TOKELAU": "TKL",
  "TONGA": "TONG",
  "TRINIDAD AND TOBAGO": "TRIN",
  "TUNISIA": "TNSA",
  "TURKEY": "TRKY",
  "TURKMENISTAN": "TKM",
  "TURKS AND CAICOS ISLANDS": "TCIS",
  "TUVALU": "TUV",
  "UGANDA": "UGAN",
  "UKRAINE": "UKR",
  "UNITED ARAB EMIRATES": "UAE",
  "UNITED KINGDOM": "GRBR",
  "UNITED STATES OF AMERICA": "USA",
  "URUGUAY": "URU",
  "UZBEKISTAN": "UZB",
  "VANUATU": "VANU",
  "VENEZUELA": "VENZ",
  "VIETNAM": "VTNM",
  "VIRGIN ISLANDS (U.S.)": "VI",
  "VIRGIN ISLANDS, BRITISH": "BRVI",
  "WAKE ISLAND": "WKI",
  "WALLIS AND FUTUNA ISLANDS": "WAFT",
  "WEST BANK": "XWB",
  "WESTERN SAHARA": "SSAH",
  "YEMEN": "YEM",
  "ZAMBIA": "ZAMB",
  "ZIMBABWE": "ZIMB"
};

const OCCUPATION_CODES = {
  "AGRICULTURE": "A",
  "ARTIST/PERFORMER": "AP",
  "BUSINESS": "B",
  "COMMUNICATIONS": "CM",
  "COMPUTER SCIENCE": "CS",
  "CULINARY/FOOD SERVICES": "C",
  "EDUCATION": "ED",
  "ENGINEERING": "EN",
  "GOVERNMENT": "G",
  "HOMEMAKER": "H",
  "LEGAL PROFESSION": "LP",
  "MEDICAL/HEALTH": "MH",
  "MILITARY": "M",
  "NATURAL SCIENCE": "NS",
  "NOT EMPLOYED": "N",
  "PHYSICAL SCIENCES": "PS",
  "RELIGIOUS VOCATION": "RV",
  "RESEARCH": "R",
  "RETIRED": "RT",
  "SOCIAL SCIENCE": "SS",
  "STUDENT": "S",
  "OTHER": "O"
};

const LIMITS = {
  employerSchoolName: 75, street: 40, city: 20, state: 20, postal: 10,
  phone: 15, salary: 15, duties: 4000,
};

const SECURITY_NOTE = "A visa may not be issued to people who fall within specific categories defined by law as inadmissible to the United States, except where a waiver is obtained in advance. A yes answer does not automatically mean you are ineligible, but if you answer yes you may be required to appear in person before a consular officer.";

const SECURITY_PARTS = [
  {
    id: "security1", label: "Background 1",
    questions: [
      { id: "sec_disease", text: "Do you have a communicable disease of public health significance?",
        official: true,
        help: "Communicable diseases of public health significance include chancroid, gonorrhoea, granuloma inguinale, infectious leprosy, lymphogranuloma venereum, infectious stage syphilis, active tuberculosis, and other diseases as determined by the Department of Health and Human Services. Common illnesses are not included." },
      { id: "sec_disorder", text: "Do you have a mental or physical disorder that poses, or is likely to pose, a threat to the safety or welfare of yourself or others?",
        help: "This asks about a disorder that creates a genuine safety risk. Having a mental or physical condition is not, by itself, what is being asked about here." },
      { id: "sec_drugs", text: "Are you, or have you ever been, a drug abuser or addict?",
        help: "Answer accurately. This is checked against other records, and an inaccurate answer is treated more seriously than the underlying issue." },
    ],
  },
  {
    id: "security2", label: "Background 2",
    questions: [
      { id: "sec_arrest", text: "Have you ever been arrested or convicted for any offence or crime, even though subject of a pardon, amnesty, or other similar action?",
        help: "Answer yes even if the case was dismissed, the record was expunged or sealed, or it happened when you were a minor. Sealed records are frequently still visible to the US government, so disclosing is safer than assuming otherwise." },
      { id: "sec_controlled", text: "Have you ever violated, or engaged in a conspiracy to violate, any law relating to controlled substances?",
        help: "This includes offences involving substances that are legal where you live but remain illegal under US federal law, cannabis among them." },
      { id: "sec_prostitution", text: "Are you coming to the United States to engage in prostitution or unlawful commercialised vice, or have you been engaged in prostitution or procuring prostitutes within the past 10 years?" },
      { id: "sec_laundering", text: "Have you ever been involved in, or do you seek to engage in, money laundering?" },
      { id: "sec_trafficking", text: "Have you ever committed or conspired to commit a human trafficking offence in the United States or outside the United States?" },
      { id: "sec_trafficking_aid", text: "Have you ever knowingly aided, abetted, assisted or colluded with an individual who has committed, or conspired to commit, a severe human trafficking offence in the United States or outside the United States?" },
      { id: "sec_trafficking_family", text: "Are you the spouse, son, or daughter of an individual who has committed or conspired to commit a human trafficking offence in the United States or outside the United States, and have you within the last five years knowingly benefited from the trafficking activities?" },
    ],
  },
  {
    id: "security3", label: "Background 3",
    questions: [
      { id: "sec_espionage", text: "Do you seek to engage in espionage, sabotage, export control violations, or any other illegal activity while in the United States?" },
      { id: "sec_terror_acts", text: "Do you seek to engage in terrorist activities while in the United States, or have you ever engaged in terrorist activities?" },
      { id: "sec_terror_support", text: "Have you ever provided, or do you intend to provide, financial assistance or other support to terrorists or terrorist organisations?" },
      { id: "sec_terror_member", text: "Are you a member or representative of a terrorist organisation?" },
      { id: "sec_terror_family", text: "Are you the spouse, son, or daughter of an individual who has engaged in terrorist activity, including providing financial assistance or other support to terrorists or terrorist organisations, in the last five years?" },
      { id: "sec_genocide", text: "Have you ever ordered, incited, committed, assisted, or otherwise participated in genocide?" },
      { id: "sec_torture", text: "Have you ever committed, ordered, incited, assisted, or otherwise participated in torture?" },
      { id: "sec_killings", text: "Have you committed, ordered, incited, assisted, or otherwise participated in extrajudicial killings, political killings, or other acts of violence?" },
      { id: "sec_child_soldiers", text: "Have you ever engaged in the recruitment or the use of child soldiers?" },
      { id: "sec_religious_freedom", text: "Have you, while serving as a government official, been responsible for or directly carried out, at any time, particularly severe violations of religious freedom?" },
      { id: "sec_population", text: "Have you ever been directly involved in the establishment or enforcement of population controls forcing a woman to undergo an abortion against her free choice, or a man or a woman to undergo sterilisation against his or her free will?" },
      { id: "sec_organs", text: "Have you ever been directly involved in the coercive transplantation of human organs or bodily tissue?" },
    ],
  },
  {
    id: "security4", label: "Background 4",
    questions: [
      { id: "sec_misrep", text: "Have you ever sought to obtain, or assist others to obtain, a visa, entry into the United States, or any other United States immigration benefit by fraud or wilful misrepresentation or other unlawful means?",
        help: "This includes a previous application that contained information you knew was inaccurate, and helping someone else submit one." },
      { id: "sec_removed", text: "Have you ever been removed or deported from any country?",
        help: "This covers any country, not only the United States." },
    ],
  },
  {
    id: "security5", label: "Background 5",
    questions: [
      { id: "sec_custody", text: "Have you ever withheld custody of a US citizen child outside the United States from a person granted legal custody by a US court?" },
      { id: "sec_voting", text: "Have you voted in the United States in violation of any law or regulation?" },
      { id: "sec_renounced", text: "Have you ever renounced United States citizenship for the purposes of avoiding taxation?" },
    ],
  },
];


/* ---------------------------------------------------------------------
   SCHEMA
   Every step, field, condition and rule. This is the file to edit when the
   DS-160 changes. The renderer below is generic and should not need touching.

   Field keys:
     type        text | date | number | tel | email | select | textarea |
                 yesno | ssn | note | warn | heading | repeat
     required    true, or a function (data) => boolean
     requiredUnless  key of a "does not apply" checkbox that exempts it
     showIf      (data) => boolean
     na          { key, label } renders a does-not-apply / do-not-know checkbox
     official    true marks help text as the Department of State's own wording
   --------------------------------------------------------------------- */

var VJ_SCHEMA = (function () {
  "use strict";

  function notEmployed(d) { return NO_EMPLOYER_OCCUPATIONS.indexOf(d.occupation) !== -1; }

  var STEPS = [];

  /* ---------- 1. Getting back in ---------- */
  STEPS.push({
    id: "access", label: "Getting back in",
    intro: "Set this up first so you can come back to your application later. You will need your reference number and the answer to the question you choose below. Nothing else.",
    fields: [
      { type: "select", id: "securityPrompt", label: "Choose a security question", required: true,
        options: SECURITY_PROMPTS,
        help: "Pick one you will still answer the same way in a year. Avoid anything a stranger could find on your social media or in a public record." },
      { type: "text", id: "securityAnswer", label: "Your answer", required: true,
        showIf: function (d) { return !!d.securityPrompt; },
        help: "Capital letters and extra spaces do not matter. Write it the way you would say it." },
      { type: "text", id: "securityAnswerConfirm", label: "Type your answer again", required: true,
        showIf: function (d) { return !!d.securityPrompt; } },
      { type: "note", text: "When you continue, we will create your application and give you a reference number on the next screen." },
      { type: "warn", head: "Keep this to yourself",
        text: "Anyone with your reference number and this answer can open your application and see your passport details. We will never ask you for this answer by email or on the phone. If someone does, it is not us." },
    ],
    validate: function (d, e) {
      if (d.securityAnswer && d.securityAnswer.trim().length < 2) e.securityAnswer = "Please give a longer answer.";
      if (d.securityAnswer && d.securityAnswerConfirm &&
          VisaJourneyForm.normaliseAnswer(d.securityAnswer) !== VisaJourneyForm.normaliseAnswer(d.securityAnswerConfirm)) {
        e.securityAnswerConfirm = "The two answers do not match.";
      }
    },
  });

  /* ---------- 2. About you ---------- */
  STEPS.push({
    id: "personal", label: "About you",
    sub: "Answer using exactly the details shown in your passport.",
    fields: [
      { type: "text", id: "surnames", label: "Surnames", required: true, official: true, letters: true,
        help: "Enter all surnames as listed in your passport. If only one name is listed in your passport, enter that surname here." },
      { type: "text", id: "givenNames", label: "Given names", required: true, official: true, letters: true,
        help: "If your passport does not include a given name, enter FNU, which stands for first name unknown." },
      { type: "text", id: "nativeName", label: "Full name in your native alphabet", requiredUnless: "nativeNameNA",
        na: { key: "nativeNameNA", label: "Does not apply, or technology not available" },
        help: "Write your name in the script you normally use, such as Arabic, Chinese, Cyrillic, or Hebrew. Tick the box below if your language uses Latin letters, or if you cannot type your alphabet on this device." },
      { type: "yesno", id: "otherNamesUsed", label: "Have you ever used any other names?", required: true, official: true,
        help: "Other names include your maiden name, religious name, professional name, or any other name you are known by or have been known by in the past." },
      { type: "repeat", key: "otherNames", prefix: "otherNames", itemLabel: "Name",
        addLabel: "Add another name", blank: { surnames: "", givenNames: "" },
        showIf: function (d) { return d.otherNamesUsed === "Yes"; },
        intro: "If you only have other surnames to enter, repeat the given names you entered above. If you only have other given names, repeat the surname you entered above. Add a separate entry for each name.",
        fields: [
          { type: "text", id: "surnames", label: "Other surnames used", required: true, letters: true,
            message: "Enter a surname. If you only have other given names, repeat your surname from above." },
          { type: "text", id: "givenNames", label: "Other given names used", required: true, letters: true,
            message: "Enter given names. If you only have other surnames, repeat your given names from above." },
        ] },
      { type: "yesno", id: "telecode", label: "Do you have a telecode that represents your name?", required: true, official: true,
        help: "Telecodes are four-digit code numbers that represent characters in some non-Roman alphabet names. If you have never been given one, answer no." },
      { type: "text", id: "telecodeSurnames", label: "Telecode for your surnames", required: true,
        showIf: function (d) { return d.telecode === "Yes"; }, hint: "Enter the four-digit groups, separated by spaces." },
      { type: "text", id: "telecodeGivenNames", label: "Telecode for your given names", required: true,
        showIf: function (d) { return d.telecode === "Yes"; } },
      { type: "select", id: "sex", label: "Sex", required: true, official: true, options: ["Male", "Female"],
        help: "Select male or female. This must match what is printed in your passport, even if it differs from how you identify." },
      /* Options and their order follow the DS-160 exactly, Other included.
         Feedback, September 2026: Common law marriage and Other were missing. */
      { type: "select", id: "maritalStatus", label: "Marital status", required: true,
        options: ["Married", "Common law marriage", "Civil union or domestic partnership",
                  "Single", "Widowed", "Divorced", "Legally separated", "Other"],
        help: "Choose the status that applies today. If you are separated but not legally divorced, select legally separated. Choose Other only if none of the rest describe your situation." },
      { type: "text", id: "maritalStatusOther", label: "Describe your marital status", required: true,
        maxLength: 60, showIf: function (d) { return d.maritalStatus === "Other"; },
        help: "A few words is enough. The official form asks for an explanation whenever Other is chosen." },
      { type: "date", id: "dob", label: "Date of birth", required: true, official: true,
        help: "If the day or month is unknown, enter it exactly as shown in your passport." },
      { type: "text", id: "cityOfBirth", label: "City of birth", required: true,
        help: "The city or town where you were born, as it appears on your passport or birth certificate." },
      { type: "text", id: "stateOfBirth", label: "State or province of birth", requiredUnless: "stateOfBirthNA",
        na: { key: "stateOfBirthNA" },
        help: "Tick the box below if the country where you were born does not use states or provinces, or if your documents do not show one." },
      { type: "select", id: "countryOfBirth", label: "Country or region of birth", required: true, official: true, options: COUNTRIES,
        help: "Select the name that is currently in use for the place where you were born. If the country has since been renamed or divided, choose the name used today, not the name at the time of your birth." },
    ],
    validate: function (d, e) {
      if (d.dob && VisaJourneyForm.inFuture(d.dob)) e.dob = "Date of birth cannot be in the future.";
    },
  });

  /* ---------- 3. Nationality and ID ---------- */
  STEPS.push({
    id: "personal2", label: "Nationality and ID",
    fields: [
      { type: "select", id: "nationality", label: "Country or region of origin (nationality)", required: true, options: COUNTRIES,
        help: "The country that issued your passport, in most cases." },
      { type: "warn", head: "You may not need a visa",
        showIf: function (d) { return d.nationality === "UNITED STATES OF AMERICA" || d.countryOfBirth === "UNITED STATES OF AMERICA"; },
        text: "US citizens do not need a visitor visa to enter the United States, and most people born in the United States are citizens by birth. Before paying for anything, please contact us so we can check whether this service applies to you. We would rather tell you now than take a fee you did not need to pay." },
      { type: "yesno", id: "otherNationality", required: true, official: true,
        label: "Do you hold, or have you ever held, any nationality other than the one above?",
        help: "Enter all nationalities you currently hold and all nationalities you have previously held, whether or not you have formally or legally given one up. If a country where you previously held nationality no longer exists as a political entity, select the nationality matching the name used for that location today." },
      { type: "repeat", key: "otherNationalities", prefix: "otherNat", itemLabel: "Nationality",
        addLabel: "Add another nationality", blank: { country: "", hasPassport: "", passportNumber: "" },
        showIf: function (d) { return d.otherNationality === "Yes"; },
        fields: [
          { type: "select", id: "country", label: "Other country or region of nationality", required: true, options: COUNTRIES, message: "Select a country." },
          { type: "yesno", id: "hasPassport", label: "Do you hold a passport for this nationality?", required: true, message: "Please answer." },
          { type: "text", id: "passportNumber", label: "Passport number for this nationality", required: true,
            showIf: function (d, row) { return row.hasPassport === "Yes"; }, message: "Enter the passport number for this nationality." },
        ] },
      { type: "yesno", id: "permanentResidentOther", required: true, official: true,
        label: "Are you a permanent resident of a country or region other than the nationality above?",
        help: "Permanent resident means any individual who has been legally granted permission by a country or region to live and work there without time limitation." },
      { type: "repeat", key: "permanentResidences", prefix: "pr", itemLabel: "Country",
        addLabel: "Add another country", blank: { country: "" },
        showIf: function (d) { return d.permanentResidentOther === "Yes"; },
        fields: [{ type: "select", id: "country", label: "Country or region of permanent residence", required: true, options: COUNTRIES, message: "Select a country." }] },
      { type: "text", id: "nationalId", label: "National identification number", requiredUnless: "nationalIdNA", official: true,
        na: { key: "nationalIdNA" },
        help: "A unique number your own government issues to you. The US government issues its own numbers separately: a Social Security number for employment, and a taxpayer ID for tax purposes. Tick the box if your country does not issue one." },
      { type: "ssn", id: "usSsn", label: "US Social Security number", requiredUnless: "usSsnNA",
        na: { key: "usSsnNA" },
        help: "Only if the United States has issued you one, usually through past work or study there. Most applicants tick the box below." },
      { type: "text", id: "usTaxId", label: "US taxpayer identification number", requiredUnless: "usTaxIdNA",
        na: { key: "usTaxIdNA" },
        help: "An ITIN or similar number, if the United States has ever issued you one. Most applicants tick the box." },
    ],
  });

  /* ---------- 4. Your trip ---------- */
  STEPS.push({
    id: "travel", label: "Your trip",
    fields: [
      { type: "note", head: "Visa type: B1/B2 visitor visa",
        text: "We prepare B1/B2 visitor applications only. If you need a student, work, or immigrant visa, this is not the right service for you." },
      { type: "yesno", id: "specificPlans", label: "Have you made specific travel plans?", required: true,
        help: "Answer yes only if you know your dates and, ideally, your flights. If your plans are still loose, answer no and give us your best estimate. Neither answer is better than the other." },

      { type: "date", id: "arrivalDate", label: "Date of arrival in the US", required: true, official: true,
        showIf: function (d) { return d.specificPlans === "Yes"; },
        help: "If you are unsure of your date of arrival or departure, provide an estimate." },
      { type: "text", id: "arrivalFlight", label: "Arrival flight", showIf: function (d) { return d.specificPlans === "Yes"; },
        hint: "Optional. The flight number if you have booked, for example BA117." },
      { type: "text", id: "arrivalCity", label: "Arrival city", required: true, showIf: function (d) { return d.specificPlans === "Yes"; },
        help: "The US city where you land, which may not be your final destination." },
      { type: "date", id: "departureDate", label: "Date of departure from the US", required: true, showIf: function (d) { return d.specificPlans === "Yes"; } },
      { type: "text", id: "departureFlight", label: "Departure flight", hint: "Optional.", showIf: function (d) { return d.specificPlans === "Yes"; } },
      { type: "text", id: "departureCity", label: "Departure city", required: true, showIf: function (d) { return d.specificPlans === "Yes"; } },
      { type: "repeat", key: "visitLocations", prefix: "loc", itemLabel: "Location", addLabel: "Add another location",
        blank: { location: "" }, showIf: function (d) { return d.specificPlans === "Yes"; },
        heading: "Places you plan to visit in the US",
        intro: "Add each city or place. An estimate is fine.",
        fields: [{ type: "text", id: "location", label: "Location", required: true, message: "Enter a place, or remove this line." }] },

      /* Same data key as the arrival date above, on purpose: only one of the two
         ever renders. domId keeps the DOM ids distinct so nothing collides if
         that ever stops being true. */
      { type: "date", id: "arrivalDate", domId: "arrivalDateEstimate",
        label: "Intended date of arrival", required: true, official: true,
        showIf: function (d) { return d.specificPlans === "No"; },
        help: "If you are unsure of your travel plans, provide an estimate. You are not held to this date." },
      { type: "number", id: "stayLength", label: "Intended length of stay", required: true, min: 1,
        showIf: function (d) { return d.specificPlans === "No"; }, unitKey: "stayUnit", unitOptions: ["Days", "Weeks", "Months", "Years"],
        help: "How long you intend to stay on this visit, not how long the visa lasts." },
      { type: "warn", head: "That is a long visit",
        showIf: function (d) { return longStay(d); },
        text: "Visitors on a B1/B2 are typically admitted for up to six months at a time, even when the visa itself lasts for years. Asking for longer can raise questions about your intentions. Please talk to us before submitting so we can go over what you actually need." },

      { type: "heading", text: "Address where you will stay in the US" },
      { type: "text", id: "usStreet", label: "Street address, line 1", required: true, maxLength: LIMITS.street,
        help: "A hotel, or the home address of the person you are visiting. If your plans are not settled, give your most likely first stop." },
      { type: "text", id: "usStreet2", label: "Street address, line 2", hint: "Optional. Apartment or suite number.", maxLength: LIMITS.street },
      { type: "text", id: "usCity", label: "City", required: true, maxLength: LIMITS.city },
      { type: "select", id: "usState", label: "State", required: true, options: US_STATES },
      { type: "text", id: "usZip", label: "ZIP code", maxLength: LIMITS.postal,
        help: "Optional if you do not know it. US ZIP codes look like 12345 or 12345-1234." },
      { type: "select", id: "payer", label: "Who is paying for your trip?", required: true,
        options: ["Myself", "Other person", "Present employer", "Employer in the US", "Other company or organization"],
        help: "Answer honestly. If someone else is funding the trip, you may be asked for proof of their finances rather than yours." },

      { type: "heading", text: "About the person paying", showIf: function (d) { return d.payer === "Other person"; } },
      { type: "text", id: "payerSurnames", label: "Surnames of the person paying", required: true, showIf: function (d) { return d.payer === "Other person"; } },
      { type: "text", id: "payerGivenNames", label: "Given names of the person paying", required: true, showIf: function (d) { return d.payer === "Other person"; } },
      { type: "tel", id: "payerPhone", label: "Their telephone number", required: true, showIf: function (d) { return d.payer === "Other person"; }, hint: "Include the country dialling code." },
      { type: "email", id: "payerEmail", label: "Their email address", requiredUnless: "payerEmailNA", na: { key: "payerEmailNA" },
        showIf: function (d) { return d.payer === "Other person"; }, hint: "Tick the box below if they do not have one." },
      { type: "select", id: "payerRelationship", label: "Their relationship to you", required: true,
        options: ["Parent", "Spouse", "Child", "Other relative", "Friend", "Other"], showIf: function (d) { return d.payer === "Other person"; } },
      { type: "yesno", id: "payerAddressSame", label: "Is their address the same as your home or mailing address?", required: true,
        showIf: function (d) { return d.payer === "Other person"; } },
      { type: "heading", text: "Their address", showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "text", id: "payerStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "text", id: "payerStreet2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "text", id: "payerCity", label: "City", required: true, maxLength: LIMITS.city, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "text", id: "payerRegion", label: "State or province", requiredUnless: "payerRegionNA", na: { key: "payerRegionNA" }, maxLength: LIMITS.state, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "text", id: "payerPostal", label: "Postal or ZIP code", requiredUnless: "payerPostalNA", na: { key: "payerPostalNA" }, maxLength: LIMITS.postal, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
      { type: "select", id: "payerCountry", label: "Country or region", required: true, options: COUNTRIES, showIf: function (d) { return d.payer === "Other person" && d.payerAddressSame === "No"; } },
    ],
    validate: function (d, e) {
      if (d.arrivalDate && VisaJourneyForm.inPast(d.arrivalDate)) e.arrivalDate = "Your arrival date must be in the future.";
      if (d.usZip && !/^\d{5}(-\d{4})?$/.test(String(d.usZip).trim())) e.usZip = "A US ZIP code looks like 12345 or 12345-1234. Leave it blank if you do not know it.";
      if (d.specificPlans === "Yes" && d.arrivalDate && d.departureDate && new Date(d.departureDate) <= new Date(d.arrivalDate)) {
        e.departureDate = "Your departure date must come after your arrival date.";
      }
      if (d.specificPlans === "No" && d.stayLength && (isNaN(d.stayLength) || Number(d.stayLength) <= 0)) {
        e.stayLength = "Enter a number greater than zero.";
      }
      if (d.payer === "Other person" && d.payerEmail && !VisaJourneyForm.isEmail(d.payerEmail)) {
        e.payerEmail = "Enter a valid email address.";
      }
    },
  });

  function longStay(d) {
    var n = Number(d.stayLength);
    if (!n || isNaN(n)) return false;
    if (d.stayUnit === "Years") return true;
    if (d.stayUnit === "Months") return n > 6;
    if (d.stayUnit === "Weeks") return n > 26;
    return n > 180;
  }

  /* ---------- 5. Travel companions ---------- */
  STEPS.push({
    id: "companions", label: "Travel companions",
    fields: [
      { type: "yesno", id: "travelingWithOthers", required: true, official: true,
        label: "Are there other people travelling with you?",
        help: "Answer yes if you are travelling with family, as part of an organised tour, or as part of a performing group or athletic team. You do not need to list people travelling with you for work with the same employer." },
      { type: "yesno", id: "travelingAsGroup", label: "Are you travelling as part of a group or organisation?", required: true,
        showIf: function (d) { return d.travelingWithOthers === "Yes"; },
        help: "A tour company, a sports team, a choir, a school trip, or a religious group all count. Travelling with your own family does not." },
      { type: "text", id: "groupName", label: "Name of the group you are travelling with", required: true,
        showIf: function (d) { return d.travelingWithOthers === "Yes" && d.travelingAsGroup === "Yes"; },
        help: "The full name of the organisation, as it appears on your booking or letter of invitation." },
      { type: "repeat", key: "companions", prefix: "comp", itemLabel: "Person", addLabel: "Add another person",
        blank: { surnames: "", givenNames: "", relationship: "" },
        showIf: function (d) { return d.travelingWithOthers === "Yes" && d.travelingAsGroup === "No"; },
        heading: "Who is travelling with you?",
        intro: "Add each person separately. Use the names exactly as they appear in their own passports.",
        fields: [
          { type: "text", id: "surnames", label: "Surnames", required: true, letters: true, message: "Enter their surnames." },
          { type: "text", id: "givenNames", label: "Given names", required: true, letters: true, message: "Enter their given names." },
          { type: "select", id: "relationship", label: "Their relationship to you", required: true,
            options: ["Parent", "Spouse", "Child", "Other relative", "Friend", "Business associate", "Other"],
            message: "Select their relationship to you." },
        ] },
    ],
  });

  /* ---------- 6. Past US travel ---------- */
  STEPS.push({
    id: "history", label: "Past US travel",
    fields: [
      { type: "yesno", id: "beenToUs", label: "Have you ever been in the US?", required: true,
        help: "Include every visit, however short, and include stops where you passed through US immigration in transit." },
      { type: "repeat", key: "usVisits", prefix: "visit", itemLabel: "Visit", addLabel: "Add another visit", max: 5,
        blank: { arrivedDate: "", stayLength: "", stayUnit: "" },
        showIf: function (d) { return d.beenToUs === "Yes"; },
        heading: "Your last five US visits",
        intro: "Start with the most recent. If you are unsure about when you visited, provide your best estimate. Five is the maximum the application accepts, so if you have been more often than that, list the five most recent.",
        maxNote: "Five visits is the maximum. List only your five most recent.",
        fields: [
          { type: "date", id: "arrivedDate", label: "Date arrived", required: true, message: "Enter a date, or remove this visit." },
          { type: "number", id: "stayLength", label: "Length of stay", min: 1, unitKey: "stayUnit", unitOptions: STAY_UNITS,
            required: function (d, row) { return row.stayUnit !== "Less than 24 hours"; }, message: "Enter how long you stayed." },
        ] },
      { type: "yesno", id: "heldUsLicense", label: "Do you, or did you ever, hold a US driver's licence?", required: true,
        showIf: function (d) { return d.beenToUs === "Yes"; },
        help: "This includes an expired licence, and a licence from any US state." },
      { type: "text", id: "licenseNumber", label: "Driver's licence number", requiredUnless: "licenseNumberUnknown",
        na: { key: "licenseNumberUnknown", label: "Do not know" },
        showIf: function (d) { return d.beenToUs === "Yes" && d.heldUsLicense === "Yes"; },
        help: "Tick the box below if you no longer have the licence and cannot recall the number." },
      { type: "select", id: "licenseState", label: "State that issued it", required: true, options: US_STATES,
        showIf: function (d) { return d.beenToUs === "Yes" && d.heldUsLicense === "Yes"; } },

      { type: "yesno", id: "hadVisa", label: "Have you ever been issued a US visa?", required: true,
        help: "Any category counts, including a visitor, student, or work visa, even one that expired long ago." },
      { type: "date", id: "priorVisaIssueDate", label: "Date your last visa was issued", required: true,
        showIf: function (d) { return d.hadVisa === "Yes"; }, hint: "If you are unsure, give your best estimate." },
      { type: "text", id: "priorVisaNumber", label: "Visa number", requiredUnless: "priorVisaNumberUnknown", official: true,
        na: { key: "priorVisaNumberUnknown", label: "Do not know" }, showIf: function (d) { return d.hadVisa === "Yes"; },
        help: "The eight-digit number printed in red on the lower right of your visa. If your previous visa was a Border Crossing Card, enter the last twelve digits from the first line of the machine readable zone." },
      { type: "yesno", id: "sameVisaType", label: "Are you applying for the same type of visa?", required: true,
        showIf: function (d) { return d.hadVisa === "Yes"; }, help: "Answer yes if your previous visa was also a B1/B2 visitor visa." },
      { type: "yesno", id: "sameCountryResidence", required: true, showIf: function (d) { return d.hadVisa === "Yes"; },
        label: "Are you applying in the same country where that visa was issued, and is that country your place of principal residence?",
        help: "Both parts must be true to answer yes. If you got your last visa in one country but now live and are applying somewhere else, answer no." },
      { type: "yesno", id: "tenPrinted", label: "Have you been ten-printed?", required: true, official: true,
        showIf: function (d) { return d.hadVisa === "Yes"; },
        help: "Ten-printed means you have provided fingerprints for all of your fingers, as opposed to having provided only two fingerprints." },
      { type: "yesno", id: "visaLostStolen", label: "Has your US visa ever been lost or stolen?", required: true, showIf: function (d) { return d.hadVisa === "Yes"; } },
      { type: "number", id: "visaLostYear", label: "Year it was lost or stolen", required: true, hint: "Just the year, for example 2019.",
        showIf: function (d) { return d.hadVisa === "Yes" && d.visaLostStolen === "Yes"; } },
      { type: "textarea", id: "visaLostExplanation", label: "Explain what happened", required: true,
        showIf: function (d) { return d.hadVisa === "Yes" && d.visaLostStolen === "Yes"; },
        help: "A sentence or two covering where it happened and whether you reported it." },
      { type: "yesno", id: "visaRevoked", label: "Has your US visa ever been cancelled or revoked?", required: true, showIf: function (d) { return d.hadVisa === "Yes"; } },
      { type: "textarea", id: "visaRevokedExplanation", label: "Explain what happened", required: true,
        showIf: function (d) { return d.hadVisa === "Yes" && d.visaRevoked === "Yes"; },
        help: "When it happened and what reason you were given, as far as you know it." },

      { type: "yesno", id: "everRefused", required: true,
        label: "Have you ever been refused a US visa, been refused admission to the United States, or withdrawn your application for admission at the port of entry?",
        help: "All three count separately. Answer yes even if you were later approved, and even if what you received was a 221(g) administrative processing letter. Being turned away at the airport counts, and so does agreeing to withdraw your application rather than be formally refused. This is checked against government records, so an inaccurate answer is treated far more seriously than the refusal itself." },
      { type: "textarea", id: "refusalExplanation", label: "Explain", required: true, rows: 4,
        showIf: function (d) { return d.everRefused === "Yes"; },
        help: "When it happened, where you applied, and what reason you were given." },
      { type: "yesno", id: "immigrantPetition", required: true,
        label: "Has anyone ever filed an immigrant petition on your behalf with US Citizenship and Immigration Services?",
        help: "This usually means a relative or an employer applied for you to live in the United States permanently, on a form such as an I-130 or I-140. Answer yes even if it was years ago, was withdrawn, or never went anywhere. This matters more than most applicants expect, so tell us about it." },
      { type: "textarea", id: "immigrantPetitionExplanation", label: "Explain", required: true, rows: 4,
        showIf: function (d) { return d.immigrantPetition === "Yes"; },
        help: "Who filed it, roughly when, and what happened to it if you know." },
    ],
    validate: function (d, e) {
      if (d.priorVisaIssueDate && VisaJourneyForm.inFuture(d.priorVisaIssueDate)) e.priorVisaIssueDate = "This date cannot be in the future.";
    },
  });

  return { STEPS: STEPS, longStay: longStay, notEmployed: notEmployed };
})();


/* ---------------- SCHEMA, continued ---------------- */

(function () {
  "use strict";
  var S = VJ_SCHEMA.STEPS;
  var payerOther = function (d) { return d.payer === "Other person"; };

  /* ---------- 7. Address and phone ---------- */
  S.push({
    id: "contact", label: "Address and phone",
    fields: [
      { type: "heading", text: "Home address" },
      { type: "text", id: "homeStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street,
        help: "Where you actually live now, which may differ from the address printed in your passport." },
      { type: "text", id: "homeStreet2", label: "Street address, line 2", hint: "Optional. Apartment, flat, or building name.", maxLength: LIMITS.street },
      { type: "text", id: "homeCity", label: "City", required: true, maxLength: LIMITS.city },
      { type: "text", id: "homeRegion", label: "State or province", requiredUnless: "homeRegionNA", na: { key: "homeRegionNA" }, maxLength: LIMITS.state,
        help: "Tick the box if your address does not include one. Many countries do not use them." },
      { type: "text", id: "homePostal", label: "Postal zone or ZIP code", requiredUnless: "homePostalNA", na: { key: "homePostalNA" }, maxLength: LIMITS.postal,
        help: "Tick the box if your address does not use one." },
      { type: "select", id: "homeCountry", label: "Country or region", required: true, options: COUNTRIES },

      { type: "heading", text: "Mailing address" },
      { type: "yesno", id: "mailingSame", label: "Is your mailing address the same as your home address?", required: true,
        help: "Answer no if your post goes somewhere else, such as a PO box or a relative's address." },
      { type: "text", id: "mailStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street, showIf: function (d) { return d.mailingSame === "No"; } },
      { type: "text", id: "mailStreet2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street, showIf: function (d) { return d.mailingSame === "No"; } },
      { type: "text", id: "mailCity", label: "City", required: true, maxLength: LIMITS.city, showIf: function (d) { return d.mailingSame === "No"; } },
      { type: "text", id: "mailRegion", label: "State or province", requiredUnless: "mailRegionNA", na: { key: "mailRegionNA" }, maxLength: LIMITS.state, showIf: function (d) { return d.mailingSame === "No"; } },
      { type: "text", id: "mailPostal", label: "Postal zone or ZIP code", requiredUnless: "mailPostalNA", na: { key: "mailPostalNA" }, maxLength: LIMITS.postal, showIf: function (d) { return d.mailingSame === "No"; } },
      { type: "select", id: "mailCountry", label: "Country or region", required: true, options: COUNTRIES, showIf: function (d) { return d.mailingSame === "No"; } },

      { type: "heading", text: "Phone" },
      { type: "tel", id: "phonePrimary", label: "Primary phone number", required: true, official: true, maxLength: LIMITS.phone,
        help: "You must provide a primary phone number. It should be the number at which you are most likely to be reached, and can be a landline or a mobile. Include your country dialling code." },
      { type: "tel", id: "phoneSecondary", label: "Secondary phone number", requiredUnless: "phoneSecondaryNA", na: { key: "phoneSecondaryNA" }, maxLength: LIMITS.phone,
        help: "If you have an additional landline or mobile number, list it here. Tick the box if you do not have one." },
      { type: "tel", id: "phoneWork", label: "Work phone number", requiredUnless: "phoneWorkNA", na: { key: "phoneWorkNA" }, maxLength: LIMITS.phone,
        help: "Tick the box if you do not have a separate work number." },
      { type: "yesno", id: "otherPhones", label: "Have you used any other phone numbers in the last five years?", required: true,
        help: "Include numbers you no longer use, such as an old mobile or a number from a previous job." },
      { type: "repeat", key: "additionalPhones", prefix: "addphone", itemLabel: "Phone number", addLabel: "Add another number",
        blank: { number: "" }, showIf: function (d) { return d.otherPhones === "Yes"; },
        fields: [{ type: "tel", id: "number", label: "Phone number", required: true, message: "Enter a number, or remove this line." }] },

      { type: "heading", text: "Email" },
      { type: "email", id: "email", label: "Email address", required: true, official: true,
        help: "You must provide an email address. It will be used for correspondence. Provide an address that is secure and to which you have reasonable access." },
      { type: "text", id: "emailConfirm", label: "Confirm email address", required: true,
        help: "Type it again rather than pasting, so a typo in the first field gets caught. This check is ours, not the government's." },
      { type: "yesno", id: "otherEmails", label: "Have you used any other email addresses in the last five years?", required: true,
        help: "Include old work addresses and any account you have stopped using." },
      { type: "repeat", key: "additionalEmails", prefix: "addemail", itemLabel: "Email address", addLabel: "Add another address",
        blank: { email: "" }, showIf: function (d) { return d.otherEmails === "Yes"; },
        fields: [{ type: "email", id: "email", label: "Email address", required: true, message: "Enter an address, or remove this line." }] },

      { type: "heading", text: "Social media" },
      { type: "note", text: "Select each platform you have used in the last five years and enter the username or handle you used on it. Never enter a password. Neither the application nor we will ever ask you for one. If you have used none of the listed platforms, choose None." },
      { type: "repeat", key: "socialMedia", prefix: "sm", itemLabel: "Platform", addLabel: "Add another platform",
        blank: { platform: "", handle: "" }, always: true,
        fields: [
          { type: "select", id: "platform", label: "Social media provider or platform", required: true, options: SOCIAL_PLATFORMS, message: "Select a platform, or choose None." },
          { type: "text", id: "handle", label: "Username or handle", required: true,
            showIf: function (d, row) { return row.platform && row.platform !== "None"; },
            message: "Enter the username or handle you used. Never enter a password." },
        ] },
      { type: "yesno", id: "otherPlatforms", required: true,
        label: "Do you want to list any other websites or apps you have used in the last five years to create or share content?",
        help: "This covers photos, videos, status updates, and similar. It does not include private person-to-person messaging services such as WhatsApp. This question is optional and answering no is a normal answer." },
      { type: "repeat", key: "additionalPlatforms", prefix: "ap", itemLabel: "Site or app", addLabel: "Add another site or app",
        blank: { platform: "", handle: "" }, showIf: function (d) { return d.otherPlatforms === "Yes"; },
        fields: [
          { type: "text", id: "platform", label: "Platform name", required: true, message: "Enter the site or app name." },
          { type: "text", id: "handle", label: "Username or handle", required: true, message: "Enter the username or handle." },
        ] },
    ],
    validate: function (d, e) {
      if (d.email && !VisaJourneyForm.isEmail(d.email)) e.email = "Enter a valid email address.";
      if (d.email && !d.emailConfirm) e.emailConfirm = "Please confirm your email address.";
      else if (d.email && String(d.email).trim().toLowerCase() !== String(d.emailConfirm).trim().toLowerCase()) {
        e.emailConfirm = "The two email addresses do not match.";
      }
      (d.additionalEmails || []).forEach(function (r, i) {
        if (r.email && !VisaJourneyForm.isEmail(r.email)) e["addemail_" + i + "_email"] = "Enter a valid email address.";
      });
    },
  });

  /* ---------- 8. Passport ---------- */
  S.push({
    id: "passport", label: "Passport",
    fields: [
      { type: "note", text: "Enter the details of the travel document you will actually use to travel to the US. It must be valid and unexpired, and sufficient to establish your identity and nationality." },
      { type: "select", id: "passportType", label: "Passport or travel document type", required: true,
        /* The DS-160 offers Regular, Official, Diplomatic, Laissez-Passer and Other.
           Travel document was ours and is not on the government form, so it is gone.
           Anyone travelling on one picks Other and describes it below. */
        options: ["Regular", "Official", "Diplomatic", "Laissez-Passer", "Other"],
        help: "Most applicants hold a regular passport. Official and diplomatic passports are issued for government travel. Choose travel document or other if you hold something that is not a passport." },
      { type: "text", id: "passportTypeOther", label: "Describe your travel document", required: true, showIf: function (d) { return d.passportType === "Other"; } },
      { type: "text", id: "passportNumber", label: "Passport or travel document number", required: true,
        help: "Copy it exactly as printed, including any letters, and without spaces. Check characters that look alike, such as 0 and O, or 1 and I." },
      { type: "text", id: "passportBookNumber", label: "Passport book number", requiredUnless: "passportBookNumberNA", official: true,
        na: { key: "passportBookNumberNA" },
        help: "Commonly called the inventory control number. You may or may not have one, and its location varies by issuing country. If you cannot tell whether your passport has one, contact your passport issuing authority. Tick the box if it does not." },
      { type: "select", id: "passportAuthority", label: "Country or authority that issued it", required: true, options: COUNTRIES,
        help: "The government that issued the document, which may differ from your country of birth." },
      { type: "heading", text: "Where was it issued?" },
      { type: "text", id: "passportIssueCity", label: "City", required: true, maxLength: LIMITS.city,
        help: "Printed on the same page as your photograph, often labelled place of issue. If it names an embassy or consulate abroad, enter that city." },
      /* Not required, matching the government form, which marks it
         "If shown on passport". Do not add required here. */
      { type: "text", id: "passportIssueState", label: "State or province", maxLength: LIMITS.state,
        hint: "Only if it is shown on your passport. Leave it blank if it is not.",
        help: "The government form marks this field \u201cif shown on passport\u201d. Most passports do not print a state or province of issue, and leaving it empty will not hold up your application." },
      { type: "select", id: "passportIssueCountry", label: "Country or region", required: true, options: COUNTRIES,
        help: "Where the document was physically issued. This can differ from the issuing authority, for example a passport issued at your country's embassy abroad." },
      { type: "date", id: "passportIssueDate", label: "Issuance date", required: true },
      { type: "date", id: "passportExpiryDate", label: "Expiration date", requiredUnless: "passportNoExpiry", official: true,
        na: { key: "passportNoExpiry", label: "No expiration" },
        help: "In most cases your passport or travel document must have at least six months of validity beyond the date of your visa application, your arrival in the United States, or both." },
      { type: "warn", head: "Your passport expires soon", showIf: function (d) { return expiringSoon(d); },
        text: "It has less than six months left beyond your intended arrival date. That is usually a problem. Contact us before going further so we can look at whether you need to renew first." },
      { type: "yesno", id: "passportLost", label: "Have you ever lost a passport or had one stolen?", required: true,
        help: "This covers any passport from any country, not only your current one, and however long ago it happened." },
      { type: "repeat", key: "lostPassports", prefix: "lost", itemLabel: "Passport", addLabel: "Add another passport",
        blank: { number: "", numberUnknown: false, country: "", explanation: "" },
        showIf: function (d) { return d.passportLost === "Yes"; },
        intro: "Add each lost or stolen passport separately.",
        fields: [
          { type: "text", id: "number", label: "Passport or travel document number", requiredUnless: "numberUnknown",
            na: { key: "numberUnknown", label: "Do not know" }, message: "Enter the number, or tick do not know." },
          { type: "select", id: "country", label: "Country or authority that issued it", required: true, options: COUNTRIES, message: "Select the issuing country." },
          { type: "textarea", id: "explanation", label: "Explain what happened", required: true, message: "Please explain what happened." },
        ] },
    ],
    validate: function (d, e) {
      if (d.passportIssueDate && VisaJourneyForm.inFuture(d.passportIssueDate)) e.passportIssueDate = "The issue date cannot be in the future.";
      if (!d.passportNoExpiry) {
        if (d.passportExpiryDate && VisaJourneyForm.inPast(d.passportExpiryDate)) {
          e.passportExpiryDate = "This passport has already expired. You will need to renew it before you can apply.";
        }
        if (d.passportIssueDate && d.passportExpiryDate && new Date(d.passportExpiryDate) <= new Date(d.passportIssueDate)) {
          e.passportExpiryDate = "The expiry date must come after the issue date.";
        }
      }
    },
  });

  function expiringSoon(d) {
    if (d.passportNoExpiry || !d.passportExpiryDate) return false;
    var expiry = new Date(d.passportExpiryDate);
    if (isNaN(expiry.getTime())) return false;
    var from = d.arrivalDate ? new Date(d.arrivalDate) : new Date();
    var threshold = new Date(from);
    threshold.setMonth(threshold.getMonth() + 6);
    return expiry < threshold;
  }

  /* ---------- 9. US point of contact ---------- */
  S.push({
    id: "uscontact", label: "US point of contact",
    fields: [
      { type: "note", official: true,
        text: "Your US point of contact can be any individual in the US who knows you and can verify your identity if necessary. If you do not personally know anyone in the US, you may enter the name of the store, company, or organisation you plan to visit during your trip." },
      { type: "note", text: "Fill in at least one of the two below. If you know the organisation but not a specific person's name, tick Do not know on the name and give the organisation instead." },
      { type: "heading", text: "Contact person" },
      { type: "text", id: "contactSurnames", label: "Surnames", requiredUnless: "contactNameUnknown", letters: true },
      { type: "text", id: "contactGivenNames", label: "Given names", requiredUnless: "contactNameUnknown", letters: true,
        na: { key: "contactNameUnknown", label: "Do not know" },
        help: "Tick the box below if you do not know the name of a specific person." },
      { type: "heading", text: "Organisation" },
      { type: "text", id: "contactOrganization", label: "Organisation name", requiredUnless: "contactOrgUnknown",
        na: { key: "contactOrgUnknown", label: "Do not know" },
        help: "The company, hotel, school, or other body. Tick the box if there is no organisation involved, for example if you are staying with family." },
      { type: "select", id: "contactRelationship", label: "Their relationship to you", required: true,
        options: ["Relative", "Spouse", "Friend", "Business associate", "Employer", "School official", "Other"],
        help: "How you know them. If you are staying at a hotel with no personal connection, choose other." },
      { type: "heading", text: "Their address and phone number" },
      { type: "text", id: "contactStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street },
      { type: "text", id: "contactStreet2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street },
      { type: "text", id: "contactCity", label: "City", required: true, maxLength: LIMITS.city },
      { type: "select", id: "contactState", label: "State", required: true, options: US_STATES },
      { type: "text", id: "contactZip", label: "ZIP code", maxLength: LIMITS.postal, help: "Optional if you do not know it. Looks like 55555 or 55555-5555." },
      { type: "tel", id: "contactPhone", label: "Phone number", required: true, maxLength: LIMITS.phone,
        help: "A US number, digits only, for example 5555555555. No country code needed." },
      { type: "email", id: "contactEmail", label: "Email address", requiredUnless: "contactEmailNA", na: { key: "contactEmailNA" },
        help: "Tick the box if you do not have one for them." },
    ],
    validate: function (d, e) {
      if (d.contactNameUnknown && d.contactOrgUnknown) {
        e.contactSurnames = "You need to give either a person or an organisation. Both cannot be unknown.";
        e.contactOrganization = "You need to give either a person or an organisation. Both cannot be unknown.";
      }
      if (d.contactZip && !/^\d{5}(-\d{4})?$/.test(String(d.contactZip).trim())) {
        e.contactZip = "A US ZIP code looks like 12345 or 12345-1234. Leave it blank if you do not know it.";
      }
      if (d.contactEmail && !VisaJourneyForm.isEmail(d.contactEmail)) e.contactEmail = "Enter a valid email address.";
    },
  });

  /* ---------- 10. Family ---------- */
  /* The DS-160 opens a whole Family Information: Spouse page as soon as the
     marital status is a marriage or partnership, and we were skipping it
     entirely. Common law and civil partnership count, not just "Married".
     Feedback, September 2026. */
  var SPOUSE_STATUSES = ["Married", "Common law marriage", "Civil union or domestic partnership"];
  var hasSpouse = function (d) { return SPOUSE_STATUSES.indexOf(d.maritalStatus) !== -1; };
  var spouseElsewhere = function (d) { return hasSpouse(d) && d.spouseAddressType === "Other"; };

  S.push({
    id: "family", label: "Family",
    fields: [
      { type: "note", text: "Give details of your biological parents. If you were adopted, give your adoptive parents instead. If a parent has died, still answer as fully as you can, and use Do not know where you genuinely do not." },
      { type: "heading", text: "Father" },
      { type: "text", id: "fatherSurnames", label: "Surnames", requiredUnless: "fatherSurnamesUnknown", letters: true, na: { key: "fatherSurnamesUnknown", label: "Do not know" } },
      { type: "text", id: "fatherGivenNames", label: "Given names", requiredUnless: "fatherGivenNamesUnknown", letters: true, na: { key: "fatherGivenNamesUnknown", label: "Do not know" } },
      { type: "date", id: "fatherDob", label: "Date of birth", requiredUnless: "fatherDobUnknown", na: { key: "fatherDobUnknown", label: "Do not know" },
        help: "If you are unsure, tick Do not know rather than guessing." },
      { type: "yesno", id: "fatherInUs", label: "Is your father in the US?", required: true, help: "Answer yes if he is currently living in or visiting the United States." },
      { type: "select", id: "fatherStatus", label: "His status in the US", required: true, options: RELATIVE_STATUS,
        showIf: function (d) { return d.fatherInUs === "Yes"; }, help: "Choose Other or I do not know if you are unsure. Do not guess." },
      { type: "heading", text: "Mother" },
      { type: "text", id: "motherSurnames", label: "Surnames", requiredUnless: "motherSurnamesUnknown", letters: true, na: { key: "motherSurnamesUnknown", label: "Do not know" },
        help: "Use her surnames as they are on her own documents, which may be her maiden name." },
      { type: "text", id: "motherGivenNames", label: "Given names", requiredUnless: "motherGivenNamesUnknown", letters: true, na: { key: "motherGivenNamesUnknown", label: "Do not know" } },
      { type: "date", id: "motherDob", label: "Date of birth", requiredUnless: "motherDobUnknown", na: { key: "motherDobUnknown", label: "Do not know" },
        help: "If you are unsure, tick Do not know rather than guessing." },
      { type: "yesno", id: "motherInUs", label: "Is your mother in the US?", required: true },
      { type: "select", id: "motherStatus", label: "Her status in the US", required: true, options: RELATIVE_STATUS, showIf: function (d) { return d.motherInUs === "Yes"; } },
      { type: "yesno", id: "immediateRelatives", required: true,
        label: "Do you have any immediate relatives in the United States, not counting your parents?",
        help: "Immediate relatives here means a spouse, a fianc\u00e9 or fianc\u00e9e, a child, or a sibling. Cousins, aunts, uncles, and grandparents are not immediate relatives for this question. Answer for anyone currently in the US, whatever their status." },
      { type: "yesno", id: "otherRelatives", label: "Do you have any other relatives in the United States?", required: true,
        help: "Anyone not covered above: cousins, aunts, uncles, grandparents, in-laws, and so on." },
      { type: "repeat", key: "relatives", prefix: "rel", itemLabel: "Relative", addLabel: "Add another relative",
        blank: { surnames: "", givenNames: "", relationship: "", status: "" },
        showIf: function (d) { return d.immediateRelatives === "Yes"; },
        intro: "Add each relative separately.",
        fields: [
          { type: "text", id: "surnames", label: "Surnames", required: true, letters: true, message: "Enter their surnames." },
          { type: "text", id: "givenNames", label: "Given names", required: true, letters: true, message: "Enter their given names." },
          { type: "select", id: "relationship", label: "Relationship to you", required: true, options: RELATIVE_RELATIONSHIP, message: "Select their relationship to you." },
          { type: "select", id: "status", label: "Their status in the US", required: true, options: RELATIVE_STATUS, message: "Select their status." },
        ] },

      { type: "heading", text: "Your spouse or partner", showIf: hasSpouse },
      { type: "note", showIf: hasSpouse,
        text: "These questions appear because of the marital status you gave earlier. Answer for your current spouse or partner. If you are separated but not divorced, this is still the person you are married to." },
      { type: "text", id: "spouseSurnames", label: "Spouse's surnames", required: hasSpouse, showIf: hasSpouse,
        letters: true, maxLength: LIMITS.name,
        help: "Include a maiden name if she uses or has used one. Use the spelling on their own documents." },
      { type: "text", id: "spouseGivenNames", label: "Spouse's given names", required: hasSpouse, showIf: hasSpouse,
        letters: true, maxLength: LIMITS.name },
      { type: "date", id: "spouseDob", label: "Spouse's date of birth", required: hasSpouse, showIf: hasSpouse },
      { type: "select", id: "spouseNationality", label: "Spouse's country or region of origin", required: hasSpouse,
        showIf: hasSpouse, options: COUNTRIES,
        help: "Their nationality, which may not be the country they were born in or the one they live in now." },
      { type: "text", id: "spouseCityOfBirth", label: "Spouse's city of birth", showIf: hasSpouse,
        requiredUnless: "spouseCityOfBirthUnknown", na: { key: "spouseCityOfBirthUnknown", label: "Do not know" } },
      { type: "text", id: "spouseStateOfBirth", label: "Spouse's state or province of birth", showIf: hasSpouse,
        maxLength: LIMITS.state, hint: "Leave blank if their birthplace does not use one." },
      { type: "select", id: "spouseCountryOfBirth", label: "Spouse's country or region of birth", showIf: hasSpouse,
        options: COUNTRIES, requiredUnless: "spouseCountryOfBirthUnknown",
        na: { key: "spouseCountryOfBirthUnknown", label: "Do not know" } },
      { type: "select", id: "spouseAddressType", label: "Spouse's address", required: hasSpouse, showIf: hasSpouse,
        options: ["Same as my home address", "Same as my mailing address", "Same as my US contact address", "Do not know", "Other"],
        help: "Pick the closest match. Choose Other only if they live somewhere none of these covers, and you will be asked for the address." },
      { type: "text", id: "spouseStreet1", label: "Street address, line 1", required: spouseElsewhere, showIf: spouseElsewhere, maxLength: LIMITS.street },
      { type: "text", id: "spouseStreet2", label: "Street address, line 2", showIf: spouseElsewhere, hint: "Optional.", maxLength: LIMITS.street },
      { type: "text", id: "spouseCity", label: "City", required: spouseElsewhere, showIf: spouseElsewhere, maxLength: LIMITS.city },
      { type: "text", id: "spouseRegion", label: "State or province", showIf: spouseElsewhere,
        requiredUnless: "spouseRegionNA", na: { key: "spouseRegionNA" }, maxLength: LIMITS.state },
      { type: "text", id: "spousePostal", label: "Postal zone or ZIP code", showIf: spouseElsewhere,
        requiredUnless: "spousePostalNA", na: { key: "spousePostalNA" }, maxLength: LIMITS.postal },
      { type: "select", id: "spouseCountry", label: "Country or region", required: spouseElsewhere, showIf: spouseElsewhere, options: COUNTRIES },
    ],
    validate: function (d, e) {
      ["fatherDob", "motherDob"].forEach(function (k) {
        if (d[k] && VisaJourneyForm.inFuture(d[k])) e[k] = "This date cannot be in the future.";
      });
      if (hasSpouse(d) && d.spouseDob && VisaJourneyForm.inFuture(d.spouseDob)) {
        e.spouseDob = "This date cannot be in the future.";
      }
    },
  });

  /* ---------- 11. Work and study ---------- */
  var noEmp = function (d) { return NO_EMPLOYER_OCCUPATIONS.indexOf(d.occupation) !== -1; };
  var hasEmp = function (d) { return !!d.occupation && !noEmp(d); };
  S.push({
    id: "work", label: "Work and study",
    intro: "This section is about your current employment or education. Previous employers and schooling come later.",
    fields: [
      { type: "select", id: "occupation", label: "Primary occupation", required: true, options: OCCUPATIONS,
        help: "Choose the field you work in, not your job title. If none fit, choose Other. If you are not currently working, choose Not employed, Retired, or Homemaker as applies." },
      { type: "textarea", id: "occupationOther", label: "Explain your occupation", required: true,
        showIf: function (d) { return d.occupation === "OTHER"; }, help: "A short plain description of what you do." },
      /* June audit fix: these answers must not ask for employer details at all. */
      { type: "note", showIf: noEmp, text: "No employer or school details are needed for this answer. Continue to the next step." },
      { type: "text", id: "employerSchoolName", label: "Present employer or school name", required: true, maxLength: LIMITS.employerSchoolName, showIf: hasEmp,
        help: "The full official name, not an abbreviation. If you are self-employed, use your business name, or your own name if you trade under it. The official form allows 75 characters." },
      { type: "heading", text: "Employer or school address", showIf: hasEmp },
      { type: "text", id: "workStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street, showIf: hasEmp },
      { type: "text", id: "workStreet2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street, showIf: hasEmp },
      { type: "text", id: "workCity", label: "City", required: true, maxLength: LIMITS.city, showIf: hasEmp,
        help: "The official form allows only 20 characters here, so abbreviate a long city name if you must." },
      { type: "text", id: "workRegion", label: "State or province", requiredUnless: "workRegionNA", na: { key: "workRegionNA" }, maxLength: LIMITS.state, showIf: hasEmp,
        help: "Tick the box if the address does not use one." },
      { type: "text", id: "workPostal", label: "Postal zone or ZIP code", requiredUnless: "workPostalNA", na: { key: "workPostalNA" }, maxLength: LIMITS.postal, showIf: hasEmp,
        help: "Tick the box if the address does not use one." },
      { type: "tel", id: "workPhone", label: "Phone number", required: true, maxLength: LIMITS.phone, showIf: hasEmp,
        help: "Include the country dialling code. Between 5 and 15 characters." },
      { type: "select", id: "workCountry", label: "Country or region", required: true, options: COUNTRIES, showIf: hasEmp },
      { type: "date", id: "workStartDate", label: "Start date", required: true, showIf: hasEmp, hint: "Approximate is fine if you cannot recall the exact day." },
      { type: "number", id: "monthlyIncome", label: "Monthly income in local currency", requiredUnless: "monthlyIncomeNA", na: { key: "monthlyIncomeNA" }, showIf: hasEmp,
        help: "Only if you are employed. Enter the amount in your own currency, not converted to dollars. Tick the box if you have no income to report." },
      { type: "textarea", id: "duties", label: "Briefly describe your duties", required: true, rows: 4, maxLength: LIMITS.duties, showIf: hasEmp,
        help: "Two or three plain sentences. Avoid internal job titles or company jargon that an outside reader would not follow. Describe what you actually do day to day." },
    ],
    validate: function (d, e) {
      if (hasEmp(d)) {
        if (d.workPhone && String(d.workPhone).trim().length < 5) e.workPhone = "The official form needs at least 5 characters here.";
        if (d.workStartDate && VisaJourneyForm.inFuture(d.workStartDate)) e.workStartDate = "A start date in the future is not valid here.";
        if (!d.monthlyIncomeNA && d.monthlyIncome && (isNaN(d.monthlyIncome) || Number(d.monthlyIncome) < 0)) {
          e.monthlyIncome = "Enter a number, or tick does not apply.";
        }
      }
    },
  });

  /* ---------- 12. Previous work and study ---------- */
  var addressFields = function (prefix) {
    return [
      { type: "text", id: "street1", label: "Street address, line 1", required: true, maxLength: LIMITS.street, message: "Enter the street address." },
      { type: "text", id: "street2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street },
      { type: "text", id: "city", label: "City", required: true, maxLength: LIMITS.city, message: "Enter the city." },
      { type: "text", id: "state", label: "State or province", requiredUnless: "stateNA", na: { key: "stateNA" }, maxLength: LIMITS.state, message: "Enter it, or tick does not apply." },
      { type: "text", id: "postal", label: "Postal zone or ZIP code", requiredUnless: "postalNA", na: { key: "postalNA" }, maxLength: LIMITS.postal, message: "Enter it, or tick does not apply." },
      { type: "select", id: "country", label: "Country or region", required: true, options: COUNTRIES, message: "Select a country." },
    ];
  };

  S.push({
    id: "prevwork", label: "Previous work and study",
    intro: "Give your employment information for the last five years that you were employed, if applicable.",
    fields: [
      { type: "yesno", id: "prevEmployed", label: "Were you previously employed?", required: true,
        help: "This is about jobs before your current one. Answer yes if you have held any job in the last five years other than the one you entered on the previous step." },
      { type: "repeat", key: "prevEmployers", prefix: "prevemp", itemLabel: "Employer", addLabel: "Add another employer",
        blank: { name: "", street1: "", street2: "", city: "", state: "", stateNA: false, postal: "", postalNA: false,
                 country: "", phone: "", jobTitle: "", supSurname: "", supSurnameUnknown: false,
                 supGivenNames: "", supGivenNamesUnknown: false, dateFrom: "", dateTo: "", duties: "" },
        showIf: function (d) { return d.prevEmployed === "Yes"; },
        fields: [{ type: "text", id: "name", label: "Employer name", required: true, maxLength: LIMITS.employerSchoolName, message: "Enter the employer name." }]
          .concat(addressFields())
          .concat([
            { type: "tel", id: "phone", label: "Telephone number", required: true, maxLength: LIMITS.phone, message: "Enter a phone number." },
            { type: "text", id: "jobTitle", label: "Job title", required: true, message: "Enter your job title." },
            { type: "text", id: "supSurname", label: "Supervisor's surname", requiredUnless: "supSurnameUnknown", na: { key: "supSurnameUnknown", label: "Do not know" }, message: "Enter it, or tick do not know." },
            { type: "text", id: "supGivenNames", label: "Supervisor's given names", requiredUnless: "supGivenNamesUnknown", na: { key: "supGivenNamesUnknown", label: "Do not know" }, message: "Enter it, or tick do not know." },
            { type: "date", id: "dateFrom", label: "Employment date from", required: true, hint: "Approximate is fine.", message: "Enter a start date." },
            { type: "date", id: "dateTo", label: "Employment date to", required: true, message: "Enter an end date." },
            { type: "textarea", id: "duties", label: "Briefly describe your duties", required: true, maxLength: LIMITS.duties,
              hint: "Two or three plain sentences describing what you actually did.", message: "Describe what you did there." },
          ]) },
      { type: "yesno", id: "attendedSchool", required: true, official: true,
        label: "Have you attended any educational institutions at a secondary level or above?",
        help: "You must answer yes if you have ever attended, for any length of time, a high school or secondary school, or its equivalent in your country, or a college, university, graduate school, doctoral programme, or vocational programme." },
      { type: "repeat", key: "schools", prefix: "school", itemLabel: "Institution", addLabel: "Add another institution",
        blank: { name: "", street1: "", street2: "", city: "", state: "", stateNA: false, postal: "", postalNA: false,
                 country: "", courseOfStudy: "", dateFrom: "", dateTo: "" },
        showIf: function (d) { return d.attendedSchool === "Yes"; },
        fields: [{ type: "text", id: "name", label: "Name of institution", required: true, maxLength: LIMITS.employerSchoolName, message: "Enter the institution name." }]
          .concat(addressFields())
          .concat([
            { type: "text", id: "courseOfStudy", label: "Course of study", required: true,
              hint: "For middle school, junior high, or high school, enter Academic or Vocational. For everything above that, enter your major or concentration.",
              message: "Enter your course of study." },
            { type: "date", id: "dateFrom", label: "Date of attendance from", required: true, message: "Enter a start date." },
            { type: "date", id: "dateTo", label: "Date of attendance to", required: true, message: "Enter an end date." },
          ]) },
    ],
    validate: function (d, e) {
      [["prevEmployers", "prevemp"], ["schools", "school"]].forEach(function (pair) {
        (d[pair[0]] || []).forEach(function (r, i) {
          if (r.dateFrom && r.dateTo && new Date(r.dateTo) <= new Date(r.dateFrom)) {
            e[pair[1] + "_" + i + "_dateTo"] = "The end date must come after the start date.";
          }
        });
      });
    },
  });

  /* ---------- 13. Additional background ---------- */
  S.push({
    id: "additional", label: "Additional background",
    fields: [
      { type: "yesno", id: "clanTribe", label: "Do you belong to a clan or tribe?", required: true,
        help: "Answer yes if you identify with a clan or tribal group. This is a neutral question and a yes answer carries no penalty." },
      { type: "text", id: "clanTribeName", label: "Clan or tribe name", required: true, showIf: function (d) { return d.clanTribe === "Yes"; } },
      { type: "repeat", key: "languages", prefix: "lang", itemLabel: "Language", addLabel: "Add another language",
        blank: { language: "" }, always: true,
        heading: "Languages you speak",
        intro: "List every language you speak, including your first language. Conversational ability counts, you do not need to be fluent.",
        fields: [{ type: "text", id: "language", label: "Language", required: true, message: "Enter a language, or remove this line." }] },
      { type: "yesno", id: "traveledCountries", label: "Have you travelled to any countries or regions within the last five years?", required: true,
        help: "List every country you have entered, including short trips, holidays, and layovers where you left the airport. Do not include countries you only flew over." },
      { type: "repeat", key: "countriesVisited", prefix: "visited", itemLabel: "Country", addLabel: "Add another country",
        blank: { country: "" }, showIf: function (d) { return d.traveledCountries === "Yes"; },
        fields: [{ type: "select", id: "country", label: "Country or region", required: true, options: COUNTRIES, message: "Select a country, or remove this line." }] },
      { type: "yesno", id: "organizations", required: true,
        label: "Have you belonged to, contributed to, or worked for any professional, social, or charitable organisation?",
        help: "This is broader than it sounds. It covers professional bodies, trade unions, alumni associations, sports clubs, religious organisations, and charities you have donated to or volunteered with." },
      { type: "repeat", key: "orgList", prefix: "org", itemLabel: "Organisation", addLabel: "Add another organisation",
        blank: { name: "" }, showIf: function (d) { return d.organizations === "Yes"; },
        fields: [{ type: "text", id: "name", label: "Organisation name", required: true, message: "Enter the organisation, or remove this line." }] },
      { type: "yesno", id: "specializedSkills", required: true,
        label: "Do you have any specialised skills or training, such as firearms, explosives, nuclear, biological, or chemical experience?",
        help: "Answer honestly. Plenty of ordinary jobs and hobbies produce a yes here: hunting, farming, mining, demolition, laboratory work, nursing, and military or police service among them. A yes answer is common and is not a bar to a visa. Concealing it is a much more serious problem than having the training." },
      { type: "textarea", id: "specializedSkillsExplanation", label: "Explain", required: true, rows: 4,
        showIf: function (d) { return d.specializedSkills === "Yes"; },
        help: "What the training or experience is, where you got it, and what you use it for." },
      { type: "yesno", id: "militaryService", label: "Have you ever served in the military?", required: true,
        help: "Any country's armed forces, including compulsory national service." },
      { type: "repeat", key: "militaryRecords", prefix: "mil", itemLabel: "Service", addLabel: "Add another period of service",
        blank: { country: "", branch: "", rank: "", specialty: "", dateFrom: "", dateTo: "" },
        showIf: function (d) { return d.militaryService === "Yes"; },
        fields: [
          { type: "select", id: "country", label: "Name of country or region", required: true, options: COUNTRIES,
            hint: "Select the current name of the country where you performed military service.", message: "Select the country." },
          { type: "text", id: "branch", label: "Branch of service", required: true, hint: "For example army, navy, air force.", message: "Enter the branch of service." },
          { type: "text", id: "rank", label: "Rank or position", required: true, message: "Enter your rank or position." },
          { type: "text", id: "specialty", label: "Military speciality", required: true,
            hint: "Your trade or role, such as infantry, signals, logistics, or medical.", message: "Enter your speciality." },
          { type: "date", id: "dateFrom", label: "Date of service from", required: true, message: "Enter a start date." },
          { type: "date", id: "dateTo", label: "Date of service to", required: true, message: "Enter an end date." },
        ] },
      { type: "yesno", id: "paramilitary", required: true,
        label: "Have you ever served in, been a member of, or been involved with a paramilitary unit, vigilante unit, rebel group, guerrilla group, or insurgent organisation?",
        help: "This covers any country and any period of your life. If you are unsure whether something you were involved in counts, tell us about it rather than deciding on your own." },
      { type: "textarea", id: "paramilitaryExplanation", label: "Explain", required: true, rows: 4,
        showIf: function (d) { return d.paramilitary === "Yes"; } },
    ],
  });

  /* ---------- 14 to 18. Security and background, five parts ---------- */
  SECURITY_PARTS.forEach(function (part) {
    var fields = [
      { type: "note", official: true, text: SECURITY_NOTE },
      { type: "note", text: "Answer every question accurately. If you are unsure whether something applies to you, answer as best you can and tell us about it, so we can go through it with you before anything is submitted." },
    ];
    part.questions.forEach(function (q) {
      fields.push({ type: "yesno", id: q.id, label: q.text, help: q.help, official: q.official, required: true });
      fields.push({ type: "textarea", id: q.id + "_explain", label: "Explain", required: true, rows: 4,
        showIf: (function (id) { return function (d) { return d[id] === "Yes"; }; })(q.id),
        help: "Dates, place, and outcome. Be factual and brief. We will follow up with you about this before anything is submitted." });
    });
    S.push({ id: part.id, label: part.label, fields: fields });
  });

  /* ---------- 19. Where you will apply ---------- */
  S.push({
    id: "location", label: "Where you will apply",
    intro: "Tell us where you intend to attend your interview. This is usually the US embassy or consulate in the country where you live.",
    fields: [
      { type: "text", id: "applyLocation", label: "Location where you will submit your application", required: true,
        help: "Enter the city and country of the US embassy or consulate, for example Yaounde, Cameroon. If you are not sure which post covers you, put your nearest large city and we will confirm it with you." },
      { type: "note", text: "Wait times and appointment availability vary a lot between posts. We will check this before anything is submitted." },
    ],
  });

  /* ---------- 20. Who helped you ---------- */
  S.push({
    id: "preparer", label: "Who helped you",
    fields: [
      { type: "note", text: "The DS-160 asks whether anyone assisted you in filling out the application. If you are using our service, the honest answer is yes, and you should name us. Saying no would be a false statement on an application signed under penalty of perjury. Being helped is entirely permitted. Concealing it is not." },
      { type: "yesno", id: "preparerUsed", label: "Did anyone assist you in filling out this application?", required: true },
      { type: "heading", text: "About who helped you", showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerSurnames", label: "Surnames", requiredUnless: "preparerNameNA", letters: true, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerGivenNames", label: "Given names", requiredUnless: "preparerNameNA", letters: true, na: { key: "preparerNameNA" },
        showIf: function (d) { return d.preparerUsed === "Yes"; }, help: "Tick the box if an organisation helped you rather than a named individual." },
      { type: "text", id: "preparerOrganization", label: "Organisation name", requiredUnless: "preparerOrgNA", na: { key: "preparerOrgNA" },
        showIf: function (d) { return d.preparerUsed === "Yes"; }, help: "If our service helped you, enter Visa Journey USA here." },
      { type: "heading", text: "Their address", showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerStreet1", label: "Street address, line 1", required: true, maxLength: LIMITS.street, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerStreet2", label: "Street address, line 2", hint: "Optional.", maxLength: LIMITS.street, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerCity", label: "City", required: true, maxLength: LIMITS.city, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerRegion", label: "State or province", requiredUnless: "preparerRegionNA", na: { key: "preparerRegionNA" }, maxLength: LIMITS.state, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerPostal", label: "Postal zone or ZIP code", requiredUnless: "preparerPostalNA", na: { key: "preparerPostalNA" }, maxLength: LIMITS.postal, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "select", id: "preparerCountry", label: "Country or region", required: true, options: COUNTRIES, showIf: function (d) { return d.preparerUsed === "Yes"; } },
      { type: "text", id: "preparerRelationship", label: "Their relationship to you", required: true, showIf: function (d) { return d.preparerUsed === "Yes"; },
        help: "For example: visa preparation service, relative, friend, lawyer." },
    ],
    validate: function (d, e) {
      if (d.preparerUsed === "Yes" && d.preparerNameNA && d.preparerOrgNA) {
        e.preparerSurnames = "Give either a person or an organisation. Both cannot be marked as not applicable.";
        e.preparerOrganization = "Give either a person or an organisation. Both cannot be marked as not applicable.";
      }
    },
  });

  /* ---------- 21. Photo ----------
     Added September 2026. The DS-160 has its own photo upload page and we had
     nothing between the last question and the review, so applicants reached the
     end without knowing a photo was needed at all. */
  S.push({
    id: "photo", label: "Photo",
    intro: "The Department of State needs a recent passport-style photograph with your application. We check it here so a problem does not surface at the consulate.",
    fields: [
      { type: "note", official: true, text: "The photograph must have been taken within the last six months, show a full front view of your face against a plain white or off-white background, with a neutral expression and both eyes open. Head coverings are allowed only for religious reasons, and glasses are not allowed at all." },
      { type: "file", id: "photo", label: "Your photograph", required: true, accept: "image/jpeg",
        hint: "JPEG, square, between 600 and 1200 pixels on each side, and under 240 KB.",
        message: "Choose a photograph to continue.",
        help: "Those four rules come from the official form and are checked as soon as you choose a file. Most phone photos are far larger than 240 KB, so you will usually need to crop it square and export it at a lower quality first. If you cannot get it to fit, send it to us and we will sort it out with you." },
      { type: "note", text: "Photo booths and most pharmacies will produce a compliant digital file if you tell them it is for a US visa. It is worth the small cost: a rejected photograph means another appointment." },
    ],
  });

  /* ---------- 22. Review ---------- */
  S.push({
    id: "review", label: "Review",
    intro: "Check your answers before sending. Go back to any step to make changes.",
    isReview: true,
    fields: [
      { type: "consent", id: "certify",
        text: "I confirm that the answers above are true and correct to the best of my knowledge.",
        message: "You must confirm your answers are true and correct." },
    ],
  });
})();


/* ---------------------------------------------------------------------
   RENDERER
   Generic. Reads the schema above and draws it. You should not need to edit
   this file to change questions, wording, or validation rules.
   --------------------------------------------------------------------- */

(function (VJ) {
  "use strict";

  var el = VJ.el, clear = VJ.clear, isBlank = VJ.isBlank;

  function buildEmpty() {
    var d = {};
    VJ_SCHEMA.STEPS.forEach(function (step) {
      (step.fields || []).forEach(function (f) {
        if (f.type === "repeat") { d[f.key] = [shallow(f.blank)]; return; }
        if (f.type === "note" || f.type === "warn" || f.type === "heading") return;
        if (f.type === "consent") { d[f.id] = false; return; }
        if (f.type === "ssn") { d[f.id + "1"] = ""; d[f.id + "2"] = ""; d[f.id + "3"] = ""; }
        else d[f.id] = "";
        if (f.na) d[f.na.key] = false;
        if (f.unitKey) d[f.unitKey] = (f.unitOptions && f.unitOptions[0]) || "";
      });
    });
    return d;
  }
  function shallow(o) { var c = {}; Object.keys(o || {}).forEach(function (k) { c[k] = o[k]; }); return c; }

  function visible(f, data, row) {
    if (!f.showIf) return true;
    try { return !!f.showIf(data, row); } catch (err) { return true; }
  }
  /* A fingerprint of what the current step should be showing: which fields are
     visible and which are required. Typing into a free-text field almost never
     changes it, which is how we know a repaint is unnecessary. Repainting when
     nothing has changed is what broke Tab and swallowed the first click on the
     next field, because the node being moved into was destroyed mid-gesture. */
  function stepSignature(step, data) {
    if (!step) return "";
    var parts = [];
    (step.fields || []).forEach(function (f) {
      parts.push(f.id || f.key || f.type, visible(f, data) ? 1 : 0, isRequired(f, data) ? 1 : 0);
      if (f.type === "repeat") {
        (data[f.key] || []).forEach(function (row, i) {
          (f.fields || []).forEach(function (sub) {
            parts.push(i, sub.id, visible(sub, data, row) ? 1 : 0, isRequired(sub, data, row) ? 1 : 0);
          });
        });
      }
    });
    return parts.join("|");
  }

  /* Clear a field's error styling in place. Used instead of a repaint so the
     click or Tab that triggered it is not interrupted. */
  function clearFieldErrorInDom(container, domId) {
    if (!container || !domId) return;
    var node = container.querySelector("#" + String(domId).replace(/([^\w-])/g, "\\$1"));
    if (!node) return;
    var wrap = node.closest ? node.closest(".vj-field") : null;
    if (!wrap) return;
    Array.prototype.forEach.call(wrap.querySelectorAll(".vj-bad"), function (n) {
      n.classList.remove("vj-bad");
    });
    var msg = wrap.querySelector(".vj-err");
    if (msg && msg.parentNode) msg.parentNode.removeChild(msg);
  }

  function isRequired(f, data, row) {
    if (f.requiredUnless) return !(row ? row[f.requiredUnless] : data[f.requiredUnless]);
    if (typeof f.required === "function") return !!f.required(data, row);
    return !!f.required;
  }

  /* ---------------- validation ---------------- */

  /* Name fields on the DS-160 take English letters only. Spaces, hyphens,
     apostrophes and full stops are allowed because real names contain them.
     Digits are not: they were getting through, which is what the September 2026
     feedback caught. Accented letters are deliberately not accepted here, since
     the official form wants names transliterated. The native-alphabet field is
     separate and is not marked letters. */
  var LETTERS_ONLY = /^[A-Za-z][A-Za-z '.\u2019-]*$/;
  var LETTERS_MESSAGE = "Use letters only, exactly as shown in your passport. Numbers are not accepted here.";

  function validateStep(step, data) {
    var e = {};
    (step.fields || []).forEach(function (f) {
      if (f.type === "note" || f.type === "warn" || f.type === "heading") return;
      if (!visible(f, data)) return;

      if (f.type === "repeat") {
        if (!f.always && !visible(f, data)) return;
        (data[f.key] || []).forEach(function (row, i) {
          f.fields.forEach(function (sub) {
            if (!visible(sub, data, row)) return;
            if (isRequired(sub, data, row) && isBlank(row[sub.id])) {
              e[f.prefix + "_" + i + "_" + sub.id] = sub.message || "This field is required.";
            } else if (sub.letters && !isBlank(row[sub.id]) && !LETTERS_ONLY.test(String(row[sub.id]))) {
              e[f.prefix + "_" + i + "_" + sub.id] = sub.lettersMessage || LETTERS_MESSAGE;
            }
          });
        });
        return;
      }

      if (f.type === "consent") {
        if (!data[f.id]) e[f.id] = f.message || "Please confirm this to continue.";
        return;
      }

      if (f.type === "ssn") {
        if (!data[f.na.key]) {
          if (isBlank(data[f.id + "1"]) || isBlank(data[f.id + "2"]) || isBlank(data[f.id + "3"])) {
            e[f.id + "1"] = "Enter all three parts of the number, or tick does not apply.";
          } else if (!/^\d{3}$/.test(data[f.id + "1"]) || !/^\d{2}$/.test(data[f.id + "2"]) || !/^\d{4}$/.test(data[f.id + "3"])) {
            e[f.id + "1"] = "A Social Security number is three digits, then two, then four.";
          }
        }
        return;
      }

      if (isRequired(f, data) && isBlank(data[f.id])) {
        e[f.id] = f.message || "This field is required.";
      }
      if (f.maxLength && data[f.id] && String(data[f.id]).length > f.maxLength) {
        e[f.id] = "The official form allows only " + f.maxLength + " characters here.";
      }
      if (f.letters && !isBlank(data[f.id]) && !LETTERS_ONLY.test(String(data[f.id]))) {
        e[f.id] = f.lettersMessage || LETTERS_MESSAGE;
      }
    });
    if (step.validate) step.validate(data, e);
    return e;
  }

  /* ---------------- field rendering ---------------- */

  function helpBlock(f) {
    if (!f.help) return null;
    var body = [el("p", { text: f.help })];
    if (f.official) body.push(el("p", { class: "vj-small vj-attrib", text: "This guidance comes from the Department of State's own DS-160 help text." }));
    return el("div", { class: "vj-help", hidden: true }, body);
  }

  function labelRow(id, label, f) {
    var lab = el("label", { class: "vj-label", "for": id }, [label]);
    if (f && f.__required) lab.appendChild(el("span", { class: "vj-req", text: "*", "aria-hidden": "true" }));
    var row = el("div", { class: "vj-labelrow" }, [lab]);
    if (f && f.help) {
      var help = helpBlock(f);
      var btn = el("button", {
        type: "button", class: "vj-help-btn", "aria-expanded": "false",
        "aria-label": "Help with " + label, text: "?",
        onclick: function () {
          var open = btn.getAttribute("aria-expanded") === "true";
          btn.setAttribute("aria-expanded", open ? "false" : "true");
          help.hidden = open;
        },
      });
      row.appendChild(btn);
      return { row: row, help: help };
    }
    return { row: row, help: null };
  }

  /* DS-160 photo rules: JPEG, square, between 600 and 1200 pixels a side, and
     under 240 KB. We check all four here rather than letting someone find out
     at the consulate. */
  var PHOTO = { minPx: 600, maxPx: 1200, maxBytes: 240 * 1024 };

  function describePhoto(data, f) {
    var w = data[f.id + "Width"], h = data[f.id + "Height"], b = data[f.id + "Bytes"];
    if (!w || !h) return "";
    return w + " by " + h + " pixels, " + Math.round((b || 0) / 1024) + " KB.";
  }

  function readPhotoFile(file, f, ctx) {
    function fail(message) {
      var wipe = {};
      wipe[f.id] = ""; wipe[f.id + "Name"] = ""; wipe[f.id + "Bytes"] = "";
      wipe[f.id + "Width"] = ""; wipe[f.id + "Height"] = "";
      ctx.setMany(wipe);
      ctx.setError(f.id, message);
    }

    if (!/^image\/jpe?g$/i.test(file.type)) {
      return fail("The photograph must be a JPEG. Save or export it as a .jpg and try again.");
    }
    if (file.size > PHOTO.maxBytes) {
      return fail("That file is " + Math.round(file.size / 1024) + " KB. The official limit is 240 KB, so it needs to be saved at a lower quality.");
    }

    var reader = new FileReader();
    reader.onerror = function () { fail("That file could not be read. Try choosing it again."); };
    reader.onload = function () {
      var url = String(reader.result || "");
      var img = new Image();
      img.onerror = function () { fail("That file is not a readable image."); };
      img.onload = function () {
        var w = img.naturalWidth, h = img.naturalHeight;
        if (w !== h) {
          return fail("The photograph must be square. Yours is " + w + " by " + h + " pixels, so it needs cropping.");
        }
        if (w < PHOTO.minPx || w > PHOTO.maxPx) {
          return fail("The photograph must be between 600 and 1200 pixels on each side. Yours is " + w + " by " + h + ".");
        }
        var next = {};
        next[f.id] = url;
        next[f.id + "Name"] = file.name;
        next[f.id + "Bytes"] = file.size;
        next[f.id + "Width"] = w;
        next[f.id + "Height"] = h;
        ctx.setMany(next);
      };
      img.src = url;
    };
    reader.readAsDataURL(file);
  }

  function renderField(ctx, f, opts) {
    opts = opts || {};
    var data = ctx.data;
    var row = opts.row || null;
    var key = opts.errKey || f.id;
    var value = row ? row[f.id] : data[f.id];
    var err = ctx.errors[key];
    var domId = opts.domId || f.domId || f.id;
    var setVal = opts.set || function (v) { ctx.set(f.id, v); };

    if (f.type === "heading") return el("p", { class: "vj-sub", text: f.text });
    if (f.type === "note") {
      var kids = [];
      if (f.head) kids.push(el("p", { class: "vj-warnhead", text: f.head }));
      kids.push(el("p", { text: f.text }));
      if (f.official) kids.push(el("p", { class: "vj-small vj-attrib", text: "This guidance comes from the Department of State's own DS-160 help text." }));
      return el("div", { class: "vj-note" }, kids);
    }
    if (f.type === "warn") {
      return el("div", { class: "vj-warnbox" }, [
        f.head ? el("p", { class: "vj-warnhead", text: f.head }) : null,
        el("p", { text: f.text }),
      ]);
    }

    if (f.type === "consent") {
      var cb = el("input", { type: "checkbox", onchange: function () { setVal(cb.checked); } });
      cb.checked = !!value;
      var wrap = el("div", {}, [
        el("label", { class: "vj-consent", "for": domId }, [cb, el("span", { text: f.text })]),
        err ? el("p", { class: "vj-err", role: "alert", text: err }) : null,
      ]);
      cb.id = domId;
      return wrap;
    }

    var required = isRequired(f, data, row);
    var marked = shallow(f); marked.__required = required; marked.help = f.help; marked.official = f.official;
    var lr = labelRow(domId, f.label, marked);
    var field = el("div", { class: "vj-field" }, [lr.row]);
    if (lr.help) field.appendChild(lr.help);
    if (f.hint) field.appendChild(el("p", { class: "vj-hint", text: f.hint }));

    var disabled = f.na ? !!(row ? row[f.na.key] : data[f.na.key]) : false;
    var input;

    if (f.type === "yesno") {
      var group = el("div", { class: "vj-yesno" });
      ["Yes", "No"].forEach(function (o) {
        var radio = el("input", { type: "radio", name: domId, value: o, onchange: function () { setVal(o); } });
        radio.checked = value === o;
        var lbl = el("label", { class: value === o ? "vj-on" : "" }, [radio, o]);
        group.appendChild(lbl);
      });
      field.appendChild(group);
    } else if (f.type === "ssn") {
      var inline = el("div", { class: "vj-inline" });
      [["1", 3, "000", "vj-ssn1"], ["2", 2, "00", "vj-ssn2"], ["3", 4, "0000", "vj-ssn3"]].forEach(function (p, i) {
        if (i > 0) inline.appendChild(el("span", { text: "-", "aria-hidden": "true" }));
        var box = el("input", {
          type: "text", inputmode: "numeric", maxlength: p[1], placeholder: p[2],
          id: f.id + p[0], "aria-label": "Social Security number part " + (i + 1) + " of 3",
          class: "vj-input " + p[3] + (err ? " vj-bad" : ""),
          oninput: function () {
            var digits = box.value.replace(/\D/g, "");
            if (box.value !== digits) box.value = digits;
            ctx.setSmart(f.id + p[0], digits, opts, f.id + p[0]);
          },
          onchange: function () {
            ctx.setSmart(f.id + p[0], box.value.replace(/\D/g, ""), opts, f.id + p[0]);
          },
        });
        box.value = data[f.id + p[0]] || "";
        box.disabled = disabled;
        inline.appendChild(box);
      });
      field.appendChild(inline);
    } else if (f.type === "select") {
      input = el("select", { id: domId, class: "vj-select" + (err ? " vj-bad" : ""), onchange: function () { setVal(input.value); } });
      /* Product rule: the leading option is always selectable and clears the
         field. Nothing is ever rendered greyed out and unpickable. */
      input.appendChild(el("option", { value: "", text: "Select one" }));
      (f.options || []).forEach(function (o) { input.appendChild(el("option", { value: o, text: o })); });
      input.value = value || "";
      input.disabled = disabled;
      field.appendChild(input);
    } else if (f.type === "file") {
      /* Photo upload. The image is read in the browser, measured, and held in
         state as a data URL so it travels with the rest of the answers. It is
         never written to localStorage, same as every other answer here. */
      var picker = el("input", {
        id: domId, type: "file", class: "vj-file-input" + (err ? " vj-bad" : ""),
        accept: f.accept || "image/jpeg",
      });
      picker.disabled = disabled;
      picker.addEventListener("change", function () {
        var file = picker.files && picker.files[0];
        if (file) readPhotoFile(file, f, ctx);
      });

      var fileBox = el("div", { class: "vj-file" }, [picker]);

      if (value) {
        fileBox.appendChild(el("div", { class: "vj-file-preview" }, [
          el("img", { src: value, alt: "The photograph you selected" }),
          el("div", { class: "vj-file-meta" }, [
            el("p", { class: "vj-file-name", text: data[f.id + "Name"] || "Your photograph" }),
            el("p", { class: "vj-small", text: describePhoto(data, f) }),
            el("button", {
              type: "button", class: "vj-btn vj-ghost vj-file-remove", text: "Remove and choose another",
              onclick: function () {
                var wipe = {};
                wipe[f.id] = ""; wipe[f.id + "Name"] = ""; wipe[f.id + "Bytes"] = "";
                wipe[f.id + "Width"] = ""; wipe[f.id + "Height"] = "";
                ctx.setMany(wipe);
              },
            }),
          ]),
        ]));
      }

      input = picker;
      field.appendChild(fileBox);
    } else if (f.type === "textarea") {
      input = el("textarea", {
        id: domId, rows: f.rows || 3, class: "vj-textarea" + (err ? " vj-bad" : ""),
        maxlength: f.maxLength || null,
        oninput: function () { ctx.setSmart(f.id, input.value, opts, domId); },
        onchange: function () { ctx.setSmart(f.id, input.value, opts, domId); },
      });
      input.value = value || "";
      input.disabled = disabled;
      field.appendChild(input);
    } else {
      var type = f.type === "number" ? "number" : f.type === "date" ? "date"
               : f.type === "tel" ? "tel" : f.type === "email" ? "email" : "text";
      input = el("input", {
        id: domId, type: type, class: "vj-input" + (err ? " vj-bad" : ""),
        maxlength: f.maxLength || null, min: f.min || null,
        /* Both events go through setSmart, which repaints only when the step's
           branching actually changes. A date field fires input on every segment,
           so an unconditional repaint here closed the picker mid-entry. */
        oninput: function () { ctx.setSmart(f.id, input.value, opts, domId); },
        onchange: function () { ctx.setSmart(f.id, input.value, opts, domId); },
      });
      input.value = value == null ? "" : value;
      input.disabled = disabled;
      if (f.unitKey) {
        var unit = el("select", { class: "vj-select", "aria-label": "Unit", onchange: function () {
          if (row) ctx.setRow(opts.listKey, opts.index, f.unitKey, unit.value);
          else ctx.set(f.unitKey, unit.value);
        } });
        unit.appendChild(el("option", { value: "", text: "Select one" }));
        (f.unitOptions || []).forEach(function (o) { unit.appendChild(el("option", { value: o, text: o })); });
        unit.value = (row ? row[f.unitKey] : data[f.unitKey]) || "";
        field.appendChild(el("div", { class: "vj-two" }, [input, unit]));
      } else {
        field.appendChild(input);
      }
    }

    if (err) field.appendChild(el("p", { class: "vj-err", role: "alert", text: err }));
    if (input) input.setAttribute("aria-invalid", err ? "true" : "false");

    if (f.na) {
      var naId = domId + "__na";
      var na = el("input", { type: "checkbox", id: naId, onchange: function () {
        if (row) ctx.setRow(opts.listKey, opts.index, f.na.key, na.checked);
        else ctx.set(f.na.key, na.checked);
      } });
      na.checked = disabled;
      field.appendChild(el("label", { class: "vj-check", "for": naId }, [na, el("span", { text: f.na.label || "Does not apply" })]));
    }

    return field;
  }

  function renderRepeat(ctx, f) {
    var rows = ctx.data[f.key] || [];
    var box = el("div", { class: "vj-group" });
    if (f.heading) box.appendChild(el("p", { class: "vj-sub", text: f.heading }));
    if (f.intro) box.appendChild(el("p", { class: "vj-hint", text: f.intro }));

    rows.forEach(function (row, i) {
      var rowEl = el("div", { class: "vj-row" });
      var head = el("div", { class: "vj-rowhead" }, [el("span", { text: f.itemLabel + " " + (i + 1) })]);
      if (rows.length > 1) {
        head.appendChild(el("button", { type: "button", class: "vj-remove", text: "Remove",
          onclick: function () { ctx.removeRow(f.key, i); } }));
      }
      rowEl.appendChild(head);
      f.fields.forEach(function (sub) {
        if (!visible(sub, ctx.data, row)) return;
        rowEl.appendChild(renderField(ctx, sub, {
          row: row, index: i, listKey: f.key,
          domId: f.prefix + "_" + i + "_" + sub.id,
          errKey: f.prefix + "_" + i + "_" + sub.id,
          set: function (v) { ctx.setRow(f.key, i, sub.id, v); },
        }));
      });
      box.appendChild(rowEl);
    });

    if (f.max && rows.length >= f.max) {
      box.appendChild(el("p", { class: "vj-hint", text: f.maxNote || "You have reached the maximum." }));
    } else {
      box.appendChild(el("button", { type: "button", class: "vj-btn vj-ghost", text: f.addLabel,
        onclick: function () { ctx.addRow(f.key, f.blank); } }));
    }
    return box;
  }

  /* ---------------- review ---------------- */

  function humanize(k) {
    return k.replace(/_explain$/, " (details)")
            .replace(/([A-Z])/g, " $1")
            .replace(/^./, function (c) { return c.toUpperCase(); })
            .replace(/\bUs\b/g, "US").replace(/\bSsn\b/g, "SSN")
            .replace(/\bDob\b/g, "Date of birth").replace(/\bN A\b/g, "not applicable");
  }
  function formatValue(v) {
    if (Object.prototype.toString.call(v) === "[object Array]") {
      var parts = v.map(function (r) {
        if (r.language !== undefined) return r.language || "";
        if (r.number !== undefined && r.explanation !== undefined) return [r.numberUnknown ? "number not known" : r.number, r.country].filter(Boolean).join(", ");
        if (r.surnames !== undefined) return [r.surnames, r.givenNames].filter(Boolean).join(", ");
        if (r.platform !== undefined) return r.platform === "None" ? "None" : (r.handle ? r.platform + ": " + r.handle : r.platform);
        if (r.arrivedDate !== undefined) return r.arrivedDate ? r.arrivedDate + (r.stayLength ? " (" + r.stayLength + " " + (r.stayUnit || "") + ")" : "") : "";
        if (r.jobTitle !== undefined) return [r.name, r.jobTitle].filter(Boolean).join(", ");
        if (r.courseOfStudy !== undefined) return [r.name, r.courseOfStudy].filter(Boolean).join(", ");
        if (r.branch !== undefined) return [r.country, r.branch, r.rank].filter(Boolean).join(", ");
        if (r.hasPassport !== undefined) return r.country ? (r.passportNumber ? r.country + " (passport " + r.passportNumber + ")" : r.country) : "";
        if (r.number !== undefined) return r.number || "";
        if (r.email !== undefined) return r.email || "";
        if (r.location !== undefined) return r.location || "";
        if (r.country !== undefined) return r.country || "";
        if (r.name !== undefined) return r.name || "";
        return "";
      }).filter(Boolean);
      return parts.length ? parts.join(" / ") : "None";
    }
    return String(v);
  }
  function renderReview(ctx) {
    var list = el("dl", { class: "vj-review" });
    Object.keys(ctx.data).forEach(function (k) {
      var v = ctx.data[k];
      if (!v || typeof v === "boolean") return;
      if (/Confirm$/.test(k) || k === "securityAnswer") return;
      /* The photo is shown as its own row below, not as a base64 blob. */
      if (String(v).slice(0, 5) === "data:") return;
      var text = formatValue(v);
      if (!text || text === "None") return;
      list.appendChild(el("div", {}, [el("dt", { text: humanize(k) }), el("dd", { text: text })]));
    });
    return list;
  }

  /* ---------------- mount ---------------- */

  /* ---------------------------------------------------------------------
     Draft cache

     Off by default. When a page turns it on, answers are held in
     sessionStorage so a browser refresh does not lose them.

     sessionStorage, never localStorage: it belongs to one tab and is gone the
     moment that tab closes, so it does not sit on a shared machine afterwards.

     The list below never goes in, whatever the setting. These are the fields
     that make a stolen or borrowed device genuinely dangerous for an applicant,
     and they are also the ones a person can retype in a few seconds. Everything
     else, names, dates, addresses, employment, is a real amount of typing and
     worth saving.

     Do not add passport or ID numbers to the cache to "make resuming smoother".
     The server round trip exists for exactly that.
     --------------------------------------------------------------------- */
  var NEVER_CACHED = [
    "securityAnswer", "securityAnswerConfirm",
    "passportNumber", "passportBookNumber",
    "nationalId", "usSsn", "usSsn1", "usSsn2", "usSsn3", "usTaxId",
    "photo", "photoName", "photoBytes", "photoWidth", "photoHeight",
  ];

  var DRAFT_PREFIX = "vj-draft:";

  function draftKey(applicationId) { return DRAFT_PREFIX + (applicationId || "new"); }

  function scrubForCache(data) {
    var out = {};
    Object.keys(data).forEach(function (k) {
      if (NEVER_CACHED.indexOf(k) !== -1) return;
      var v = data[k];
      /* Repeat rows can hold passport numbers of their own. */
      if (Object.prototype.toString.call(v) === "[object Array]") {
        out[k] = v.map(function (row) {
          if (!row || typeof row !== "object") return row;
          var copy = {};
          Object.keys(row).forEach(function (rk) {
            if (NEVER_CACHED.indexOf(rk) === -1) copy[rk] = row[rk];
          });
          return copy;
        });
        return;
      }
      if (typeof v === "string" && v.slice(0, 5) === "data:") return;
      out[k] = v;
    });
    return out;
  }

  function saveDraft(applicationId, stepIndex, data) {
    try {
      window.sessionStorage.setItem(draftKey(applicationId), JSON.stringify({
        applicationId: applicationId, stepIndex: stepIndex,
        data: scrubForCache(data), at: Date.now(),
      }));
    } catch (err) { /* full, disabled, or private mode. Not worth failing over. */ }
  }

  function readDraft(applicationId) {
    try {
      var raw = window.sessionStorage.getItem(draftKey(applicationId));
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      return parsed && parsed.data ? parsed : null;
    } catch (err) { return null; }
  }

  function clearDraft(applicationId) {
    try { window.sessionStorage.removeItem(draftKey(applicationId)); } catch (err) {}
  }

  function mount(container, options) {
    options = options || {};
    VJ.injectStyles();

    /* A draft only ever fills gaps. Anything the caller passed in, which on a
       real site means answers fetched from the server, wins over it. */
    var useCache = options.draftCache === "session";
    var draft = useCache ? readDraft(options.applicationId) : null;
    var restoredFromDraft = false;

    var seedData = merge(buildEmpty(), draft ? draft.data : null);
    seedData = merge(seedData, options.initialData);
    if (draft && !options.initialData) restoredFromDraft = true;

    var seedStep = options.initialStep;
    if (seedStep == null && draft && typeof draft.stepIndex === "number") seedStep = draft.stepIndex;

    var state = {
      stepIndex: seedStep || 0,
      data: seedData,
      errors: {},
      applicationId: options.applicationId || (draft ? draft.applicationId : null),
      saveState: "idle",
      idJustIssued: false,
      submitted: false,
      copied: false,
      resumeSent: false,
      refEmail: "",
      refEmailBusy: false,
      refEmailSent: "",
      refEmailError: "",
    };

    function merge(base, extra) {
      if (!extra) return base;
      Object.keys(extra).forEach(function (k) { base[k] = extra[k]; });
      return base;
    }

    var ctx = {
      get data() { return state.data; },
      get errors() { return state.errors; },
      set: function (k, v) {
        state.data[k] = v;
        applyClears(k, v);
        delete state.errors[k];
        if (state.saveState === "saved") state.saveState = "idle";
        render();
      },
      setRow: function (listKey, i, field, v) {
        state.data[listKey][i][field] = v;
        var prefix = prefixFor(listKey);
        delete state.errors[prefix + "_" + i + "_" + field];
        render();
      },

      /* Free-text fields write through this on every keystroke: it updates
         state and clears any error on the field, but does NOT repaint. A
         repaint mid-word destroys the input being typed into and drops the
         caret, so text and textarea only repaint on change, which fires when
         the field is left. Selects and yes/no keep repainting, because
         branches like the security answer depend on them. */
      /* Set several keys and repaint once. The photo field writes the image
         plus its measurements together, and repainting between them would
         show a half-updated field. */
      setError: function (k, message) { state.errors[k] = message; render(); },

      /* The setter every free-text field uses. It writes the value, clears any
         error on that field in place, and repaints only if the step's visible
         or required fields actually changed. No repaint means Tab moves on
         normally and a click into the next field lands the first time. */
      setSmart: function (k, v, o, domId) {
        var step = VJ_SCHEMA.STEPS[state.stepIndex];
        var before = stepSignature(step, state.data);

        if (o && o.listKey != null && o.index != null) {
          state.data[o.listKey][o.index][k] = v;
          delete state.errors[prefixFor(o.listKey) + "_" + o.index + "_" + k];
        } else {
          state.data[k] = v;
          delete state.errors[k];
        }
        if (state.saveState === "saved") state.saveState = "idle";

        clearFieldErrorInDom(container, domId || (o && o.domId) || k);
        syncDraft();

        if (stepSignature(step, state.data) !== before) render();
      },
      setMany: function (obj) {
        Object.keys(obj).forEach(function (k) {
          state.data[k] = obj[k];
          delete state.errors[k];
        });
        if (state.saveState === "saved") state.saveState = "idle";
        render();
      },
      setQuiet: function (k, v, o) {
        if (o && o.listKey != null && o.index != null) {
          state.data[o.listKey][o.index][k] = v;
          delete state.errors[prefixFor(o.listKey) + "_" + o.index + "_" + k];
        } else {
          state.data[k] = v;
          delete state.errors[k];
        }
        syncDraft();
      },
      addRow: function (listKey, blank) { state.data[listKey].push(shallow(blank)); render(); },
      removeRow: function (listKey, i) {
        if (state.data[listKey].length > 1) state.data[listKey].splice(i, 1);
        render();
      },
    };

    function prefixFor(listKey) {
      var found = "";
      VJ_SCHEMA.STEPS.forEach(function (s) {
        (s.fields || []).forEach(function (f) { if (f.type === "repeat" && f.key === listKey) found = f.prefix; });
      });
      return found || listKey;
    }

    /* When a branch closes, wipe what it held. Hidden values must never be
       validated or submitted. */
    function applyClears(k, v) {
      var d = state.data;
      VJ_SCHEMA.STEPS.forEach(function (step) {
        (step.fields || []).forEach(function (f) {
          if (f.type === "repeat") {
            if (!f.always && f.showIf && !f.showIf(d)) d[f.key] = [shallow(f.blank)];
            return;
          }
          if (f.type === "note" || f.type === "warn" || f.type === "heading" || f.type === "consent") return;
          if (f.showIf && !f.showIf(d)) {
            if (f.type === "ssn") { d[f.id + "1"] = ""; d[f.id + "2"] = ""; d[f.id + "3"] = ""; }
            else d[f.id] = "";
          }
          if (f.na && d[f.na.key]) {
            if (f.type === "ssn") { d[f.id + "1"] = ""; d[f.id + "2"] = ""; d[f.id + "3"] = ""; }
            else d[f.id] = "";
          }
        });
      });
      (Object.keys(d)).forEach(function (key) {
        if (Object.prototype.toString.call(d[key]) !== "[object Array]") return;
      });
    }

    function save(reason) {
      if (typeof options.onSaveStep !== "function") return Promise.resolve(true);
      state.saveState = "saving"; render();
      return Promise.resolve(options.onSaveStep({
        applicationId: state.applicationId,
        stepId: VJ_SCHEMA.STEPS[state.stepIndex].id,
        stepIndex: state.stepIndex,
        data: state.data,
        reason: reason,
      })).then(function () { state.saveState = "saved"; render(); return true; })
        .catch(function () { state.saveState = "error"; render(); return false; });
    }

    function goNext() {
      var step = VJ_SCHEMA.STEPS[state.stepIndex];
      var e = validateStep(step, state.data);
      state.errors = e;
      if (Object.keys(e).length) {
        render();
        var bad = container.querySelector('[aria-invalid="true"], .vj-bad');
        if (bad && bad.scrollIntoView) { bad.scrollIntoView({ block: "center", behavior: "smooth" }); if (bad.focus) bad.focus(); }
        return;
      }

      if (step.id === "access" && !state.applicationId) {
        state.saveState = "saving"; render();
        var creating = typeof options.onCreateApplication === "function"
          ? Promise.resolve(options.onCreateApplication({
              securityPrompt: state.data.securityPrompt,
              securityAnswer: VJ.normaliseAnswer(state.data.securityAnswer),
            })).then(function (r) {
              if (!r || !r.applicationId) throw new Error("No reference number returned");
              return r.applicationId;
            })
          : Promise.resolve(VJ.generatePreviewId());
        creating.then(function (id) {
          state.applicationId = id;
          state.idJustIssued = true;
          /* The answer has been handed over to be hashed. Drop it so it is not
             carried through the rest of the session or included in a later save. */
          state.data.securityAnswer = "";
          state.data.securityAnswerConfirm = "";
          state.saveState = "saved";
          state.stepIndex += 1;
          /* Before the id existed the draft was filed under "new". Move it to
             the real reference and drop the placeholder, or the next fresh
             application started in this tab would inherit an abandoned one. */
          if (useCache) { clearDraft(null); syncDraft(); }
          render();
        }).catch(function (err) {
          state.saveState = "error";
          /* Surface the real reason. A silent generic message here means the
             next failure takes an hour to diagnose instead of a minute. */
          var detail = (err && err.message) ? " (" + err.message + ")" : "";
          state.errors = { securityAnswer: "We could not start your application. Please try again in a moment." + detail };
          if (window.console && console.error) console.error("onCreateApplication failed:", err);
          render();
        });
        return;
      }

      save("step-complete").then(function (ok) {
        if (!ok) return;
        if (state.stepIndex === VJ_SCHEMA.STEPS.length - 1) {
          state.submitted = true;
          if (typeof options.onSubmit === "function") options.onSubmit(state.data);
          render();
          return;
        }
        state.stepIndex += 1;
        state.errors = {};
        render();
      });
    }

    function goBack() { state.errors = {}; state.stepIndex = Math.max(0, state.stepIndex - 1); render(); }

    /* Emailing the reference number is opt-in and asked for at the one moment it
       is useful: the screen where the number is issued. Nothing is sent unless
       the applicant types an address and presses the button.

       The security answer is never included. Anyone who can read the mailbox
       would otherwise have both halves of the credential in one message, which
       is the exact thing the on-screen warning tells people not to do. */
    function emailReference() {
      var address = String(state.refEmail || "").trim();
      state.refEmailError = "";

      if (!address) { state.refEmailError = "Enter an email address first."; render(); return; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address)) {
        state.refEmailError = "That does not look like a complete email address."; render(); return;
      }

      var send = options.onEmailReference || options.onRequestResumeLink;
      if (typeof send !== "function") {
        state.refEmailError = "We cannot send email from here yet. Please write the number down.";
        render();
        return;
      }

      state.refEmailBusy = true;
      render();

      Promise.resolve(send({ applicationId: state.applicationId, email: address, kind: "reference" }))
        .then(function () {
          state.refEmailBusy = false;
          state.refEmailSent = address;
          state.refEmail = "";
          render();
        })
        .catch(function (err) {
          state.refEmailBusy = false;
          state.refEmailError = "We could not send that just now. Please write the number down and try again later.";
          if (window.console && console.error) console.error("onEmailReference failed:", err);
          render();
        });
    }

    function saveAndExit() {
      save("save-and-exit").then(function () {
        if (typeof options.onRequestResumeLink !== "function") return;
        /* Early in the form there is no email address yet, and silently doing
           nothing looked like a broken button. Say what is missing. */
        if (!state.data.email) {
          state.saveState = "error";
          state.errors = {};
          state.refEmailError = "Your answers are saved. We do not have an email address for you yet, so use your reference number to come back.";
          render();
          return;
        }
        return Promise.resolve(options.onRequestResumeLink({ applicationId: state.applicationId, email: state.data.email }))
          .then(function () { state.resumeSent = true; render(); })
          .catch(function () { state.saveState = "error"; render(); });
      });
    }

    function copyId() {
      if (!state.applicationId || !navigator.clipboard) return;
      navigator.clipboard.writeText(state.applicationId).then(function () {
        state.copied = true; render();
        setTimeout(function () { state.copied = false; render(); }, 2000);
      });
    }

    /* Every state change repaints the whole step, which destroys the node the
       applicant is typing into and drops focus to the body. So: remember what
       was focused and where the caret sat, repaint, then put both back.

       render() is the wrapper. paint() below is the actual draw. Call render()
       from everywhere, never paint() directly. */
    function render() {
      var active = document.activeElement;
      var focusId = (active && active.id && container.contains(active)) ? active.id : null;
      var selStart = null, selEnd = null;

      if (focusId) {
        try { selStart = active.selectionStart; selEnd = active.selectionEnd; } catch (err) {}
      }

      paint();

      if (!focusId) return;
      var next = container.querySelector("#" + focusId.replace(/([^\w-])/g, "\\$1"));
      if (!next) return;

      try { next.focus({ preventScroll: true }); } catch (err) { next.focus(); }
      if (selStart !== null && next.setSelectionRange) {
        try { next.setSelectionRange(selStart, selEnd); } catch (err) {}
      }
    }

    function paint() {
      clear(container);
      container.className = "vj-root";

      if (state.submitted && useCache) clearDraft(state.applicationId);

      if (state.submitted) {
        /* When a paymentUrl is supplied the fee has not been paid yet, so this
           screen has to say so plainly and give somewhere to go. Without one it
           stays a plain acknowledgement. Feedback, September 2026: there was no
           payment step at the end of the form at all. */
        var payUrl = options.paymentUrl
          ? options.paymentUrl + (options.paymentUrl.indexOf("?") === -1 ? "?" : "&") +
            "ref=" + encodeURIComponent(state.applicationId || "")
          : null;

        container.appendChild(el("div", { class: "vj-wrap", style: "padding-top:4rem" }, [
          el("h1", { class: "vj-h1", text: "Your answers have been received" }),
          state.applicationId ? el("p", { style: "margin:1rem 0" }, [
            "Your reference number is ",
            el("strong", { class: "vj-ref", text: state.applicationId }),
            ". Quote it in any email to us.",
          ]) : null,
          el("p", { text: "A member of the team will review your answers and email you if anything needs clarifying. Nothing has been submitted to the Department of State yet." }),
          payUrl ? el("div", { class: "vj-note", style: "margin:1.5rem 0" }, [
            el("p", { text: "One step left. Your preparation fee has not been charged yet, and we start the review once it is. The government fee is separate and is paid directly to the government when you book your interview." }),
          ]) : null,
          payUrl ? el("a", { class: "vj-btn vj-primary", href: payUrl, text: "Continue to payment" }) : null,
          el("p", { class: "vj-small", style: "margin-top:1.5rem" , text: "Two things will still need you personally: you must electronically sign the DS-160 yourself, which we cannot do for you, and you must attend your interview in person." }),
        ]));
        return;
      }

      var step = VJ_SCHEMA.STEPS[state.stepIndex];

      /* reference bar, on every step */
      var statusText = state.saveState === "saving" ? "Saving your answers"
        : state.saveState === "saved" ? "Progress saved"
        : state.saveState === "error" ? "Could not save. Check your connection."
        : "Answers save as you complete each step";
      var bar = el("div", { class: "vj-bar" }, [
        el("div", { class: "vj-bar-in" }, [
          el("div", {}, [
            el("p", { class: "vj-small", text: "Your reference number" }),
            el("div", { class: "vj-inline" }, [
              el("span", { class: "vj-ref", text: state.applicationId || "Not assigned yet" }),
              state.applicationId ? el("button", { type: "button", class: "vj-btn vj-plain",
                style: "border:1px solid #cbd5e1;padding:.125rem .5rem",
                text: state.copied ? "Copied" : "Copy", onclick: copyId }) : null,
            ]),
          ]),
          el("div", { style: "text-align:right" }, [
            el("p", { class: "vj-small", "aria-live": "polite", text: statusText,
              style: state.saveState === "error" ? "color:#b91c1c" : "" }),
            el("button", { type: "button", class: "vj-link", text: "Save and finish later", onclick: saveAndExit }),
          ]),
        ]),
        state.resumeSent ? el("div", { class: "vj-wrap", style: "padding-bottom:.75rem" }, [
          el("div", { class: "vj-note" }, [el("p", { text: "We have emailed a link to " + (state.data.email || "your email address") + " that will bring you back to this application. Keep your reference number handy, but note that the link is what gets you back in, so treat it like a password and do not forward it." })]),
        ]) : null,
      ]);
      container.appendChild(bar);

      var wrap = el("div", { class: "vj-wrap" });
      var pct = ((state.stepIndex + 1) / VJ_SCHEMA.STEPS.length) * 100;
      wrap.appendChild(el("nav", { class: "vj-progress", "aria-label": "Application progress" }, [
        el("p", { class: "vj-small", text: "Step " + (state.stepIndex + 1) + " of " + VJ_SCHEMA.STEPS.length + ": " + step.label }),
        el("div", { class: "vj-track" }, [el("div", { class: "vj-fill", style: "width:" + pct + "%" })]),
      ]));

      var card = el("div", { class: "vj-card" });

      /* Say plainly that answers came back, and name what did not, so nobody
         reaches the consulate having assumed their passport number survived. */
      if (restoredFromDraft && !state.submitted) {
        card.appendChild(el("div", { class: "vj-note", style: "margin-bottom:1.25rem" }, [
          el("p", { text: "We have put back the answers you had entered before the page reloaded. Passport, ID and photograph details are never kept in this browser, so please check those again." }),
          el("button", {
            type: "button", class: "vj-btn vj-ghost", style: "margin-top:.75rem",
            text: "Start this application again",
            onclick: function () {
              clearDraft(state.applicationId);
              restoredFromDraft = false;
              state.data = buildEmpty();
              state.stepIndex = 0;
              state.errors = {};
              render();
            },
          }),
        ]));
      }

      if (state.idJustIssued) {
        card.appendChild(el("div", { class: "vj-issued" }, [
          el("p", { style: "font-weight:600;margin:0", text: "Your application has been created" }),
          el("p", { class: "vj-issued-id", text: state.applicationId }),
          el("p", { style: "margin:0;font-size:.875rem;line-height:1.6", text: "Write this down or photograph it now. This number and your security question answer are the only two things that will get you back into this application. Keep them somewhere safe and do not send them together in one message." }),
          el("div", { class: "vj-issued-btns" }, [
            el("button", { type: "button", class: "vj-btn vj-primary", text: state.copied ? "Copied" : "Copy reference number", onclick: copyId }),
            el("button", { type: "button", class: "vj-btn vj-ghost", text: "I have written it down",
              onclick: function () { state.idJustIssued = false; render(); } }),
          ]),

          /* Optional, and offered rather than assumed. Plenty of applicants are
             on a borrowed phone with no easy way to write anything down. */
          state.refEmailSent
            ? el("p", { class: "vj-emailed", text: "Sent to " + state.refEmailSent + ". It contains your reference number only, never your security answer." })
            : el("div", { class: "vj-email-ref" }, [
                el("label", { for: "vj-ref-email", text: "Would you like it emailed to you as well?" }),
                el("div", { class: "vj-email-row" }, [
                  (function () {
                    var input = el("input", {
                      id: "vj-ref-email", type: "email", class: "vj-input", autocomplete: "email",
                      placeholder: "you@example.com",
                      oninput: function () { state.refEmail = input.value; },
                    });
                    input.value = state.refEmail;
                    input.disabled = state.refEmailBusy;
                    return input;
                  })(),
                  el("button", {
                    type: "button", class: "vj-btn vj-ghost",
                    text: state.refEmailBusy ? "Sending" : "Email it to me",
                    onclick: emailReference,
                  }),
                ]),
                state.refEmailError ? el("p", { class: "vj-err", text: state.refEmailError }) : null,
                el("p", { class: "vj-small", text: "We send the reference number only. We will never email or ask for your security answer." }),
              ]),
        ]));
      }

      card.appendChild(el("h1", { class: "vj-h1", text: step.label }));
      if (step.sub) card.appendChild(el("p", { class: "vj-small", text: step.sub }));
      if (step.intro) card.appendChild(el("p", { class: "vj-hint", text: step.intro }));
      card.appendChild(el("p", { class: "vj-small", style: "margin-bottom:1.5rem", text: "Tap the question mark beside any field if you are unsure what it wants." }));

      if (step.isReview) card.appendChild(renderReview(ctx));

      (step.fields || []).forEach(function (f) {
        if (!visible(f, state.data)) return;
        card.appendChild(f.type === "repeat" ? renderRepeat(ctx, f) : renderField(ctx, f));
      });

      var backBtn = el("button", { type: "button", class: "vj-btn vj-plain", text: "Back", onclick: goBack });
      backBtn.disabled = state.stepIndex === 0;
      var isLast = state.stepIndex === VJ_SCHEMA.STEPS.length - 1;
      card.appendChild(el("div", { class: "vj-nav" }, [
        backBtn,
        el("button", { type: "button", class: "vj-btn vj-primary", onclick: goNext,
          text: isLast ? "Send my answers" : step.id === "access" ? "Create my application" : "Continue" }),
      ]));

      if (Object.keys(state.errors).length) {
        card.appendChild(el("p", { class: "vj-err", role: "alert", text: "Some answers need attention. Check the highlighted fields above." }));
      }

      wrap.appendChild(card);
      wrap.appendChild(el("p", { class: "vj-small", style: "margin-top:1.5rem;line-height:1.6",
        text: "Your answers go to our team for review. We do not submit anything without your confirmation, and you can ask us to delete your information at any time." }));
      container.appendChild(wrap);
    }

    /* Nothing here is written to browser storage, so a refresh cannot restore
       answers on its own. What it can do is remember WHERE the person was, which
       the page turns into a URL. The answers themselves come back from the
       server, which already has every completed step via onSaveStep. */
    /* Called from every setter, not from paint. Typing deliberately does not
       repaint, so hanging the save off a repaint would miss almost everything
       the applicant types. */
    function syncDraft() {
      if (!useCache) return;
      saveDraft(state.applicationId, state.stepIndex, state.data);
    }

    var lastReported = null;
    function reportPosition() {
      if (typeof options.onStepChange !== "function") return;
      var step = VJ_SCHEMA.STEPS[state.stepIndex] || {};
      var token = (state.applicationId || "") + "@" + state.stepIndex;
      /* Fires on every repaint, so only speak up when the position genuinely
         moved. Otherwise the page would rewrite its own URL constantly. */
      if (token === lastReported) return;
      lastReported = token;
      options.onStepChange({
        applicationId: state.applicationId,
        stepIndex: state.stepIndex,
        stepId: step.id,
      });
    }

    var _paint = paint;
    paint = function () { _paint(); reportPosition(); syncDraft(); };

    render();
    reportPosition();

    return {
      getData: function () { return state.data; },
      getApplicationId: function () { return state.applicationId; },
      getStepIndex: function () { return state.stepIndex; },
      /* True when the current step holds edits that have not reached the server.
         A page can use it to warn before a refresh throws them away. */
      hasUnsavedEdits: function () { return state.saveState === "idle" && state.stepIndex > 0; },
      goToStep: function (i) { state.stepIndex = i; render(); },
      clearDraft: function () { clearDraft(state.applicationId); },
      restoredFromDraft: function () { return restoredFromDraft; },
    };
  }

  /* ---------------- resume screen ---------------- */

  function mountResume(container, options) {
    options = options || {};
    VJ.injectStyles();
    /* Prefilled when someone is sent here by a refresh, so they only have to
       answer the security question rather than dig out the reference again. */
    var applicationId = String(options.applicationId || "").toUpperCase();
    var answer = "", prompt = "", busy = false, error = "", attemptsRemaining = null;

    /* A correct answer has to actually reopen the application. Before this, the
       success branch fell through and simply redrew the same two fields, so the
       button appeared to do nothing.

       The saved answers come back from the server in the onResume result and are
       handed straight to mount() in this same container. Nothing is written to
       browser storage on the way through, which is the whole reason resuming
       needs a server round trip in the first place. */
    function openApplication(result) {
      if (typeof options.onResumed === "function") { options.onResumed(result); return; }

      clear(container);
      mount(container, {
        applicationId: result.applicationId || applicationId,
        initialData: result.data || {},
        initialStep: typeof result.stepIndex === "number" ? result.stepIndex : 0,
        paymentUrl: options.paymentUrl,
        onSaveStep: options.onSaveStep,
        onSubmit: options.onSubmit,
        onRequestResumeLink: options.onRequestResumeLink,
      });
      if (window.scrollTo) window.scrollTo({ top: 0, behavior: "smooth" });
    }

    function render() {
      clear(container);
      container.className = "vj-root";

      /* The button is created further down but the inputs above it need to be
         able to enable it. Typing a reference number used to leave it greyed
         out, because the input handler updated the variable without redrawing,
         so the page looked broken before the request was ever made. Toggling it
         in place keeps the field from being rebuilt mid-keystroke. */
      var btn;
      function syncButton() {
        if (!btn) return;
        btn.disabled = busy || (prompt ? !String(answer).trim() : !String(applicationId).trim());
      }

      var card = el("div", { class: "vj-card" }, [
        el("h1", { class: "vj-h1", text: "Return to your application" }),
        el("p", { class: "vj-hint", text: options.intro ||
          "Enter your reference number and answer your security question to pick up where you left off." }),
      ]);

      var idInput = el("input", { id: "vj-resume-id", class: "vj-input vj-ref", autocomplete: "off", spellcheck: "false",
        oninput: function () {
          applicationId = idInput.value.toUpperCase();
          idInput.value = applicationId;
          syncButton();
        } });
      idInput.value = applicationId;
      idInput.disabled = !!prompt;
      card.appendChild(el("div", { class: "vj-field" }, [
        el("label", { class: "vj-label", "for": "vj-resume-id", text: "Reference number" }),
        idInput,
        el("p", { class: "vj-hint", style: "margin-top:.375rem", text: "The code we showed you when you started, also in your confirmation email." }),
      ]));

      if (prompt) {
        var ansInput = el("input", { id: "vj-resume-answer", class: "vj-input", autocomplete: "off",
          oninput: function () { answer = ansInput.value; syncButton(); } });
        ansInput.value = answer;
        card.appendChild(el("div", { class: "vj-field" }, [
          el("label", { class: "vj-label", "for": "vj-resume-answer", text: prompt }),
          ansInput,
          el("p", { class: "vj-hint", style: "margin-top:.375rem", text: "Capital letters and extra spaces do not matter." }),
        ]));
      }

      if (error) {
        var msg = error;
        if (typeof attemptsRemaining === "number" && attemptsRemaining <= 2) {
          msg += " You have " + attemptsRemaining + " attempt" + (attemptsRemaining === 1 ? "" : "s") + " left before this application is locked.";
        }
        card.appendChild(el("p", { class: "vj-err", role: "alert", text: msg }));
      }

      btn = el("button", { type: "button", class: "vj-btn vj-primary", style: "width:100%",
        text: busy ? "Checking" : prompt ? "Open my application" : "Continue",
        onclick: function () {
          busy = true; error = ""; render();
          var p = prompt
            ? Promise.resolve(options.onResume({ applicationId: applicationId, answer: VJ.normaliseAnswer(answer) }))
            : Promise.resolve(options.onLookup({ applicationId: applicationId }));
          p.then(function (r) {
            busy = false;

            if (!prompt) {
              if (r && r.securityPrompt) { prompt = r.securityPrompt; render(); return; }
              error = "We could not find that application. Check the reference number and try again.";
              render();
              return;
            }

            /* The answer was accepted. Anything less than a usable payload is a
               server problem, and saying so is better than dropping the person
               into an empty form and losing what they had. */
            if (!r || (!r.data && !r.applicationId)) {
              error = "Your answer was accepted, but we could not load your saved answers. Please contact us with your reference number rather than starting again.";
              render();
              return;
            }

            openApplication(r);
          }).catch(function (err) {
            busy = false;
            error = (err && err.message) || "We could not find that application. Check the reference number and try again.";
            if (err && typeof err.attemptsRemaining === "number") attemptsRemaining = err.attemptsRemaining;
            render();
          });
        } });
      syncButton();
      card.appendChild(btn);
      if (prompt) {
        card.appendChild(el("button", {
          type: "button", class: "vj-btn vj-ghost", style: "width:100%;margin-top:.625rem",
          text: "Use a different reference number",
          onclick: function () { prompt = ""; answer = ""; error = ""; attemptsRemaining = null; render(); },
        }));
      }

      card.appendChild(el("p", { class: "vj-small", style: "margin-top:1.5rem;border-top:1px solid #e2e8f0;padding-top:1rem;line-height:1.6",
        text: "Lost your reference number, or cannot remember your answer? Contact us and we will email a link to the address on your application." }));

      container.appendChild(el("div", { class: "vj-wrap", style: "padding-top:3rem;max-width:28rem" }, [card]));
    }
    render();
  }

  VJ.mount = mount;
  VJ.mountResume = mountResume;
  VJ.validateStep = validateStep;
  VJ.buildEmpty = buildEmpty;
  VJ.COUNTRY_CODES = COUNTRY_CODES;
  VJ.OCCUPATION_CODES = OCCUPATION_CODES;
})(VisaJourneyForm);

if (typeof module !== "undefined" && module.exports) module.exports = VisaJourneyForm;
