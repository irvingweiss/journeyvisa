const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const DIR = process.argv[2] || (__dirname + '/../src/');
const BASE = process.argv[3] || 'http://localhost:8899/';
let pass=0, fail=0; const bad=[];
const ok=(n,c,d)=>{ if(c){pass++;console.log('  PASS  '+n);} else {fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));} };
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function open(file){return new Promise(res=>{
  const errs=[]; const vc=new VirtualConsole();
  vc.on('jsdomError',e=>{const m=e.message||String(e); if(!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);});
  const dom=new JSDOM(fs.readFileSync(DIR+file.split('?')[0],'utf8'),
    {runScripts:'dangerously',resources:'usable',url:BASE+file,virtualConsole:vc,pretendToBeVisual:true});
  setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);});}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));
const set=(w,el,v)=>{el.value=v; el.dispatchEvent(new w.Event('input'));};

(async()=>{
 console.log('\nEMAILING THE REFERENCE NUMBER');
 const { d, w, errs } = await open('application.html');
 ok('page loads clean', errs.length===0, errs[0]);

 const sent = [];
 const holder = d.createElement('div'); d.body.appendChild(holder);
 w.VisaJourneyForm.mount(holder, {
   onCreateApplication: () => Promise.resolve({ applicationId: 'REF7HK2Q10' }),
   onEmailReference: p => { sent.push(p); return Promise.resolve(); },
 });
 const sel=holder.querySelector('#securityPrompt'); sel.value=sel.options[1].value; sel.dispatchEvent(new w.Event('change'));
 set(w, holder.querySelector('#securityAnswer'), 'Rex');
 set(w, holder.querySelector('#securityAnswerConfirm'), 'rex');
 btn(holder,/Create my application/).click();
 await wait(150);

 ok('reference issued', /REF7HK2Q10/.test(holder.textContent));
 ok('email option offered on that screen', !!holder.querySelector('#vj-ref-email'));
 ok('it is optional, nothing sent yet', sent.length===0);
 ok('states that the answer is never emailed', /never email or ask for your security answer/.test(holder.textContent));

 btn(holder,/Email it to me/).click();
 await wait(60);
 ok('empty address is refused', /Enter an email address first/.test(holder.textContent));
 ok('still nothing sent', sent.length===0);

 set(w, holder.querySelector('#vj-ref-email'), 'not-an-email');
 btn(holder,/Email it to me/).click();
 await wait(60);
 ok('malformed address is refused', /does not look like a complete email/.test(holder.textContent));
 ok('still nothing sent', sent.length===0);

 set(w, holder.querySelector('#vj-ref-email'), 'ada@example.com');
 btn(holder,/Email it to me/).click();
 await wait(120);
 ok('a valid address sends', sent.length===1, JSON.stringify(sent));
 ok('payload carries the reference', sent[0] && sent[0].applicationId==='REF7HK2Q10');
 ok('payload carries the address', sent[0] && sent[0].email==='ada@example.com');
 ok('payload contains no security answer', JSON.stringify(sent[0]).indexOf('Rex')===-1 && !('answer' in sent[0]) && !('securityAnswer' in sent[0]));
 ok('confirms to the applicant', /Sent to ada@example.com/.test(holder.textContent));
 ok('confirmation repeats what was not sent', /never your security answer/.test(holder.textContent));

 // failure path
 const h2 = d.createElement('div'); d.body.appendChild(h2);
 w.VisaJourneyForm.mount(h2, {
   onCreateApplication: () => Promise.resolve({ applicationId: 'REFFAIL123' }),
   onEmailReference: () => Promise.reject(new Error('smtp down')),
 });
 const s2=h2.querySelector('#securityPrompt'); s2.value=s2.options[1].value; s2.dispatchEvent(new w.Event('change'));
 set(w, h2.querySelector('#securityAnswer'), 'Rex');
 set(w, h2.querySelector('#securityAnswerConfirm'), 'rex');
 btn(h2,/Create my application/).click();
 await wait(150);
 set(w, h2.querySelector('#vj-ref-email'), 'ada@example.com');
 btn(h2,/Email it to me/).click();
 await wait(120);
 ok('a send failure is reported, not swallowed', /could not send that just now/.test(h2.textContent));
 ok('failure tells them to write it down', /write the number down/.test(h2.textContent));

 // no callback at all: the option should not be offered
 const h3 = d.createElement('div'); d.body.appendChild(h3);
 w.VisaJourneyForm.mount(h3, { onCreateApplication: () => Promise.resolve({ applicationId: 'REFNONE111' }) });
 const s3=h3.querySelector('#securityPrompt'); s3.value=s3.options[1].value; s3.dispatchEvent(new w.Event('change'));
 set(w, h3.querySelector('#securityAnswer'), 'Rex');
 set(w, h3.querySelector('#securityAnswerConfirm'), 'rex');
 btn(h3,/Create my application/).click();
 await wait(150);
 set(w, h3.querySelector('#vj-ref-email'), 'ada@example.com');
 btn(h3,/Email it to me/).click();
 await wait(60);
 ok('with no sender configured it says so plainly', /cannot send email from here yet/.test(h3.textContent));

 console.log('\n'+'='.repeat(60));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail) bad.forEach(x=>console.log('  - '+x));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
