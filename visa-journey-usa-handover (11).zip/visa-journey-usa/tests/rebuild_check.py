#!/usr/bin/env python3
"""Clean-room rebuild check.

Copies the package to a temp directory, deletes every generated file, runs the
three build scripts, and asserts that everything comes back.

This exists because it caught a real bug: an edit to build.py silently removed the
generator for the two legal pages, and nothing noticed, because stale copies of
those pages were still sitting in src/ and getting copied through to deploy/. The
site was correct only by accident. A developer running build.py on a fresh
checkout would have lost both pages.

Any test that runs against already-built output cannot catch that class of bug.
This one can.

    python3 rebuild_check.py [path-to-package-root]
"""

import os, shutil, subprocess, sys, tempfile

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1
                       else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

PAGES = [
    'index.html', 'about-us.html', 'contact-us.html', 'application.html',
    'payment.html', 'resume.html', 'terms-and-conditions.html', 'privacy-policy.html',
    'b1-b2-visitor-visa.html', 'ds-160-help.html', 'visa-interview-preparation.html',
    'us-visa-renewal.html', 'visiting-family-in-usa.html', 'business-visitor-visa.html',
]
DEPLOY_EXTRA = ['404.html', 'site.css', 'site.js', 'visa-application-form.js',
                'payment-step.js', 'hero.svg', 'favicon.svg', 'robots.txt',
                'sitemap.xml', 'netlify.toml', 'DEPLOY.md']

passed = failed = 0
def ok(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('  PASS  ' + name)
    else:
        failed += 1
        print('  FAIL  ' + name + (' -> ' + str(detail) if detail else ''))

tmp = tempfile.mkdtemp(prefix='vj-rebuild-')
work = os.path.join(tmp, 'pkg')
shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('node_modules', '__pycache__'))

# Delete everything the build is supposed to produce. If a generator has gone
# missing, the file simply will not come back.
for name in os.listdir(os.path.join(work, 'src')):
    if name.endswith('.html'):
        os.remove(os.path.join(work, 'src', name))
shutil.rmtree(os.path.join(work, 'deploy'), ignore_errors=True)
shutil.rmtree(os.path.join(work, 'preview'), ignore_errors=True)

print('\nCLEAN REBUILD')
src = os.path.join(work, 'src')
for script in ('build.py', 'deploy.py', 'bundle.py'):
    r = subprocess.run([sys.executable, script], cwd=src, capture_output=True, text=True)
    ok(script + ' runs without error', r.returncode == 0, (r.stderr or '').strip().splitlines()[-1:] or '')

print('\nSOURCE PAGES REGENERATED')
for page in PAGES:
    ok(page, os.path.exists(os.path.join(src, page)))

print('\nDEPLOY FOLDER REGENERATED')
dep = os.path.join(work, 'deploy')
for name in PAGES + DEPLOY_EXTRA:
    ok(name, os.path.exists(os.path.join(dep, name)))

print('\nPREVIEW REGENERATED')
prev = os.path.join(work, 'preview', 'visa-journey-usa.html')
ok('single file written', os.path.exists(prev))
if os.path.exists(prev):
    body = open(prev).read()
    ok('preview is a full build', len(body) > 200000, len(body))
    for route in ['route-home', 'route-about', 'route-contact', 'route-application',
                  'route-payment', 'route-resume', 'route-terms', 'route-privacy',
                  'route-b1b2', 'route-ds160', 'route-interview', 'route-renewal',
                  'route-family', 'route-business']:
        ok('preview contains ' + route, 'id="%s"' % route in body)

print('\nREBUILD MATCHES WHAT WAS SHIPPED')
for page in PAGES:
    a = os.path.join(src, page)
    b = os.path.join(ROOT, 'src', page)
    if os.path.exists(b):
        ok(page + ' identical to the shipped copy', open(a).read() == open(b).read())

shutil.rmtree(tmp, ignore_errors=True)

print('\n' + '=' * 60)
print('  %d passed, %d failed' % (passed, failed))
print('=' * 60)
sys.exit(1 if failed else 0)
