/* The single-file preview: no server, no sibling files. Everything must be inside it. */
const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
let pass=0, fail=0; const bad=[];
const ok=(n,c,d)=>{ if(c){pass++;console.log('  PASS  '+n);} else {fail++;bad.push(n);console.log('  FAIL  '+n+(d?' -> '+d:''));} };
const errs=[]; const vc=new VirtualConsole();
vc.on('jsdomError',e=>{const m=e.message||String(e); if(!/Not implemented|fonts\.googleapis/.test(m)) errs.push(m);});
const html = fs.readFileSync(process.argv[2] || __dirname + '/../preview/visa-journey-usa.html','utf8');
const dom = new JSDOM(html, { runScripts:'dangerously', url:'https://example.com/', virtualConsole:vc, pretendToBeVisual:true });
const wait = ms => new Promise(r=>setTimeout(r,ms));

(async () => {
 await wait(900);
 const d=dom.window.document, w=dom.window;
 console.log('\nSINGLE-FILE PREVIEW');
 ok('no script errors', errs.length===0, errs[0]);
 ok('self-contained: no external file references',
    !/(src|href)="(?!https:\/\/fonts|https:\/\/travel|data:|#|mailto:)[^"]+\.(js|css|svg|png|jpg)"/.test(html));
 ok('form and payment modules both inlined', typeof w.VisaJourneyForm==='object' && typeof w.VisaJourneyPayment==='object');
 ok('22 steps present', w.VJ_SCHEMA.STEPS.length===22);

 const vis=()=>[...d.querySelectorAll('.route')].filter(r=>!r.hidden).map(r=>r.id).join(',');
 const go=h=>{ w.location.hash=h; w.dispatchEvent(new w.Event('hashchange')); };
 ok('opens on the homepage', vis()==='route-home');
 for (const [hash, id] of [['#about','route-about'],['#contact','route-contact'],
      ['#application','route-application'],['#payment','route-payment'],
      ['#resume','route-resume'],['#terms','route-terms'],['#privacy','route-privacy']]) {
   go(hash); ok('route '+hash+' shows '+id, vis()===id, vis());
 }
 go('#home-faq'); ok('in-page anchor returns to the homepage', vis()==='route-home');
 go('#payment?ref=ABC'); ok('payment route tolerates a query string', vis()==='route-payment');

 go('#application');
 await wait(120);
 ok('form mounts on the application route', d.getElementById('visa-application').innerHTML.length>1000);
 const sel=d.getElementById('securityPrompt'); sel.value=sel.options[1].value; sel.dispatchEvent(new w.Event('change'));
 for (const [id,v] of [['securityAnswer','Rex'],['securityAnswerConfirm','rex']]) {
   const el=d.getElementById(id); el.value=v; el.dispatchEvent(new w.Event('input'));
 }
 [...d.querySelectorAll('#visa-application button')].find(b=>/Create my application/.test(b.textContent)).click();
 await wait(150);
 ok('step 1 issues a reference and advances', /Step 2 of 22/.test(d.getElementById('visa-application').textContent));

 go('#payment'); await wait(120);
 const p=d.getElementById('payment');
 ok('payment mounts with no yellow panel', p.innerHTML.length>800 && !/Separate government fee/.test(p.textContent));

 go('#resume'); await wait(120);
 const r=d.getElementById('resume');
 const rb=()=>[...r.querySelectorAll('button')].find(b=>/Continue|Open my application/.test(b.textContent));
 const rid=r.querySelector('#vj-resume-id'); rid.value='abc12'; rid.dispatchEvent(new w.Event('input'));
 ok('resume button enables as you type', rb().disabled===false);
 rb().click(); await wait(120);
 const ra=r.querySelector('#vj-resume-answer'); ra.value='Rex'; ra.dispatchEvent(new w.Event('input'));
 rb().click(); await wait(150);
 ok('resume reopens the form with saved answers', /Step 3 of 22/.test(r.textContent));

 const img=d.querySelector('.hero-frame img');
 ok('hero is an inline data URI', (img.getAttribute('src')||'').startsWith('data:image/svg+xml'));

 console.log('\n' + '='.repeat(60));
 console.log('  ' + pass + ' passed, ' + fail + ' failed');
 if (fail) bad.forEach(b=>console.log('  - '+b));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
