const {JSDOM,VirtualConsole}=require('jsdom'), fs=require('fs');
const DIR=process.argv[2]||(__dirname+'/../src/');
const BASE=process.argv[3]||'http://localhost:8899/';
let pass=0,fail=0;const bad=[];
const ok=(n,c,d)=>{if(c){pass++;console.log('  PASS  '+n);}else{fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));}};
function open(f){return new Promise(res=>{const errs=[];const vc=new VirtualConsole();
 vc.on('jsdomError',e=>{const m=e.message||String(e);if(!/Not implemented|fonts\.googleapis|Could not load/.test(m))errs.push(m);});
 const dom=new JSDOM(fs.readFileSync(DIR+f.split('?')[0],'utf8'),
  {runScripts:'dangerously',resources:'usable',url:BASE+f,virtualConsole:vc,pretendToBeVisual:true});
 setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);});}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));
const errsIn=(root)=>[...root.querySelectorAll('.vj-err')].map(e=>e.textContent);

(async()=>{
 const {d,w}=await open('application.html');
 const S=w.VJ_SCHEMA.STEPS;
 const idx=id=>S.findIndex(x=>x.id===id);
 const mk=(step,data)=>{const b=d.createElement('div');d.body.appendChild(b);
   w.VisaJourneyForm.mount(b,{initialStep:step,applicationId:'X',initialData:data||{}});return b;};

 /* ============================================================ SCENARIO A */
 console.log('\nA. INDONESIAN DOMESTIC WORKER IN SAUDI ARABIA');
 console.log('   one name only, employer paying, applying outside her own country\n');

 const mono = mk(idx('personal'), { surnames:'SUPARNI', givenNames:'FNU' });
 btn(mono,/Continue/).click();
 ok('a single-name applicant is not blocked by the name rules',
    !errsIn(mono).some(e=>/letters|Numbers/i.test(e)), errsIn(mono).join(' | '));
 ok('the form explains what to do when there is no given name',
    /FNU/.test(mono.textContent));
 ok('and explains what to do when there is only one name',
    /only one name is listed/i.test(mono.textContent));

 const payer = mk(idx('travel'), { payer:'Present employer' });
 const asksPersonName = !!payer.querySelector('#payerSurnames');
 const asksCompany = /company|organisation|organization|employer/i.test(
   [...payer.querySelectorAll('label')].map(l=>l.textContent).join(' '));
 ok('an employer paying is not asked for a person\'s surname',
    !asksPersonName || asksCompany, 'person-name fields shown: '+asksPersonName+', company field: '+asksCompany);

 const org = mk(idx('travel'), { payer:'Other company or organization' });
 ok('a company paying is asked for the company, not a surname',
    !org.querySelector('#payerSurnames') || /company|organisation/i.test(
      [...org.querySelectorAll('label')].map(l=>l.textContent).join(' ')),
    'payerSurnames present: '+!!org.querySelector('#payerSurnames'));

 const thirdCountry = mk(idx('history'), { hadVisa:'Yes' });
 ok('asks whether she is applying where she lives',
    /same country where that visa was issued|principal residence/i.test(thirdCountry.textContent));

 const noEmail = mk(idx('contact'), {});
 ok('an email address is demanded with no way out',
    !noEmail.querySelector('#email__na'), 'this is faithful to the DS-160, but see notes');

 /* ============================================================ SCENARIO B */
 console.log('\nB. A SIX-YEAR-OLD CHILD, FORM COMPLETED BY HER MOTHER');
 console.log('   no job, no school above secondary, cannot certify anything\n');

 const child = mk(idx('work'), { occupation:'NOT EMPLOYED' });
 ok('a child is not asked for an employer', !child.querySelector('#employerSchoolName'));
 ok('and is told nothing more is needed', /No employer or school details/i.test(child.textContent));

 const childPrev = mk(idx('prevwork'), { prevEmployed:'No', attendedSchool:'No' });
 btn(childPrev,/Continue/).click();
 ok('no previous work or schooling is accepted', errsIn(childPrev).length===0, errsIn(childPrev).join(' | '));

 const kidDob = new Date(); kidDob.setFullYear(kidDob.getFullYear()-6);
 const iso = kidDob.toISOString().slice(0,10);
 const minorReview = mk(S.length-1, { dob: iso, preparerUsed:'Yes' });
 ok('the review page says something about a child signing',
    /parent|guardian|under 1[68]|on behalf/i.test(minorReview.textContent),
    'no mention of who signs for a minor');

 const cert = mk(S.length-1, { dob: iso });
 const certLabel = [...cert.querySelectorAll('label')].map(l=>l.textContent).join(' ');
 ok('the certification wording works when a parent is answering',
    /parent|guardian|on behalf/i.test(certLabel), certLabel.slice(0,120));

 const prep = mk(idx('preparer'), { preparerUsed:'Yes' });
 ok('a parent can be recorded as the person who helped', !!prep.querySelector('#preparerSurnames'));
 ok('and their relationship can be given', !!prep.querySelector('#preparerRelationship'));

 /* ============================================================ SCENARIO C */
 console.log('\nC. A STATELESS APPLICANT ON A TRAVEL DOCUMENT, LIVING IN A CAMP');
 console.log('   no national passport, no expiry date, no street address, no postal code\n');

 const lp = mk(idx('passport'), { passportType:'Other' });
 ok('a non-passport travel document can be described', !!lp.querySelector('#passportTypeOther'));
 const lp2 = mk(idx('passport'), { passportType:'Laissez-Passer' });
 ok('Laissez-Passer is offered as a type', !!lp2);
 ok('a document with no expiry can be recorded',
    !!mk(idx('passport'),{}).querySelector('#passportExpiryDate__na'));

 const addr = mk(idx('contact'), {});
 ok('an address with no state or province is allowed', !!addr.querySelector('#homeRegion__na'));
 ok('an address with no postal code is allowed', !!addr.querySelector('#homePostal__na'));
 const noStreet = mk(idx('contact'), { homeStreet1:'', homeCity:'Kilis', homeCountry:'TURKEY' });
 btn(noStreet,/Continue/).click();
 ok('a street address is still demanded',
    errsIn(noStreet).some(e=>/required/i.test(e)), 'see notes on camps and informal addresses');

 const natField = (()=>{for(const s of S)for(const f of (s.fields||[]))if(f.id==='nationality')return f;})();
 ok('a stateless applicant has something to select for nationality',
    natField.options.some(o=>/stateless/i.test(o)) || !!natField.help,
    'no stateless option and no guidance');

 const prevEmp = mk(idx('prevwork'), { prevEmployed:'Yes', prevEmployers:[{}] });
 btn(prevEmp,/Continue/).click();
 const supErr = errsIn(prevEmp).join(' | ');
 ok('an unknown former supervisor does not block the step',
    !/supervisor/i.test(supErr) || /do not know/i.test(prevEmp.textContent), supErr.slice(0,160));

 console.log('\n'+'='.repeat(62));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail){ console.log('\n  Findings:'); bad.forEach(x=>console.log('   - '+x)); }
 console.log('='.repeat(62));
})();
