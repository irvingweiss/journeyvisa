const {JSDOM,VirtualConsole}=require('jsdom'), fs=require('fs');
const DIR=process.argv[2]||(__dirname+'/../src/');
const BASE=process.argv[3]||'http://localhost:8899/';
let pass=0,fail=0;const bad=[];
const ok=(n,c,d)=>{if(c){pass++;console.log('  PASS  '+n);}else{fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));}};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function open(f){return new Promise(res=>{const errs=[];const vc=new VirtualConsole();
 vc.on('jsdomError',e=>{const m=e.message||String(e);if(!/Not implemented|fonts\.googleapis|Could not load/.test(m))errs.push(m);});
 const dom=new JSDOM(fs.readFileSync(DIR+f.split('?')[0],'utf8'),
  {runScripts:'dangerously',resources:'usable',url:BASE+f,virtualConsole:vc,pretendToBeVisual:true});
 setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);});}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));

(async()=>{
 const {d,w,errs}=await open('application.html');
 const S=w.VJ_SCHEMA.STEPS;
 const mk=(step,data)=>{const b=d.createElement('div');d.body.appendChild(b);
   w.VisaJourneyForm.mount(b,{initialStep:step,applicationId:'X',initialData:data||{}});return b;};
 const idx=id=>S.findIndex(x=>x.id===id);

 console.log('\nA COMPLEX ALGERIAN APPLICANT');
 ok('page loads clean', errs.length===0, errs[0]);

 console.log('\n  names as they appear on Maghrebi and French documents');
 const nameCase=(v)=>{const b=mk(idx('personal'),{surnames:v});btn(b,/Continue/).click();
   const err=b.querySelector('#surnames').closest('.vj-field').querySelector('.vj-err');
   return err?err.textContent:'';};
 ok('BENALI accepted', nameCase('BENALI')==='' , nameCase('BENALI'));
 ok('Ait Ahmed accepted', nameCase('Ait Ahmed')==='');
 ok('Abd El-Kader accepted', nameCase('Abd El-Kader')==='');
 ok("'Abd Allah accepted (leading apostrophe)", nameCase("'Abd Allah")==='', nameCase("'Abd Allah"));
 const acc=nameCase('Aïcha');
 ok('Aïcha still rejected, as the DS-160 requires', acc!=='');
 ok('and the reason given is accents, not numbers', /without accents/.test(acc), acc);
 ok('and it says where to find the right spelling', /bottom of your passport/.test(acc));
 const dig=nameCase('Belkacem 2');
 ok('a digit still gets the numbers message', /Numbers are not accepted/.test(dig), dig);
 const ar=nameCase('بلقاسم');
 ok('Arabic script gets its own message, not the numbers one', /separate field/.test(ar), ar);

 console.log('\n  name in its own alphabet');
 const nat=mk(idx('personal'),{});
 ok('there is a native-alphabet field', !!nat.querySelector('#nativeName'));
 const nn=nat.querySelector('#nativeName'); nn.value='بلقاسم بن علي'; nn.dispatchEvent(new w.Event('input',{bubbles:true}));
 await wait(40);
 btn(nat,/Continue/).click();
 ok('Arabic is accepted there', !nat.querySelector('#nativeName').closest('.vj-field').querySelector('.vj-err'));

 console.log('\n  dual French nationality');
 const dual=mk(idx('personal2'),{nationality:'ALGERIA',otherNationality:'Yes',
   otherNationalities:[{country:'FRANCE',hasPassport:'Yes',passportNumber:'12AB34567'}]});
 ok('told they may not need a visa at all', /may not need a visa at all/.test(dual.textContent));
 ok('names ESTA as the alternative', /ESTA/.test(dual.textContent));
 ok('sends them to the official list', /travel\.state\.gov/.test(dual.textContent));
 ok('says they can come back if it does not apply', /carry on where you left off/.test(dual.textContent));
 const dual2=mk(idx('personal2'),{nationality:'ALGERIA',otherNationality:'Yes',
   otherNationalities:[{country:'MOROCCO',hasPassport:'Yes'}]});
 ok('not shown for a second passport that is not visa waiver', !/may not need a visa at all/.test(dual2.textContent));
 const dual3=mk(idx('personal2'),{nationality:'ALGERIA',otherNationality:'Yes',
   otherNationalities:[{country:'FRANCE',hasPassport:'No'}]});
 ok('not shown when they hold the nationality but no passport', !/may not need a visa at all/.test(dual3.textContent));

 console.log('\n  phone numbers from +213');
 let hinted=0, tels=0;
 S.forEach(st=>(st.fields||[]).forEach(f=>{ if(f.type==='tel'){tels++; if(f.hint)hinted++;} }));
 ok('every phone field explains the format', hinted===tels, hinted+' of '+tels);
 const contact=mk(idx('contact'),{});
 ok('the primary phone names a country code example', /country dialling code/.test(contact.textContent));

 console.log('\n  a US contact in a territory');
 const us=mk(idx('uscontact'),{});
 const states=[...us.querySelector('#contactState').options].map(o=>o.text);
 ['Guam','Puerto Rico','Virgin Islands','American Samoa','Northern Mariana Islands','District of Columbia'].forEach(t=>
   ok('  '+t+' selectable', states.includes(t)));

 console.log('\n  the rest of a complex case');
 const wilaya=mk(idx('contact'),{});
 ok('a home address without a state or province can be skipped', !!wilaya.querySelector('#homeRegionNA') || /does not apply/i.test(wilaya.textContent));
 const emailField=(()=>{for(const st of S)for(const f of (st.fields||[]))if(f.id==='emailConfirm')return f;})();
 ok('email confirmation uses an email field', emailField.type==='email');
 const mil=mk(idx('additional'),{militaryService:'Yes',militaryRecords:[{}]});
 ok('conscript military service can be recorded', /Branch of service/.test(mil.textContent));
 const ref=mk(idx('history'),{everRefused:'Yes'});
 ok('a previous refusal can be explained', !!ref.querySelector('#refusalExplanation'));
 const sm=mk(idx('contact'),{});
 ok('social media offers a way to say none', /None/.test(sm.querySelector('select[id*=platform], .vj-repeat select')?.textContent||sm.textContent));

 console.log('\n'+'='.repeat(60));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail) bad.forEach(x=>console.log('  - '+x));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
