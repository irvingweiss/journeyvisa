/* Full functional suite. Runs the real pages in a DOM over HTTP, the way a
   browser would, and asserts every behaviour we have changed in this project. */

const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');

const DIR = process.argv[2] || '/mnt/user-data/outputs/site/';
const BASE = process.argv[3] || 'http://localhost:8899/';

let pass = 0, fail = 0;
const failures = [];

function ok(name, cond, detail) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; failures.push(name + (detail ? ' -> ' + detail : '')); console.log('  FAIL  ' + name + (detail ? ' -> ' + detail : '')); }
}
function group(t) { console.log('\n' + t); }

function load(file, cb) {
  const errs = [];
  const vc = new VirtualConsole();
  vc.on('jsdomError', e => {
    const m = e.message || String(e);
    if (!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);
  });
  const dom = new JSDOM(fs.readFileSync(DIR + file.split('?')[0], 'utf8'), {
    runScripts: 'dangerously', resources: 'usable',
    url: BASE + file, virtualConsole: vc, pretendToBeVisual: true,
  });
  setTimeout(() => cb(dom, errs), 1400);
}

const wait = ms => new Promise(r => setTimeout(r, ms));
const open = file => new Promise(r => load(file, (dom, errs) => r({ dom, errs, d: dom.window.document, w: dom.window })));

const btn = (root, re) => [...root.querySelectorAll('button')].find(b => re.test(b.textContent));
const setVal = (w, el, v, ev) => { el.value = v; el.dispatchEvent(new w.Event(ev || 'input')); };

(async () => {

  /* ============================================================ 1. the form */
  group('1. APPLICATION FORM — structure');
  {
    const { d, w, errs } = await open('application.html');
    ok('page loads with no script errors', errs.length === 0, errs[0]);
    ok('form mounts', d.getElementById('visa-application').innerHTML.length > 1000);
    ok('developer fallback stays hidden', d.getElementById('app-fallback').hidden === true);

    const S = w.VJ_SCHEMA.STEPS;
    ok('22 steps', S.length === 22, 'got ' + S.length);
    ok('photo step exists before review', S[S.length - 2].id === 'photo' && S[S.length - 1].id === 'review');

    const find = id => { for (const st of S) for (const f of (st.fields || [])) if (f.id === id) return f; };

    group('1a. schema fixes from the client feedback');
    const marital = find('maritalStatus').options;
    ok('marital status has all 8 DS-160 options', marital.length === 8);
    ok('marital status includes Common law marriage', marital.includes('Common law marriage'));
    ok('marital status includes Other', marital.includes('Other'));
    const pt = find('passportType').options;
    ok('passport type has no Travel document', !pt.includes('Travel document'), pt.join('/'));
    ok('passport type matches the DS-160 five', pt.join(',') === 'Regular,Official,Diplomatic,Laissez-Passer,Other');
    const pis = find('passportIssueState');
    ok('passport state or province is optional', !pis.required && !pis.requiredUnless);
    let letters = 0;
    for (const st of S) for (const f of (st.fields || [])) {
      if (f.letters) letters++;
      if (f.type === 'repeat') for (const g of f.fields) if (g.letters) letters++;
    }
    ok('name fields carry letters-only validation', letters >= 18, letters + ' fields');
    ok('duplicate arrivalDate has a distinct DOM id', S.some(st => (st.fields || []).some(f => f.domId === 'arrivalDateEstimate')));
  }

  /* ================================================ 2. typing, tab, clicking */
  group('2. INPUT BEHAVIOUR — the reported bugs');
  {
    const { d, w } = await open('application.html');
    const S = w.VJ_SCHEMA.STEPS;

    const sel = d.getElementById('securityPrompt');
    setVal(w, sel, sel.options[1].value, 'change');
    const a = d.getElementById('securityAnswer');
    a.focus();
    let typed = '', lostFocus = 0, rebuilt = 0;
    for (const ch of 'Rexington') {
      const before = d.getElementById('securityAnswer');
      typed += ch; before.value = typed;
      try { before.setSelectionRange(typed.length, typed.length); } catch (e) {}
      before.dispatchEvent(new w.Event('input'));
      if (d.getElementById('securityAnswer') !== before) rebuilt++;
      if (!d.activeElement || d.activeElement.id !== 'securityAnswer') lostFocus++;
    }
    ok('typing never rebuilds the field', rebuilt === 0, rebuilt + ' rebuilds');
    ok('typing never loses focus', lostFocus === 0, lostFocus + ' losses');
    ok('full value retained', d.getElementById('securityAnswer').value === 'Rexington');

    const mk = (step, data) => {
      const b = d.createElement('div'); d.body.appendChild(b);
      w.VisaJourneyForm.mount(b, { initialStep: step, applicationId: 'X', initialData: data || {} });
      return b;
    };

    const broken = [];
    S.forEach((st, i) => {
      const b = mk(i, { maritalStatus: 'Married', specificPlans: 'Yes', occupation: 'BUSINESS' });
      const ins = [...b.querySelectorAll('input[type=text],input[type=number],input[type=tel],input[type=email],textarea')];
      if (ins.length < 2) return;
      const first = ins[0], next = ins[1];
      first.focus();
      first.value = first.classList.contains('vj-date-year') ? '1990' : 'Testing';
      first.dispatchEvent(new w.Event('input'));
      next.focus();
      first.dispatchEvent(new w.Event('change'));
      if (!b.contains(next) || d.activeElement !== next) broken.push(st.label);
    });
    ok('tab and click hold across all 22 steps', broken.length === 0, broken.join(', '));

    /* Dates are now day / month / year controls rather than a native picker,
       because the picker made a birth year almost impossible to reach. */
    const trip = mk(S.findIndex(x => x.id === 'travel'), { specificPlans: 'No' });
    const dateWrap = trip.querySelector('.vj-date');
    ok('date renders as three controls', !!dateWrap && dateWrap.children.length === 3);
    const [dEl, mEl, yEl] = dateWrap.children;
    const yNode = yEl;
    dEl.value = '01'; dEl.dispatchEvent(new w.Event('change', { bubbles: true }));
    mEl.value = '03'; mEl.dispatchEvent(new w.Event('change', { bubbles: true }));
    yEl.focus(); yEl.value = '2027'; yEl.dispatchEvent(new w.Event('input', { bubbles: true }));
    ok('year box survives typing', trip.querySelector('.vj-date').children[2] === yNode);
    ok('year value kept', trip.querySelector('.vj-date').children[2].value === '2027');

    const stay = mk(S.findIndex(x => (x.fields || []).some(f => f.id === 'stayLength')), { specificPlans: 'No', stayUnit: 'Months' });
    const len = stay.querySelector('#stayLength');
    len.focus(); setVal(w, len, '11');
    ok('a text value that opens a branch still repaints', /long visit|longer/i.test(stay.textContent));
    ok('focus survives that repaint', d.activeElement && d.activeElement.id === 'stayLength');

    const yn = mk(S.findIndex(x => x.id === 'travel'), {});
    [...yn.querySelectorAll('label')].find(l => /^Yes$/.test(l.textContent)).querySelector('input').click();
    ok('yes/no still opens its branch', !!yn.querySelector('.vj-date'));

    const errStep = mk(1, {});
    btn(errStep, /Continue/).click();
    ok('validation blocks an empty step', !!errStep.querySelector('.vj-err'));
    const sur = errStep.querySelector('#surnames');
    const surNode = sur;
    sur.focus(); setVal(w, sur, 'Okafor');
    ok('field not rebuilt when the error clears', errStep.querySelector('#surnames') === surNode);
    ok('error message removed in place', !surNode.closest('.vj-field').querySelector('.vj-err'));
    ok('red border removed', !surNode.classList.contains('vj-bad'));

    setVal(w, errStep.querySelector('#surnames'), 'Smith3', 'change');
    btn(errStep, /Continue/).click();
    ok('digits in a name are rejected', /Numbers are not accepted/.test(errStep.textContent));
    setVal(w, errStep.querySelector('#surnames'), "O'Brien-Smith", 'change');
    ok('apostrophes and hyphens accepted', !/Numbers are not accepted/.test(errStep.textContent));
  }

  /* ======================================================= 3. spouse + photo */
  group('3. SPOUSE AND PHOTO STEPS');
  {
    const { d, w } = await open('application.html');
    const S = w.VJ_SCHEMA.STEPS;
    const mk = (step, data) => {
      const b = d.createElement('div'); d.body.appendChild(b);
      w.VisaJourneyForm.mount(b, { initialStep: step, applicationId: 'X', initialData: data || {} });
      return b;
    };
    const iFam = S.findIndex(x => x.id === 'family');

    ok('single hides the spouse block', !mk(iFam, { maritalStatus: 'Single' }).querySelector('#spouseSurnames'));
    ok('married shows the spouse block', !!mk(iFam, { maritalStatus: 'Married' }).querySelector('#spouseSurnames'));
    ok('common law shows it too', !!mk(iFam, { maritalStatus: 'Common law marriage' }).querySelector('#spouseSurnames'));
    ok('civil union shows it too', !!mk(iFam, { maritalStatus: 'Civil union or domestic partnership' }).querySelector('#spouseSurnames'));
    ok('spouse address fields hidden until Other', !mk(iFam, { maritalStatus: 'Married' }).querySelector('#spouseStreet1'));
    ok('spouse address Other reveals the address', !!mk(iFam, { maritalStatus: 'Married', spouseAddressType: 'Other' }).querySelector('#spouseStreet1'));
    const married = mk(iFam, { maritalStatus: 'Married' });
    btn(married, /Continue/).click();
    ok('married cannot skip the spouse block', married.querySelector('#spouseSurnames').classList.contains('vj-bad'));

    const ph = mk(S.findIndex(x => x.id === 'photo'), {});
    const inp = ph.querySelector('#photo');
    ok('photo field is a JPEG file input', inp.getAttribute('type') === 'file' && inp.getAttribute('accept') === 'image/jpeg');
    btn(ph, /Continue/).click();
    ok('photo is required', /Choose a photograph/.test(ph.textContent));
    const fire = f => { Object.defineProperty(inp, 'files', { value: [f], configurable: true }); inp.dispatchEvent(new w.Event('change')); };
    fire(new w.File(['x'], 'p.png', { type: 'image/png' }));
    ok('PNG rejected', /must be a JPEG/.test(ph.textContent));
    fire(new w.File([new Uint8Array(300 * 1024)], 'big.jpg', { type: 'image/jpeg' }));
    ok('over 240 KB rejected', /official limit is 240 KB/.test(ph.textContent));
  }

  /* ============================================ 4. submit and payment handoff */
  group('4. SUBMIT AND PAYMENT HANDOFF');
  {
    const { d, w } = await open('application.html');
    const S = w.VJ_SCHEMA.STEPS;
    const b = d.createElement('div'); d.body.appendChild(b);
    w.VisaJourneyForm.mount(b, {
      initialStep: S.length - 1, applicationId: 'REF123456', paymentUrl: 'payment.html',
      initialData: { certify: true }, onSubmit: () => Promise.resolve(),
    });
    const cb = b.querySelector('input[type=checkbox]');
    if (cb && !cb.checked) cb.click();
    btn(b, /Send my answers/).click();
    await wait(120);
    ok('confirmation screen reached', /answers have been received/.test(b.textContent));
    const cta = b.querySelector('a.vj-primary');
    ok('payment CTA present', !!cta && /Continue to payment/.test(cta.textContent));
    ok('reference passed to payment', cta && cta.getAttribute('href') === 'payment.html?ref=REF123456');
    ok('explains the fee is not yet charged', /has not been charged yet/.test(b.textContent));
  }

  /* ================================================= 5. refresh and position */
  group('5. SURVIVING A REFRESH');
  {
    const { d, w } = await open('application.html');
    const sel = d.getElementById('securityPrompt');
    setVal(w, sel, sel.options[1].value, 'change');
    setVal(w, d.getElementById('securityAnswer'), 'Rex');
    setVal(w, d.getElementById('securityAnswerConfirm'), 'rex');
    btn(d.getElementById('visa-application'), /Create my application/).click();
    await wait(150);
    const ref = (d.querySelector('.vj-ref') || {}).textContent;
    ok('reference written to the URL', w.location.search.indexOf(ref) > -1, w.location.search);
    ok('step written to the URL', /step=1/.test(w.location.search), w.location.search);
    btn(d.getElementById('visa-application'), /^Back$/).click();
    await wait(150);
    ok('URL follows Back too', /step=0/.test(w.location.search), w.location.search);

    const r = await open('application.html?ref=' + ref + '&step=7');
    ok('refresh reopens at the saved step', /Step 8 of 22/.test(r.d.getElementById('visa-application').textContent));
    ok('refresh keeps the reference', (r.d.querySelector('.vj-ref') || {}).textContent === ref);
    ok('no errors on the refreshed load', r.errs.length === 0, r.errs[0]);
  }

  /* ================================================================ 6. resume */
  group('6. RESUME');
  {
    const { d, w, errs } = await open('resume.html');
    ok('resume page loads clean', errs.length === 0, errs[0]);
    const box = d.getElementById('resume');
    const go = () => btn(box, /Continue|Open my application/);
    ok('button disabled with no reference', go().disabled === true);
    const id = box.querySelector('#vj-resume-id');
    setVal(w, id, 'abc123xyz9');
    ok('reference uppercased as typed', id.value === 'ABC123XYZ9');
    ok('button enables as you type', go().disabled === false);
    go().click();
    await wait(120);
    ok('security question appears', !!box.querySelector('#vj-resume-answer'));
    ok('button becomes Open my application', /Open my application/.test(go().textContent));
    ok('can go back to change the reference', !!btn(box, /different reference/));
    setVal(w, box.querySelector('#vj-resume-answer'), '  Rex  ');
    go().click();
    await wait(150);
    ok('form opens in place', /Step \d+ of 22/.test(box.textContent));
    ok('reopens at the saved step', /Step 3 of 22/.test(box.textContent));
    ok('reference carried into the form', (box.querySelector('.vj-ref') || {}).textContent === 'ABC123XYZ9');
    const back = btn(box, /^Back$/);
    if (back) back.click();
    await wait(120);
    ok('saved answers restored', (box.querySelector('#surnames') || {}).value === 'OKAFOR');
    ok('second saved answer restored', (box.querySelector('#givenNames') || {}).value === 'ADA');

    const pre = await open('resume.html?ref=ABC123XYZ9');
    ok('reference prefilled from the URL', pre.d.querySelector('#vj-resume-id').value === 'ABC123XYZ9');
    ok('prefilled button ready to press', btn(pre.d.getElementById('resume'), /Continue/).disabled === false);
    ok('explains why the answer is needed again', /do not keep your answers in this browser/.test(pre.d.body.textContent));
  }

  /* =============================================================== 7. payment */
  group('7. PAYMENT PAGE');
  {
    const { d, w, errs } = await open('payment.html?ref=REF1');
    ok('payment page loads clean', errs.length === 0, errs[0]);
    const p = d.getElementById('payment');
    ok('payment widget mounts', p.innerHTML.length > 800);
    ok('ACH Direct Debit removed', !/ACH|Direct Debit/i.test(p.textContent));
    ok('no radio buttons left', p.querySelectorAll('input[type=radio]').length === 0);
    ok('consent checkbox replaced by a sentence', p.querySelectorAll('input[type=checkbox]').length === 0);
    ok('disclosure sentence still shown', /preparation service fee paid to Visa Journey USA/.test(p.textContent));
    ok('Shopping Cart label removed', !/Shopping Cart/i.test(p.textContent));
    ok('government fee panel removed', !/Separate government fee/.test(p.textContent));
    ok('combined total removed', !/Total across both/.test(p.textContent) && !/370/.test(p.textContent));
    ok('service fee still listed', /Visa service fee/.test(p.textContent));
    ok('reference shown on the page', /REF1/.test(p.textContent));

    let paid = false;
    const b = d.createElement('div'); d.body.appendChild(b);
    w.VisaJourneyPayment.mount(b, { applicationId: 'R1', serviceFee: 185, governmentFee: 185, hostedRedirect: true, onPay: () => { paid = true; return Promise.resolve(); } });
    btn(b, /Pay \$185/).click();
    await wait(80);
    ok('pay button works with no checkbox to tick', paid);
  }

  /* ============================================================== 8. the site */
  group('8. SITE PAGES');
  {
    const pages = ['index.html', 'about-us.html', 'contact-us.html', 'terms-and-conditions.html', 'privacy-policy.html'];
    for (const page of pages) {
      const { d, errs } = await open(page);
      ok(page + ' loads with header and footer', !!d.querySelector('.site-header') && !!d.querySelector('.site-footer') && errs.length === 0, errs[0]);
    }

    const home = await open('index.html');
    const img = home.d.querySelector('.hero-frame img');
    const heroSrc = img && img.getAttribute('src');
    ok('hero image is local', /^\/?hero\.svg$/.test(heroSrc || ''), heroSrc);
    ok('hero has width and height set', img.getAttribute('width') && img.getAttribute('height'));
    ok('no remote asset URLs anywhere', !/visajourneyusa\.com\/assets/.test(home.d.documentElement.outerHTML));
    const cs = home.w.getComputedStyle(home.d.querySelector('.hero-copy .btn-primary'));
    ok('primary button text is white', cs.color === 'rgb(255, 255, 255)', cs.color);
    ok('primary button text is bold', cs.fontWeight === '700', cs.fontWeight);

    const c = await open('contact-us.html');
    const form = c.d.getElementById('contact-form');
    form.dispatchEvent(new c.w.Event('submit', { cancelable: true, bubbles: true }));
    ok('contact form flags empty fields', c.d.getElementById('err-c-name').hidden === false);
    c.d.getElementById('c-name').value = 'Ada';
    c.d.getElementById('c-email').value = 'not-an-email';
    c.d.getElementById('c-subject').value = 'Something else';
    c.d.getElementById('c-message').value = 'Hello';
    form.dispatchEvent(new c.w.Event('submit', { cancelable: true, bubbles: true }));
    ok('contact form rejects a bad email', c.d.getElementById('err-c-email').hidden === false);
    c.d.getElementById('c-email').value = 'ada@example.com';
    c.d.getElementById('c-email').dispatchEvent(new c.w.Event('input'));
    form.dispatchEvent(new c.w.Event('submit', { cancelable: true, bubbles: true }));
    ok('contact form shows the success state', c.d.getElementById('contact-success').hidden === false);
    ok('success echoes the email back', c.d.getElementById('success-email').textContent === 'ada@example.com');
    c.d.getElementById('menu-toggle').click();
    ok('mobile menu opens', c.d.getElementById('mobile-nav').classList.contains('is-open'));
  }

  /* ============================================================== summary */
  console.log('\n' + '='.repeat(60));
  console.log('  ' + pass + ' passed, ' + fail + ' failed');
  if (fail) { console.log('\nFailures:'); failures.forEach(f => console.log('  - ' + f)); }
  console.log('='.repeat(60));
  process.exit(fail ? 1 : 0);
})();
