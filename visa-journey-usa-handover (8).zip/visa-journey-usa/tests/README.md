# Tests

Runs the real pages in a headless DOM and asserts the behaviour, rather than
eyeballing it. Every bug fixed during the build has a test here, so a later change
that reintroduces one gets caught.

One dependency:

    npm install jsdom

## Run them

From this folder. Start with the rebuild check: it is the only one that catches a
build script quietly losing a page.

    # clean-room rebuild, no server needed
    python3 rebuild_check.py

    # the source build
    python3 -m http.server 8899 --directory ../src &
    node suite.js ../src/
    kill %1

    # the deploy build, served with clean URLs the way Netlify does
    python3 serve_clean.py ../deploy &
    node suite.js ../deploy/ http://127.0.0.1:8898/
    python3 deploy_checks.py ../deploy
    kill %1

    # the draft cache and the reference email, both need the source build served
    python3 -m http.server 8899 --directory ../src &
    node draft.js ../src/
    node email.js ../src/
    node dates.js ../src/
    node persona.js ../src/
    node scenarios.js ../src/
    kill %1

    # the single-file preview, which needs no server
    node single.js ../preview/visa-journey-usa.html

## What each covers

- `rebuild_check.py` (48 checks) copies the package to a temp directory, deletes
  every generated file, runs all three build scripts, and asserts everything comes
  back byte-identical. This one found two real bugs the day it was written.

- `suite.js` (91 checks) the form's 22 steps and schema rules, typing and Tab and
  click behaviour, the spouse and photo steps, submit and payment handoff, surviving
  a refresh, the resume flow, the payment page, and every site page including the
  contact form.
- `deploy_checks.py` (51 checks) files present, internal links and asset paths,
  robots tags per page, sitemap contents, `netlify.toml`, and a real HTTP fetch of
  every public URL plus the 404.
- `draft.js` (17 checks) a refresh restores what was typed, and the fields that
  must never reach the browser (security answer, passport and ID numbers, the
  photograph) are absent from the stored draft.
- `email.js` (21 checks) the reference-number email is opt-in, validates the
  address, reports failures, and never puts the security answer in the payload.
- `dates.js` (28 checks) every date is a day / month / year control rather than a
  native picker, partial dates never reach the answer data, and impossible dates,
  silly years and future birth dates are all caught. Also covers the standalone year field.
- `persona.js` (31 checks) walks a deliberately awkward applicant through the form:
  a dual Algerian and French national with accented and Arabic-script names, a
  previous refusal, conscript military service, an address with no state, a +213
  phone and a US contact in a territory. This is the suite that catches
  assumptions baked in by a US or western European author.
- `scenarios.js` (22 checks) three more awkward applicants: a single-name
  Indonesian worker applying from a third country with her employer paying, a
  six-year-old whose mother is doing the typing, and a stateless applicant on a
  travel document with no expiry date and no postal address.
- `single.js` (20 checks) the preview file is genuinely self-contained and every
  route, the form, payment and resume all work inside it.

## Why the rebuild check exists

An edit to `build.py` silently deleted the generator for the two legal pages, and
nothing noticed for several rounds of changes, because stale copies of those pages
were sitting in `src/` and being copied through to `deploy/`. The site was correct
by accident. Anyone running `build.py` on a fresh checkout would have lost both
pages.

No test that runs against already-built output can catch that. Run this one after
any change to a build script.

## If a test fails

The name says what broke. The ones most likely to fail after a careless edit are
the input-behaviour checks in section 2 of `suite.js` and the button colour checks
in section 8. Both are guarding fixes explained in the main README under
"Two things not to undo".
