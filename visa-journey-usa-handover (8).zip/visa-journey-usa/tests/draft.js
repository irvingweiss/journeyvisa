const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const BASE = process.argv[3] || 'http://localhost:8899/';
const DIR = process.argv[2] || (__dirname + '/../src/');
let pass=0, fail=0; const bad=[];
const ok=(n,c,d)=>{ if(c){pass++;console.log('  PASS  '+n);} else {fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));} };
const wait = ms => new Promise(r=>setTimeout(r,ms));

/* One shared storage object across both loads, the way a real tab behaves. */
const store = {};
function open(file){
  return new Promise(res=>{
    const errs=[]; const vc=new VirtualConsole();
    vc.on('jsdomError',e=>{const m=e.message||String(e); if(!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);});
    const dom=new JSDOM(fs.readFileSync(DIR+file.split('?')[0],'utf8'),
      {runScripts:'dangerously',resources:'usable',url:BASE+file,virtualConsole:vc,pretendToBeVisual:true});
    // jsdom gives each document its own sessionStorage; share one so a "reload" sees it
    Object.defineProperty(dom.window,'sessionStorage',{configurable:true,value:{
      getItem:k=>k in store?store[k]:null,
      setItem:(k,v)=>{store[k]=String(v);},
      removeItem:k=>{delete store[k];},
      clear:()=>{Object.keys(store).forEach(k=>delete store[k]);}
    }});
    setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);
  });
}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));
const set=(w,el,v,ev)=>{el.value=v; el.dispatchEvent(new w.Event(ev||'input'));};

(async()=>{
 console.log('\nDRAFT CACHE');
 const a = await open('application.html');
 ok('page loads clean', a.errs.length===0, a.errs[0]);
 const sel=a.d.getElementById('securityPrompt'); set(a.w,sel,sel.options[1].value,'change');
 set(a.w,a.d.getElementById('securityAnswer'),'Rex');
 set(a.w,a.d.getElementById('securityAnswerConfirm'),'rex');
 btn(a.d.getElementById('visa-application'),/Create my application/).click();
 await wait(180);
 const ref=(a.d.querySelector('.vj-ref')||{}).textContent;
 ok('application created', !!ref, ref);

 // fill step 2 and leave it half done, no Continue
 set(a.w,a.d.getElementById('surnames'),'OKAFOR');
 set(a.w,a.d.getElementById('givenNames'),'ADA');
 await wait(60);
 const keys=Object.keys(store);
 ok('a draft was written', keys.length>0, keys.join(','));
 ok('no leftover placeholder draft once the reference exists',
    keys.length===1 && keys[0].indexOf(ref)>-1, keys.join(','));
 const saved=JSON.parse(store['vj-draft:'+ref]);
 ok('draft holds the typed answers', saved.data.surnames==='OKAFOR' && saved.data.givenNames==='ADA');
 ok('security answer NOT cached', !('securityAnswer' in saved.data) && !('securityAnswerConfirm' in saved.data));
 ok('no value in the draft looks like an answer to the security question',
    JSON.stringify(saved.data).indexOf('Rex')===-1);

 // now the reload
 const b = await open('application.html?ref='+ref+'&step=1');
 const box=b.d.getElementById('visa-application');
 ok('reload lands on the same step', /Step 2 of 22/.test(box.textContent));
 ok('typed answers came back', (box.querySelector('#surnames')||{}).value==='OKAFOR');
 ok('second answer came back', (box.querySelector('#givenNames')||{}).value==='ADA');
 ok('reference preserved', (b.d.querySelector('.vj-ref')||{}).textContent===ref);
 ok('tells the applicant what was restored', /put back the answers/.test(box.textContent));
 ok('warns that passport and ID were not', /never kept in this browser/.test(box.textContent));
 ok('offers a way to discard it', !!btn(box,/Start this application again/));

 // sensitive fields must not be restorable
 const S=b.w.VJ_SCHEMA.STEPS;
 const iPass=S.findIndex(x=>x.id==='passport');
 const holder=b.d.createElement('div'); b.d.body.appendChild(holder);
 b.w.VisaJourneyForm.mount(holder,{applicationId:ref, draftCache:'session', initialStep:iPass});
 const pn=holder.querySelector('#passportNumber');
 set(b.w,pn,'X1234567');
 await wait(60);
 const after=JSON.parse(store[Object.keys(store)[0]]);
 ok('passport number never reaches the cache', !('passportNumber' in after.data), Object.keys(after.data).filter(k=>/passport/i.test(k)).join(','));
 ok('no data URLs in the cache', JSON.stringify(after.data).indexOf('data:')===-1);

 // discard clears it
 const disc=btn(box,/Start this application again/);
 disc.click(); await wait(80);
 ok('discard wipes the stored draft', Object.keys(store).length===0 || !JSON.parse(store[Object.keys(store)[0]]||'{"data":{}}').data.surnames);

 console.log('\n'+'='.repeat(60));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail) bad.forEach(x=>console.log('  - '+x));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
