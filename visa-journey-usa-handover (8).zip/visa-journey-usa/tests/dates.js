const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const DIR = process.argv[2] || (__dirname + '/../src/');
const BASE = process.argv[3] || 'http://localhost:8899/';
let pass=0, fail=0; const bad=[];
const ok=(n,c,d)=>{ if(c){pass++;console.log('  PASS  '+n);} else {fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));} };
const wait=ms=>new Promise(r=>setTimeout(r,ms));
function open(file){return new Promise(res=>{
  const errs=[]; const vc=new VirtualConsole();
  vc.on('jsdomError',e=>{const m=e.message||String(e); if(!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);});
  const dom=new JSDOM(fs.readFileSync(DIR+file.split('?')[0],'utf8'),
    {runScripts:'dangerously',resources:'usable',url:BASE+file,virtualConsole:vc,pretendToBeVisual:true});
  setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);});}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));

(async()=>{
 console.log('\nDATE OF BIRTH ENTRY');
 const { d, w, errs } = await open('application.html');
 ok('page loads clean', errs.length===0, errs[0]);
 const S = w.VJ_SCHEMA.STEPS;
 const mk=(step,data)=>{const b=d.createElement('div');d.body.appendChild(b);
   w.VisaJourneyForm.mount(b,{initialStep:step,applicationId:'X',initialData:data||{}});return b;};

 const personal = mk(1,{});
 ok('no native date input left anywhere on the step', personal.querySelectorAll('input[type=date]').length===0);
 const dobWrap = personal.querySelector('#dob').closest('.vj-date');
 ok('date of birth renders three controls', !!dobWrap && dobWrap.children.length===3);
 const [day, month, year] = dobWrap.children;
 ok('day is a dropdown of 31 plus a placeholder', day.tagName==='SELECT' && day.options.length===32);
 ok('month is a dropdown of named months', month.tagName==='SELECT' && month.options[1].text==='January');
 ok('year is a typeable text box, not a spinner', year.tagName==='INPUT' && year.getAttribute('type')==='text');
 ok('year accepts four digits', year.getAttribute('maxlength')==='4');
 ok('year uses a numeric keypad on phones', year.getAttribute('inputmode')==='numeric');

 // type a birth year directly
 const fire=(el,ev)=>el.dispatchEvent(new w.Event(ev,{bubbles:true}));
 day.value='07'; fire(day,'change');
 month.value='03'; fire(month,'change');
 year.value='1984'; fire(year,'input');
 await wait(60);
 const api = personal;
 ok('a typed year is kept', api.querySelector('#dob').closest('.vj-date').children[2].value==='1984');

 // the value must reach the answer data in the stored format
 const holder = d.createElement('div'); d.body.appendChild(holder);
 let captured=null;
 const app = w.VisaJourneyForm.mount(holder,{initialStep:1, applicationId:'X'});
 const w2 = holder.querySelector('#dob').closest('.vj-date');
 w2.children[0].value='07'; fire(w2.children[0],'change');
 w2.children[1].value='03'; fire(w2.children[1],'change');
 w2.children[2].value='1984'; fire(w2.children[2],'input');
 await wait(60);
 ok('stored as a plain yyyy-mm-dd string', app.getData().dob==='1984-03-07', app.getData().dob);

 // partial dates must not count as an answer
 const partial = d.createElement('div'); d.body.appendChild(partial);
 const p2 = w.VisaJourneyForm.mount(partial,{initialStep:1, applicationId:'X'});
 const pw = partial.querySelector('#dob').closest('.vj-date');
 pw.children[1].value='03'; fire(pw.children[1],'change');
 await wait(40);
 ok('a month on its own is not stored', p2.getData().dob==='', JSON.stringify(p2.getData().dob));
 ok('the partial choice stays on screen', partial.querySelector('#dob').closest('.vj-date').children[1].value==='03');
 btn(partial,/Continue/).click();
 await wait(40);
 ok('an incomplete date is caught', /Enter the day, the month and the year/.test(partial.textContent));

 // impossible date
 const bogus = mk(1,{ dob:'2000-02-31' });
 btn(bogus,/Continue/).click();
 await wait(40);
 ok('31 February is rejected', /That date does not exist/.test(bogus.textContent));

 // silly year
 const oldy = mk(1,{ dob:'1084-03-07' });
 btn(oldy,/Continue/).click();
 await wait(40);
 ok('a year like 1084 is caught', /Check the year/.test(oldy.textContent));

 // future date of birth still caught by the existing rule
 const future = mk(1,{ dob:'2090-03-07' });
 btn(future,/Continue/).click();
 await wait(40);
 ok('a future date of birth is still rejected', /future|Check the year/.test(future.textContent));

 // existing values round-trip into the three controls
 const restored = mk(1,{ dob:'1984-03-07' });
 const rw = restored.querySelector('#dob').closest('.vj-date');
 ok('a saved date fills all three controls',
    rw.children[0].value==='07' && rw.children[1].value==='03' && rw.children[2].value==='1984',
    [rw.children[0].value, rw.children[1].value, rw.children[2].value].join('/'));

 // every other date field got the same treatment
 let native=0, converted=0;
 S.forEach((st,i)=>{
   const b = mk(i,{ maritalStatus:'Married', specificPlans:'Yes', hasBeenToUs:'Yes', previousVisa:'Yes' });
   native += b.querySelectorAll('input[type=date]').length;
   converted += b.querySelectorAll('.vj-date').length;
 });
 ok('no native date pickers remain in the whole form', native===0, native+' left');
 ok('date fields converted across the form', converted>0, converted+' found');


 // ---- a year asked for on its own
 console.log('\n  standalone year fields');
 const iVisa = S.findIndex(x => (x.fields||[]).some(f => f.id === 'visaLostYear'));
 const vy = mk(iVisa, { hadVisa:'Yes', visaLostStolen:'Yes' });
 const yf = vy.querySelector('#visaLostYear');
 ok('year field exists', !!yf);
 ok('it is a typed box, not a number spinner', yf.getAttribute('type')==='text', yf.getAttribute('type'));
 ok('numeric keypad on phones', yf.getAttribute('inputmode')==='numeric');
 ok('capped at four digits', yf.getAttribute('maxlength')==='4');
 yf.value='20a19x'; yf.dispatchEvent(new w.Event('input',{bubbles:true}));
 await wait(40);
 ok('letters are stripped as you type', vy.querySelector('#visaLostYear').value==='2019', vy.querySelector('#visaLostYear').value);
 const short = mk(iVisa, { hadVisa:'Yes', visaLostStolen:'Yes', visaLostYear:'19' });
 btn(short,/Continue/).click(); await wait(40);
 ok('a two-digit year is refused', /Enter the year in full/.test(short.textContent));
 const wild = mk(iVisa, { hadVisa:'Yes', visaLostStolen:'Yes', visaLostYear:'1084' });
 btn(wild,/Continue/).click(); await wait(40);
 ok('an impossible year is refused', /Check the year/.test(wild.textContent));
 const good = mk(iVisa, { hadVisa:'Yes', visaLostStolen:'Yes', visaLostYear:'2019', visaLostExplanation:'Stolen from a bag in transit.' });
 btn(good,/Continue/).click(); await wait(40);
 ok('a real year passes', !/Check the year|Enter the year/.test(good.textContent));

 // nothing anywhere still asks for a year through a number spinner
 let spinners = 0;
 S.forEach((st,i)=>{
   const b = mk(i, { hadVisa:'Yes', visaLostStolen:'Yes', maritalStatus:'Married', specificPlans:'Yes' });
   b.querySelectorAll('input[type=number]').forEach(n => {
     const lab = n.closest('.vj-field');
     if (lab && /year/i.test(lab.textContent)) spinners++;
   });
 });
 ok('no year is collected through a number spinner', spinners===0, spinners+' left');

 console.log('\n'+'='.repeat(60));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail) bad.forEach(x=>console.log('  - '+x));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
