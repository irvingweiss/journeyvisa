"""Serves the deploy folder the way Netlify does: /about-us -> about-us.html,
404.html for anything missing. Lets us test the real artefact, not an approximation."""
import http.server, os, sys
ROOT = sys.argv[1]

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def translate_path(self, path):
        p = path.split('?')[0].split('#')[0]
        if p == '/': p = '/index.html'
        full = os.path.join(ROOT, p.lstrip('/'))
        if not os.path.exists(full) and os.path.exists(full + '.html'):
            return full + '.html'
        if not os.path.exists(full):
            return os.path.join(ROOT, '404.html')
        return full
    def log_message(self, *a): pass

http.server.HTTPServer(('127.0.0.1', 8898), H).serve_forever()
