/* =====================================================================
   Visa Journey USA — site behaviour
   No dependencies. Everything degrades: with JS off the nav links still
   work and the contact form still submits to whatever action you set.
   ===================================================================== */

(function () {
  "use strict";

  /* Guarded so an older browser without smooth scrolling still completes the
     action rather than throwing halfway through it. */
  function scrollTo(el) {
    if (el && typeof el.scrollIntoView === "function") {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }

  /* ---------------------------------------------------------- nav ---- */

  var toggle = document.getElementById("menu-toggle");
  var mobileNav = document.getElementById("mobile-nav");

  if (toggle && mobileNav) {
    toggle.addEventListener("click", function () {
      var open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", open ? "false" : "true");
      mobileNav.classList.toggle("is-open", !open);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      toggle.setAttribute("aria-expanded", "false");
      mobileNav.classList.remove("is-open");
    });
  }

  /* ------------------------------------------------- contact form ---- */

  var form = document.getElementById("contact-form");
  if (!form) return;

  var success = document.getElementById("contact-success");
  var successEmail = document.getElementById("success-email");
  var again = document.getElementById("send-another");

  var RULES = [
    { id: "c-name", message: "Please enter your name." },
    { id: "c-email", message: "Please enter your email address.", email: true },
    { id: "c-subject", message: "Please choose what this is about." },
    { id: "c-message", message: "Please write your message." }
  ];

  function showError(field, message) {
    var box = document.getElementById("err-" + field.id);
    field.classList.add("invalid");
    field.setAttribute("aria-invalid", "true");
    if (box) { box.textContent = message; box.hidden = false; }
  }

  function clearError(field) {
    var box = document.getElementById("err-" + field.id);
    field.classList.remove("invalid");
    field.removeAttribute("aria-invalid");
    if (box) { box.hidden = true; box.textContent = ""; }
  }

  RULES.forEach(function (rule) {
    var field = document.getElementById(rule.id);
    if (!field) return;
    field.addEventListener("input", function () { clearError(field); });
    field.addEventListener("change", function () { clearError(field); });
  });

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    var firstBad = null;

    RULES.forEach(function (rule) {
      var field = document.getElementById(rule.id);
      if (!field) return;
      var value = field.value.trim();
      clearError(field);

      if (!value) {
        showError(field, rule.message);
        firstBad = firstBad || field;
        return;
      }
      if (rule.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        showError(field, "That does not look like a complete email address.");
        firstBad = firstBad || field;
      }
    });

    if (firstBad) {
      firstBad.focus();
      scrollTo(firstBad);
      return;
    }

    /* ------------------------------------------------------------------
       DEVELOPER: this is where the message goes to your server. Replace
       the block below with a real request, and keep the success state:

         fetch("/api/contact", {
           method: "POST",
           headers: { "Content-Type": "application/json" },
           body: JSON.stringify({
             name: ..., email: ..., reference: ..., subject: ..., message: ...
           })
         }).then(...)

       Validate again on the server and rate limit the endpoint. Client-side
       checks are for the person filling it in, not for security.
       ------------------------------------------------------------------ */

    var email = document.getElementById("c-email").value.trim();
    if (successEmail) successEmail.textContent = email;

    form.hidden = true;
    if (success) {
      success.hidden = false;
      scrollTo(success);
      var heading = success.querySelector("h2");
      if (heading) { heading.setAttribute("tabindex", "-1"); heading.focus(); }
    }
  });

  if (again) {
    again.addEventListener("click", function () {
      form.reset();
      RULES.forEach(function (rule) {
        var field = document.getElementById(rule.id);
        if (field) clearError(field);
      });
      if (success) success.hidden = true;
      form.hidden = false;
      scrollTo(form);
      var first = document.getElementById("c-name");
      if (first) first.focus();
    });
  }
})();
