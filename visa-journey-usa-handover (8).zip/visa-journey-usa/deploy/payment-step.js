/* =====================================================================
   Visa Journey USA — payment step (vanilla JavaScript)
   =====================================================================

   Visually this matches the existing payment page: the three-step header, the
   navy banner, the two-column layout with Payment Information on the left and
   Shopping Cart on the right, the card brand logos, and the green button.

   WHAT IS DIFFERENT, AND WHY

   1. THE CARD FIELDS ARE STRIPE ELEMENTS, NOT PLAIN INPUTS.
      They sit in the same positions and look the same, but each one is an
      iframe served by Stripe. The card number never enters your page, your
      server, or your logs. This is what keeps you on PCI SAQ A (a short
      self-assessment) instead of SAQ D (quarterly scanning, formal policies,
      annual validation), and it makes it impossible to store a CVV by
      accident, which is prohibited outright.

      Call mountCardFields() with your Stripe instance. The mount points are
      #vj-card-number, #vj-card-expiry and #vj-card-cvc.

      If you would rather not use Elements at all, set `hostedRedirect: true`
      and the card area is replaced by a single button that sends the customer
      to Stripe Checkout. Either is fine. Hand-rolled card inputs are not.

   2. THE BUTTON NO LONGER SAYS "OBTAIN YOUR VISA NOW".
      You prepare applications. A consular officer decides the outcome, and can
      refuse regardless of how good the paperwork is. Promising a visa is the
      single riskiest claim on the site.

   3. THE GOVERNMENT FEE IS NOT A GREY ASTERISK.
      It sits in the cart at the same weight as your own fee, with a total, so
      nobody reaches their card details thinking $185 is the whole cost. This
      also cuts chargebacks from customers who felt ambushed.

   4. THE VERISIGN AND "GUARANTEED SAFE CHECKOUT" BADGES ARE NOT INCLUDED.
      VeriSign's seal business passed to Symantec and then DigiCert years ago,
      so that seal is no longer issued and displaying it claims a certification
      that does not exist. The other two are decorative images with no
      certifying body behind them. The slot is still there: pass `sealHtml` to
      drop in a real seal your actual provider issues to you, served from their
      domain so a customer can click it and verify. Card brand logos are fine
      and are included.

   USAGE

     VisaJourneyPayment.mount(document.getElementById("payment"), {
       applicationId: "AB3K9QRTVX",
       serviceFee: 185,
       governmentFee: 185,
       onPay: async ({ nameOnCard, method }) => { ... },   // confirm with Stripe
       onBack: () => history.back(),
       mountCardFields: (nodes) => {
         const elements = stripe.elements();
         elements.create("cardNumber").mount(nodes.number);
         elements.create("cardExpiry").mount(nodes.expiry);
         elements.create("cardCvc").mount(nodes.cvc);
       },
     });
   ===================================================================== */

var VisaJourneyPayment = (function () {
  "use strict";

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k === "html") node.innerHTML = v;
      else if (k.slice(0, 2) === "on") node.addEventListener(k.slice(2).toLowerCase(), v);
      else node.setAttribute(k, v === true ? "" : v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  var STYLE_ID = "vjp-styles";
  var CSS = [
    ".vjp{--navy:#17356b;--navy-line:#1b3a6b;--green:#3ea63e;--green-dark:#348a34;",
    "--ink:#1f2937;--muted:#4b5563;--line:#cbd5e1;--amber:#b45309;--amber-bg:#fffbeb;",
    "font-family:system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:var(--ink);",
    "background:#fff;padding:1.5rem 1rem 4rem;box-sizing:border-box}",
    ".vjp *,.vjp *:before,.vjp *:after{box-sizing:inherit}",
    ".vjp-wrap{max-width:64rem;margin:0 auto}",
    ".vjp-title{text-align:center;font-size:1.5rem;font-weight:400;color:var(--ink);margin:0 0 1.5rem}",
    ".vjp-steps{display:flex;justify-content:center;gap:3rem;flex-wrap:wrap;margin-bottom:1.75rem;padding:0;list-style:none}",
    ".vjp-step{text-align:center}",
    ".vjp-dot{width:2rem;height:2rem;border-radius:999px;display:flex;align-items:center;justify-content:center;",
    "margin:0 auto .5rem;font-size:.875rem;font-weight:600;color:#fff;background:#9ca3af}",
    ".vjp-step.vjp-now .vjp-dot{background:var(--navy)}",
    ".vjp-step p{margin:0;font-size:.875rem;color:var(--muted)}",
    ".vjp-step.vjp-now p{color:var(--navy);font-weight:600}",
    ".vjp-banner{background:var(--navy);color:#fff;text-align:center;padding:1.25rem 1rem;margin-bottom:1.75rem}",
    ".vjp-banner p{margin:0;font-size:1.0625rem;font-weight:600}",
    ".vjp-banner p+p{margin-top:.375rem;font-size:.9375rem;font-weight:400;color:#c7d5ee}",
    ".vjp-cols{display:grid;grid-template-columns:1fr;gap:1.5rem}",
    "@media(min-width:820px){.vjp-cols{grid-template-columns:1.15fr .85fr}}",
    ".vjp-box{border:2px solid var(--navy-line);padding:1.5rem}",
    ".vjp-boxhead{color:var(--navy);font-size:1rem;font-weight:700;letter-spacing:.02em;margin:0 0 1.25rem;text-transform:uppercase}",
    ".vjp-radio{display:flex;gap:.5rem;align-items:center;margin-bottom:1.25rem;cursor:pointer}",
    ".vjp-radio span{font-weight:600;font-size:.9375rem}",
    ".vjp-method{font-weight:600;font-size:.9375rem;color:var(--ink);margin:0 0 1.25rem}",
    ".vjp-disclosure{font-size:.875rem;line-height:1.6;color:var(--ink);margin:1.25rem 0 0}",
    ".vjp-line{display:grid;grid-template-columns:9rem 1fr;gap:1rem;align-items:center;margin-bottom:1rem}",
    "@media(max-width:560px){.vjp-line{grid-template-columns:1fr;gap:.375rem}}",
    ".vjp-line>label{font-size:.9375rem;color:var(--ink)}",
    ".vjp-in{width:100%;border:1px solid var(--line);border-radius:2px;padding:.5rem .625rem;font-size:1rem;",
    "font-family:inherit;background:#fff;color:var(--ink);min-height:2.375rem}",
    ".vjp-in:focus{outline:none;border-color:var(--navy);box-shadow:0 0 0 2px rgba(23,53,107,.25)}",
    ".vjp-pair{display:grid;grid-template-columns:1fr 1fr;gap:1rem}",
    ".vjp-stripe{border:1px solid var(--line);border-radius:2px;padding:.625rem;background:#fff;min-height:2.375rem}",
    ".vjp-stripe.vjp-ready{padding:.5rem .625rem}",
    ".vjp-brands{display:flex;gap:.5rem;margin:.25rem 0 1rem;flex-wrap:wrap}",
    ".vjp-brands img{height:1.5rem;width:auto}",
    ".vjp-brand-fallback{display:inline-flex;align-items:center;justify-content:center;height:1.5rem;padding:0 .5rem;",
    "border:1px solid var(--line);border-radius:2px;font-size:.6875rem;font-weight:700;color:var(--muted);background:#f8fafc}",
    ".vjp-pay{display:block;width:100%;background:var(--green);color:#fff;border:0;padding:1rem;font-size:1.125rem;",
    "font-weight:700;cursor:pointer;font-family:inherit;margin-top:1.25rem}",
    ".vjp-pay:hover{background:var(--green-dark)}",
    ".vjp-pay[disabled]{opacity:.6;cursor:default}",
    ".vjp-cart{display:flex;justify-content:space-between;align-items:baseline;gap:1rem;font-size:1.25rem}",
    ".vjp-cart .vjp-amt{font-weight:600;white-space:nowrap}",
    ".vjp-cartrow{display:flex;justify-content:space-between;align-items:baseline;gap:1rem;",
    "padding:.625rem 0;border-top:1px solid var(--line);font-size:.9375rem}",
    ".vjp-cartrow:first-of-type{border-top:0}",
    ".vjp-total{display:flex;justify-content:space-between;gap:1rem;padding-top:.75rem;margin-top:.25rem;",
    "border-top:2px solid var(--navy-line);font-weight:700;font-size:1.0625rem}",
    ".vjp-seal{margin-top:1.25rem;text-align:center}",
    ".vjp-assure{margin:1.25rem 0 0;padding:0;list-style:none;border-top:1px solid var(--line);padding-top:1rem}",
    ".vjp-assure li{font-size:.8125rem;color:var(--muted);line-height:1.5;margin-bottom:.375rem}",
    ".vjp-note{font-size:.8125rem;color:var(--muted);line-height:1.55;margin:1rem 0 0}",
    ".vjp-consent{display:flex;gap:.625rem;margin:1.25rem 0 0;cursor:pointer}",
    ".vjp-consent span{font-size:.8125rem;line-height:1.55;color:var(--ink)}",
    ".vjp-err{color:#b91c1c;font-size:.875rem;margin:.75rem 0 0}",
    ".vjp-back{background:none;border:0;color:var(--navy);text-decoration:underline;font-size:.875rem;",
    "cursor:pointer;font-family:inherit;padding:0;margin-top:1rem}",
    ".vjp-ref{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:600}",
  ].join("");

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID; s.textContent = CSS;
    document.head.appendChild(s);
  }

  var BRANDS = ["Visa", "Mastercard", "Discover", "Amex"];

  function mount(container, options) {
    options = options || {};
    injectStyles();

    var serviceFee = options.serviceFee == null ? 185 : options.serviceFee;
    /* Still accepted so existing mount calls do not break, but nothing on this
       page renders it since the government fee panel was removed. */
    var governmentFee = options.governmentFee == null ? 185 : options.governmentFee;
    void governmentFee;
    var state = { method: "card", busy: false, error: "", nameFirst: "", nameLast: "" };

    function render() {
      container.className = "vjp";
      container.innerHTML = "";

      /* ---- header ---- */
      var steps = el("ol", { class: "vjp-steps" });
      ["Complete the Form", "Review", "Payment"].forEach(function (label, i) {
        var now = i === 2;
        steps.appendChild(el("li", { class: "vjp-step" + (now ? " vjp-now" : "") }, [
          el("div", { class: "vjp-dot", text: String(i + 1) }),
          el("p", { text: label }),
        ]));
      });

      var banner = el("div", { class: "vjp-banner" }, [
        el("p", { text: "Your payment is processed over a secure, encrypted connection." }),
        el("p", { text: "Complete your preparation fee and we will review your application." }),
      ]);

      /* ---- left column: payment information ---- */
      var left = el("div", { class: "vjp-box" }, [el("p", { class: "vjp-boxhead", text: "Payment Information" })]);

      /* Card is the only method offered, so this is a heading rather than a
         radio. A radio group with one option asks the customer to make a choice
         that does not exist. ACH was removed in September 2026; if it comes
         back, restore the radio group along with it. */
      left.appendChild(el("p", { class: "vjp-method", text: "Credit card payment" }));

      {
        if (options.hostedRedirect) {
          left.appendChild(el("p", { class: "vjp-note", style: "margin-top:0",
            text: "You will be taken to our payment provider to enter your card details securely. We never see or store your card number." }));
        } else {
          /* Name on card is safe to collect here: it is not card data under PCI. */
          var f = el("input", { class: "vjp-in", "aria-label": "First name on card",
            oninput: function () { state.nameFirst = f.value; } });
          var l = el("input", { class: "vjp-in", "aria-label": "Last name on card",
            oninput: function () { state.nameLast = l.value; } });
          f.value = state.nameFirst; l.value = state.nameLast;
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Name on Card" }),
            el("div", { class: "vjp-pair" }, [f, l]),
          ]));

          /* Stripe Elements mount points. Each renders an iframe served by
             Stripe, so the card number never enters this page. */
          var numberNode = el("div", { class: "vjp-stripe", id: "vj-card-number" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Credit Card Number" }), numberNode,
          ]));

          var brands = el("div", { class: "vjp-brands" });
          BRANDS.forEach(function (b) {
            if (options.brandLogos && options.brandLogos[b]) {
              brands.appendChild(el("img", { src: options.brandLogos[b], alt: b }));
            } else {
              brands.appendChild(el("span", { class: "vjp-brand-fallback", text: b.toUpperCase() }));
            }
          });
          left.appendChild(el("div", { class: "vjp-line" }, [el("span", {}), brands]));

          var expiryNode = el("div", { class: "vjp-stripe", id: "vj-card-expiry" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Expiration Date" }), expiryNode,
          ]));

          var cvcNode = el("div", { class: "vjp-stripe", id: "vj-card-cvc", style: "max-width:10rem" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "CCV" }), cvcNode,
          ]));

          if (typeof options.mountCardFields === "function") {
            setTimeout(function () {
              try { options.mountCardFields({ number: numberNode, expiry: expiryNode, cvc: cvcNode }); }
              catch (err) { state.error = "We could not load the secure card fields. Please refresh and try again."; }
            }, 0);
          } else {
            [numberNode, expiryNode, cvcNode].forEach(function (n) {
              n.appendChild(el("span", { style: "color:#9ca3af;font-size:.8125rem",
                text: "Secure field, loaded by payment provider" }));
            });
          }
        }
      }

      /* Stated as a plain disclosure, not a checkbox. The wording still has to
         appear before the pay button, and it still has to say the fee is ours,
         that the government fee is separate, and that nothing is guaranteed. */
      left.appendChild(el("p", { class: "vjp-disclosure",
        text: "This $" + serviceFee + " is a preparation service fee paid to Visa Journey USA. It is separate from the government fees you pay yourself, and it does not guarantee a visa." }));

      var payBtn = el("button", { type: "button", class: "vjp-pay",
        text: state.busy ? "Processing" : "Pay $" + serviceFee + " and Submit",
        onclick: function () {
          state.error = ""; state.busy = true; render();
          Promise.resolve(options.onPay && options.onPay({
            method: state.method,
            nameOnCard: (state.nameFirst + " " + state.nameLast).trim(),
          })).catch(function () {
            state.busy = false;
            state.error = "We could not take the payment. No money has been taken. Please check your details and try again.";
            render();
          });
        } });
      payBtn.disabled = state.busy;
      left.appendChild(payBtn);
      if (state.error) left.appendChild(el("p", { class: "vjp-err", role: "alert", text: state.error }));
      left.appendChild(el("p", { class: "vjp-note",
        text: "Paying this fee does not submit your application to the U.S. government. You must still sign the DS-160 yourself and attend your interview in person." }));

      /* ---- right column: shopping cart ---- */
      var right = el("div", {}, []);
      var cart = el("div", { class: "vjp-box" }, [
        el("div", { class: "vjp-cart" }, [
          el("span", { text: "Visa service fee" }),
          el("span", { class: "vjp-amt", text: "$" + serviceFee }),
        ]),
      ]);

      /* The government fee panel and the combined total were removed at the
         client's request, September 2026. The separation of the two fees is now
         carried by the disclosure sentence above the pay button, by the notice
         bar at the top of every page, and by the site footer. If any of those
         three ever go, this panel needs to come back: nothing else on this page
         tells the customer the government fee exists. */

      if (options.sealHtml) {
        cart.appendChild(el("div", { class: "vjp-seal", html: options.sealHtml }));
      }

      /* Only claims that can be substantiated. See the note at the top of this
         file about the badges that were here before. */
      cart.appendChild(el("ul", { class: "vjp-assure" }, [
        el("li", { text: "Payments handled by a PCI-compliant payment provider" }),
        el("li", { text: "Card details are never stored on our servers" }),
        el("li", { text: "Refund terms are set out in our Terms and Conditions" }),
      ]));

      right.appendChild(cart);
      if (options.applicationId) {
        right.appendChild(el("p", { class: "vjp-note" }, [
          "Application ", el("span", { class: "vjp-ref", text: options.applicationId }),
        ]));
      }
      if (typeof options.onBack === "function") {
        right.appendChild(el("button", { type: "button", class: "vjp-back", text: "Back to review", onclick: options.onBack }));
      }

      container.appendChild(el("div", { class: "vjp-wrap" }, [
        el("h1", { class: "vjp-title", text: "Prepare your visa application in 3 easy steps" }),
        steps, banner,
        el("div", { class: "vjp-cols" }, [left, right]),
      ]));
    }

    render();
    return { setBusy: function (v) { state.busy = v; render(); },
             setError: function (m) { state.error = m; state.busy = false; render(); } };
  }

  return { mount: mount };
})();

if (typeof module !== "undefined" && module.exports) module.exports = VisaJourneyPayment;
