# Visa Journey USA — developer handover

Static site. No framework, no build step, no dependencies. Plain HTML, one CSS
file, and three JavaScript files. It runs on any static host.

---

## What is in this package

    deploy/     Upload this. Production-ready, clean URLs, headers, sitemap.
    src/        The same site with relative links, plus the build scripts.
    preview/    One self-contained HTML file. For showing people, not for hosting.
    tests/      330 automated checks. Run them before and after any change.

The tests are not decoration. Several of them guard fixes that look like tidy-up
candidates to anyone who was not here, and the two listed at the bottom of this
file have already been reintroduced once each.

If you only read one other file, read `deploy/DEPLOY.md`.

---

## Deploying

Drag the `deploy` folder onto Netlify. Not the zip, not the files individually.
`netlify.toml` is read automatically, so nothing needs configuring in the dashboard.

If it goes into Git instead:

    Build command:      (leave empty)
    Publish directory:  deploy

For any other host: serve `deploy/` as the document root and turn on extensionless
URL resolution, so `/about-us` serves `about-us.html`. Netlify does this by default.
On nginx it is `try_files $uri $uri.html $uri/ =404;`.

---

## Pages

    /                        homepage
    /about-us
    /contact-us              form, client-side validation only
    /application             the 21-section DS-160 form
    /payment                 preparation fee, hands off to your payment provider
    /resume                  get back into an application in progress
    /terms-and-conditions    plain-English summary, full text still to be pasted in
    /privacy-policy          same
    404.html                 Netlify serves this automatically

`/payment` and `/resume` are `noindex` and are deliberately absent from the sitemap.

---

## The three JavaScript files

**`visa-application-form.js`** is the application form. It exposes two functions:

    VisaJourneyForm.mount(element, options)
    VisaJourneyForm.mountResume(element, options)

It styles itself, holds all 21 sections and their conditional logic, and keeps
nothing in localStorage or sessionStorage. Passport and ID numbers do not survive
a page close, which is deliberate: shared and stolen devices are a real risk for
this audience. That also means an unsaved step is genuinely lost, so
`onSaveStep` has to reject when a write fails.

**`payment-step.js`** is the fee screen. `VisaJourneyPayment.mount(element, options)`.

**`site.js`** is the mobile menu and the contact form. Nothing else.

---

## What you need to build

### 1. Four endpoints for the form

Open `application.html` and `resume.html` and look for `var DEMO = true`. While
that is true, reference numbers are generated in the browser and nothing is stored.
Fine for review, wrong for real applicants: every one of them loses their answers.

Flip it to false and the `fetch` calls beside it take over. They expect:

    POST /api/application
      in:   { securityPrompt, securityAnswer }
      out:  { applicationId }
      Hash the answer with bcrypt or argon2. Never store it in plain text.
      The form drops it from memory as soon as this resolves.

    PATCH /api/application/:id
      in:   { applicationId, stepId, data }
      out:  204
      Must return non-2xx on a failed write. The form shows "Could not save"
      and keeps the answers on screen, which is the whole safety net.

    POST /api/application/submit
      in:   the full answer set
      out:  200

    GET /api/application/:id
      out:  { applicationId, data, stepIndex }  when the session is valid
            401 or 403 when it is not
      This is what makes a browser refresh survivable. The page keeps the
      reference and step in the URL, then asks for the answers back. Authorise
      it with the session you set on create or resume, never with the
      reference number alone: the reference is not a secret, it is printed on
      screen and emailed.

    POST /api/application/lookup
      in:   { applicationId }
      out:  { securityPrompt }

    POST /api/application/resume
      in:   { applicationId, answer }
      out:  { applicationId, data, stepIndex }
      This one has to return the saved answers, not just a success flag.
      `data` is the same shape onSaveStep has been receiving, and `stepIndex`
      is where they left off. The widget hands all three to the form and
      reopens it in place. Return 401 for a wrong answer, and put
      attemptsRemaining on the error body to have the count shown.

Rate limit `lookup` and `resume`. Those two are what someone would hammer to guess
a reference number. Lock an application after a handful of failed answers.

Resuming deliberately needs this round trip: nothing is kept in browser storage, so
the server is the only place the saved answers exist.

### 2. The contact form

`site.js` validates and shows a success state without sending anything. Either:

- Netlify Forms: add `netlify` and `name="contact"` to the `<form>` tag in
  `contact-us.html` and remove the `preventDefault` in `site.js`. Submissions
  appear in the Netlify dashboard. No backend at all.
- Or point it at your own endpoint. Validate again server side and rate limit it.

### 3. Payment

`payment.html` currently runs in hosted-redirect mode, so no card fields are on the
page. `onPay` shows a preview message instead of charging anything.

Create the payment intent or checkout session server side and redirect from `onPay`.
Never trust an amount sent from the browser. To use Stripe Elements inline instead
of a redirect, drop `hostedRedirect` and pass `mountCardFields`; the commented
example is in `payment.html`.

---

## Before it goes live

- **Remove `noindex,nofollow`.** The current production site sends it on every page.
  These files send `index,follow`, so if the tag survives the switch it is being
  injected by a layout or a header somewhere. Nothing can rank until it is gone.
- ~~Host the hero image locally.~~ Done. The hotlinked photograph 404'd, so it is
  now `hero.svg`, a 4 KB flat vector in the site's palette with no external
  dependency. Swap in a photograph if you prefer, but keep it local and 4:3.
- **Fill in the three `EDIT:` markers.** Grep for them. They are the registered legal
  entity in the footer, the service fee figure, and the support hours.
- **Paste the real legal copy** into `terms-and-conditions.html` and
  `privacy-policy.html`. Both currently carry an honest plain-English summary and a
  marked block where the full text belongs.
- Update the date in `sitemap.xml` when the pages change.

---

## Refreshing the page

Answers are never written to browser storage, so a refresh cannot restore them from
the browser. Instead:

- The form reports its position, and `application.html` keeps it in the URL as
  `?ref=ABC123&step=7` via `replaceState`.
- On load with a `ref`, the page asks `GET /api/application/:id` for the saved
  answers and reopens at the saved step.
- If that returns 401 or 403, the person goes to `/resume?ref=ABC123` with the
  reference already filled in, so it is one security question rather than a lost
  application.
- A `beforeunload` guard warns before a refresh throws away edits made since the
  last Continue, since only completed steps reach the server.

### Emailing the reference number

Optional, offered on the screen where the number is issued, and only sent if the
applicant types an address and presses the button. It is wired to:

    POST /api/application/email-reference
      in:   { applicationId, email, kind: "reference" }
      out:  200

**It does not send anything yet.** `DEMO = true` means the button is wired to a
callback that deliberately fails with "no email was actually sent", so nobody is
shown a confirmation for mail that never left. Flip `DEMO` and build the endpoint
and it starts working with no other change. The same applies to the resume link
behind "Save and finish later".

Two rules for whoever writes that endpoint:

- **The email contains the reference number and nothing else.** Never the security
  answer. Those two together are the whole credential, and the form explicitly tells
  applicants not to send them in one message. Sending them one ourselves would be
  worse than pointless.
- **Rate limit it.** An open send endpoint keyed on an application id is a way to
  post mail to strangers.

Delete the `onEmailReference` callback from `application.html` and the option
disappears from the screen. There is also `onRequestResumeLink`, used by the
"Save and finish later" link, which emails a link back into the application. That
one only works once the applicant has reached the step where their email address is
collected, and the form now says so rather than doing nothing.

### The draft cache

There is also a browser-side cache, so a refresh puts the answers back immediately
without waiting on the server. `application.html` and `resume.html` switch it on with
`draftCache: "session"`. Set it to `"none"` to turn it off.

It uses sessionStorage, never localStorage: it belongs to one tab and is gone when
that tab closes, so nothing is left sitting on a shared machine.

These are never written to it, whatever the setting, and the list is in
`visa-application-form.js` as `NEVER_CACHED`:

- the security answer and its confirmation
- passport number and passport book number, including inside the other-nationality rows
- national ID, US SSN, US taxpayer ID
- the photograph

Those are the fields that make a borrowed or stolen device genuinely dangerous, and
they each take seconds to retype. The form says so on screen when it restores a
draft, and offers a button to throw the draft away. The draft is deleted on submit.

Do not add passport or ID numbers to that cache to make resuming smoother. The
server round trip exists for exactly that.

Until `GET /api/application/:id` exists, the cache is the only thing restoring
answers, and only within the same tab. Close the tab and they are gone. That is
still the single biggest reason not to leave `DEMO = true` on a live site.

## Applicants who are not American or western European

A form like this quietly assumes things: that names are ASCII, that addresses have
a state, that a phone number has no country code, that everyone holds one
nationality. `tests/persona.js` walks an Algerian applicant with a complicated case
through the whole form to catch those. Five real problems came out of the first run
and are fixed:

- **Accented names.** Aïcha and Benoît were rejected with "Numbers are not accepted
  here", which is both wrong and useless. They are still rejected, because the
  DS-160 wants English characters, but the message now names accents as the cause
  and points at the machine-readable strip on the passport photo page, which holds
  the exact spelling to type. Arabic or other non-Latin script gets a third message
  pointing at the native-alphabet field. Names beginning with an apostrophe, like
  'Abd Allah, were rejected outright and now pass.
- **US territories.** Guam, the US Virgin Islands, American Samoa and the Northern
  Mariana Islands were missing from the state lists, so an applicant whose US
  contact lives in any of them could not complete the step.
- **Phone formats.** Only one of eight phone fields said to include the country
  dialling code. All of them do now, and the US contact field says to use a US
  number.
- **Dual nationality.** Someone holding Algerian and French nationality can usually
  travel on an ESTA with no interview, no MRV fee and no fee to us. The form now
  says so when a second passport is from a Visa Waiver country, and sends them to
  travel.state.gov to check. That list changes: re-check it yearly. The comment in
  the code says the same.
- **Email confirmation** was a text field, so phones offered the wrong keyboard.

## Applicants who are children

The DS-160 is explicit about this and we were not. Under 16, a parent or legal
guardian signs; at 16 or 17 the applicant signs but a parent may help. Our
certification said "I confirm that the answers above are true and correct", which a
six-year-old cannot agree to and which left the parent unsure whose name they had
just put to it.

The review step now works out the applicant's age from the date of birth and shows
the right guidance, and the certification wording changes to cover a parent or
guardian answering on the applicant's behalf. Consent text may now be a function of
the answers, which is how that switch is done.

## Date entry

Every date in the form is three controls, day and month as dropdowns and the year
as a typed four-digit box, matching what the DS-160 does. Native
`<input type="date">` is not used anywhere.

The reason is the date of birth. A browser date picker opens on the current month
and expects the applicant to scroll back forty years, and on several browsers the
year segment resists being typed into once a value is set. Applicants could not
reach their own birth year.

The composed value is still stored as a plain `yyyy-mm-dd` string under the same
key, so saving, validation, the review screen and the submit payload are unchanged.
Half-entered dates are held in the widget rather than the answer data, so a lone
month never reaches the server or counts as an answer.

Where the form asks for a year on its own, `type: "year"` gives the same typed
four-digit box rather than a number spinner whose arrows step one year at a time.
It strips non-digits as you type and rejects a partial year, a year before 1900 and
anything more than 25 years ahead. Use it for any year field added later.

## Photo handling

`/application` step 21 takes a passport-style photograph. It is read in the browser,
checked against the DS-160 rules (JPEG, square, 600 to 1200 pixels a side, under
240 KB) and held in state as a data URL.

That means it arrives in the `onSubmit` payload as `photo`, with `photoName`,
`photoBytes`, `photoWidth` and `photoHeight` beside it. Decode the base64 and write
it to file storage. Do not leave a data URL sitting in a database column.

Like every other answer, it is not written to localStorage, so closing the tab loses
it. That is deliberate.

## Two things not to undo

Both are marked with comments in the files. Both were bugs that got fixed, and both
look like tidy-up candidates to someone who was not here.

**In `site.css`:** the button rules carry a `.vj-site` prefix. Most buttons on this
site are anchors, and `.vj-site a` sets a link colour at a higher specificity than a
bare `.btn-primary`. Strip the prefix and the filled buttons go back to dark teal
text on a teal background.

**In `visa-application-form.js`:** free-text, date and number inputs write to
state through `setSmart`. It updates the value, clears any error on that field in
place, and repaints **only when the step's visible or required fields actually
change**, which it works out by comparing a fingerprint of the step before and
after. Selects, yes/no controls and checkboxes still repaint every time, because
they drive most of the branching.

That conditional repaint is the whole fix for three separate symptoms, all of
which came from destroying and rebuilding the DOM during a user gesture:

- typing lost focus after every character
- Tab did not move to the next field
- clicking from one field into another needed a second click, because the node
  being clicked into was rebuilt between mousedown and mouseup
- date fields could not be filled at all, since a date input fires `input` on
  every segment and the picker closed each time

`render()` also wraps `paint()` to restore focus and caret position for the
repaints that do still happen. Keep both.
Selects and yes/no controls must keep repainting immediately, because conditional
branches depend on them.

---

## Rebuilding

Only if you change the shared header or footer. They live in `src/build.py` rather
than being copy-pasted into eight files.

    cd src
    python3 build.py      # regenerates the eight pages
    python3 deploy.py     # rebuilds ../deploy with clean URLs and headers
    python3 bundle.py     # rebuilds the single-file preview

If you are moving this into a real templating system, `build.py` is the spec for
what the shared chrome contains.
