#!/usr/bin/env python3
"""Assembles the Visa Journey USA site. Shared chrome lives here so the six pages
cannot drift apart. Run: python3 build.py"""

import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = HERE
os.makedirs(OUT, exist_ok=True)

NAV = [
    ("index.html", "Home"),
    ("about-us.html", "About"),
    ("contact-us.html", "Contact"),
]

MARK = """<svg class="mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
  <rect x="1" y="1" width="30" height="30" rx="9" fill="#0f766e"/>
  <circle cx="16" cy="16" r="8.5" fill="none" stroke="#ffffff" stroke-width="1.4" stroke-dasharray="2.2 2.2"/>
  <path d="M11.5 16.6l3 3 6-6.6" fill="none" stroke="#ffffff" stroke-width="1.9"
        stroke-linecap="round" stroke-linejoin="round"/>
</svg>"""

DISCLAIMER = """<div class="notice-bar">
  <div class="wrap">
    <p><strong>Visa Journey USA is a private preparation service.</strong> We are not affiliated with, endorsed by, or connected to the U.S. Department of State or any government agency. You can apply directly at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a> and pay only the government fee. Our fee is separate, and is charged for preparing and reviewing your application. We do not influence, expedite, or guarantee any visa decision.</p>
  </div>
</div>"""


def header(active):
    links = "".join(
        '<a href="%s"%s>%s</a>' % (h, ' aria-current="page"' if h == active else "", t)
        for h, t in NAV
    )
    mobile = "".join('<a href="%s">%s</a>' % (h, t) for h, t in NAV)
    return f"""{DISCLAIMER}
<header class="site-header">
  <div class="header-in wrap">
    <a class="brand" href="index.html">{MARK}<span class="brand-name">Visa Journey <em>USA</em></span></a>
    <nav class="nav" aria-label="Main">
      {links}
      <a class="btn btn-primary btn-sm" href="application.html">Start your application</a>
    </nav>
    <button class="menu-btn" type="button" id="menu-toggle" aria-expanded="false" aria-controls="mobile-nav">
      <span class="menu-bars" aria-hidden="true"></span>
      <span class="sr-only">Menu</span>
    </button>
  </div>
  <nav class="mobile-nav" id="mobile-nav" aria-label="Main, mobile">
    {mobile}
    <a href="terms-and-conditions.html">Terms and conditions</a>
    <a href="privacy-policy.html">Privacy policy</a>
    <a class="btn btn-primary" href="application.html">Start your application</a>
  </nav>
</header>"""


FOOTER = """<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="brand brand-light" href="index.html">""" + MARK + """<span class="brand-name">Visa Journey <em>USA</em></span></a>
        <p class="footer-blurb">A private preparation and review service for U.S. B1/B2 visitor visa applications.</p>
      </div>

      <div>
        <h2>Service</h2>
        <ul>
          <li><a href="application.html">Start your application</a></li>
          <li><a href="index.html#how-it-works">How it works</a></li>
          <li><a href="index.html#faq">Common questions</a></li>
          <li><a href="resume.html">Return to an application</a></li>
        </ul>
      </div>

      <div>
        <h2>Company</h2>
        <ul>
          <li><a href="about-us.html">About us</a></li>
          <li><a href="contact-us.html">Contact us</a></li>
          <li><a href="terms-and-conditions.html">Terms and conditions</a></li>
          <li><a href="privacy-policy.html">Privacy policy</a></li>
        </ul>
      </div>

      <div>
        <h2>Get in touch</h2>
        <!-- EDIT: add the registered legal entity name and state of registration on the
             line below, plus a phone number if you have one. -->
        <address>
          Visa Journey USA<br>
          1175 West Broadway, Suite 33<br>
          Hewlett, NY 11557<br>
          <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a>
        </address>
      </div>
    </div>

    <div class="footer-legal">
      <p>Visa Journey USA is a private preparation and review service. We are not a law firm, we do not provide legal advice, and we are not affiliated with, endorsed by, or connected to the U.S. Department of State, U.S. Citizenship and Immigration Services, or any other government agency.</p>
      <p>You can complete and submit a visa application yourself at no cost beyond the government fee at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a>. Our fee is charged for preparation and review and is separate from any government fee. We do not influence, expedite, or guarantee the outcome of any visa application.</p>
      <p class="copyright">&copy; 2026 Visa Journey USA. All rights reserved.</p>
    </div>
  </div>
</footer>

<script src="site.js" defer></script>"""


def page(slug, title, description, body, active=None, extra_head="", robots="index,follow"):
    active = active or slug
    html = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{description}">
<link rel="canonical" href="https://www.visajourneyusa.com/{'' if slug == 'index.html' else slug.replace('.html','')}">
<meta name="robots" content="{robots}">

<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:type" content="website">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="site.css">
{extra_head}
</head>
<body class="vj-site">
{header(active)}
<main id="main">
{body}
</main>
{FOOTER}
</body>
</html>
"""
    open(os.path.join(OUT, slug), "w").write(html)
    return slug


# ----------------------------------------------------------------- icons
def icon(paths):
    return ('<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
            'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" '
            'aria-hidden="true">%s</svg>' % paths)

ICONS = {
    "guide": icon('<path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2z"/>'
                  '<path d="M9.6 9a2.4 2.4 0 0 1 4.7.5c0 1.6-2.4 2.4-2.4 2.4"/>'
                  '<path d="M12 14.6h.01"/>'),
    "review": icon('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/>'
                   '<path d="M14 3v5h5"/><path d="M9 14.5l2 2 4-4.5"/>'),
    "prepare": icon('<rect x="5" y="4" width="14" height="17" rx="2"/>'
                    '<path d="M9 4V3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v1"/>'
                    '<path d="M9 10h6"/><path d="M9 14h6"/><path d="M9 18h3"/>'),
    "steps": icon('<path d="M3 20h5v-5"/><path d="M9.5 20h5v-9"/><path d="M16 20h5V6"/>'),
    "support": icon('<rect x="2.5" y="5" width="19" height="14" rx="2"/>'
                    '<path d="M3 7l9 6 9-6"/>'),
    "interview": icon('<circle cx="12" cy="8" r="3.5"/>'
                      '<path d="M4.5 20a7.5 7.5 0 0 1 12-6"/>'
                      '<path d="M15.5 18.5l1.8 1.8 3.2-3.6"/>'),
}


# ----------------------------------------------------------------- homepage
services = [
    ("guide", "Questions in plain language",
     "Every question on the form rewritten so it reads like a person asking, with an explanation beside the ones that most often catch people out."),
    ("review", "A real review before you file",
     "We read your answers and documents for gaps, contradictions and omissions, then come back to you with specific questions rather than a checklist."),
    ("prepare", "Accurate the first time",
     "Dates, names and addresses checked against each other, so the application is not held up by an inconsistency you would never have spotted."),
    ("steps", "Stop and start whenever",
     "Short sections that save as you finish them. Come back later with your reference number and pick up exactly where you left off."),
    ("support", "A person on the other end",
     "Email support from someone on our team who has seen your application, not a script and not a chatbot."),
    ("interview", "Ready for the interview",
     "What to expect at the consulate, which documents to bring, and the questions applicants in your situation are usually asked."),
]

service_cards = "\n".join(f"""      <article class="card">
        <span class="card-icon">{ICONS[k]}</span>
        <h3>{h}</h3>
        <p>{p}</p>
      </article>""" for k, h, p in services)

steps = [
    ("Answer the questions",
     "You work through the application in short sections. Your answers save as you finish each one, and a reference number lets you come back at any time."),
    ("We review what you entered",
     "Our team reads it properly. Anything incomplete, inconsistent or likely to raise a question comes back to you with a plain explanation of why."),
    ("You confirm before anything is filed",
     "Nothing is submitted without your explicit sign-off. The application is signed under penalty of perjury, so the answers have to be yours."),
    ("You go to the interview prepared",
     "We send the document list for your situation and what to expect on the day. The interview and the decision are between you and the consulate."),
]

step_items = "\n".join(f"""        <li>
          <h3>{h}</h3>
          <p>{p}</p>
        </li>""" for h, p in steps)

faqs = [
    ("Are you part of the U.S. government?",
     "No. Visa Journey USA is a private company with no affiliation to the Department of State or any other agency. You can apply on your own at travel.state.gov and pay only the government fee. We are an optional service for people who would rather have help."),
    ("Can you guarantee my visa will be approved?",
     "No, and nobody can. The decision rests entirely with a consular officer. What we can do is make sure your application is complete, accurate and consistent, which removes the avoidable reasons an application gets delayed or sent back."),
    ("Can you get me a faster interview appointment?",
     "No. Appointment availability is set by the consulate, and we have no ability to move it. Anyone claiming otherwise is selling something they do not have."),
    ("What exactly am I paying you for?",
     "Preparation and review. Our fee covers the guided application, the review of your answers and documents, and support by email through the process. It does not include the government fee, which you pay directly to the government."),
    ("What happens to my passport details?",
     "They are used to prepare your application and nothing else. Nothing is stored in your browser, so a shared or stolen device does not expose them. You can ask us to delete your information at any point."),
    ("What if I decide I do not need the service?",
     "Contact us. If you have not started, there is nothing to cancel. If you have, our refund terms are set out in the terms and conditions, and we will talk it through with you."),
]

faq_items = "\n".join(f"""        <details class="faq-item">
          <summary><span>{q}</span></summary>
          <div class="faq-body"><p>{a}</p></div>
        </details>""" for q, a in faqs)

JSONLD = """<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "name": "Visa Journey USA",
  "description": "Private preparation and review service for U.S. B1/B2 visitor visa applications. Not affiliated with any government agency.",
  "url": "https://www.visajourneyusa.com/",
  "email": "support@visajourneyusa.com",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "1175 West Broadway, Suite 33",
    "addressLocality": "Hewlett",
    "addressRegion": "NY",
    "postalCode": "11557",
    "addressCountry": "US"
  },
  "areaServed": "Worldwide"
}
</script>"""

home_body = f"""
  <section class="hero">
    <div class="wrap hero-in">
      <div class="hero-copy">
        <h1>The U.S. visitor visa form, explained as you fill it in.</h1>
        <p class="lede">The B1/B2 form asks for a lot, in language that was not written for you. We take you through it in plain English and check the whole thing before you rely on it.</p>
        <div class="btn-row">
          <a class="btn btn-primary" href="application.html">Start your application</a>
          <a class="btn btn-quiet" href="#how-it-works">See how it works</a>
        </div>
        <ul class="hero-facts">
          <li>About 30 minutes, across as many sittings as you like</li>
          <li>Reviewed by a person before anything is filed</li>
        </ul>
      </div>

      <div class="hero-visual">
        <div class="hero-frame">
          <img src="hero.svg" alt="An application form beside a passport, with an approval stamp"
               width="800" height="600" fetchpriority="high">
        </div>
      </div>
    </div>
  </section>

  <section class="section" id="what-we-do">
    <div class="wrap">
      <div class="section-head">
        <h2>What the service actually covers</h2>
        <p class="lede">Six things we can do, and nothing we cannot.</p>
      </div>
      <div class="card-grid">
{service_cards}
      </div>
    </div>
  </section>

  <section class="section band" id="how-it-works">
    <div class="wrap">
      <div class="section-head">
        <h2>How it works</h2>
        <p class="lede">Four stages. You keep control of your own application the whole way through.</p>
      </div>
      <ol class="steps">
{step_items}
      </ol>
    </div>
  </section>

  <section class="section soft" id="faq">
    <div class="wrap faq-in">
      <div class="section-head">
        <h2>Questions people ask before they pay</h2>
        <p class="lede">Including the ones with answers you might not want to hear.</p>
      </div>
      <div class="faq-list">
{faq_items}
      </div>
    </div>
  </section>

  <section class="cta">
    <div class="wrap">
      <h2>Ready when you are.</h2>
      <p>Most people finish in about half an hour, spread over a few sittings. Nothing is submitted until you say so.</p>
      <a class="btn btn-light" href="application.html">Start your application</a>
    </div>
  </section>
"""

page("index.html",
     "Visa Journey USA | B1/B2 visitor visa preparation and review",
     "A private preparation and review service for U.S. B1/B2 visitor visa applications. Guided questions through the whole B1/B2 form, and a real review before you file.",
     home_body, extra_head=JSONLD)


# ----------------------------------------------------------------- about
about_body = """
  <section class="page-head">
    <div class="wrap narrow">
      <h1>About us</h1>
      <p class="lede">We help travellers prepare and review their U.S. B1/B2 visitor visa applications. We are a private service, not a government agency and not a law firm.</p>
    </div>
  </section>

  <section class="section">
    <div class="wrap narrow">
      <h2>Who we are</h2>
      <p class="p">Visa Journey USA is an independent preparation service based in the United States. We work with visitors from around the world who are planning a trip to the U.S. for tourism, to see family, or for temporary business.</p>
      <p class="p">We have no affiliation with the U.S. Department of State or any other government agency, and we do not represent ourselves as one. You can always apply directly at travel.state.gov and pay only the official fee. What we offer is a clearer, guided way to get through the same application, for people who would rather not do it alone.</p>

      <div class="pull">
        <p>We would rather tell you the service is wrong for you than take a fee you did not need to pay. If you do not need a visa, or you need a category we do not handle, we will say so.</p>
      </div>
    </div>
  </section>

  <section class="section soft">
    <div class="wrap narrow">
      <h2>What we do</h2>
      <p class="p">The visa application asks for a great deal of detail, and small errors or omissions cause delays that were entirely avoidable. Our service covers:</p>
      <ul class="list">
        <li>Guidance through every part of the application, in plain language</li>
        <li>A review of your answers and documents for completeness and accuracy</li>
        <li>Explanations of the questions that most often confuse applicants</li>
        <li>Preparation for your visa interview</li>
      </ul>
      <p class="p">We help you prepare and organise. The decision on any visa rests solely with the U.S. Department of State, and we never promise, expedite or guarantee a particular outcome. What we can promise is care, accuracy, and clear support through the process.</p>
    </div>
  </section>

  <section class="section">
    <div class="wrap narrow">
      <h2>What we hold ourselves to</h2>
      <div class="mini-grid">
        <div class="mini">
          <h3>Clarity</h3>
          <p>A dense, technical form turned into something you can actually follow without a lawyer beside you.</p>
        </div>
        <div class="mini">
          <h3>Accuracy</h3>
          <p>Your answers are read carefully before you rely on them, not after a problem appears.</p>
        </div>
        <div class="mini">
          <h3>Honesty</h3>
          <p>We are direct about what we do, what we charge, and what only a consular officer can decide.</p>
        </div>
        <div class="mini">
          <h3>Care with your data</h3>
          <p>Passport and ID details are used to prepare your application and nothing else, and are never stored in your browser.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section soft">
    <div class="wrap narrow">
      <h2>Our commitment on fees</h2>
      <p class="p">Support should not come at the cost of transparency. Our service fee is separate from, and in addition to, the government's application fee, and we make that distinction clear before you pay rather than in the small print afterwards.</p>
      <p class="p">You can read the detail in our <a href="privacy-policy.html">privacy policy</a> and <a href="terms-and-conditions.html">terms and conditions</a>.</p>
    </div>
  </section>

  <section class="cta">
    <div class="wrap">
      <h2>Ready to begin?</h2>
      <p>If you would like guided support preparing your U.S. travel visa application, we are here to help.</p>
      <a class="btn btn-light" href="application.html">Start your application</a>
    </div>
  </section>
"""

page("about-us.html", "About us | Visa Journey USA",
     "Visa Journey USA is a private, independent preparation and review service for U.S. B1/B2 visitor visa applications. What we do, what we charge, and what only the government decides.",
     about_body)


# ----------------------------------------------------------------- contact
contact_body = """
  <section class="page-head">
    <div class="wrap">
      <h1>Contact us</h1>
      <p class="lede">Questions about an application already in progress, or about whether the service is right for you before you pay. Either is welcome.</p>
    </div>
  </section>

  <section class="section contact-section">
    <div class="wrap contact-in">
      <div class="form-card">
        <form id="contact-form" novalidate>
          <div class="field">
            <label for="c-name">Your name<span class="req" aria-hidden="true">*</span></label>
            <input type="text" id="c-name" name="name" autocomplete="name" required>
            <p class="err" id="err-c-name" role="alert" hidden></p>
          </div>

          <div class="field">
            <label for="c-email">Email address<span class="req" aria-hidden="true">*</span></label>
            <input type="email" id="c-email" name="email" autocomplete="email" required>
            <p class="hint">We reply to this address, so please check it before sending.</p>
            <p class="err" id="err-c-email" role="alert" hidden></p>
          </div>

          <div class="field">
            <label for="c-reference">Reference number</label>
            <input type="text" id="c-reference" name="reference" autocomplete="off" spellcheck="false" class="mono">
            <p class="hint">If you have already started an application this helps us find it. Leave it blank if you have not.</p>
          </div>

          <div class="field">
            <label for="c-subject">What is this about?<span class="req" aria-hidden="true">*</span></label>
            <select id="c-subject" name="subject" required>
              <option value="">Select one</option>
              <option>A question before I start</option>
              <option>An application I have already started</option>
              <option>Billing or a refund</option>
              <option>Deleting my information</option>
              <option>Something else</option>
            </select>
            <p class="err" id="err-c-subject" role="alert" hidden></p>
          </div>

          <div class="field">
            <label for="c-message">Your message<span class="req" aria-hidden="true">*</span></label>
            <textarea id="c-message" name="message" rows="6" required></textarea>
            <p class="hint">Please do not include your passport number, national ID number or any password in this message.</p>
            <p class="err" id="err-c-message" role="alert" hidden></p>
          </div>

          <button class="btn btn-primary btn-block" type="submit">Send message</button>
          <p class="form-foot">We use what you send here only to answer you. See our <a href="privacy-policy.html">privacy policy</a>.</p>
        </form>

        <div class="form-success" id="contact-success" hidden>
          <span class="success-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>
          </span>
          <h2>Message sent</h2>
          <p>Thank you. We have your message and will reply to <strong id="success-email"></strong>. If it is about an application already in progress, keep your reference number handy.</p>
          <button class="btn btn-quiet" type="button" id="send-another">Send another message</button>
        </div>
      </div>

      <aside class="contact-aside">
        <div class="info-card">
          <h2>Email</h2>
          <p><a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a></p>

          <h2>Post</h2>
          <p>1175 West Broadway, Suite 33<br>Hewlett, NY 11557<br>United States</p>

          <!-- EDIT: set your real hours and response time, or remove this block. -->
          <h2>When we reply</h2>
          <p>Monday to Friday, 9am to 6pm Eastern. We normally answer within one business day.</p>
        </div>

        <div class="warn-card">
          <h2>We will never ask for a password</h2>
          <p>Not by email, not on the phone, and never the answer to your security question. If a message claiming to be from us asks for either, it is not from us. Forward it to the address above.</p>
        </div>
      </aside>
    </div>
  </section>
"""

page("contact-us.html", "Contact us | Visa Journey USA",
     "Contact Visa Journey USA about a B1/B2 visa application in progress, or with a question before you start. Email support@visajourneyusa.com or use the form.",
     contact_body)


# ----------------------------------------------------------------- application
app_body = """
  <section class="app-head">
    <div class="wrap">
      <h1>Your application</h1>
      <p class="lede">Short sections, saved as you go. You get a reference number on the first screen, and that is how you come back to it later.</p>
    </div>
  </section>

  <section class="widget-band">
    <div class="wrap">
      <div id="visa-application"></div>
      <noscript>
        <div class="app-fallback">
          <h2>This form needs JavaScript</h2>
          <p class="p">Turn it on and reload, or email <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a> and we will send you the questions another way.</p>
        </div>
      </noscript>
      <div class="app-fallback" id="app-fallback" hidden>
        <h2>The form did not load</h2>
        <p class="p">Reload the page, and if it happens again email <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a>.</p>
        <p class="p"><strong>Developer:</strong> <code>visa-application-form.js</code> is missing from the site root, or it failed to parse.</p>
      </div>
    </div>
  </section>

  <script src="visa-application-form.js"></script>
  <script>
  (function () {
    var mountEl = document.getElementById("visa-application");
    var fallback = document.getElementById("app-fallback");

    if (typeof window.VisaJourneyForm === "undefined") { fallback.hidden = false; return; }

    /* ==================================================================
       DEVELOPER: flip DEMO to false once the endpoints below exist.
       While it is true, nothing is stored anywhere and reference numbers
       are generated in the browser. Fine for review, wrong for real
       applicants: every one of them would lose their answers.
       ================================================================== */
    var DEMO = true;

    function post(url, payload) {
      return fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }).then(function (r) {
        if (!r.ok) throw new Error("request failed");
        return r.status === 204 ? null : r.json();
      });
    }

    function param(name) {
      var m = new RegExp("[?&]" + name + "=([^&]*)").exec(window.location.search);
      return m ? decodeURIComponent(m[1]) : "";
    }

    /* In demo mode nothing is sent, so the form must not show a confirmation.
       Rejecting with userMessage puts the truth on screen instead. Delete this
       along with the DEMO flag once the mail endpoint is live. */
    function demoNotSent() {
      var e = new Error("demo mode: no email sent");
      e.userMessage = "Demo mode: no email was actually sent. Wire the email endpoint on the server to enable this.";
      return e;
    }

    /* ------------------------------------------------------------------
       Surviving a refresh.

       Answers are never kept in browser storage, so the page cannot restore
       them on its own. What it can do is keep the reference number and the
       step in the URL, so a refresh knows exactly where the person was. The
       answers come back from the server, which already has every completed
       step from onSaveStep.

       Refresh with a live session  -> the application reopens where it was.
       Refresh with no session      -> off to /resume with the reference
                                       prefilled, so it is one question, not
                                       a lost application.
       ------------------------------------------------------------------ */
    function rememberPosition(pos) {
      if (!pos.applicationId || !window.history || !window.history.replaceState) return;
      var url = window.location.pathname + "?ref=" + encodeURIComponent(pos.applicationId) +
                "&step=" + pos.stepIndex;
      /* Browsers refuse replaceState on file:// and in some sandboxed frames.
         Losing the URL is a small thing; throwing mid-form is not. */
      try { window.history.replaceState(null, "", url); } catch (err) {}
    }

    var callbacks = {
      paymentUrl: "payment.html",
      onStepChange: rememberPosition,

      /* ----------------------------------------------------------------
         Refresh recovery in the browser.

         "session" keeps answers in sessionStorage so a reload puts them back
         immediately, with no server involved. It belongs to one tab and dies
         when that tab closes, so nothing is left behind on a shared machine.

         Passport numbers, national ID and SSN, the security answer and the
         photograph are never written there, whatever this is set to. Those are
         the fields that make a borrowed device dangerous, and they take seconds
         to retype. The form says so on screen when it restores a draft.

         Set to "none" to turn it off entirely. Once the API is live, the server
         becomes the real source and this is only covering the gap between one
         step's save and the next.
         ---------------------------------------------------------------- */
      draftCache: "session",

      onCreateApplication: function (payload) {
        if (DEMO) {
          return Promise.resolve({
            applicationId: "DEMO" + Math.random().toString(36).slice(2, 8).toUpperCase()
          });
        }
        /* Server hashes securityAnswer with bcrypt or argon2 and returns
           { applicationId }. Never store the answer in plain text. */
        return post("/api/application", payload);
      },

      onSaveStep: function (payload) {
        if (DEMO) return Promise.resolve();
        /* Must reject on a failed write. The applicant then sees
           "Could not save" and keeps their answers on screen. */
        return fetch("/api/application/" + encodeURIComponent(payload.applicationId), {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }).then(function (r) { if (!r.ok) throw new Error("save failed"); });
      },

      onSubmit: function (data) {
        if (DEMO) return Promise.resolve();
        /* data includes the photograph as a data URL under `photo`, with
           photoName, photoBytes, photoWidth and photoHeight beside it. Decode
           and store it as a file server side rather than leaving base64 in a
           database column. */
        return post("/api/application/submit", data);
      },

      onRequestResumeLink: function (payload) {
        if (DEMO) return Promise.reject(demoNotSent());
        return post("/api/application/resume-link", payload);
      },

      /* Optional. Offered on the screen where the reference number is issued,
         and only sent if the applicant types an address and presses the button.

         The email must contain the reference number and nothing else. Never the
         security answer: putting both in one message hands the whole credential
         to anyone who can read that mailbox, and the form tells applicants not
         to do exactly that.

         Rate limit it. An open send endpoint keyed on an application id is a
         way to post mail to strangers.

         Delete this callback and the option disappears from the screen. */
      onEmailReference: function (payload) {
        if (DEMO) return Promise.reject(demoNotSent());
        return post("/api/application/email-reference", payload);
      }
    };

    function start(extra) {
      var opts = {};
      Object.keys(callbacks).forEach(function (k) { opts[k] = callbacks[k]; });
      Object.keys(extra || {}).forEach(function (k) { opts[k] = extra[k]; });

      var app = VisaJourneyForm.mount(mountEl, opts);

      /* A refresh mid-step throws away whatever has been typed since the last
         Continue, because only completed steps reach the server. Worth one
         browser prompt. */
      window.addEventListener("beforeunload", function (e) {
        if (!app.hasUnsavedEdits || !app.hasUnsavedEdits()) return;
        e.preventDefault();
        e.returnValue = "";
      });
      return app;
    }

    var ref = param("ref");
    var step = parseInt(param("step"), 10);

    if (!ref) { start(); return; }

    if (DEMO) {
      /* No server to ask, so the step is honoured and the answers are not.
         Say so rather than showing empty fields with no explanation. */
      start({ applicationId: ref, initialStep: isNaN(step) ? 0 : step });
      return;
    }

    /* GET the saved answers using whatever session the server set when the
       application was created or resumed. A 401 means the session is gone,
       which is the normal case on a fresh browser, not an error. */
    fetch("/api/application/" + encodeURIComponent(ref), { credentials: "same-origin" })
      .then(function (r) {
        if (r.status === 401 || r.status === 403) {
          window.location.replace("resume.html?ref=" + encodeURIComponent(ref));
          return null;
        }
        if (!r.ok) throw new Error("could not load");
        return r.json();
      })
      .then(function (saved) {
        if (!saved) return;
        start({
          applicationId: saved.applicationId || ref,
          initialData: saved.data || {},
          initialStep: typeof saved.stepIndex === "number" ? saved.stepIndex
                     : (isNaN(step) ? 0 : step)
        });
      })
      .catch(function () {
        window.location.replace("resume.html?ref=" + encodeURIComponent(ref));
      });
  })();
  </script>
"""

page("application.html", "Start your application | Visa Journey USA",
     "Begin your U.S. B1/B2 visitor visa application. Short sections, saved as you go, with a reference number so you can come back at any time.",
     app_body, active="application.html")


# ----------------------------------------------------------------- payment
payment_body = """
  <section class="app-head">
    <div class="wrap">
      <h1>Payment</h1>
      <p class="lede">Your preparation fee. The government fee is separate and is paid directly to the government when you book your interview.</p>
    </div>
  </section>

  <section class="widget-band">
    <div class="wrap">
      <div id="payment"></div>
      <div class="app-fallback" id="pay-fallback" hidden>
        <h2>The payment page did not load</h2>
        <p class="p">Reload the page, and if it happens again email <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a> before trying again. Do not send card details by email.</p>
      </div>
    </div>
  </section>

  <script src="payment-step.js"></script>
  <script>
  (function () {
    var mountEl = document.getElementById("payment");
    if (typeof window.VisaJourneyPayment === "undefined") {
      document.getElementById("pay-fallback").hidden = false;
      return;
    }

    var ref = (function () {
      var m = /[?&]ref=([^&]+)/.exec(window.location.search);
      return m ? decodeURIComponent(m[1]) : "";
    })();

    VisaJourneyPayment.mount(mountEl, {
      applicationId: ref,

      /* EDIT: confirm both figures. serviceFee is what you charge.
         governmentFee is the published MRV fee and is shown for comparison
         only, so nobody thinks our fee is the whole cost. */
      serviceFee: 185,
      governmentFee: 185,

      /* Hosted redirect means the card fields are not on this page at all.
         To use Stripe Elements inline instead, drop hostedRedirect and pass
         mountCardFields:

           mountCardFields: function (nodes) {
             var elements = stripe.elements();
             elements.create("cardNumber").mount(nodes.number);
             elements.create("cardExpiry").mount(nodes.expiry);
             elements.create("cardCvc").mount(nodes.cvc);
           }

         Either way the card number never touches this page or your server. */
      hostedRedirect: true,

      onBack: function () { window.location.href = "application.html"; },

      onPay: function () {
        /* DEVELOPER: create the payment intent or checkout session server
           side and redirect. Never trust an amount sent from the browser. */
        mountEl.innerHTML =
          '<div class="app-fallback" style="text-align:center">' +
          "<h2>This is a preview</h2>" +
          '<p class="p" style="margin-left:auto;margin-right:auto">No payment was taken and no card details were collected. ' +
          "Wire this to your payment provider before the site goes live.</p>" +
          '<p style="margin-top:1.5rem"><a class="btn btn-quiet" href="index.html">Back to the homepage</a></p>' +
          "</div>";
        window.scrollTo({ top: 0, behavior: "smooth" });
        return Promise.resolve();
      }
    });
  })();
  </script>
"""

page("payment.html", "Payment | Visa Journey USA",
     "Pay the Visa Journey USA preparation fee. The government MRV fee is separate and is paid directly to the U.S. government.",
     payment_body, active="application.html", robots="noindex,follow")


# ------------------------------------------------------------------ resume
resume_body = """
  <section class="app-head">
    <div class="wrap">
      <h1>Return to your application</h1>
      <p class="lede">Enter your reference number and answer your security question to pick up where you left off.</p>
    </div>
  </section>

  <section class="widget-band">
    <div class="wrap">
      <div id="resume"></div>
      <div class="app-fallback" id="resume-fallback" hidden>
        <h2>This page did not load</h2>
        <p class="p">Reload it, and if it happens again email <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a> with your reference number.</p>
      </div>
    </div>
  </section>

  <script src="visa-application-form.js"></script>
  <script>
  (function () {
    var mountEl = document.getElementById("resume");
    if (typeof window.VisaJourneyForm === "undefined") {
      document.getElementById("resume-fallback").hidden = false;
      return;
    }

    /* Same flag as application.html. See that file for what each endpoint owes. */
    var DEMO = true;

    function post(url, payload) {
      return fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }).then(function (r) {
        if (!r.ok) throw new Error(r.status === 401 ? "That answer did not match." : "request failed");
        return r.json();
      });
    }

    function param(name) {
      var m = new RegExp("[?&]" + name + "=([^&]*)").exec(window.location.search);
      return m ? decodeURIComponent(m[1]) : "";
    }

    /* In demo mode nothing is sent, so the form must not show a confirmation.
       Rejecting with userMessage puts the truth on screen instead. Delete this
       along with the DEMO flag once the mail endpoint is live. */
    function demoNotSent() {
      var e = new Error("demo mode: no email sent");
      e.userMessage = "Demo mode: no email was actually sent. Wire the email endpoint on the server to enable this.";
      return e;
    }
    var prefill = param("ref");

    VisaJourneyForm.mountResume(mountEl, {

      /* Arriving here after a refresh: the reference is already known, so only
         the security question is left to answer. */
      applicationId: prefill,
      intro: prefill
        ? "For your security we do not keep your answers in this browser, so we need your security question again before reopening your application."
        : "Enter your reference number and answer your security question to pick up where you left off.",

      onLookup: function (payload) {
        if (DEMO) return Promise.resolve({ securityPrompt: "What was the name of your first pet?" });
        /* Returns { securityPrompt } for a known reference number. Rate limit
           this: it is the endpoint someone would use to guess at references. */
        return post("/api/application/lookup", payload);
      },

      /* This is the one that matters. Returning nothing, or returning only a
         success flag, leaves the applicant staring at a button that appears to
         do nothing. It has to return the saved answers:

             { applicationId, data, stepIndex }

         data is the same shape that onSaveStep has been receiving. stepIndex is
         where they left off. The widget hands all three straight to the form. */
      onResume: function (payload) {
        if (DEMO) {
          return Promise.resolve({
            applicationId: payload.applicationId,
            stepIndex: 2,
            data: {
              surnames: "OKAFOR", givenNames: "ADA", sex: "Female",
              maritalStatus: "Married", nationality: "NIGERIA"
            }
          });
        }
        /* Compare against the stored hash, count failed attempts, and lock the
           application after a handful. Reject with an error carrying
           attemptsRemaining and the widget will show the count. */
        return post("/api/application/resume", payload);
      },

      /* Passed through to the form once it reopens, so a resumed application
         saves and submits exactly like a fresh one. */
      paymentUrl: "payment.html",
      draftCache: "session",

      onSaveStep: function (payload) {
        if (DEMO) return Promise.resolve();
        return fetch("/api/application/" + encodeURIComponent(payload.applicationId), {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }).then(function (r) { if (!r.ok) throw new Error("save failed"); });
      },

      onSubmit: function (data) {
        if (DEMO) return Promise.resolve();
        return post("/api/application/submit", data);
      },

      onEmailReference: function (payload) {
        if (DEMO) return Promise.reject(demoNotSent());
        return post("/api/application/email-reference", payload);
      }
    });
  })();
  </script>
"""

page("resume.html", "Return to your application | Visa Journey USA",
     "Come back to a Visa Journey USA application already in progress using your reference number and security question.",
     resume_body, active="application.html", robots="noindex,follow")


# ----------------------------------------------------------------- legal
def legal(slug, title, h1, summary_intro, points, note):
    items = "\n".join("        <li>%s</li>" % p for p in points)
    body = f"""
  <section class="page-head">
    <div class="wrap narrow">
      <h1>{h1}</h1>
      <p class="meta">Last updated 1 September 2026</p>
    </div>
  </section>

  <section class="section">
    <div class="wrap narrow">
      <h2>In short</h2>
      <p class="p">{summary_intro}</p>
      <ul class="list">
{items}
      </ul>

      <div class="pull">
        <p>{note}</p>
      </div>

      <!-- ==========================================================
           EDIT: paste the full existing policy text below this line.
           Use <h2> for section headings, <p class="p"> for paragraphs
           and <ul class="list"> for lists, and it will match.
           ========================================================== -->

      <h2>Full policy</h2>
      <p class="p">The complete text of this policy is being finalised with counsel and will appear here. In the meantime, email <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a> with any question about it and we will answer directly.</p>
    </div>
  </section>
"""
    page(slug, title,
         "The %s for Visa Journey USA, a private preparation and review service for U.S. B1/B2 visitor visa applications." % h1.lower(),
         body)


legal("terms-and-conditions.html", "Terms and conditions | Visa Journey USA",
      "Terms and conditions",
      "The plain-English version of what you are agreeing to when you use this service. The full text follows below.",
      ["We provide preparation, review and support. We do not submit anything without your confirmation.",
       "We are not a government agency and not a law firm, and we do not give legal advice.",
       "Our fee is for our work and is separate from the government fee, which you pay directly to the government.",
       "We cannot guarantee, influence or expedite a visa decision, and we make no promise about any outcome.",
       "The answers on your application are yours. You are responsible for their accuracy, and the form is signed under penalty of perjury.",
       "You can ask us to stop work and delete your information at any point."],
      "If anything below conflicts with something a member of our team has told you, tell us. We would rather fix the wording than argue about it later.")

legal("privacy-policy.html", "Privacy policy | Visa Journey USA",
      "Privacy policy",
      "What we collect, why we have it, and what we do not do with it. The full text follows below.",
      ["We collect the information you enter on the application, plus your name and email so we can reach you.",
       "We use it to prepare and review your application. We do not sell it and we do not use it for advertising.",
       "Nothing is stored in your browser. Passport and ID numbers do not survive on a shared or stolen device.",
       "Payments are handled by our payment processor. We never see or store full card numbers.",
       "You can ask for a copy of your information, or ask us to delete it, by emailing us.",
       "We will never ask you for a password or the answer to your security question by email or phone."],
      "If you want your information deleted, email us and say so. You do not need to give a reason, and it does not affect anything else.")


print("built:", sorted(os.listdir(OUT)))
