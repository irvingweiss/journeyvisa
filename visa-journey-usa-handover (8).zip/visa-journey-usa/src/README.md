# src

The site with relative links, so it works from a folder without a server. Open
`index.html` directly.

Shared header and footer live in `build.py`, not in the eight page files. Edit
them there and re-run the scripts, or the pages drift apart.

    python3 build.py      regenerates the eight pages in this folder
    python3 deploy.py     rebuilds ../deploy for hosting
    python3 bundle.py     rebuilds ../preview/visa-journey-usa.html

Everything else is explained in the README one level up.
