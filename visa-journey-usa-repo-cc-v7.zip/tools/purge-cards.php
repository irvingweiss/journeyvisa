<?php
/* Delete stored card numbers whose retention period has ended.
 *
 *   php tools/purge-cards.php
 *
 * Run it daily from cron, for example:
 *
 *   15 3 * * *  php /path/to/visa-journey-usa/tools/purge-cards.php
 *
 * A card number is deleted card_retention_days after it was saved (90 unless
 * config.php says otherwise) if nobody has recorded a charge for it.
 * Recording a charge deletes it straight away. The API also runs this purge
 * on its own now and then, so a missed cron run is not a leak, but cron is
 * what makes the retention period a promise rather than a likelihood.
 *
 * Prints how many numbers were deleted. Never prints card data: it never
 * decrypts anything.
 */
if (PHP_SAPI !== 'cli') { fwrite(STDERR, "Run this from the command line.\n"); exit(1); }

require __DIR__ . '/../api/lib/Http.php';
require __DIR__ . '/../api/lib/Config.php';
require __DIR__ . '/../api/lib/Db.php';
require __DIR__ . '/../api/lib/CardVault.php';

$configFile = __DIR__ . '/../api/config.php';
if (!is_file($configFile)) {
    fwrite(STDERR, "No api/config.php. See step 3 of INSTALL.md.\n");
    exit(1);
}
$cfg = Config::load($configFile);

try {
    $db = Db::pdo($cfg);
} catch (Throwable $e) {
    /* Not the driver's message, which quotes the DSN. */
    fwrite(STDERR, "Could not connect to the database with the settings in api/config.php.\n");
    exit(1);
}

try {
    $n = CardVault::purgeExpired($db);
} catch (Throwable $e) {
    fwrite(STDERR, "The purge failed and nothing was deleted: " . get_class($e) . ".\n"
        . "Check that schema.migrations.sql has been run (card_vault must exist).\n");
    exit(1);
}
echo gmdate('Y-m-d H:i:s') . " UTC  deleted $n expired card number" . ($n === 1 ? '' : 's') . "\n";
