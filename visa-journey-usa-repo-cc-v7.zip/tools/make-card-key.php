<?php
/* Generate the master key for stored card numbers (CARD_KEY).
 *
 *   php tools/make-card-key.php
 *
 * Prints a new random key: 32 bytes from the operating system's secure random
 * source, base64 encoded. Put it in the server's environment as CARD_KEY, and
 * keep one copy in a password manager only the owner can open. Never in the
 * repository, config.php under version control, a ticket, an email or a chat.
 *
 * Run it ONCE. A second run makes a different key, and cards saved under the
 * first one can only be read with the first one. To rotate on purpose, see
 * card_previous_keys in api/config.example.php.
 *
 * The same key can be made without PHP:  openssl rand -base64 32
 */
if (PHP_SAPI !== 'cli') { fwrite(STDERR, "Run this from the command line.\n"); exit(1); }

$key = base64_encode(random_bytes(32));

echo "\nCARD_KEY=$key\n\n";
echo "Set that in the server environment, for the PHP process that runs the API:\n";
echo "  Apache:   SetEnv CARD_KEY \"...\"   in the vhost (not in a file under the web root)\n";
echo "  PHP-FPM:  env[CARD_KEY] = \"...\"   in the pool config, then reload php-fpm\n";
echo "  cPanel / Plesk: the environment variables screen for this site\n";
echo "Then keep one copy in a password manager. Lose it and the stored card\n";
echo "numbers cannot be read; applicants would have to enter their cards again.\n\n";
