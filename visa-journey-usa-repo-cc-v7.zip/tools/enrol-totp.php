<?php
/* Enrol the second factor and print the recovery codes.
 *
 *   php tools/enrol-totp.php
 *
 * Run once. It prints a secret for the environment, a URI to scan, and ten
 * recovery codes, then writes the hashed recovery codes to the database.
 */
if (PHP_SAPI !== 'cli') { fwrite(STDERR, "Run this from the command line.\n"); exit(1); }

require __DIR__ . '/../api/lib/Http.php';
require __DIR__ . '/../api/lib/Config.php';
require __DIR__ . '/../api/lib/Db.php';
require __DIR__ . '/../api/lib/Totp.php';

/* Say what is missing rather than dying in a require with a stack trace. */
$configFile = __DIR__ . '/../api/config.php';
if (!is_file($configFile)) {
    fwrite(STDERR, "No api/config.php yet. Copy api/config.example.php to\n"
        . "api/config.php and fill in the database details first (step 3 of\n"
        . "INSTALL.md).\n");
    exit(1);
}
/* Config::load, not a bare require. Reading config.php directly meant this
   tool got no defaults, so a config that omitted db_user and db_pass produced
   "Undefined array key" notices and then connected with nulls -- and the
   failure was reported as "check dsn, db_user and db_pass", pointing at the
   one thing that was fine. */
$cfg = Config::load($configFile);

try {
    $db = Db::pdo($cfg);
} catch (Throwable $e) {
    /* Not $e->getMessage(): a PDO connection error quotes the DSN back, and
       this is the one tool whose output people paste into chat windows. */
    fwrite(STDERR, "Could not connect to the database with the settings in\n"
        . "api/config.php. Check dsn, db_user and db_pass, and that the\n"
        . "schema has been loaded.\n");
    exit(1);
}

$secret = Totp::generateSecret();
$account = $cfg['admin_email'] ?: 'admin@visajourneyusa.com';
$uri = Totp::uri($secret, $account, 'Visa Journey USA');

echo "\n1. Put this in the server environment (never in the repository):\n\n";
echo "   TOTP_SECRET=$secret\n";
echo "\n2. Add it to your authenticator app. Either scan a QR code made from\n";
echo "   this URI, or type the secret in by hand:\n\n";
echo "   $uri\n";
echo "\n3. Check it works before you rely on it. The code right now is: "
   . Totp::at($secret, intdiv(time(), 30)) . "\n";

/* Any codes from a previous enrolment stop working now.
 *
 * They used to be left in place, so running this a second time -- which is
 * exactly what you do after losing the phone -- left twenty live codes, ten of
 * them printed on a screen you no longer trust. An audit found it. The whole
 * point of re-enrolling is that the old factor is gone. */
$existing = (int) $db->query(
    'SELECT COUNT(*) FROM admin_recovery_codes WHERE used_at IS NULL'
)->fetchColumn();

/* All of it in one transaction. Revoking the old codes and writing the ten new
 * ones have to stand or fall together: a failure halfway used to leave the
 * admin with ten codes on screen, some smaller number stored, and the old ones
 * already gone. */
$codes = [];
try {
    $db->beginTransaction();

    /* Only the unused ones. The used rows are the record of which codes were
       spent and are worth keeping; deleting them loses that history. */
    if ($existing > 0) {
        $db->exec('DELETE FROM admin_recovery_codes WHERE used_at IS NULL');
    }

    /* The replay marker, or a code from the new secret landing on a step below
       the old marker would be refused as reused. Created if it is missing:
       Admin::verifyCode cannot tell a missing row from a used step, so an
       absent row means every correct code is refused forever. */
    $st = $db->prepare('UPDATE admin_state SET last_totp_step = 0 WHERE id = 1');
    $st->execute();
    if ($st->rowCount() === 0
        && (int) $db->query('SELECT COUNT(*) FROM admin_state WHERE id = 1')
                    ->fetchColumn() === 0) {
        $db->exec('INSERT INTO admin_state (id, last_totp_step) VALUES (1, 0)');
        echo "\n   (admin_state had no row. Created it.)\n";
    }

    $ins = $db->prepare(
        'INSERT INTO admin_recovery_codes (code_hash, used_at) VALUES (?, NULL)'
    );
    for ($i = 0; $i < 10; $i++) {
        $code = strtolower(bin2hex(random_bytes(5)));
        $codes[] = $code;
        $ins->execute([password_hash($code, PASSWORD_BCRYPT)]);
    }

    $db->commit();
} catch (Throwable $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    /* Again not the driver's message, which quotes the DSN. */
    fwrite(STDERR, "\nSomething went wrong writing the recovery codes, and\n"
        . "nothing was changed. The old codes and the old secret still work.\n"
        . "Check the database and run this again.\n");
    exit(1);
}

if ($existing > 0) {
    echo "\n   (Revoked $existing unused recovery code"
       . ($existing === 1 ? '' : 's') . " from an earlier enrolment. Any you\n"
       . "   wrote down before now no longer work.)\n";
}

echo "\n4. Recovery codes. Each works once, in the same box as the six digits.\n";
echo "   Shown now and never again; only their hashes are stored.\n";
echo "   Keep them somewhere that is NOT the phone with the authenticator app:\n";
echo "   there is one admin account, so losing the phone without these locks\n";
echo "   the only login out of the site.\n\n";
foreach ($codes as $c) { echo "   $c\n"; }
echo "\n";
