<?php
/* Visa Journey USA — the API, end to end.
 *
 * Starts the real API on a throwaway SQLite database and drives every endpoint
 * over HTTP, the way the browser does. No framework, no composer, no MySQL
 * server: it needs PHP with pdo_sqlite and nothing else, so it runs on the
 * developer's laptop and on the server.
 *
 *     php tests/api_test.php
 *
 * Exits non-zero on the first failure, so it can gate a deploy.
 *
 * The SQLite schema is translated from schema.mysql.sql at run time rather than
 * kept as a second copy. A column added to the real schema and forgotten here
 * would otherwise pass this test and fail in production.
 *
 * What it does NOT cover: MySQL-specific behaviour. It is portability proof and
 * logic proof, not a substitute for running the curl checks in INSTALL.md
 * against the real server once.
 */

declare(strict_types=1);

$root = dirname(__DIR__);

/* ---------------------------------------------------------------- harness */

$passed = 0;
$failed = 0;

function ok(string $what): void
{
    global $passed;
    $passed++;
    echo "  ok    $what\n";
}

function bad(string $what, string $detail = ''): void
{
    global $failed;
    $failed++;
    echo "  FAIL  $what\n";
    if ($detail !== '') {
        echo "        $detail\n";
    }
}

function is_same(string $what, $expected, $actual): void
{
    if ($expected === $actual) {
        ok($what);
    } else {
        bad($what, 'expected ' . var_export($expected, true)
            . ', got ' . var_export($actual, true));
    }
}

function is_true(string $what, $actual): void
{
    $actual ? ok($what) : bad($what, 'expected truthy, got ' . var_export($actual, true));
}

function section(string $name): void
{
    echo "\n$name\n";
}

/* Read one row, and CLOSE THE CURSOR.
 *
 * Not fussiness. An open SELECT cursor holds a shared read lock on the SQLite
 * file, and the API server is a single-threaded php -S writing to the same
 * file: it blocks on the next INSERT, the request never answers, and the
 * failure turns up as a timeout in whatever section runs next rather than
 * here. That cost an hour. MySQL, which this runs on in production, has no
 * such interaction. */
function row(PDO $db, string $sql, array $args = []): ?array
{
    $st = $db->prepare($sql);
    $st->execute($args);
    $out = $st->fetch();
    $st->closeCursor();
    return $out === false ? null : $out;
}

function rows(PDO $db, string $sql, array $args = []): array
{
    $st = $db->prepare($sql);
    $st->execute($args);
    $out = $st->fetchAll();
    $st->closeCursor();
    return $out;
}

function value(PDO $db, string $sql, array $args = [])
{
    $st = $db->prepare($sql);
    $st->execute($args);
    $out = $st->fetchColumn();
    $st->closeCursor();
    return $out;
}

/* ------------------------------------------------- the throwaway database */

/** Translate the MySQL schema to SQLite. Types only; the logic is portable. */
function sqlite_schema(string $mysql): string
{
    $out = [];
    foreach (explode("\n", $mysql) as $line) {
        $trimmed = trim($line);
        /* Index declarations inside CREATE TABLE: SQLite wants them separate,
           and an index changes no result, so drop them. */
        if (preg_match('/^INDEX\s/i', $trimmed) || preg_match('/^KEY\s/i', $trimmed)) {
            continue;
        }
        $out[] = $line;
    }
    $sql = implode("\n", $out);

    $sql = preg_replace('/BIGINT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY/i',
        'INTEGER PRIMARY KEY AUTOINCREMENT', $sql);
    $sql = preg_replace('/\)\s*ENGINE=\w+\s+DEFAULT\s+CHARSET=\w+\s*;/i', ');', $sql);
    $sql = preg_replace('/\bLONGTEXT\b/i', 'TEXT', $sql);
    $sql = preg_replace('/\bVARCHAR\(\d+\)/i', 'TEXT', $sql);
    $sql = preg_replace('/\bTINYINT\(1\)/i', 'INTEGER', $sql);
    $sql = preg_replace('/\bDECIMAL\(\d+,\d+\)/i', 'REAL', $sql);
    $sql = preg_replace('/\bDATETIME\b/i', 'TEXT', $sql);
    $sql = preg_replace('/\bDATE\b/i', 'TEXT', $sql);
    /* A trailing comma left behind by a dropped INDEX line. */
    $sql = preg_replace('/,(\s*\))/', '$1', $sql);
    /* The append-only triggers on card_reveal_log. MySQL's one-statement
       body is SIGNAL; SQLite's is RAISE inside BEGIN ... END. Translated
       rather than dropped, so the suite proves the log refuses UPDATE and
       DELETE. */
    $sql = preg_replace(
        "/FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = ('[^']*');/i",
        'FOR EACH ROW BEGIN SELECT RAISE(ABORT, $1); END;', $sql);
    return $sql;
}

/* Sweep anything an earlier run left behind. A run killed with SIGKILL cannot
   clean up after itself, and each leftover directory holds a config.php with
   the generated admin hash and TOTP secret. They also used to satisfy the
   route-coverage check: the directory name is keyed on the pid, @mkdir
   tolerates an existing one, and server.log was opened in append mode, so a
   recycled pid made the PREVIOUS run's requests count as this run's coverage.
   An audit demonstrated that with a single pre-seeded log line. */
foreach ((array) glob(sys_get_temp_dir() . '/vj-api-test-*') as $stale) {
    if (is_dir($stale) && time() - (int) @filemtime($stale) > 3600) {
        exec('rm -rf ' . escapeshellarg($stale));
    }
}

$tmp = sys_get_temp_dir() . '/vj-api-test-' . getmypid();
exec('rm -rf ' . escapeshellarg($tmp));
@mkdir($tmp, 0700, true);
/* And start this run's log empty, so coverage is this run's requests only. */
foreach ((array) glob($tmp . '/server*.log') as $stale) {
    @file_put_contents($stale, '');
}
@file_put_contents($tmp . '/server.log', '');
$dbFile = $tmp . '/test.sqlite';
$photoDir = $tmp . '/photos';
@mkdir($photoDir, 0700, true);

$schemaSql = sqlite_schema(file_get_contents($root . '/schema.mysql.sql'));
try {
    $seed = new PDO('sqlite:' . $dbFile, null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $seed->exec($schemaSql);
} catch (Throwable $e) {
    echo "Could not build the test database.\n" . $e->getMessage() . "\n";
    echo "\nTranslated schema was:\n$schemaSql\n";
    exit(2);
}
unset($seed);

/* ------------------------------------------------------- the test config */

$adminEmail = 'manager@example.com';
$adminPassword = 'correct horse battery staple';
$adminHash = password_hash($adminPassword, PASSWORD_BCRYPT, ['cost' => 4]);

require $root . '/api/lib/Totp.php';
$totpSecret = Totp::generateSecret();

$origin = 'https://test.local';

/* A real key, generated per run, for the card routes. */
$cardKey = base64_encode(random_bytes(32));

/* VJ_STRINGIFY=1 makes PDO hand back every column as a string, which is what
 * PHP 7.4 does for SQLite and Postgres and for MySQL with emulated prepares.
 * The suite is meant to pass both ways: run it twice. Without this, testing on
 * a modern PHP only ever exercises native integers, and a `=== 1` against a
 * column that arrives as '1' in production would sail through. */
$stringify = getenv('VJ_STRINGIFY') === '1' ? 'true' : 'false';

$config = <<<PHP
<?php
return [
    'dsn'      => 'sqlite:$dbFile',
    'db_user'  => null,
    'db_pass'  => null,
    'admin_email'         => '$adminEmail',
    'admin_password_hash' => '$adminHash',
    'totp_secret'         => '$totpSecret',
    'admin_fail_limit'   => 5,
    'admin_fail_window'  => 900,
    'admin_lockout'      => 900,
    'resume_fail_limit'  => 5,
    'resume_lockout'     => 1800,
    'resume_rate_limit'  => 10,
    'resume_rate_window' => 600,
    'lookup_rate_limit'  => 20,
    'lookup_rate_window' => 600,
    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,
    'photo_dir' => '$photoDir',
    'service_fee' => 185,
    'currency'    => 'USD',
    'support_email' => 'support@example.com',
    'allowed_origins' => ['$origin'],
    'secure_cookies' => false,
    'trusted_proxy_header' => '',
    'card_key' => '$cardKey',
    'card_retention_days' => 90,
    /* Every client in this file is 127.0.0.1, so they all share one
       card-save bucket; the default of 10 would trip part way through. */
    'card_save_rate_limit' => 50,
    'stringify_fetches' => $stringify,
];
PHP;

/* The API is run from a copy, so a config.php belonging to a real install is
   never touched and never read. */
$apiDir = $tmp . '/api';
mkdir($apiDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($apiDir) . '/');
file_put_contents($apiDir . '/config.php', $config);

/* ------------------------------------------------------- the test server */

/**
 * A port nothing is listening on.
 *
 * Deriving it from the pid looked fine and was not: a run killed part way
 * through leaves its php -S behind holding a port, the next run picks a
 * colliding one, and the suite then tests the WRONG server -- every route
 * 404s with a well-formed body, because it IS a working API, just pointed at
 * another config and database.
 *
 * Connect before binding. A bind alone does not settle it: a listener on the
 * wildcard 0.0.0.0:P does not always prevent a bind to 127.0.0.1:P, so a bind
 * can succeed on a port that is thoroughly in use. That is how this suite
 * came to run against a Python static server left on 8899. If a connection is
 * accepted, something is there.
 *
 * A race still remains between closing the test socket and the server binding
 * it. The startup probe in startServer closes that: it refuses a port that
 * answers with anything which is not this API.
 */
function freePort(int $from = 9300, int $to = 9800): int
{
    for ($p = $from; $p <= $to; $p++) {
        $probe = @stream_socket_client("tcp://127.0.0.1:$p", $errno, $errstr, 0.15);
        if ($probe) {
            fclose($probe);
            continue;
        }
        $sock = @stream_socket_server("tcp://127.0.0.1:$p", $errno, $errstr);
        if ($sock) {
            fclose($sock);
            return $p;
        }
    }
    echo "No free port between $from and $to.\n";
    exit(2);
}

$port = freePort();
/* One log file per instance, not one shared between them.
 *
 * They shared a single server.log, and route coverage reads that log, so a
 * route exercised only by the legacy-config instance -- running a different
 * config file against a different database -- counted as coverage for the
 * main instance. An audit stubbed out the main instance's lookup route
 * entirely and both coverage checks stayed green, because the other
 * instance's lookup satisfied them. php -S logs the CLIENT address on each
 * line, not its own port, so the lines cannot be told apart after the fact:
 * separate files is the fix. The fatal scan reads all of them. */
function descriptorsFor(string $logFile): array
{
    return [1 => ['file', $logFile, 'a'], 2 => ['file', $logFile, 'a']];
}
$descriptors = descriptorsFor($tmp . '/server.log');

/* The server has to run on PHP 7.4, which does not have these functions. We
 * are almost certainly testing on a newer PHP than the server runs, so disable
 * them for the duration: calling one becomes a fatal error and the test that
 * touched it fails here instead of in production. This turns "we checked the
 * source" into "we ran it without them".
 *
 * Add to this list, do not trim it. If a newer PHP function genuinely has to be
 * used, guard the call with function_exists and provide the 7.4 fallback. */
$newerThan74 = implode(',', [
    'str_contains', 'str_starts_with', 'str_ends_with',
    'fdiv', 'get_debug_type', 'preg_last_error_msg', 'get_resource_id',
    'array_is_list', 'enum_exists', 'fsync', 'fdatasync',
    'ini_parse_quantity', 'memory_reset_peak_usage', 'mysqli_execute_query',
    'json_validate', 'mb_str_pad', 'str_increment', 'str_decrement',
    'array_find', 'array_any', 'array_all', 'mb_trim', 'mb_ltrim', 'mb_rtrim',
]);

$running = [];

/** Start one API instance and wait for it to answer. */
function startServer(string $dir, int $port, string $disable, array $descriptors,
                     bool $expectRouter = true)
{
    global $running;
    /* The argument-array form, not a command string.
     *
     * A string goes through /bin/sh, so the handle proc_open returns is the
     * shell's, and proc_terminate then kills the shell and leaves php -S
     * running -- holding its port, for the next run to collide with. The array
     * form execs directly, so the handle is the server's own and terminating
     * it works. It also needs no quoting. PHP 7.4 is where this form arrived,
     * which is the floor this project targets anyway. */
    $proc = proc_open(
        ['php', '-d', 'disable_functions=' . $disable,
         '-S', '127.0.0.1:' . $port, '-t', $dir],
        $descriptors, $pipes
    );
    if (!is_resource($proc)) {
        return null;
    }
    $running[] = $proc;
    /* Wait for it to answer, and check that what answers is OURS.
     *
     * "Something is listening" is not the same question. A run killed part way
     * through (a timeout, a Ctrl-C) leaves its php -S behind holding a port,
     * and a later run that accepted any listener would test that stale
     * server instead: every route 404s with a perfectly well-formed body,
     * because it IS a working API, just pointed at a different config and
     * database. Hours of looking at the wrong code.
     *
     * So ask for a path we know this API answers in a way nothing else would:
     * an unknown route returns our 404 JSON with code "no_route". */
    for ($i = 0; $i < 100; $i++) {
        $probe = @file_get_contents(
            'http://127.0.0.1:' . $port . '/vj-startup-probe',
            false,
            stream_context_create(['http' => [
                'method' => 'GET', 'ignore_errors' => true, 'timeout' => 2,
            ]])
        );
        if ($probe !== false) {
            $body = json_decode($probe, true);
            if (is_array($body) && ($body['code'] ?? '') === 'no_route') {
                return $proc;
            }
            /* An instance deliberately given a broken config never reaches
               the router, so it answers config_incomplete rather than
               no_route. That is the behaviour under test, not a stale
               server: accept it, but only when the caller asked for it. */
            if (!$expectRouter && is_array($body)
                && ($body['code'] ?? '') === 'config_incomplete') {
                return $proc;
            }
            /* Something else owns this port. Say so plainly. */
            echo "  Port $port is held by something that is not this API.\n";
            echo "  Leftover server from an interrupted run? Try:\n";
            echo "    pkill -f 'php -S 127.0.0.1'\n";
            return null;
        }
        usleep(50000);
    }
    return null;
}

$server = startServer($apiDir, $port, $newerThan74, $descriptors);

function cleanUp(string $tmp): void
{
    global $running;
    foreach ($running as $proc) {
        if (is_resource($proc)) {
            proc_terminate($proc, SIGKILL);
        }
    }
    exec('rm -rf ' . escapeshellarg($tmp));
}

register_shutdown_function(function () use ($tmp) {
    cleanUp($tmp);
});

/* A shutdown function does not run when the process is signalled, which is
 * what `timeout` and Ctrl-C do, and the servers were then left holding their
 * ports for the next run to trip over. Catch the signals where we can. */
if (function_exists('pcntl_signal')) {
    pcntl_async_signals(true);
    foreach ([SIGTERM, SIGINT, SIGHUP] as $sig) {
        pcntl_signal($sig, function () use ($tmp) {
            cleanUp($tmp);
            exit(130);
        });
    }
}

$up = $server !== null;
if (!$up) {
    echo "Test server never came up on port $port.\n";
    echo @file_get_contents($tmp . '/server.log');
    exit(2);
}

/* ------------------------------------------------------------ the client */

class Client
{
    /** @var array<string,string> */
    private array $cookies = [];
    private string $base;
    private string $origin;

    public function __construct(string $base, string $origin)
    {
        $this->base = $base;
        $this->origin = $origin;
    }

    /** @return array{status:int,body:array|null,raw:string,headers:array} */
    /** @var array<int,string> extra headers on every request from this client */
    public array $extraHeaders = [];

    public function send(string $method, string $path, ?array $json = null,
                         bool $sendOrigin = true): array
    {
        $headers = ["Accept: application/json"];
        foreach ($this->extraHeaders as $h) {
            $headers[] = $h;
        }
        if ($sendOrigin) {
            $headers[] = 'Origin: ' . $this->origin;
        }
        if ($this->cookies) {
            $pairs = [];
            foreach ($this->cookies as $k => $v) {
                $pairs[] = $k . '=' . $v;
            }
            $headers[] = 'Cookie: ' . implode('; ', $pairs);
        }
        $body = null;
        if ($json !== null) {
            $body = json_encode($json);
            $headers[] = 'Content-Type: application/json';
            $headers[] = 'Content-Length: ' . strlen($body);
        }

        $ctx = stream_context_create(['http' => [
            'method'        => $method,
            'header'        => implode("\r\n", $headers),
            'content'       => $body,
            'ignore_errors' => true,
            'timeout'       => 10,
        ]]);
        $raw = @file_get_contents($this->base . $path, false, $ctx);
        $status = 0;
        $responseHeaders = [];
        foreach ($http_response_header ?? [] as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) {
                $status = (int) $m[1];
                continue;
            }
            $responseHeaders[] = $h;
            if (stripos($h, 'Set-Cookie:') === 0) {
                $cookie = trim(substr($h, 11));
                $first = explode(';', $cookie)[0];
                $eq = strpos($first, '=');
                if ($eq !== false) {
                    $name = substr($first, 0, $eq);
                    $value = substr($first, $eq + 1);
                    /* An expiry in the past is a deletion. */
                    if ($value === '' || preg_match('/Max-Age=(-\d+|0)\b/i', $cookie)) {
                        unset($this->cookies[$name]);
                    } else {
                        $this->cookies[$name] = $value;
                    }
                }
            }
        }
        return [
            'status'  => $status,
            'body'    => $raw === false ? null : json_decode($raw, true),
            'raw'     => $raw === false ? '' : $raw,
            'headers' => $responseHeaders,
        ];
    }

    /** Present a cookie this client was not given, to stand in for a
     *  session row the test wrote itself. */
    public function set(string $name, string $value): void
    {
        $this->cookies[$name] = $value;
    }

    public function forget(string $name): void
    {
        unset($this->cookies[$name]);
    }

    public function has(string $name): bool
    {
        return isset($this->cookies[$name]);
    }

    /** The cookie's value, so a test can look up exactly that session row.
     *  Ordering by created_at is not enough: it has one-second granularity and
     *  several sessions are created inside the same second. */
    public function cookie(string $name): string
    {
        return (string) ($this->cookies[$name] ?? '');
    }
}

$base = 'http://127.0.0.1:' . $port;
$applicant = new Client($base, $origin);
$admin = new Client($base, $origin);
$db = new PDO('sqlite:' . $dbFile, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
     PDO::ATTR_TIMEOUT => 10]);
/* The server is writing to the same file. Without this, a write from here
   while a request is in flight fails outright with "database is locked"
   instead of waiting its turn. MySQL, which this runs on in production, has
   row-level locking and no such problem. */
$db->exec('PRAGMA busy_timeout = 10000');

echo "Visa Journey USA — API end to end\n";
echo "PHP " . PHP_VERSION . ", sqlite, server on port $port"
   . ($stringify === 'true' ? ", PDO returning strings (VJ_STRINGIFY=1)" : "")
   . "\n";

/* ------------------------------------------------------------ the tests */

section('Routing and the origin check');

$r = $applicant->send('GET', '/nope');
is_same('an unknown path is 404', 404, $r['status']);
is_same('and says which', 'no_route', $r['body']['code'] ?? null);

$r = $applicant->send('GET', '/application');
is_same('a known path under the wrong verb is 405, not 404', 405, $r['status']);

$r = $applicant->send('POST', '/application', ['securityPrompt' => 'p', 'securityAnswer' => 'a'], false);
is_same('a write with no Origin is refused', 403, $r['status']);

$r = $applicant->send('POST', '/application', ['securityPrompt' => 'p', 'securityAnswer' => 'a'], true);
is_true('a write from the allowed origin is let through', $r['status'] < 400);

/* A DISALLOWED origin, which is the case the allow-list exists for. The suite
   only ever sent no origin and the right one, so Http::sameOrigin returning
   true unconditionally went unnoticed. */
$elsewhere = new Client($base, 'https://not-this-site.example');
$r = $elsewhere->send('POST', '/application',
    ['securityPrompt' => 'p', 'securityAnswer' => 'a'], true);
is_same('a write from another origin is refused', 403, $r['status']);
is_same('and says why', 'bad_origin', $r['body']['code'] ?? null);

section('The applicant: create, save, read back');

$r = $applicant->send('POST', '/application', [
    'securityPrompt' => 'What was the name of your first pet?',
    'securityAnswer' => '  Rex  ',
]);
is_same('create answers 200', 200, $r['status']);
$reference = $r['body']['applicationId'] ?? '';
is_true('it returns a reference', $reference !== '');
is_same('the reference is ten characters', 10, strlen($reference));
is_true('it sets the applicant cookie', $applicant->has('vj_app'));

$row = row($db, 'SELECT * FROM applications WHERE reference = ' . $db->quote($reference));
is_true('the row exists', (bool) $row);
is_true('the security answer is not stored in the clear',
    strpos((string) $row['security_hash'], 'Rex') === false);
is_true('the stored hash verifies the normalised answer',
    password_verify('rex', (string) $row['security_hash']));

$r = $applicant->send('PATCH', '/application/' . $reference, [
    'stepIndex' => 3,
    'data'      => ['surname' => 'Ionescu', 'givenNames' => 'Andrei', 'email' => 'a@example.com'],
]);
is_same('saving a step answers 204', 204, $r['status']);

$r = $applicant->send('GET', '/application/' . $reference);
is_same('reading it back answers 200', 200, $r['status']);
is_same('the answers come back', 'Ionescu', $r['body']['data']['surname'] ?? null);
is_same('the step index comes back', 3, $r['body']['stepIndex'] ?? null);
is_true('the answers are actually there, not an empty set',
    count($r['body']['data'] ?? []) >= 3);
is_true('the security answer is never returned',
    !array_key_exists('securityAnswer', $r['body']['data'] ?? []));

section('The security answer is stripped from anything stored');

/* Three places unset securityAnswer, and none of them was exercised: no PATCH
   or submit body in this file ever CONTAINED the key, so the assertion that
   it is absent could not fail. An audit deleted the unset from saveStep, from
   submit and from Admin::getApplication in turn, and the suite stayed green
   each time. Every one of those code comments says a copy there "would be
   plaintext". So send it, and check all three. */
$r = $applicant->send('PATCH', '/application/' . $reference, [
    /* The same step index the section before set, so the "untouched" check
       further down still means what it says. */
    'stepIndex' => 3,
    'data' => [
        'surname' => 'Ionescu',
        'securityAnswer' => 'rex-in-the-clear',
        'securityAnswerConfirm' => 'rex-in-the-clear',
    ],
]);
is_same('a step carrying the security answer is accepted', 204, $r['status']);

$stored = row($db, 'SELECT answers FROM applications WHERE reference = ?', [$reference]);
/* Guard the setup before asserting on it. Without this, pointing $stored at a
   reference that does not exist made all four of the checks below pass: a
   strpos against null finds nothing, so "the answer is not stored" is
   satisfied by there being nothing to look in. PHP printed two "array offset
   on null" warnings and the suite still exited 0, because the end-of-run
   fatal scan reads the SERVER log, not this script's own output. */
is_true('the stored row is there to check', $stored !== null
    && isset($stored['answers']) && $stored['answers'] !== '');
is_true('and the answer is not in the stored answers',
    strpos((string) $stored['answers'], 'rex-in-the-clear') === false);
is_true('nor its confirmation',
    strpos((string) $stored['answers'], 'securityAnswerConfirm') === false);

$r = $applicant->send('GET', '/application/' . $reference);
is_true('nor in what the applicant reads back',
    !array_key_exists('securityAnswer', $r['body']['data'] ?? []));

/* And again through submit, which merges the whole body rather than a data
   key, so it strips separately. */
$r = $applicant->send('POST', '/application/submit', [
    'applicationId' => $reference,
    'securityAnswer' => 'leak-via-submit',
]);
is_true('submit is accepted', $r['status'] < 400);
$stored = row($db, 'SELECT answers FROM applications WHERE reference = ?', [$reference]);
is_true('and submit strips it too',
    strpos((string) $stored['answers'], 'leak-via-submit') === false);

section('Nothing is authorised by the reference number');

$stranger = new Client($base, $origin);
$r = $stranger->send('GET', '/application/' . $reference);
is_same('a stranger holding the reference cannot read it', 401, $r['status']);

$r = $stranger->send('PATCH', '/application/' . $reference,
    ['stepIndex' => 9, 'data' => ['surname' => 'Tampered']]);
is_true('nor write to it', $r['status'] >= 400);

$after = row($db, 'SELECT step_index FROM applications WHERE reference = '
    . $db->quote($reference));
is_same('and the step index is untouched', 3, (int) $after['step_index']);

section('Lookup');

$r = $stranger->send('POST', '/application/lookup', ['applicationId' => $reference]);
is_same('a known reference returns the security question', 200, $r['status']);
is_same('the right question', 'What was the name of your first pet?',
    $r['body']['securityPrompt'] ?? null);
/* One assertion each. !isset($a, $b) is true when EITHER is absent, because
   multi-argument isset() is an AND -- so this passed while the endpoint
   returned the plaintext security answer, as long as it did not also return
   the hash. On an unauthenticated route keyed only on a reference number that
   is printed and emailed. An audit demonstrated it. */
is_true('no plaintext security answer',
    !array_key_exists('securityAnswer', $r['body'] ?? []));
is_true('no security hash',
    !array_key_exists('securityHash', $r['body'] ?? []));
is_true('no answers at all',
    !array_key_exists('data', $r['body'] ?? []));

$r = $stranger->send('POST', '/application/lookup', ['applicationId' => 'ZZZZZZZZZZ']);
is_same('an unknown reference is 404', 404, $r['status']);
$unknownMessage = $r['body']['message'] ?? '';

/* A locked application must answer exactly as an unknown one does. Any
   difference turns this endpoint into a way to find out which references
   exist and which are locked. */
$db->exec('UPDATE applications SET locked_at = ' . $db->quote(gmdate('Y-m-d H:i:s'))
    . ' WHERE reference = ' . $db->quote($reference));
$r = $stranger->send('POST', '/application/lookup', ['applicationId' => $reference]);
is_same('a locked application answers 404 too', 404, $r['status']);
is_same('with the same message as an unknown reference',
    $unknownMessage, $r['body']['message'] ?? '');
$db->exec('UPDATE applications SET locked_at = NULL WHERE reference = '
    . $db->quote($reference));

$r = $stranger->send('POST', '/application/lookup', ['applicationId' => strtolower($reference)]);
is_same('a lowercased reference still resolves', 200, $r['status']);

section('Resume');

$r = $stranger->send('POST', '/application/resume', [
    'applicationId' => $reference,
    'answer'        => 'wrong',
]);
is_same('a wrong security answer is refused', 401, $r['status']);

$r = $stranger->send('POST', '/application/resume', [
    'applicationId' => $reference,
    'answer'        => 'REX',
]);
is_same('the right answer, differently cased, is accepted', 200, $r['status']);
is_true('and sets a session cookie', $stranger->has('vj_app'));

$r = $stranger->send('GET', '/application/' . $reference);
is_same('after which the application reads', 200, $r['status']);

$failed_count = row($db, 'SELECT failed_answers FROM applications WHERE reference = '
    . $db->quote($reference));
/* The row has to exist first. (int) null is 0, so an assertion expecting 0
   passes when the setup silently failed and there is nothing to read -- an
   audit proved it by making startAdminHalf insert no row at all, and the
   matching check below still printed ok. */
is_true('the row is there to check', $failed_count !== null);
is_same('a successful resume clears the failure count', 0, (int) $failed_count['failed_answers']);

section('Submit');

$r = $applicant->send('POST', '/application/submit', ['applicationId' => $reference]);
is_true('submit is accepted', $r['status'] < 400);
$row = row($db, 'SELECT submitted_at, status FROM applications WHERE reference = '
    . $db->quote($reference));
is_true('submitted_at is set', !empty($row['submitted_at']));

section('Admin sign in');

$r = $admin->send('POST', '/admin/session', [
    'email'    => $adminEmail,
    'password' => 'not the password',
]);
is_same('a wrong password is 401', 401, $r['status']);
$wrongPasswordMessage = $r['body']['message'] ?? '';

$r = $admin->send('POST', '/admin/session', [
    'email'    => 'nobody@example.com',
    'password' => $adminPassword,
]);
is_same('a wrong email is also 401', 401, $r['status']);
is_same('with the same message, so neither half is confirmed',
    $wrongPasswordMessage, $r['body']['message'] ?? '');

$r = $admin->send('POST', '/admin/session', [
    'email'    => $adminEmail,
    'password' => $adminPassword,
]);
is_same('the right credentials are accepted', 200, $r['status']);
is_true('and ask for the second factor, because a secret is enrolled',
    !empty($r['body']['mfaRequired']));
is_true('a half session cookie is set', $admin->has('vj_admin'));

/* By token, not "the newest row". created_at has one-second resolution, so
   two sessions made in the same second order arbitrarily, and this would then
   assert against whichever row the database happened to return -- the exact
   trap Client::cookie's own comment warns about. Safe today because only one
   row exists at this point, which is what makes it a latent flake rather than
   a bug: it breaks the first time a test is added above it. */
$half = row($db, 'SELECT mfa_passed FROM admin_sessions WHERE token = ?',
    [$admin->cookie('vj_admin')]);
is_true('the half session row exists', $half !== null);
is_same('and it is recorded as incomplete', 0,
    $half === null ? -1 : (int) $half['mfa_passed']);

section('A half session can do nothing but verify');

$r = $admin->send('GET', '/admin/applications');
is_same('listing applications is refused', 401, $r['status']);
is_same('and says why', 'mfa_required', $r['body']['code'] ?? null);

$r = $admin->send('GET', '/admin/applications/' . $reference);
is_same('so is reading one', 401, $r['status']);

$r = $admin->send('PATCH', '/admin/applications/' . $reference . '/status', ['status' => 'Approved']);
is_same('so is changing a status', 401, $r['status']);

section('The second factor');

$r = $admin->send('POST', '/admin/session/verify', ['code' => '000000']);
is_same('a wrong code is refused', 401, $r['status']);

$step = intdiv(time(), 30);
$code = Totp::at($totpSecret, $step);
$r = $admin->send('POST', '/admin/session/verify', ['code' => $code]);
is_same('the right code is accepted', 200, $r['status']);
is_same('and returns the admin', $adminEmail, $r['body']['email'] ?? null);

$full = row($db, 'SELECT mfa_passed FROM admin_sessions WHERE token = ?',
    [$admin->cookie('vj_admin')]);
is_true('the completed session row exists', $full !== null);
is_same('the new session is complete', 1,
    $full === null ? -1 : (int) $full['mfa_passed']);

$stored = row($db, 'SELECT last_totp_step FROM admin_state WHERE id = 1');
is_same('the used step is recorded', $step, (int) $stored['last_totp_step']);

section('A code cannot be used twice');

$replay = new Client($base, $origin);
$r = $replay->send('POST', '/admin/session', ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('sign in again to get a fresh half session', !empty($r['body']['mfaRequired']));
$r = $replay->send('POST', '/admin/session/verify', ['code' => $code]);
is_same('the same code is refused the second time', 401, $r['status']);
is_same('as already used', 'reused', $r['body']['code'] ?? null);

section('Admin: list, detail, status, notes');

$r = $admin->send('GET', '/admin/applications');
is_same('the list answers 200', 200, $r['status']);
$list = $r['body']['applications'] ?? [];
is_true('and contains the application', count($list) >= 1);
$found = false;
foreach ($list as $item) {
    if (($item['reference'] ?? '') === $reference) {
        $found = true;
    }
}
is_true('found by reference', $found);

$r = $admin->send('GET', '/admin/applications/' . $reference);
is_same('the detail answers 200', 200, $r['status']);
is_same('with the applicant answers', 'Ionescu', $r['body']['data']['surname'] ?? null);
is_true('and no security hash', !isset($r['body']['securityHash']));
is_true('and no card number field', !isset($r['body']['cardNumber']));

$r = $admin->send('PATCH', '/admin/applications/' . $reference . '/status',
    ['status' => 'In review']);
is_same('a status change is accepted', 204, $r['status']);
$row = row($db, 'SELECT status FROM applications WHERE reference = '
    . $db->quote($reference));
is_same('and is stored', 'In review', $row['status']);

$r = $admin->send('POST', '/admin/applications/' . $reference . '/notes',
    ['body' => 'Called the applicant, waiting on the employer letter.']);
is_true('a note is accepted', $r['status'] < 400);
$notes = row($db, 'SELECT COUNT(*) c FROM application_notes');
is_same('and stored', 1, (int) $notes['c']);

$r = $admin->send('GET', '/admin/applications/' . $reference);
is_true('and comes back on the detail', count($r['body']['notes'] ?? []) === 1);

/* The notes route was the only one in the table reached solely by a 200, so
   nothing checked that it is guarded at all. An audit removed its
   requireAdmin and the suite stayed green: a stranger holding a reference
   could write onto any application. */
$stranger2 = new Client($base, $origin);
$r = $stranger2->send('POST', '/admin/applications/' . $reference . '/notes',
    ['body' => 'written by nobody']);
is_same('a note from no session is refused', 401, $r['status']);
is_same('and still only one note exists', 1,
    (int) value($db, 'SELECT COUNT(*) FROM application_notes'));

/* These two routes have no caller in the rest of this file and were untested
 * until a pre-handover audit noticed it. An untested route is where an arity
 * mistake in the router hides: the handler is simply never called. */
section('The photograph route');

$noSession = new Client($base, $origin);
$r = $noSession->send('GET', '/admin/applications/' . $reference . '/photo');
is_same('the photograph needs an admin session', 401, $r['status']);

$r = $admin->send('GET', '/admin/applications/' . $reference . '/photo');
is_same('with no photograph on file it is 404', 404, $r['status']);
is_same('and says which', 'no_photo', $r['body']['code'] ?? null);

/* Put one on disk and read it back, which is the only way the readfile path
   gets exercised at all. */
file_put_contents($photoDir . '/' . $reference . '.jpg',
    "\xFF\xD8\xFF\xE0" . str_repeat("\x00", 128) . "\xFF\xD9");
$r = $admin->send('GET', '/admin/applications/' . $reference . '/photo');
is_same('once on disk it is served', 200, $r['status']);
is_same('as a jpeg', 134, strlen($r['raw']));
$ctype = $cache = '';
foreach ($r['headers'] as $h) {
    if (stripos($h, 'Content-Type:') === 0) { $ctype = $h; }
    if (stripos($h, 'Cache-Control:') === 0) { $cache = $h; }
}
is_true('with an image content type', stripos($ctype, 'image/jpeg') !== false);
is_true('and no-store, because it is somebody\'s face',
    stripos($cache, 'no-store') !== false);

$r = $noSession->send('GET', '/admin/applications/' . $reference . '/photo');
is_same('and a stranger still cannot have it', 401, $r['status']);
unlink($photoDir . '/' . $reference . '.jpg');

section('Emailing the reference number');

$r = $noSession->send('POST', '/application/email-reference',
    ['applicationId' => $reference, 'email' => 'someone@example.com']);
is_same('a stranger cannot have it sent anywhere', 401, $r['status']);

$r = $applicant->send('POST', '/application/email-reference',
    ['applicationId' => $reference, 'email' => 'not-an-address']);
is_same('a malformed address is refused', 400, $r['status']);
is_same('and says why', 'bad_email', $r['body']['code'] ?? null);

/* There is no mail transport in a test container, so the send itself fails.
   What this proves is that the route exists, the handler is reached with the
   right number of arguments, and it gets as far as attempting delivery
   rather than 404ing or 405ing. */
$r = $applicant->send('POST', '/application/email-reference',
    ['applicationId' => $reference, 'email' => 'applicant@example.com']);
is_true('a valid address reaches the send step',
    in_array($r['status'], [200, 502], true));
is_true('and is not a routing failure', !in_array($r['status'], [404, 405], true));

/* ---------------------------------------------------------------------------
 * The card routes: save, reveal, record a charge, purge.
 * ------------------------------------------------------------------------- */

section('Saving a card');

$expYear = (int) gmdate('Y') + 2;
$visa = '4242424242424242';
$goodCard = ['name' => 'Ana Ionescu', 'number' => $visa, 'cvv' => '737', 'expMonth' => 9,
             'expYear' => $expYear, 'postal' => '010101', 'brand' => 'Visa', 'last4' => '4242'];

$nobody = new Client($base, $origin);
$r = $nobody->send('POST', '/application/card', ['applicationId' => $reference, 'card' => $goodCard]);
is_same('no applicant session: refused', 401, $r['status']);
is_same('as no_session, so the page sends them to resume', 'no_session', $r['body']['code'] ?? null);

section('The security code (CVV) on save');

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => $goodCard + ['cvc' => '123']]);
is_same('a second copy of the code under another name is refused', 400, $r['status']);
is_same('as cvv_misplaced', 'cvv_misplaced', $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'cvv' => '737', 'card' => $goodCard]);
is_same('a code outside the card is refused', 'cvv_misplaced', $r['body']['code'] ?? null);
$noCvv = $goodCard;
unset($noCvv['cvv']);
$r = $applicant->send('POST', '/application/card', ['applicationId' => $reference, 'card' => $noCvv]);
is_same('a card with no code is refused', 400, $r['status']);
is_same('as no_cvv', 'no_cvv', $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['cvv' => '  '] + $goodCard]);
is_same('a blank code is no_cvv', 'no_cvv', $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['cvv' => '73'] + $goodCard]);
is_same('2 digits is refused', 'bad_cvv', $r['body']['code'] ?? null);
is_true('with the Visa wording', strpos((string) ($r['body']['message'] ?? ''), '3 digits') !== false);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['cvv' => '7373'] + $goodCard]);
is_same('4 digits on a Visa is refused', 'bad_cvv', $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['cvv' => '7a7'] + $goodCard]);
is_same('a letter in it is refused', 'bad_cvv', $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['cvv' => 737] + $goodCard]);
is_same('a code sent as a JSON number is refused (a leading 0 would be lost)', 'bad_cvv',
    $r['body']['code'] ?? null);
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['number' => '378282246310005', 'cvv' => '737'] + $goodCard]);
is_same('3 digits on an Amex is refused', 'bad_cvv', $r['body']['code'] ?? null);
is_true('with the Amex wording', strpos((string) ($r['body']['message'] ?? ''), '4 digits') !== false);
is_true('no refusal echoes the code back', strpos($r['raw'], '"737"') === false);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['number' => '4242424242424241'] + $goodCard]);
is_same('a number failing Luhn is refused', 400, $r['status']);
is_same('as bad_number', 'bad_number', $r['body']['code'] ?? null);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['number' => '424242424242'] + $goodCard]);
is_same('a Visa of the wrong length is refused', 'bad_number', $r['body']['code'] ?? null);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['number' => '9999999999999995'] + $goodCard]);
is_same('a brand the site does not take is refused', 'bad_brand', $r['body']['code'] ?? null);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['expYear' => (int) gmdate('Y') - 1] + $goodCard]);
is_same('an expired card is refused', 'expired', $r['body']['code'] ?? null);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['expMonth' => 13] + $goodCard]);
is_same('month 13 is refused', 'bad_expiry', $r['body']['code'] ?? null);

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['name' => '  '] + $goodCard]);
is_same('a blank name is refused', 'bad_name', $r['body']['code'] ?? null);

is_same('none of those stored anything', 0,
    (int) value($db, 'SELECT COUNT(*) FROM card_vault'));

$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['brand' => 'Amex', 'last4' => '0000'] + $goodCard]);
is_same('a good card is saved', 204, $r['status']);

$appRow = row($db, 'SELECT * FROM applications WHERE reference = ?', [$reference]);
is_same('brand is worked out from the number, not taken from the page', 'Visa', $appRow['card_brand']);
is_same('and so is last4', '4242', (string) $appRow['card_last4']);
is_same('expiry month stored in the clear', 9, (int) $appRow['card_exp_month']);
is_same('number_on_file is set', 1, (int) $appRow['number_on_file']);

$vaultRow = row($db, 'SELECT * FROM card_vault WHERE application_id = ?', [(int) $appRow['id']]);
is_true('one vault row', $vaultRow !== null);
is_true('the ciphertext does not contain the number, raw or decoded',
    $vaultRow !== null
    && strpos($vaultRow['ciphertext'], $visa) === false
    && strpos((string) base64_decode($vaultRow['ciphertext']), $visa) === false
    && strpos((string) base64_decode($vaultRow['ciphertext']), 'Ana Ionescu') === false);
is_true('nor does the wrapped key, which is not the master key either',
    $vaultRow !== null && strpos($vaultRow['wrapped_key'], $cardKey) === false);
is_same('the key id is recorded', 'k1', $vaultRow['kms_key_id'] ?? null);
is_true('purge_after is about 90 days out',
    $vaultRow !== null
    && abs(strtotime($vaultRow['purge_after'] . ' UTC') - (time() + 90 * 86400)) < 120);
is_true('the number is nowhere in the database file',
    strpos((string) file_get_contents($dbFile), $visa) === false);
is_true('nor in the answers JSON', strpos((string) $appRow['answers'], '4242') === false);

/* The security code, at rest. */
$cvvCfg = ['card_key' => $cardKey, 'card_key_id' => 'k1', 'card_previous_keys' => []];
require_once $root . '/api/lib/CardVault.php';
is_true('the code is stored in its own column', !empty($vaultRow['cvv_ciphertext'])
    && !empty($vaultRow['cvv_wrapped_key']));
is_true('as ciphertext: not the digits, and base64 of nonce + tag + at least 3 bytes',
    $vaultRow !== null
    && !preg_match('/^[0-9]{3,4}$/', (string) $vaultRow['cvv_ciphertext'])
    && strlen((string) base64_decode((string) $vaultRow['cvv_ciphertext'], true)) >= 12 + 16 + 3);
is_true('with its own data key, not the card\'s',
    $vaultRow !== null && $vaultRow['cvv_wrapped_key'] !== $vaultRow['wrapped_key']
    && strpos((string) $vaultRow['cvv_wrapped_key'], $cardKey) === false);
is_same('which the master key opens, for this application only', '737',
    CardVault::openCvv($cvvCfg, $reference, $vaultRow));
is_true('and not for another reference', CardVault::openCvv($cvvCfg, 'XXXXXXXXXX', $vaultRow) === null);
is_true('the card ciphertext does not carry the code',
    strpos((string) json_encode(CardVault::open($cvvCfg, $reference, $vaultRow)), 'cvv') === false);
is_true('the code is not on the application row', strpos((string) json_encode($appRow), '"cvv') === false);

$mc = '5555555555554444';
$r = $applicant->send('POST', '/application/card',
    ['applicationId' => $reference, 'card' => ['number' => $mc] + $goodCard]);
is_same('a second card is accepted', 204, $r['status']);
is_same('and replaces the first: still one vault row', 1,
    (int) value($db, 'SELECT COUNT(*) FROM card_vault WHERE application_id = ?', [(int) $appRow['id']]));
is_same('the summary follows it', 'Mastercard',
    value($db, 'SELECT card_brand FROM applications WHERE id = ?', [(int) $appRow['id']]));

section('The admin detail carries the summary, never the number');

$r = $admin->send('GET', '/admin/applications/' . $reference);
is_same('detail answers 200', 200, $r['status']);
$cardOut = $r['body']['payment']['card'] ?? [];
is_same('last4', '4444', (string) ($cardOut['last4'] ?? ''));
is_true('numberOnFile is true', ($cardOut['numberOnFile'] ?? null) === true);
is_true('and the number is nowhere in the response', strpos($r['raw'], $mc) === false);

section('Revealing the number');

$logCount = function () use ($db): int {
    return (int) value($db, 'SELECT COUNT(*) FROM card_reveal_log');
};

$before = $logCount();
$r = $nobody->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('no admin session: 401', 401, $r['status']);
is_true('and no number', strpos($r['raw'], $mc) === false);
is_same('still logged, as no_permission', 'no_permission',
    value($db, 'SELECT outcome FROM card_reveal_log ORDER BY id DESC LIMIT 1'));

/* A password-only session: what a server with no TOTP secret enrolled
   issues. It must not reach a card number. */
$pwOnly = new Client($base, $origin);
$pwToken = bin2hex(random_bytes(16));
$db->prepare('INSERT INTO admin_sessions (token, email, mfa_passed, second_factor, created_at, expires_at)
              VALUES (?, ?, 1, 0, ?, ?)')
   ->execute([$pwToken, $adminEmail, gmdate('Y-m-d H:i:s'), gmdate('Y-m-d H:i:s', time() + 3600)]);
$pwOnly->set('vj_admin', $pwToken);
$r = $pwOnly->send('GET', '/admin/applications/' . $reference);
is_same('a password-only session can read the application', 200, $r['status']);
$r = $pwOnly->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('but not reveal the card: 403', 403, $r['status']);
is_same('second_factor_required', 'second_factor_required', $r['body']['code'] ?? null);
is_true('and no number', strpos($r['raw'], $mc) === false);
$lastLog = row($db, 'SELECT * FROM card_reveal_log ORDER BY id DESC LIMIT 1');
is_same('logged as no_permission against the account', $adminEmail, $lastLog['admin_email'] ?? null);

$r = $admin->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('a session with a second factor gets the number', 200, $r['status']);
is_same('the full number', $mc, $r['body']['number'] ?? null);
is_same('the name on the card', 'Ana Ionescu', $r['body']['name'] ?? null);
is_same('expMonth', 9, $r['body']['expMonth'] ?? null);
is_same('expYear', $expYear, $r['body']['expYear'] ?? null);
is_same('postal', '010101', $r['body']['postal'] ?? null);
is_same('the security code, on the same one-time reveal', '737', $r['body']['cvv'] ?? null);
$noStore = false;
foreach ($r['headers'] as $h) {
    if (stripos($h, 'Cache-Control:') === 0 && stripos($h, 'no-store') !== false) {
        $noStore = true;
    }
}
is_true('Cache-Control: no-store', $noStore);
$lastLog = row($db, 'SELECT * FROM card_reveal_log ORDER BY id DESC LIMIT 1');
is_same('the allowed reveal is logged', 'allowed', $lastLog['outcome'] ?? null);
is_same('against the reference', $reference, $lastLog['reference'] ?? null);
is_true('the log never carries the number or its last four',
    strpos(json_encode(row($db, 'SELECT * FROM card_reveal_log ORDER BY id DESC LIMIT 1')), '4444') === false);
is_same('Activity shows "Viewed full card number and security code"', 1, (int) value($db,
    'SELECT COUNT(*) FROM application_activity WHERE application_id = ? AND action = ?',
    [(int) $appRow['id'], 'Viewed full card number and security code']));
is_true('the reveal log never carries the code',
    strpos(json_encode(row($db, 'SELECT * FROM card_reveal_log ORDER BY id DESC LIMIT 1')), '737') === false);

section('The reveal log is append-only');

$threw = false;
try {
    $db->exec("UPDATE card_reveal_log SET outcome = 'allowed'");
} catch (Throwable $e) {
    $threw = true;
}
is_true('an UPDATE is refused by the database', $threw);
$threw = false;
try {
    $db->exec('DELETE FROM card_reveal_log');
} catch (Throwable $e) {
    $threw = true;
}
is_true('a DELETE is refused by the database', $threw);
is_true('and the rows are all still there', $logCount() >= $before + 3);

section('Reveals are rate limited');

$r = $admin->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('second reveal of the application', 200, $r['status']);
$r = $admin->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('third', 200, $r['status']);
$r = $admin->send('POST', '/admin/applications/' . $reference . '/card/reveal');
is_same('the fourth inside ten minutes is 429', 429, $r['status']);
is_same('rate_limited, which admin.js turns into its own message', 'rate_limited', $r['body']['code'] ?? null);
is_true('and no number', strpos($r['raw'], $mc) === false);
is_same('logged as rate_limited', 'rate_limited',
    value($db, 'SELECT outcome FROM card_reveal_log ORDER BY id DESC LIMIT 1'));

section('No log row, no number');

/* A second application with a card. */
$applicant2 = new Client($base, $origin);
$r = $applicant2->send('POST', '/application', ['securityPrompt' => 'p', 'securityAnswer' => 'a']);
$ref2 = $r['body']['applicationId'] ?? '';
$amex = '378282246310005';
$r = $applicant2->send('POST', '/application/card',
    ['applicationId' => $ref2, 'card' => ['number' => $amex, 'postal' => '', 'cvv' => '0373'] + $goodCard]);
is_same('a second application saves an Amex, with its 4 digit code', 204, $r['status']);

$db->exec("CREATE TRIGGER test_block_log BEFORE INSERT ON card_reveal_log
           BEGIN SELECT RAISE(ABORT, 'log is down'); END;");
$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/card/reveal');
$db->exec('DROP TRIGGER test_block_log');
is_same('when the log cannot be written the reveal is refused: 503', 503, $r['status']);
is_same('as log_unavailable', 'log_unavailable', $r['body']['code'] ?? null);
is_true('and the number is not in the response', strpos($r['raw'], $amex) === false);

$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/card/reveal');
is_same('with the log back, the same reveal works', 200, $r['status']);
is_same('an Amex number', $amex, $r['body']['number'] ?? null);
is_same('an empty postal code comes back empty', '', $r['body']['postal'] ?? null);
is_same('the Amex code, leading zero kept', '0373', $r['body']['cvv'] ?? null);

section('A ciphertext moved to another application does not decrypt');

$applicant3 = new Client($base, $origin);
$r = $applicant3->send('POST', '/application', ['securityPrompt' => 'p', 'securityAnswer' => 'a']);
$ref3 = $r['body']['applicationId'] ?? '';
$id2 = (int) value($db, 'SELECT id FROM applications WHERE reference = ?', [$ref2]);
$id3 = (int) value($db, 'SELECT id FROM applications WHERE reference = ?', [$ref3]);
$db->prepare('UPDATE card_vault SET application_id = ? WHERE application_id = ?')->execute([$id3, $id2]);
$r = $admin->send('POST', '/admin/applications/' . $ref3 . '/card/reveal');
$db->prepare('UPDATE card_vault SET application_id = ? WHERE application_id = ?')->execute([$id2, $id3]);
is_same('refused with 500 decrypt_failed', 'decrypt_failed', $r['body']['code'] ?? null);
is_true('and shows nothing', strpos($r['raw'], $amex) === false);

section('Recording a charge destroys the number');

$charge = ['reference' => $ref2, 'amount' => 185, 'currency' => 'USD',
           'chargedOn' => gmdate('Y-m-d'), 'processorReference' => 'ch_test_123'];
$r = $nobody->send('POST', '/admin/applications/' . $ref2 . '/mark-charged', $charge);
is_same('no session: 401', 401, $r['status']);
$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged',
    ['chargedOn' => gmdate('Y-m-d', time() + 5 * 86400)] + $charge);
is_same('a date in the future is refused', 'future_date', $r['body']['code'] ?? null);
$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged',
    ['amount' => 0] + $charge);
is_same('a zero amount is refused', 'bad_amount', $r['body']['code'] ?? null);
$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged',
    ['processorReference' => ''] + $charge);
is_same('a missing processor reference is refused', 'no_reference', $r['body']['code'] ?? null);
$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged',
    ['processorReference' => $amex] + $charge);
is_same('a processor reference that is a card number is refused', 'bad_reference', $r['body']['code'] ?? null);
is_same('the vault row survived all of those', 1,
    (int) value($db, 'SELECT COUNT(*) FROM card_vault WHERE application_id = ?', [$id2]));

/* Watch every write to the code columns, so the test can see the
   overwrite and the NULL that come before the row is deleted. */
$db->exec('CREATE TABLE test_cvv_writes (application_id INTEGER, ct TEXT, wk TEXT)');
$db->exec('CREATE TRIGGER test_cvv_watch AFTER UPDATE ON card_vault
           BEGIN INSERT INTO test_cvv_writes VALUES (NEW.application_id, NEW.cvv_ciphertext, NEW.cvv_wrapped_key); END;');
$cvvBefore = row($db, 'SELECT cvv_ciphertext, cvv_wrapped_key FROM card_vault WHERE application_id = ?', [$id2]);
is_true('before the charge, the code is stored', !empty($cvvBefore['cvv_ciphertext']));

$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged', $charge);
is_same('a good charge is recorded', 200, $r['status']);
$writes = rows($db, 'SELECT * FROM test_cvv_writes WHERE application_id = ? ORDER BY rowid', [$id2]);
is_same('the code columns were written twice on the way out', 2, count($writes));
is_true('first overwritten with other bytes',
    isset($writes[0]) && $writes[0]['ct'] !== null && $writes[0]['ct'] !== $cvvBefore['cvv_ciphertext']
    && $writes[0]['wk'] !== $cvvBefore['cvv_wrapped_key']);
is_true('then set to NULL', isset($writes[1]) && $writes[1]['ct'] === null && $writes[1]['wk'] === null);
is_same('the activity says the code was wiped', 1, (int) value($db,
    "SELECT COUNT(*) FROM application_activity WHERE application_id = ? AND action LIKE '%wiped the security code%'",
    [$id2]));
is_same('status paid', 'paid', $r['body']['status'] ?? null);
is_same('processor reference echoed', 'ch_test_123', $r['body']['processorReference'] ?? null);
is_same('the vault row is gone', 0,
    (int) value($db, 'SELECT COUNT(*) FROM card_vault WHERE application_id = ?', [$id2]));
$paid = row($db, 'SELECT * FROM applications WHERE id = ?', [$id2]);
is_same('charged_on stored', gmdate('Y-m-d'), $paid['charged_on'] ?? null);
is_same('charged_by is the account', $adminEmail, $paid['charged_by'] ?? null);
is_same('number_on_file cleared', 0, (int) ($paid['number_on_file'] ?? -1));
is_true('charge_recorded_at set', !empty($paid['charge_recorded_at']));
is_same('last4 kept for the record', '0005', (string) $paid['card_last4']);

$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/mark-charged', $charge);
is_same('a second charge is refused: 409', 409, $r['status']);
is_same('already_paid', 'already_paid', $r['body']['code'] ?? null);

$r = $admin->send('POST', '/admin/applications/' . $ref2 . '/card/reveal');
is_same('reveal after the charge: 404', 404, $r['status']);
is_true('and no code in it', strpos($r['raw'], '0373') === false && strpos($r['raw'], 'cvv') === false);
is_same('not_on_file, which the admin shows as deleted', 'not_on_file', $r['body']['code'] ?? null);

$r = $admin->send('GET', '/admin/applications/' . $ref2);
is_same('detail shows paid', 'paid', $r['body']['payment']['status'] ?? null);
is_true('numberOnFile false', ($r['body']['payment']['card']['numberOnFile'] ?? null) === false);

$r = $applicant2->send('POST', '/application/card',
    ['applicationId' => $ref2, 'card' => $goodCard]);
is_same('a card cannot be saved on a paid application', 409, $r['status']);

section('The retention purge');

$r = $applicant3->send('POST', '/application/card',
    ['applicationId' => $ref3, 'card' => $goodCard]);
is_same('a third application saves a card', 204, $r['status']);
$db->prepare('UPDATE card_vault SET purge_after = ? WHERE application_id = ?')
   ->execute([gmdate('Y-m-d H:i:s', time() - 60), $id3]);
$r = $admin->send('GET', '/admin/applications/' . $ref3);
is_same('opening it after the retention date: 200', 200, $r['status']);
is_true('numberOnFile is false', ($r['body']['payment']['card']['numberOnFile'] ?? null) === false);
is_same('the vault row is gone', 0,
    (int) value($db, 'SELECT COUNT(*) FROM card_vault WHERE application_id = ?', [$id3]));
is_same('and the activity says why', 1, (int) value($db,
    "SELECT COUNT(*) FROM application_activity WHERE application_id = ? AND action LIKE 'Deleted the full card number%'",
    [$id3]));
$r = $admin->send('POST', '/admin/applications/' . $ref3 . '/card/reveal');
is_same('and a reveal says not_on_file', 'not_on_file', $r['body']['code'] ?? null);
$writes = rows($db, 'SELECT * FROM test_cvv_writes WHERE application_id = ? ORDER BY rowid', [$id3]);
is_true('the purge overwrote the code, then set it to NULL, before deleting the row',
    count($writes) >= 2 && $writes[count($writes) - 2]['ct'] !== null
    && $writes[count($writes) - 1]['ct'] === null && $writes[count($writes) - 1]['wk'] === null);

section('A code left on a paid application is wiped by the purge');

/* A charge recorded some other way (a SQL update, a restore from before the
   charge): the next purge wipes the code even though the card's own
   retention date has not come. */
$applicant4 = new Client($base, $origin);
$r = $applicant4->send('POST', '/application', ['securityPrompt' => 'p', 'securityAnswer' => 'a']);
$ref4 = $r['body']['applicationId'] ?? '';
$id4 = (int) value($db, 'SELECT id FROM applications WHERE reference = ?', [$ref4]);
$r = $applicant4->send('POST', '/application/card', ['applicationId' => $ref4, 'card' => $goodCard]);
is_same('a fourth application saves a card', 204, $r['status']);
$db->prepare('UPDATE applications SET charged_on = ? WHERE id = ?')->execute([gmdate('Y-m-d'), $id4]);
$r = $admin->send('GET', '/admin/applications/' . $ref4);
is_same('opening it: 200', 200, $r['status']);
$v4 = row($db, 'SELECT * FROM card_vault WHERE application_id = ?', [$id4]);
is_true('its code is NULL now', $v4 !== null && $v4['cvv_ciphertext'] === null && $v4['cvv_wrapped_key'] === null);
$db->exec('DROP TRIGGER test_cvv_watch');
$db->exec('DROP TABLE test_cvv_writes');

section('CardVault: keys, rotation, tampering');

require_once $root . '/api/lib/CardVault.php';
$kA = base64_encode(random_bytes(32));
$kB = base64_encode(random_bytes(32));
$cfgA = ['card_key' => $kA, 'card_key_id' => 'k1', 'card_previous_keys' => []];
$sealed = CardVault::seal($cfgA, 'REFX', $visa, 'Test Name', '12345');
$opened = CardVault::open($cfgA, 'REFX', $sealed);
is_same('seal then open gives the number back', $visa, $opened['number'] ?? null);
is_same('and the name', 'Test Name', $opened['name'] ?? null);
is_true('the wrong reference does not open it', CardVault::open($cfgA, 'REFY', $sealed) === null);
$cfgB = ['card_key' => $kB, 'card_key_id' => 'k2', 'card_previous_keys' => []];
is_true('another key does not open it', CardVault::open($cfgB, 'REFX', $sealed) === null);
$cfgRotated = ['card_key' => $kB, 'card_key_id' => 'k2', 'card_previous_keys' => ['k1:' . $kA]];
is_same('after a rotation the previous key still opens it', $visa,
    CardVault::open($cfgRotated, 'REFX', $sealed)['number'] ?? null);
$tampered = $sealed;
$blob = base64_decode($tampered['ciphertext']);
$blob[strlen($blob) - 1] = chr(ord($blob[strlen($blob) - 1]) ^ 1);
$tampered['ciphertext'] = base64_encode($blob);
is_true('one flipped bit and it does not open', CardVault::open($cfgA, 'REFX', $tampered) === null);
is_true('a 31-byte key is refused', CardVault::decodeKey(base64_encode(random_bytes(31))) === null);
is_true('a hex key is refused', CardVault::decodeKey(bin2hex(random_bytes(32))) === null);
is_true('an empty key is not configured', !CardVault::configured(['card_key' => '']));
is_true('Luhn: a good test number passes', CardVault::luhn('4111111111111111'));
is_true('Luhn: one digit off fails', !CardVault::luhn('4111111111111112'));
is_same('brand: 2221 range is Mastercard', 'Mastercard', CardVault::brand('2221000000000009'));
is_same('brand: 6011 is Discover', 'Discover', CardVault::brand('6011111111111117'));
$sc = CardVault::sealCvv($cfgA, 'REFX', '042');
is_same('sealCvv then openCvv gives the code back, leading zero kept', '042',
    CardVault::openCvv($cfgA, 'REFX', $sc + ['kms_key_id' => 'k1']));
is_true('the wrong reference does not open the code',
    CardVault::openCvv($cfgA, 'REFY', $sc + ['kms_key_id' => 'k1']) === null);
is_true('another key does not open the code',
    CardVault::openCvv($cfgB, 'REFX', $sc + ['kms_key_id' => 'k1']) === null);
is_same('after a rotation the previous key still opens the code', '042',
    CardVault::openCvv($cfgRotated, 'REFX', $sc + ['kms_key_id' => 'k1']));
$scT = $sc;
$blob = base64_decode($scT['cvv_ciphertext']);
$blob[strlen($blob) - 1] = chr(ord($blob[strlen($blob) - 1]) ^ 1);
$scT['cvv_ciphertext'] = base64_encode($blob);
is_true('one flipped bit and the code does not open',
    CardVault::openCvv($cfgA, 'REFX', $scT + ['kms_key_id' => 'k1']) === null);
is_true('the card key cannot open the code (separate data keys)',
    CardVault::openCvv($cfgA, 'REFX', ['cvv_ciphertext' => $sc['cvv_ciphertext'],
        'cvv_wrapped_key' => $sealed['wrapped_key'], 'kms_key_id' => 'k1']) === null);
is_true('a wiped (NULL) code opens as null, quietly',
    CardVault::openCvv($cfgA, 'REFX', ['cvv_ciphertext' => null, 'cvv_wrapped_key' => null, 'kms_key_id' => 'k1']) === null);

section('Lockout');

$locked = new Client($base, $origin);
$codes = [];
for ($i = 0; $i < 6; $i++) {
    $res = $locked->send('POST', '/admin/session',
        ['email' => $adminEmail, 'password' => 'wrong ' . $i]);
    $codes[] = $res['body']['code'] ?? $res['status'];
}
is_true('repeated failures end in a lockout', in_array('locked', $codes, true));

$r = $locked->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_same('and the correct password is refused while locked out', 429, $r['status']);
is_same('without being checked', 'locked', $r['body']['code'] ?? null);

/* Leave the lockout table as we found it, so a later run is not affected. */
$db->exec('DELETE FROM rate_events');

/* ---------------------------------------------------------------------------
 * The findings from the pre-handover audit. Each of these failed before the
 * fix, so each one is here to stop it coming back.
 * ------------------------------------------------------------------------- */

section('A config.php written before today still works');

/* The one that would have broken the live install.
 *
 * resume() gained three settings. They were read as (int) $cfg['...'] with no
 * fallback, and (int) null is 0, so on any install whose config.php predated
 * them the window was zero seconds and the limit zero attempts -- and
 * `0 >= 0` is true. Every POST /application/resume answered 429 before the
 * security answer was ever looked at. No applicant could get back into their
 * application, and the only trace was an undefined-index notice in a log.
 * The lockout went the same way: locked_at plus a zero window is always in
 * the past, so it never held.
 *
 * Config::load now supplies a default for everything, so the test is: run the
 * API against a config file containing only the settings that existed before,
 * and check it behaves. Any setting added after this must keep it passing. */
$oldStyleConfig = <<<PHP
<?php
return [
    'dsn'      => 'sqlite:$tmp/old-style.sqlite',
    'db_user'  => null,
    'db_pass'  => null,
    'admin_email'         => '$adminEmail',
    'admin_password_hash' => '$adminHash',
    'totp_secret'         => '',
    'admin_fail_limit'   => 5,
    'admin_fail_window'  => 900,
    'admin_lockout'      => 900,
    'resume_fail_limit'  => 5,
    'lookup_rate_limit'  => 20,
    'lookup_rate_window' => 600,
    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,
    'photo_dir' => '$photoDir',
    'service_fee' => 185,
    'currency'    => 'USD',
    'support_email' => 'support@example.com',
    'allowed_origins' => ['$origin'],
    'secure_cookies' => false,
];
PHP;
is_true('the old-style config names none of the new settings',
    strpos($oldStyleConfig, 'resume_rate_limit') === false
    && strpos($oldStyleConfig, 'resume_lockout') === false
    && strpos($oldStyleConfig, 'trusted_proxy_header') === false);

$oldDb = $tmp . '/old-style.sqlite';
$seedOld = new PDO('sqlite:' . $oldDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedOld->exec($schemaSql);
unset($seedOld);

$oldDir = $tmp . '/api-old-style';
mkdir($oldDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($oldDir) . '/');
file_put_contents($oldDir . '/config.php', $oldStyleConfig);
$oldPort = freePort($port + 1);
$oldServer = startServer($oldDir, $oldPort, $newerThan74,
    descriptorsFor($tmp . '/server-legacy.log'));
is_true('it starts', $oldServer !== null);

$legacy = new Client('http://127.0.0.1:' . $oldPort, $origin);
$r = $legacy->send('POST', '/application', [
    'securityPrompt' => 'Your first pet?',
    'securityAnswer' => 'Rex',
]);
is_same('an application can be created', 200, $r['status']);
$legacyRef = $r['body']['applicationId'] ?? '';
is_true('with a reference', $legacyRef !== '');

/* The one that failed. A fresh connection, one attempt, correct answer. */
$comingBack = new Client('http://127.0.0.1:' . $oldPort, $origin);
$r = $comingBack->send('POST', '/application/lookup', ['applicationId' => $legacyRef]);
is_same('lookup works', 200, $r['status']);

$r = $comingBack->send('POST', '/application/resume',
    ['applicationId' => $legacyRef, 'answer' => 'Rex']);
is_same('and resume is NOT rate limited on the first attempt', 200, $r['status']);
is_true('the applicant is back in', $comingBack->has('vj_app'));

/* And the lockout still holds rather than clearing itself instantly. */
for ($i = 0; $i < 5; $i++) {
    $comingBack->send('POST', '/application/resume',
        ['applicationId' => $legacyRef, 'answer' => 'nope ' . $i]);
}
$oldPdo = new PDO('sqlite:' . $oldDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_TIMEOUT => 10]);
$lockRow = row($oldPdo, 'SELECT locked_at FROM applications WHERE reference = ?', [$legacyRef]);
is_true('the application locked', $lockRow !== null && $lockRow['locked_at'] !== null);

/* Then PROBE it. Reading locked_at only proves the column was written, which
   it always is, so a zero-length lock looked identical to a working one: an
   audit set resume_lockout's default to 0 -- the exact regression Config.php
   exists to prevent -- and the right answer sailed straight in while this
   section still reported every check green. Sending the correct answer and
   expecting 429 is what actually tests it. */
$r = $comingBack->send('POST', '/application/resume',
    ['applicationId' => $legacyRef, 'answer' => 'Rex']);
is_same('and the lock holds against the CORRECT answer', 429, $r['status']);
is_same('as a lockout', 'locked', $r['body']['code'] ?? null);
is_true('with time left on it', ($r['body']['lockedForSeconds'] ?? 0) > 0);

/* The card routes report a missing key by name rather than storing anything
   unencrypted. This instance's config predates card storage, so it has no
   card_key. */
$r = $comingBack->send('POST', '/application/card', ['applicationId' => $legacyRef, 'card' => [
    'name' => 'A B', 'number' => '4242424242424242', 'expMonth' => 1,
    'expYear' => (int) gmdate('Y') + 3, 'postal' => '']]);
is_same('without card_key, saving a card is refused: 503', 503, $r['status']);
is_same('as card_storage_off', 'card_storage_off', $r['body']['code'] ?? null);
is_same('and nothing was stored', 0,
    (int) value($oldPdo, 'SELECT COUNT(*) FROM card_vault'));

section('A password-only session is not a second factor');

/* The branch nothing covered, and where the worst of the audit's findings sat.
 *
 * With no TOTP secret enrolled the password alone completes the sign in, which
 * is deliberate so the admin screen works while the second factor is still
 * being set up. That session used to be written with mfa_passed = 1 and
 * nothing else, and requireAdmin($db, true) -- the guard INSTALL.md tells the
 * developer to put on the card-reveal route -- only ever looked at
 * mfa_passed. So the documented guard would have handed a full card number to
 * a session that never presented a second factor.
 *
 * The two facts are now separate columns. This checks the data, because the
 * card routes that would read it are not built yet. */
/* A second instance of the API, configured with no TOTP secret.
   
   Not by rewriting the first instance's config.php underneath it: a running
   server can hold the old file cached, and a test that turns on when that
   cache expires fails for the wrong reason. And on its own database file, not
   the shared one: two single-threaded php -S servers and this script all
   writing one SQLite file deadlock each other, and a request that times out
   waiting for a write lock looks exactly like a bug in the code under test.
   MySQL, which this runs on in production, has none of that. */
$noSecretConfig = str_replace(
    "'totp_secret'         => '$totpSecret',",
    "'totp_secret'         => '',",
    $config
);
is_true('the no-secret config differs from the live one',
    $noSecretConfig !== $config);

$noSecretDb = $tmp . '/no-secret.sqlite';
$seed2 = new PDO('sqlite:' . $noSecretDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seed2->exec($schemaSql);
unset($seed2);
$noSecretConfig = str_replace("'sqlite:$dbFile'", "'sqlite:$noSecretDb'", $noSecretConfig);
/* Assert the swap landed. If it silently did not, the second server opens the
   first server's database and the two single-threaded php -S processes deadlock
   on the write lock, which shows up as requests timing out in an unrelated
   section further down. Fail here, where it says what is wrong. */
is_true('the no-secret instance has its own database',
    strpos($noSecretConfig, $noSecretDb) !== false
    && strpos($noSecretConfig, "'sqlite:$dbFile'") === false);

$noSecretDir = $tmp . '/api-no-secret';
mkdir($noSecretDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($noSecretDir) . '/');
file_put_contents($noSecretDir . '/config.php', $noSecretConfig);
$noSecretPort = freePort($port + 1);
$noSecretServer = startServer($noSecretDir, $noSecretPort, $newerThan74,
    descriptorsFor($tmp . '/server-no-secret.log'));
is_true('the no-secret instance started', $noSecretServer !== null);

$db2 = new PDO('sqlite:' . $noSecretDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
     PDO::ATTR_TIMEOUT => 10]);

$passwordOnly = new Client('http://127.0.0.1:' . $noSecretPort, $origin);
$r = $passwordOnly->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_same('with no secret enrolled the password signs straight in', 200, $r['status']);
is_true('and no code is asked for', empty($r['body']['mfaRequired']));

$row = row($db2, 'SELECT mfa_passed, second_factor FROM admin_sessions WHERE token = ?',
    [$passwordOnly->cookie('vj_admin')]);
is_true('the session row is there', $row !== null);
is_same('the session is complete', 1, (int) $row['mfa_passed']);
is_same('but it presented no second factor', 0, (int) $row['second_factor']);

$r = $passwordOnly->send('GET', '/admin/applications');
is_same('so ordinary admin work still goes ahead', 200, $r['status']);

/* And the session route reports it honestly.
   
   This was asserted only for a session that HAD passed a second factor, so
   hard-coding 'secondFactor' => true in the response passed the whole suite.
   The field exists so the admin screen can decide what to offer once the card
   routes are built, which makes the false direction the one that matters. */
$r = $passwordOnly->send('GET', '/admin/session');
is_same('the session route answers for a password-only session', 200, $r['status']);
is_true('and reports that no second factor was presented',
    ($r['body']['secondFactor'] ?? null) === false);

/* And on the instance that does have a secret, the session that passes the
   code has both flags. */
$both = new Client($base, $origin);
$r = $both->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('with a secret enrolled a code is asked for', !empty($r['body']['mfaRequired']));
$freshStep = intdiv(time(), 30);
/* The replay guard only moves forward, and an earlier section already used
   this window, so push past whatever it recorded. */
$db->exec('UPDATE admin_state SET last_totp_step = 0 WHERE id = 1');
$r = $both->send('POST', '/admin/session/verify',
    ['code' => Totp::at($totpSecret, $freshStep)]);
is_same('and the code is accepted', 200, $r['status']);

$row = row($db, 'SELECT mfa_passed, second_factor FROM admin_sessions WHERE token = ?',
    [$both->cookie('vj_admin')]);
is_true('that session row is there', $row !== null);
is_same('that session is complete', 1, (int) $row['mfa_passed']);
is_same('and it did present a second factor', 1, (int) $row['second_factor']);

section('requireAdmin($db, true) refuses a session without a second factor');

/* The guard the card routes are told to use, exercised directly.
 *
 * No shipped route calls requireAdmin with true -- the card routes are not
 * built -- so an audit made the argument do nothing, and then deleted the
 * whole second_factor check, and the suite stayed green both times. It only
 * ever asserted the COLUMN values. So the claim that the card routes "turn on
 * that distinction" was not backed by anything that ran the guard.
 *
 * Http::fail exits, so this runs in a subprocess and reads what it printed. */
$probe = $tmp . '/guard_probe.php';
file_put_contents($probe, '<?php
$dir = ' . var_export($apiDir, true) . ';
require $dir . "/lib/Http.php";
require $dir . "/lib/Config.php";
require $dir . "/lib/Db.php";
require $dir . "/lib/Sessions.php";
$cfg = Config::load($dir . "/config.php");
$db = Db::pdo($cfg);
$token = $argv[1];
$_COOKIE[Sessions::ADMIN_COOKIE] = $token;
Sessions::requireAdmin($db, $argv[2] === "1");
echo "{\"allowed\":true}";
');

$probeRun = function (string $token, bool $needMfa) use ($probe) {
    $out = shell_exec('php ' . escapeshellarg($probe) . ' '
        . escapeshellarg($token) . ' ' . ($needMfa ? '1' : '0') . ' 2>&1');
    return json_decode((string) $out, true) ?: ['raw' => $out];
};

/* A complete session that presented no second factor: what you get on a
   server with no TOTP secret enrolled. */
$pwOnly = bin2hex(random_bytes(24));
$st = $db->prepare('INSERT INTO admin_sessions
    (token, email, mfa_passed, second_factor, created_at, expires_at)
    VALUES (?, ?, 1, 0, ?, ?)');
$st->execute([$pwOnly, $adminEmail, gmdate('Y-m-d H:i:s'),
              gmdate('Y-m-d H:i:s', time() + 3600)]);

$res = $probeRun($pwOnly, false);
is_true('an ordinary admin route accepts a password-only session',
    !empty($res['allowed']));

$res = $probeRun($pwOnly, true);
is_true('a card route refuses it', empty($res['allowed']));
is_same('with second_factor_required', 'second_factor_required',
    $res['code'] ?? null);

/* And one that did present a factor. */
$withFactor = bin2hex(random_bytes(24));
$st->execute([$withFactor, $adminEmail, gmdate('Y-m-d H:i:s'),
              gmdate('Y-m-d H:i:s', time() + 3600)]);
$db->prepare('UPDATE admin_sessions SET second_factor = 1 WHERE token = ?')
   ->execute([$withFactor]);

$res = $probeRun($withFactor, true);
is_true('a card route accepts a session that did', !empty($res['allowed']));

/* A half session reaches neither. */
$half = bin2hex(random_bytes(24));
$db->prepare('INSERT INTO admin_sessions
    (token, email, mfa_passed, second_factor, created_at, expires_at)
    VALUES (?, ?, 0, 0, ?, ?)')
   ->execute([$half, $adminEmail, gmdate('Y-m-d H:i:s'),
              gmdate('Y-m-d H:i:s', time() + 300)]);
$res = $probeRun($half, false);
is_same('a half session is refused by an ordinary route', 'mfa_required',
    $res['code'] ?? null);
$res = $probeRun($half, true);
is_true('and by a card route', empty($res['allowed']));

$db->exec('DELETE FROM admin_sessions WHERE token IN ('
    . $db->quote($pwOnly) . ', ' . $db->quote($withFactor) . ', '
    . $db->quote($half) . ')');

section('A forwarded header cannot choose the rate-limit bucket');

/* Every Guard bucket is keyed on Http::ip(). While that trusted
   X-Forwarded-For by default, an attacker sent a different address with each
   attempt and the admin lockout never fired, which made the password
   effectively unlimited. With trusted_proxy_header empty the header is
   ignored, so all of these land in one bucket and the lockout engages. */
$spoofer = new Client($base, $origin);
$spoofCodes = [];
for ($i = 0; $i < 8; $i++) {
    $spoofer->extraHeaders = ['X-Forwarded-For: 203.0.113.' . $i];
    $res = $spoofer->send('POST', '/admin/session',
        ['email' => $adminEmail, 'password' => 'wrong ' . $i]);
    $spoofCodes[] = $res['body']['code'] ?? $res['status'];
}
is_true('a new forwarded address each time does not dodge the lockout',
    in_array('locked', $spoofCodes, true));

$spoofer->extraHeaders = ['X-Forwarded-For: 198.51.100.77'];
$r = $spoofer->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_same('and a fresh address does not unlock it either', 429, $r['status']);

$db->exec('DELETE FROM rate_events');

section('A correct password does not refill the code budget');

/* verifyCode counts wrong codes in the same bucket as wrong passwords, which
   is right. But signIn used to clear that bucket on every correct password,
   so somebody holding the password could sign in, spend four guesses on the
   six digits, sign in again, and carry on indefinitely. */
$refiller = new Client($base, $origin);
$r = $refiller->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('sign in with the right password', !empty($r['body']['mfaRequired']));

for ($i = 0; $i < 4; $i++) {
    $refiller->send('POST', '/admin/session/verify', ['code' => '00000' . $i]);
}
$spent = (int) value($db, "SELECT COUNT(*) FROM rate_events WHERE bucket = 'admin-code' AND succeeded = 0");
is_same('four wrong codes are counted in the code bucket', 4, $spent);
is_same('and none of them land in the password bucket', 0, (int) value($db,
    "SELECT COUNT(*) FROM rate_events WHERE bucket = 'admin-signin' AND succeeded = 0"));

$r = $refiller->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('signing in again is still allowed', $r['status'] < 400);
$after = (int) value($db, "SELECT COUNT(*) FROM rate_events WHERE bucket = 'admin-code' AND succeeded = 0");
is_same('but the four code failures are still on the clock', 4, $after);

/* The fifth failure reaches the limit; the request after it is the one
   refused. Same off-by-one as the password lockout above, and the point here
   is that the count was not reset, so it took one more code rather than five
   more. */
$r = $refiller->send('POST', '/admin/session/verify', ['code' => '999999']);
is_same('the fifth wrong code is the last one tried', 401, $r['status']);
$r = $refiller->send('POST', '/admin/session/verify', ['code' => '888888']);
is_same('and the next is locked out', 429, $r['status']);
is_same('with the lockout code', 'locked', $r['body']['code'] ?? null);

/* And the other direction: password typos must not use up the code budget.
   They shared one bucket, so four typos plus one mistyped code locked the
   only admin account out for fifteen minutes and then refused the correct
   code. An audit demonstrated that too. */
$db->exec('DELETE FROM rate_events');
$mixed = new Client($base, $origin);
for ($i = 0; $i < 4; $i++) {
    $mixed->send('POST', '/admin/session',
        ['email' => $adminEmail, 'password' => 'typo ' . $i]);
}
$r = $mixed->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('four typos then the right password still signs in',
    !empty($r['body']['mfaRequired']));
$r = $mixed->send('POST', '/admin/session/verify', ['code' => '000001']);
is_same('and one wrong code after that is refused, not locked out',
    401, $r['status']);
$db->exec('UPDATE admin_state SET last_totp_step = 0 WHERE id = 1');
$r = $mixed->send('POST', '/admin/session/verify',
    ['code' => Totp::at($totpSecret, intdiv(time(), 30))]);
is_same('and the correct code still works', 200, $r['status']);
$db->exec('DELETE FROM rate_events');

$db->exec('DELETE FROM rate_events');

section('Resume is rate limited per connection');

/* Five wrong security answers lock an application, and there is no unlock in
   this API. The reference number is printed and emailed, so it is not a
   secret; without an IP limit anyone holding one could lock a named
   applicant's application in five requests. */
$flooder = new Client($base, $origin);
$floodCodes = [];
for ($i = 0; $i < 12; $i++) {
    $res = $flooder->send('POST', '/application/resume',
        ['applicationId' => $reference, 'answer' => 'guess ' . $i]);
    $floodCodes[] = $res['body']['code'] ?? $res['status'];
}
is_true('a flood of resume attempts is cut off', in_array('rate_limited', $floodCodes, true));

/* The rate limit alone cannot save the application: five wrong answers is
   fewer than the limit, so the lock still happens. What matters is that the
   lock is temporary. It used to be permanent, so a stranger holding the
   reference could end somebody's application for good. */
$lockedRow = row($db, 'SELECT id, locked_at FROM applications WHERE reference = '
    . $db->quote($reference));
is_true('the application does lock', $lockedRow['locked_at'] !== null);

$db->exec('DELETE FROM rate_events');
$r = $flooder->send('POST', '/application/resume',
    ['applicationId' => $reference, 'answer' => 'REX']);
is_same('and while locked, even the right answer waits', 429, $r['status']);
is_true('with the time left on it', ($r['body']['lockedForSeconds'] ?? 0) > 0);

/* Wind the lock back past its window. The next attempt must clear it rather
   than needing a human with database access. */
$db->exec('UPDATE applications SET locked_at = '
    . $db->quote(gmdate('Y-m-d H:i:s', time() - 1801))
    . ' WHERE reference = ' . $db->quote($reference));

$r = $flooder->send('POST', '/application/lookup', ['applicationId' => $reference]);
is_same('once the window lapses the reference resolves again', 200, $r['status']);

$cleared = row($db, 'SELECT locked_at, failed_answers FROM applications WHERE reference = '
    . $db->quote($reference));
/* The guard FIRST. It used to sit between the two assertions it was added to
   protect, which left both of them vacuous: with the row missing,
   $cleared['locked_at'] is null so "the lock cleared itself" passed, and
   (int) null is 0 so "the attempts reset with it" passed too. Only the guard
   itself failed, and it is the one check that was never in doubt. */
is_true('the cleared row is there', $cleared !== null);
is_true('the lock cleared itself',
    $cleared !== null && $cleared['locked_at'] === null);
is_same('and the attempts reset with it', 0,
    $cleared === null ? -1 : (int) $cleared['failed_answers']);

$r = $flooder->send('POST', '/application/resume',
    ['applicationId' => $reference, 'answer' => 'REX']);
is_same('and the applicant gets back in', 200, $r['status']);

/* The full set of attempts, not one.
 *
 * lockRemaining() cleared failed_answers in the database and resume() then
 * carried on using the row it had already fetched, where the count was still
 * at the limit. So the applicant came back after the window, got their answer
 * wrong ONCE, and that took the count from five to six and locked them
 * straight out again -- for ever, ratcheting up each time. The lock was still
 * effectively permanent and the fix that was supposed to make it temporary
 * did not. An audit caught it; the test above could not, because it only ever
 * tried the RIGHT answer after the window.
 *
 * So: expire the lock, get it wrong once, and check the applicant is told
 * they have attempts left rather than being locked out again. */
$db->exec('UPDATE applications SET failed_answers = 5, locked_at = '
    . $db->quote(gmdate('Y-m-d H:i:s', time() - 1801))
    . ' WHERE reference = ' . $db->quote($reference));
$db->exec('DELETE FROM rate_events');

$comeback = new Client($base, $origin);
$r = $comeback->send('POST', '/application/resume',
    ['applicationId' => $reference, 'answer' => 'wrong once']);
is_same('one wrong answer after the window is just wrong, not locked',
    401, $r['status']);
is_same('and says so', 'wrong', $r['body']['code'] ?? null);
is_true('with attempts still left',
    ($r['body']['attemptsRemaining'] ?? 0) > 0);

$after = row($db, 'SELECT failed_answers, locked_at FROM applications WHERE reference = ?',
    [$reference]);
is_same('the count restarted from the cleared value', 1, (int) $after['failed_answers']);
is_true('and the application is not locked again', $after['locked_at'] === null);

$r = $comeback->send('POST', '/application/resume',
    ['applicationId' => $reference, 'answer' => 'REX']);
is_same('and the right answer still works after that', 200, $r['status']);

$db->exec('DELETE FROM rate_events');
$db->exec('UPDATE applications SET failed_answers = 0, locked_at = NULL');

$db->exec('DELETE FROM rate_events');
$db->exec('UPDATE applications SET failed_answers = 0, locked_at = NULL');

section('The photograph is checked by its bytes, not its label');

$photoApp = new Client($base, $origin);
$r = $photoApp->send('POST', '/application', [
    'securityPrompt' => 'Your first school?',
    'securityAnswer' => 'Oak Lane',
]);
$photoRef = $r['body']['applicationId'] ?? '';
is_true('a second application to submit', $photoRef !== '');

/* A PHP script announced as a JPEG. The declared type used to be the only
   check, so this was written to disk under a .jpg name. */
$notAnImage = 'data:image/jpeg;base64,'
    . base64_encode("<?php echo 'this is not a photograph'; ?>");
$r = $photoApp->send('POST', '/application/submit',
    ['applicationId' => $photoRef, 'photo' => $notAnImage]);
is_same('a script claiming to be a photograph is refused', 400, $r['status']);
is_same('and says why', 'bad_photo', $r['body']['code'] ?? null);
is_true('and nothing was written to the photo folder',
    count(glob($photoDir . '/' . $photoRef . '.*') ?: []) === 0);

/* A real PNG announced as a JPEG: the label and the bytes disagree. */
$realPng = base64_decode(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
);
$r = $photoApp->send('POST', '/application/submit', [
    'applicationId' => $photoRef,
    'photo' => 'data:image/jpeg;base64,' . base64_encode($realPng),
]);
is_same('a PNG labelled as a JPEG is refused', 400, $r['status']);

/* The same PNG, honestly labelled, goes through. */
$r = $photoApp->send('POST', '/application/submit', [
    'applicationId' => $photoRef,
    'photo' => 'data:image/png;base64,' . base64_encode($realPng),
]);
is_true('an honest PNG is accepted', $r['status'] < 400);
is_true('and is on disk as a png', is_file($photoDir . '/' . $photoRef . '.png'));

/* An oversized photograph must say so rather than being dropped in silence.
   submit() used to discard it and answer 200, so an applicant filed a visa
   application with no photograph and was told it had all gone through. */
$big = 'data:image/png;base64,' . base64_encode(str_repeat('x', 3 * 1024 * 1024));
$r = $photoApp->send('POST', '/application/submit',
    ['applicationId' => $photoRef, 'photo' => $big]);
is_same('an oversized photograph is refused, not dropped', 400, $r['status']);
is_true('and the applicant is told which thing was wrong',
    stripos((string) ($r['body']['message'] ?? ''), 'photograph') !== false);

section('Sign out destroys the session on the server');

$outToken = $admin->cookie('vj_admin');
is_true('there is a session to sign out of', $outToken !== '');
$r = $admin->send('DELETE', '/admin/session');
is_true('sign out is accepted', $r['status'] < 400);
$r = $admin->send('GET', '/admin/applications');
is_same('after which the list is refused', 401, $r['status']);

/* The row has to go, not just the cookie. The test only proved the CLIENT
   had dropped its cookie, so an audit removed the DELETE from
   Sessions::endAdmin and nothing noticed -- leaving a token that still works
   for anyone who copied it, which is what the code comment there warns
   about. */
is_same('and the session row is gone from the server', 0,
    (int) value($db, 'SELECT COUNT(*) FROM admin_sessions WHERE token = ?', [$outToken]));

/* Replaying the token proves it, since a client can always re-send a cookie
   it kept. */
$thief = new Client($base, $origin);
$thief->extraHeaders = ['Cookie: vj_admin=' . $outToken];
$r = $thief->send('GET', '/admin/applications');
is_same('so a copy of it is worth nothing', 401, $r['status']);

section('An expired session is refused');

/* Nothing in the suite ever used an expired session, so dropping the
   expires_at condition from Sessions::admin() and applicantId() -- making
   every session last for ever -- went unnoticed. */
$expiring = new Client($base, $origin);
$r = $expiring->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('sign in', !empty($r['body']['mfaRequired']) || $r['status'] === 200);
$db->exec('UPDATE admin_state SET last_totp_step = 0 WHERE id = 1');
$r = $expiring->send('POST', '/admin/session/verify',
    ['code' => Totp::at($totpSecret, intdiv(time(), 30))]);
is_same('and finish it', 200, $r['status']);
$adminToken = $expiring->cookie('vj_admin');
$r = $expiring->send('GET', '/admin/applications');
is_same('the admin session works', 200, $r['status']);

$db->exec('UPDATE admin_sessions SET expires_at = '
    . $db->quote(gmdate('Y-m-d H:i:s', time() - 60))
    . ' WHERE token = ' . $db->quote($adminToken));
$r = $expiring->send('GET', '/admin/applications');
is_same('once expired it is refused', 401, $r['status']);

$appToken = $applicant->cookie('vj_app');
is_true('the applicant has a session too', $appToken !== '');

/* Keep the whole row, because the one below may not exist to UPDATE.
 *
 * This section back-dates expires_at on purpose, and Guard::sweep() -- which
 * fires on one request in fifty -- runs DELETE FROM applicant_sessions WHERE
 * expires_at < now. So the request that proves the expiry is refused could
 * also be the request that removes the row, and the UPDATE that used to put
 * expires_at back then matched nothing: the applicant session was gone for
 * good and three checks in the next two sections failed with a 401. Measured
 * at roughly one run in twelve, which is worse than a check that never
 * passes, because people learn to re-run it instead of reading it.
 * Re-inserting is unconditional, so the sweep cannot win the race. */
$savedSession = row($db,
    'SELECT token, application_id, created_at FROM applicant_sessions WHERE token = ?',
    [$appToken]);
is_true('and its row is there to restore afterwards', $savedSession !== null);

$db->exec('UPDATE applicant_sessions SET expires_at = '
    . $db->quote(gmdate('Y-m-d H:i:s', time() - 60))
    . ' WHERE token = ' . $db->quote($appToken));
$r = $applicant->send('GET', '/application/' . $reference);
is_same('and so is an expired applicant session', 401, $r['status']);

$db->exec('DELETE FROM applicant_sessions WHERE token = ' . $db->quote($appToken));
$restore = $db->prepare(
    'INSERT INTO applicant_sessions (token, application_id, created_at, expires_at)
     VALUES (?, ?, ?, ?)'
);
$restore->execute([
    $savedSession['token'], $savedSession['application_id'],
    $savedSession['created_at'], gmdate('Y-m-d H:i:s', time() + 3600),
]);
$r = $applicant->send('GET', '/application/' . $reference);
is_same('and the restored session works again', 200, $r['status']);

section('Every response is no-store');

$r = $applicant->send('GET', '/application/' . $reference);
/* Assert the status too. Without it this section meant only "the last
   Cache-Control header on whatever came back said no-store" -- an audit
   dropped the applicant's cookie and both checks here passed against a 401,
   because the error path sets no-store as well. A header check on a response
   you have not identified is not a check. */
is_same('the applicant read succeeded', 200, $r['status']);
$cache = '';
foreach ($r['headers'] as $h) {
    if (stripos($h, 'Cache-Control:') === 0) {
        $cache = $h;
    }
}
is_true('the applicant read is no-store', stripos($cache, 'no-store') !== false);

/* And on a 204, which is a different code path: Http::noContent sets its own
   headers, so omitting no-store there was invisible. Every PATCH and the
   sign out answer 204. */
$r = $applicant->send('PATCH', '/application/' . $reference,
    ['stepIndex' => 3, 'data' => ['surname' => 'Ionescu']]);
is_same('a write answers 204', 204, $r['status']);
$cache204 = '';
foreach ($r['headers'] as $h) {
    if (stripos($h, 'Cache-Control:') === 0) { $cache204 = $h; }
}
is_true('and a 204 is no-store as well', stripos($cache204, 'no-store') !== false);

section('Mounted under /api as well as at the root');

$r = $applicant->send('GET', '/api/application/' . $reference);
is_same('the same route answers under /api', 200, $r['status']);
is_same('with the same application', $reference, $r['body']['applicationId'] ?? null);

/* --------------------------------------------------------------- the end */

/* Every instance's log, so a fatal in one of the extra instances is not
   invisible just because route coverage only reads the main one. */
$log = '';
foreach ((array) glob($tmp . '/server*.log') as $logFile) {
    $log .= (string) @file_get_contents($logFile);
}
$fatals = [];
foreach (explode("\n", $log) as $line) {
    if (stripos($line, 'Fatal error') !== false
        || stripos($line, 'Parse error') !== false
        || stripos($line, 'Uncaught') !== false) {
        $fatals[] = trim($line);
    }
}
/* Every route, exercised at least once.
 *
 * /application/email-reference and the photograph route sat untested for a
 * while without anything noticing, and an untested route is exactly where a
 * mistake in the router hides: the handler is never called, so nothing fails.
 * This reads the route table out of index.php and the server's own request
 * log, and fails if any route was never reached. A new route therefore
 * arrives with a test or arrives failing. */
/* A freshly signed-in manager. The $admin client signed out above, so these
   sections need their own full session: password, then a current code. */
$manager = new Client($base, $origin);
$r = $manager->send('POST', '/admin/session',
    ['email' => $adminEmail, 'password' => $adminPassword]);
is_true('a fresh manager passes the password step', $r['status'] === 200);
/* Clear the replay guard first. It records the highest step ever accepted and
   refuses anything at or below it, which is the point -- the sign-in section
   above already consumed the current step, and a code for a FUTURE step is
   outside the drift window, so there is no code this client could send. The
   guard itself is tested in its own section; here it is just in the way. */
$db->exec('UPDATE admin_state SET last_totp_step = 0 WHERE id = 1');
$r = $manager->send('POST', '/admin/session/verify',
    ['code' => Totp::at($totpSecret, intdiv(time(), 30))]);
is_same('and the second factor is accepted', 200, $r['status']);

section('The signed-in manager can be asked who they are');

/* GET /api/admin/session, added so the admin screen can restore a session on
   reload rather than showing the sign-in form to somebody already signed in.
   It arrived with no test and route coverage caught it, which is that check
   doing its job. */
$r = $manager->send('GET', '/admin/session');
is_same('it answers 200 for a signed-in manager', 200, $r['status']);
is_same('with the email', 'manager@example.com', $r['body']['email'] ?? null);
is_true('and says a second factor was presented',
    ($r['body']['secondFactor'] ?? null) === true);

$r = (new Client($base, $origin))->send('GET', '/admin/session');
is_same('a caller with no cookie gets 401', 401, $r['status']);
is_same('as not signed in', 'not_signed_in', $r['body']['code'] ?? null);

section('The admin detail never carries the plaintext security answer');

/* The gap this closes was invisible, and the commit message claimed it was
 * covered.
 *
 * Admin::getApplication unsets securityAnswer from what it returns. That
 * unset could be DELETED and all 184 checks stayed green, because saveStep
 * strips the key before it is ever stored, so applications.answers never
 * contains it under test and the unset is a no-op. An audit went further and
 * actively added 'securityAnswer' => 'LEAK' to the response: still green.
 *
 * So write the key straight into the stored row, the way a future code path
 * or a hand-run UPDATE could, and prove the read strips it. This is the only
 * one of the three unsets whose removal puts a plaintext answer on a wire. */
$answersRow = row($db, 'SELECT answers FROM applications WHERE reference = '
    . $db->quote($reference));
is_true('the row is there to tamper with', $answersRow !== null);
$tampered = json_decode((string) $answersRow['answers'], true);
is_true('and its answers parse', is_array($tampered));
$tampered['securityAnswer'] = 'PLAINTEXT-SHOULD-NEVER-LEAVE';
$tampered['securityAnswerConfirm'] = 'PLAINTEXT-SHOULD-NEVER-LEAVE';
$st = $db->prepare('UPDATE applications SET answers = ? WHERE reference = ?');
$st->execute([json_encode($tampered), $reference]);
is_same('the tampered answer is stored', 1, (int) value($db,
    'SELECT COUNT(*) FROM applications WHERE reference = ' . $db->quote($reference)
    . " AND answers LIKE '%PLAINTEXT-SHOULD-NEVER-LEAVE%'"));

$r = $manager->send('GET', '/admin/applications/' . $reference);
is_same('the detail still answers 200', 200, $r['status']);
is_true('and the answer is not in the data it returns',
    !isset($r['body']['data']['securityAnswer']));
is_true('nor its confirmation',
    !isset($r['body']['data']['securityAnswerConfirm']));
is_true('nor anywhere else in the whole response',
    strpos(json_encode($r['body']), 'PLAINTEXT-SHOULD-NEVER-LEAVE') === false);

/* Put it back, so later sections see the row they expect. */
unset($tampered['securityAnswer'], $tampered['securityAnswerConfirm']);
$st->execute([json_encode($tampered), $reference]);

section('A forwarded header is read from the right end');

/* Http::ip's whole $parts branch was dead code under test.
 *
 * Every config the harness writes sets trusted_proxy_header to '', so ip()
 * returned at the first line and nothing exercised the choice of which end
 * of X-Forwarded-For to believe. Reading the LEFTMOST entry -- the headline
 * bug of an earlier round, which reopens unlimited admin password guessing
 * and lets anyone lock the manager out by naming their address -- was not
 * detected by any check. The suite proved the default was safe and proved
 * nothing about the configuration INSTALL.md tells nginx and ALB users to
 * set. */
$proxyDb = $tmp . '/proxy.sqlite';
$seedProxy = new PDO('sqlite:' . $proxyDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedProxy->exec($schemaSql);
unset($seedProxy);

$proxyConfig = str_replace(
    ["'sqlite:$dbFile'", "'trusted_proxy_header' => ''"],
    ["'sqlite:$proxyDb'", "'trusted_proxy_header' => 'X-Forwarded-For'"],
    $config
);
is_true('the proxy config names the header and its own database',
    strpos($proxyConfig, "'X-Forwarded-For'") !== false
    && strpos($proxyConfig, $proxyDb) !== false
    && strpos($proxyConfig, "'sqlite:$dbFile'") === false);

$proxyDir = $tmp . '/api-proxy';
mkdir($proxyDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($proxyDir) . '/');
file_put_contents($proxyDir . '/config.php', $proxyConfig);
$proxyPort = freePort($port + 1);
$proxyServer = startServer($proxyDir, $proxyPort, $newerThan74,
    descriptorsFor($tmp . '/server-proxy.log'));
is_true('the proxy instance started', $proxyServer !== null);

$proxyPdo = new PDO('sqlite:' . $proxyDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_TIMEOUT => 10]);

/* Five wrong passwords, each claiming a DIFFERENT leftmost address. If the
   leftmost entry were believed, each would get its own bucket and none would
   ever lock. The rightmost entry is the same every time, because that is the
   one the edge itself wrote. */
for ($i = 0; $i < 5; $i++) {
    $spoof = new Client('http://127.0.0.1:' . $proxyPort, $origin);
    $spoof->extraHeaders[] = 'X-Forwarded-For: 9.9.9.' . $i . ', 203.0.113.7';
    $spoof->send('POST', '/admin/session',
        ['email' => 'manager@example.com', 'password' => 'wrong ' . $i]);
}
$buckets = [];
foreach ($proxyPdo->query('SELECT ip, COUNT(*) c FROM rate_events GROUP BY ip')
         as $bucketRow) {
    $buckets[$bucketRow['ip']] = (int) $bucketRow['c'];
}
is_same('all five land in one bucket', 1, count($buckets));
is_same('keyed on the address the edge wrote, not the one the caller chose',
    '203.0.113.7', (string) array_key_first($buckets));
is_same('with all five failures in it', 5, (int) reset($buckets));

/* And the lockout therefore actually bites. */
$sixth = new Client('http://127.0.0.1:' . $proxyPort, $origin);
$sixth->extraHeaders[] = 'X-Forwarded-For: 9.9.9.99, 203.0.113.7';
$r = $sixth->send('POST', '/admin/session',
    ['email' => 'manager@example.com', 'password' => $adminPassword]);
is_same('the sixth attempt is locked out even with the CORRECT password',
    429, $r['status']);

/* A port on the entry, which IIS with ARR and Azure App Service both append.
   filter_var rejects "203.0.113.7:51234", so this used to fall back to the
   connection address with nothing in the log, and every visitor behind that
   edge shared one bucket. */
$ported = new Client('http://127.0.0.1:' . $proxyPort, $origin);
$ported->extraHeaders[] = 'X-Forwarded-For: 9.9.9.1, 198.51.100.22:51234';
$ported->send('POST', '/admin/session',
    ['email' => 'manager@example.com', 'password' => 'wrong']);
is_same('an entry with a port is still read as its address', 1, (int) value($proxyPdo,
    "SELECT COUNT(*) FROM rate_events WHERE ip = '198.51.100.22'"));

section('A relative photo_dir stores nothing');

/* photo_dir must be absolute, and this is what happens if it is not.
 *
 * Under PHP-FPM the working directory is the script's own, which is api/ --
 * inside the document root on most installs. So a relative photo_dir makes
 * mkdir create api/<whatever>/ and writes passport photographs into a folder
 * the web server will hand to anyone who guesses the reference, with no
 * session check anywhere near it. An audit reached exactly that through
 * photo_dir => ['/var/photos'], where (string) of an array is the literal
 * directory name "Array": created relative to api/, photograph written, 200
 * returned to the applicant.
 *
 * The type check in Config::load stops the array. This stops the plain
 * relative string, which is the easier mistake to make by hand. */
$relDb = $tmp . '/relative-photo.sqlite';
$seedRel = new PDO('sqlite:' . $relDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedRel->exec($schemaSql);
unset($seedRel);
$relConfig = str_replace(
    ["'photo_dir' => '$photoDir',", "'sqlite:$dbFile'"],
    ["'photo_dir' => 'photos-relative',", "'sqlite:$relDb'"],
    $config
);
is_true('the relative-photo_dir config is as intended',
    strpos($relConfig, "'photos-relative'") !== false
    && strpos($relConfig, "'sqlite:$dbFile'") === false);

$relDir = $tmp . '/api-relative-photo';
mkdir($relDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($relDir) . '/');
file_put_contents($relDir . '/config.php', $relConfig);
$relPort = freePort($port + 1);
$relServer = startServer($relDir, $relPort, $newerThan74,
    descriptorsFor($tmp . '/server-relative-photo.log'));
is_true('the relative-photo_dir instance started', $relServer !== null);

$relClient = new Client('http://127.0.0.1:' . $relPort, $origin);
$r = $relClient->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
$relRef = $r['body']['applicationId'] ?? '';
is_true('an application can be created on it', $relRef !== '');

$r = $relClient->send('POST', '/application/submit', [
    'applicationId' => $relRef,
    'photo' => 'data:image/png;base64,' . base64_encode($realPng),
]);
is_true('the submission is refused rather than quietly accepted',
    $r['status'] >= 400);
is_true('and nothing was written anywhere under the API directory',
    count(glob($relDir . '/photos-relative/*') ?: []) === 0
    && !is_dir($relDir . '/photos-relative'));
is_true('and the log names photo_dir and says it must be absolute',
    strpos((string) @file_get_contents($tmp . '/server-relative-photo.log'),
        'photo_dir') !== false
    && strpos((string) @file_get_contents($tmp . '/server-relative-photo.log'),
        'absolute') !== false);

section('Without a support address the reference email says so');

/* support_email was called cosmetic, and it was not.
 *
 * Application::supportLine() guards it, so an empty value just leaves a
 * sentence out of a message -- which is what INSTALL.md described. But
 * emailReference interpolated the same setting straight into the mail
 * headers, so with the documented empty default the headers began
 * "From: \r\nReply-To: \r\n", which most MTAs reject outright. The applicant
 * was told to write their reference number down instead, and nothing anywhere
 * named the setting. A developer-perspective audit found it by reading the
 * two uses side by side.
 *
 * It now refuses before building the header and logs which setting is wrong.
 * The status is the same 502 either way, so the log line is the assertion
 * that distinguishes "no mail transport here" from "no address configured". */
$noSupportDb = $tmp . '/no-support.sqlite';
$seedNoSupport = new PDO('sqlite:' . $noSupportDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedNoSupport->exec($schemaSql);
unset($seedNoSupport);
$noSupportConfig = str_replace(
    ["'support_email' => 'support@example.com',", "'sqlite:$dbFile'"],
    ["'support_email' => '',", "'sqlite:$noSupportDb'"],
    $config
);
is_true('the no-support config is as intended',
    strpos($noSupportConfig, "'support_email' => ''") !== false
    && strpos($noSupportConfig, "'sqlite:$dbFile'") === false);

$noSupportDir = $tmp . '/api-no-support';
mkdir($noSupportDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($noSupportDir) . '/');
file_put_contents($noSupportDir . '/config.php', $noSupportConfig);
$noSupportPort = freePort($port + 1);
$noSupportServer = startServer($noSupportDir, $noSupportPort, $newerThan74,
    descriptorsFor($tmp . '/server-no-support.log'));
is_true('the no-support instance started', $noSupportServer !== null);

$noSupport = new Client('http://127.0.0.1:' . $noSupportPort, $origin);
$r = $noSupport->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
$noSupportRef = $r['body']['applicationId'] ?? '';
is_true('an application can be created on it', $noSupportRef !== '');

$r = $noSupport->send('POST', '/application/email-reference',
    ['applicationId' => $noSupportRef, 'email' => 'applicant@example.com']);
is_same('asking for the reference email is refused', 502, $r['status']);
is_same('as a send failure', 'send_failed', $r['body']['code'] ?? null);
is_true('and the applicant is told to write the number down',
    stripos((string) ($r['body']['message'] ?? ''), 'write the number down') !== false);
$noSupportLog = (string) @file_get_contents($tmp . '/server-no-support.log');
is_true('the log names support_email as the reason',
    strpos($noSupportLog, 'support_email') !== false);
is_true('and does not claim the mail transport refused it',
    strpos($noSupportLog, 'mail() refused') === false);

section('A mistyped setting is refused by name, not cast into nonsense');

/* Config::load's type checking and Config::missing had no coverage at all.
 *
 * Audits found five separate settings where a value of the wrong TYPE became
 * plausible-looking nonsense instead of an error: (int) [5] is 1, so a fail
 * limit of [5] locked the only manager out on the first typo; (string) of an
 * array is "Array", so photo_dir => ['/var/photos'] wrote passport
 * photographs into a relative directory inside the web root and answered 200;
 * the same cast on trusted_proxy_header keyed the rate limit on a header
 * named "Array" that any caller could set. None of them logged anything.
 *
 * Deleting the whole clamp list used to pass, and so did `return [];` as the
 * first statement of Config::missing. */
$badConfig = str_replace(
    ["'admin_fail_limit'   => 5,", "'allowed_origins' => ['$origin'],"],
    ["'admin_fail_limit'   => [5],", "'allowed_origins' => '$origin',"],
    $config
);
is_true('the bad config really is malformed',
    strpos($badConfig, '[5]') !== false
    && strpos($badConfig, "'allowed_origins' => '") !== false);

/* allowed_origins written as a list of NUMBERS, which is what happens when
   someone writes a port without quotes. It passes is_array and then fails
   every strict in_array, so every write answers 403 with nothing in the log.
   Only the bare-string shape was covered; an audit showed the item check
   could be deleted outright with the suite still green. */
$portsDb = $tmp . '/ports.sqlite';
$seedPorts = new PDO('sqlite:' . $portsDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedPorts->exec($schemaSql);
unset($seedPorts);
$portsConfig = str_replace(
    ["'allowed_origins' => ['$origin'],", "'sqlite:$dbFile'"],
    ["'allowed_origins' => [8080, 443],", "'sqlite:$portsDb'"],
    $config
);
is_true('the numeric-origins config is as intended',
    strpos($portsConfig, '[8080, 443]') !== false);
$portsDir = $tmp . '/api-ports';
mkdir($portsDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($portsDir) . '/');
file_put_contents($portsDir . '/config.php', $portsConfig);
$portsPort = freePort($port + 1);
$portsServer = startServer($portsDir, $portsPort, $newerThan74,
    descriptorsFor($tmp . '/server-ports.log'), false);
is_true('the numeric-origins instance started', $portsServer !== null);
$r = (new Client('http://127.0.0.1:' . $portsPort, $origin))->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
is_same('a list of numbers stops the API rather than 403ing every write',
    500, $r['status']);
is_same('as an incomplete config', 'config_incomplete', $r['body']['code'] ?? null);
is_true('naming allowed_origins',
    strpos((string) ($r['body']['message'] ?? ''), 'allowed_origins') !== false);

/* And the two shapes a hand-typed list really contains: a stray leading
   space, and a trailing slash. Neither is a type error, both used to match
   nothing under the strict comparison, and both answered 403 silently. */
$sloppyDb = $tmp . '/sloppy.sqlite';
$seedSloppy = new PDO('sqlite:' . $sloppyDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedSloppy->exec($schemaSql);
unset($seedSloppy);
$sloppyConfig = str_replace(
    ["'allowed_origins' => ['$origin'],", "'sqlite:$dbFile'"],
    ["'allowed_origins' => [' $origin/'],", "'sqlite:$sloppyDb'"],
    $config
);
is_true('the sloppy-origins config is as intended',
    strpos($sloppyConfig, "[' $origin/']") !== false);
$sloppyDir = $tmp . '/api-sloppy';
mkdir($sloppyDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($sloppyDir) . '/');
file_put_contents($sloppyDir . '/config.php', $sloppyConfig);
$sloppyPort = freePort($port + 1);
$sloppyServer = startServer($sloppyDir, $sloppyPort, $newerThan74,
    descriptorsFor($tmp . '/server-sloppy.log'));
is_true('the sloppy-origins instance started', $sloppyServer !== null);
$r = (new Client('http://127.0.0.1:' . $sloppyPort, $origin))->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
is_same('a stray space and trailing slash are tolerated, not silently refused',
    200, $r['status']);

$badDir = $tmp . '/api-bad-config';
mkdir($badDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($badDir) . '/');
file_put_contents($badDir . '/config.php', $badConfig);
$badPort = freePort($port + 1);
$badServer = startServer($badDir, $badPort, $newerThan74,
    descriptorsFor($tmp . '/server-bad-config.log'), false);
is_true('the instance with a bad config started', $badServer !== null);

/* allowed_origins as a bare string is the one that must stop the API dead.
   It used to pass empty(), then fail inside Http::sameOrigin(array) as an
   uncaught TypeError OUTSIDE the try block, so the caller got a zero-byte 500
   and the log said only "Uncaught TypeError" with nothing naming the config. */
$badClient = new Client('http://127.0.0.1:' . $badPort, $origin);
$r = $badClient->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
is_same('a bare-string allowed_origins stops the API', 500, $r['status']);
is_same('as an incomplete config', 'config_incomplete', $r['body']['code'] ?? null);
is_true('naming the setting', strpos((string) ($r['body']['message'] ?? ''),
    'allowed_origins') !== false);
is_true('and the body is not empty', trim($r['raw']) !== '');

$badLog = (string) @file_get_contents($tmp . '/server-bad-config.log');
is_true('the log names admin_fail_limit and what was wrong with it',
    strpos($badLog, 'admin_fail_limit') !== false
    && strpos($badLog, 'not a valid int') !== false);
is_true('and no uncaught TypeError anywhere in it',
    stripos($badLog, 'Uncaught TypeError') === false);

section('A placeholder second-factor secret is a configuration error');

/* The guard that made this necessary tested the TEXT of the secret, not the
 * decoded key. None of 0, 1, 8, 9 or any punctuation mark is in the base32
 * alphabet, so a placeholder like '000000' or a dashed paste decodes to a
 * ZERO-LENGTH HMAC key -- and the codes from an empty key are whatever
 * anybody can compute. An audit did exactly that: signIn saw a non-empty
 * secret and issued a half session, verifyCode accepted the universally
 * computable code, and the result was a full session with second_factor = 1,
 * the flag the card-reveal routes are specified to check.
 *
 * Empty still means "not enrolled yet" and signs straight in. Set but
 * unusable now fails closed and says which tool to re-run. */
$junkDb = $tmp . '/junk-secret.sqlite';
$seedJunk = new PDO('sqlite:' . $junkDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedJunk->exec($schemaSql);
unset($seedJunk);
$junkConfig = str_replace(
    ["'totp_secret'         => '$totpSecret',", "'sqlite:$dbFile'"],
    ["'totp_secret'         => '000000',", "'sqlite:$junkDb'"],
    $config
);
is_true('the junk-secret config is the one we meant to write',
    strpos($junkConfig, "'000000'") !== false
    && strpos($junkConfig, "'sqlite:$dbFile'") === false);

$junkDir = $tmp . '/api-junk-secret';
mkdir($junkDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($junkDir) . '/');
file_put_contents($junkDir . '/config.php', $junkConfig);
$junkPort = freePort($port + 1);
$junkServer = startServer($junkDir, $junkPort, $newerThan74,
    descriptorsFor($tmp . '/server-junk-secret.log'));
is_true('the junk-secret instance started', $junkServer !== null);

$junkClient = new Client('http://127.0.0.1:' . $junkPort, $origin);
$r = $junkClient->send('POST', '/admin/session',
    ['email' => 'manager@example.com', 'password' => $adminPassword]);
is_same('the correct password does NOT sign in', 500, $r['status']);
is_same('it is reported as a configuration problem',
    'not_configured', $r['body']['code'] ?? null);
is_true('no session cookie is issued', !$junkClient->has('vj_admin'));
is_true('and no admin session row exists',
    (int) value(new PDO('sqlite:' . $junkDb, null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]),
        'SELECT COUNT(*) FROM admin_sessions') === 0);
is_true('and the log says which tool to re-run',
    strpos((string) @file_get_contents($tmp . '/server-junk-secret.log'),
        'enrol-totp.php') !== false);

section('Http::ip, every branch of it');

/* The instance above proves the whole path end to end through a real server,
 * which is the check that matters. These are direct calls, because the branches
 * differ by the SHAPE of the header and booting an instance per shape would
 * cost thirty seconds to test twenty lines. Between them they cover every
 * route through the function; before this round none of them were covered at
 * all, which is how three separate defects got in.
 *
 * Whatever this returns is the key for every rate-limit and lockout bucket, so
 * a caller who can choose it can guess passwords without limit and lock the
 * only manager out by naming their address. */
require_once $root . '/api/lib/Http.php';

$ipWith = function (array $cfg, $header, string $remote = '10.0.0.9') {
    Http::configure($cfg);
    $_SERVER['REMOTE_ADDR'] = $remote;
    if ($header === null) {
        unset($_SERVER['HTTP_X_FORWARDED_FOR'], $_SERVER['HTTP_CF_CONNECTING_IP']);
    } else {
        $_SERVER[$cfg['_key'] ?? 'HTTP_X_FORWARDED_FOR'] = $header;
    }
    return Http::ip();
};
$xff = ['trusted_proxy_header' => 'X-Forwarded-For'];

is_same('no header configured: the connection address, whatever is sent',
    '10.0.0.9', $ipWith([], '9.9.9.1, 203.0.113.7'));
is_same('one proxy: the entry the edge wrote, not the one the caller chose',
    '203.0.113.7', $ipWith($xff, '9.9.9.1, 203.0.113.7'));
is_same('two proxies: one further left, past the inner proxy',
    '203.0.113.7',
    $ipWith($xff + ['trusted_proxy_hops' => 2], '9.9.9.1, 203.0.113.7, 172.70.1.1'));
/* A chain shorter than the hop count. The explicit guard in ip() makes this
   return the connection address deliberately; without it the out-of-range
   index yields null, fails validation and reaches the same answer by accident,
   with an undefined-index notice on the way. Same result, so this check does
   not distinguish the two -- it pins the OUTCOME, which is the part that must
   never become "read the leftmost entry". */
is_same('a chain shorter than the hop count falls back, it does not read leftmost',
    '10.0.0.9', $ipWith($xff + ['trusted_proxy_hops' => 2], 'evil'));
is_same('and the same with a two-entry chain and three hops',
    '10.0.0.9', $ipWith($xff + ['trusted_proxy_hops' => 3], 'evil, 203.0.113.7'));
is_same('an IPv4 address with a port (IIS ARR, Azure)',
    '198.51.100.22', $ipWith($xff, '9.9.9.1, 198.51.100.22:51234'));
is_same('a bracketed IPv6 address with a port',
    '2001:db8::1', $ipWith($xff, '9.9.9.1, [2001:db8::1]:443'));
is_same('a bare IPv6 address', '2001:db8::2', $ipWith($xff, '2001:db8::2'));
is_same('a trailing comma from the edge falls back rather than trusting junk',
    '10.0.0.9', $ipWith($xff, '203.0.113.7, '));
is_same('nothing usable in the header falls back',
    '10.0.0.9', $ipWith($xff, 'unknown'));
is_same('an empty header falls back', '10.0.0.9', $ipWith($xff, ''));
is_same('a header set outright by the edge is read from the LEFT',
    '198.51.100.5',
    $ipWith(['trusted_proxy_header' => 'CF-Connecting-IP',
             '_key' => 'HTTP_CF_CONNECTING_IP'], '198.51.100.5'));

/* Configuration mistakes. Each of these used to hand the bucket to the caller
   or collapse every visitor into one, silently. */
/* Set the header the unknown name WOULD read, so this distinguishes
   "refused the name" from "the name happened to match nothing". Without the
   header present the check passes either way, which is no check at all. */
$_SERVER['HTTP_X_CLIENT_IP'] = '9.9.9.9';
is_same('a header name this code does not know is refused, not trusted',
    '10.0.0.9', $ipWith(['trusted_proxy_header' => 'X-Client-IP',
        '_key' => 'HTTP_X_CLIENT_IP'], '9.9.9.9'));
unset($_SERVER['HTTP_X_CLIENT_IP']);
/* Naming two headers is refused outright. The guard here is against a future
   "helpful" change that splits on the comma and honours the first name, which
   would silently start trusting a header the installer only half-meant. */
is_same('naming two headers at once is refused rather than half-honoured',
    '10.0.0.9', $ipWith(['trusted_proxy_header' => 'X-Forwarded-For, CF-Connecting-IP'],
        '9.9.9.1, 203.0.113.7'));
is_same('the PHP variable spelling is accepted, not doubled into HTTP_HTTP_',
    '203.0.113.7', $ipWith(['trusted_proxy_header' => 'HTTP_X_FORWARDED_FOR'],
        '9.9.9.1, 203.0.113.7'));
is_same('a non-string header setting is ignored, not cast to "Array"',
    '10.0.0.9', $ipWith(['trusted_proxy_header' => ['X-Forwarded-For']],
        '9.9.9.1, 203.0.113.7'));
is_same('a hop count below one is treated as one',
    '203.0.113.7', $ipWith($xff + ['trusted_proxy_hops' => 0],
        '9.9.9.1, 203.0.113.7'));

/* Leave the static clean for anything after this. */
Http::configure([]);
unset($_SERVER['HTTP_X_FORWARDED_FOR'], $_SERVER['HTTP_CF_CONNECTING_IP']);

section('Every setting has a default and a declared type');

/* The two tables in Config have to stay in step.
 *
 * load() walks TYPES and reads $cfg[$key] for each entry, so a type declared
 * for a setting that is not in DEFAULTS is an undefined index on every
 * request from an install whose config.php does not happen to name it. And a
 * setting in DEFAULTS with no type declared is simply unchecked -- which is
 * how five settings came to accept values of the wrong type and turn them
 * into plausible nonsense. Adding a setting now means adding both, or this
 * fails and says which one is missing. */
require_once $root . '/api/lib/Config.php';
$defaultKeys = array_keys(Config::DEFAULTS);
$typeKeys = array_keys(Config::TYPES);
sort($defaultKeys);
sort($typeKeys);
is_same('no setting is missing a declared type',
    [], array_values(array_diff($defaultKeys, $typeKeys)));
is_same('and no declared type is missing a default',
    [], array_values(array_diff($typeKeys, $defaultKeys)));

section('An unspellable boolean falls back to the safe value');

/* The bool normaliser had no coverage: replacing it with the plain (bool)
 * cast it was written to replace passed the entire suite.
 *
 * secure_cookies is the one that matters. (bool) '' is false, which silently
 * drops Secure from the cookie that authorises reading passport numbers and
 * dates of birth, so an unspellable value must fall back to the default of
 * true rather than to whatever PHP's cast produces. */
$secureDb = $tmp . '/secure.sqlite';
$seedSecure = new PDO('sqlite:' . $secureDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedSecure->exec($schemaSql);
unset($seedSecure);
$secureConfig = str_replace(
    ["'secure_cookies' => false,", "'sqlite:$dbFile'"],
    ["'secure_cookies' => '',", "'sqlite:$secureDb'"],
    $config
);
is_true('the unspellable-bool config is as intended',
    strpos($secureConfig, "'secure_cookies' => ''") !== false);
$secureDir = $tmp . '/api-secure';
mkdir($secureDir, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . '/. ' . escapeshellarg($secureDir) . '/');
file_put_contents($secureDir . '/config.php', $secureConfig);
$securePort = freePort($port + 1);
$secureServer = startServer($secureDir, $securePort, $newerThan74,
    descriptorsFor($tmp . '/server-secure.log'));
is_true('the unspellable-bool instance started', $secureServer !== null);

$secureClient = new Client('http://127.0.0.1:' . $securePort, $origin);
$r = $secureClient->send('POST', '/application',
    ['securityPrompt' => 'Your first pet?', 'securityAnswer' => 'Rex']);
is_same('it still serves requests', 200, $r['status']);
$setCookie = '';
foreach ($r['headers'] as $h) {
    if (stripos($h, 'Set-Cookie:') === 0) { $setCookie = $h; }
}
is_true('a session cookie was set', $setCookie !== '');
is_true('and it carries Secure, because the default is true not false',
    stripos($setCookie, 'Secure') !== false);
is_true('the log names secure_cookies as the setting it fell back on',
    strpos((string) @file_get_contents($tmp . '/server-secure.log'),
        'secure_cookies') !== false);

section('A row left at the fail limit with no lock heals itself');

/* The branch added in round 4 had no test: deleting it passed everything.
 *
 * A support person hand-running an "unlock" UPDATE that writes locked_at = ''
 * rather than NULL leaves a row with the failure count at the limit and no
 * timestamp beside it. resume() would then give the applicant one attempt and
 * lock them straight out again, for ever. lockRemaining heals that shape on
 * the way past, and this is the only path into that function that did not. */
$healRef = $reference;
$limit = 5;
$st = $db->prepare("UPDATE applications SET locked_at = '', failed_answers = ?"
    . ' WHERE reference = ?');
$st->execute([$limit, $healRef]);
$beforeHeal = row($db, 'SELECT locked_at, failed_answers FROM applications'
    . ' WHERE reference = ' . $db->quote($healRef));
is_true('the row is in the state a hand-run unlock leaves',
    $beforeHeal !== null && $beforeHeal['locked_at'] === ''
    && (int) $beforeHeal['failed_answers'] === $limit);

$healer = new Client($base, $origin);
$r = $healer->send('POST', '/application/lookup', ['applicationId' => $healRef]);
is_same('the reference still resolves rather than reading as locked',
    200, $r['status']);
$afterHeal = row($db, 'SELECT locked_at, failed_answers FROM applications'
    . ' WHERE reference = ' . $db->quote($healRef));
is_true('the row is there after the heal', $afterHeal !== null);
is_true('the stray timestamp is cleared',
    $afterHeal !== null && $afterHeal['locked_at'] === null);
is_same('and the count is back to zero, so the next wrong answer is not the last',
    0, $afterHeal === null ? -1 : (int) $afterHeal['failed_answers']);

section('A placeholder secret is refused even when it is the right length');

/* The round-4 fix checked the decoded LENGTH, and that was not enough.
 *
 * 'AAAAAAAAAAAAAAAA' is sixteen base32 characters, so it decodes to a full
 * ten bytes -- of 0x00. An audit computed the code for the current step from
 * that known key, signed in with it, and ended up holding a session with
 * second_factor = 1, the flag the card routes are specified to check. Length
 * alone cannot tell a secret from a placeholder.
 *
 * These are direct calls because the guard is a pure function and booting an
 * instance per placeholder would cost a second each. The end-to-end path is
 * covered by the junk-secret instance below. */
foreach (['AAAAAAAAAAAAAAAA', 'AAAA-AAAA-AAAA-AAAA', 'BBBBBBBBBBBBBBBB',
          '2222222222222222', 'ABABABABABABABAB', 'CHANGEMECHANGEME',
          'AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
          '000000', '0', '------', ''] as $placeholder) {
    is_true('refused as a secret: ' . ($placeholder === '' ? '(empty)' : $placeholder),
        !Totp::usable($placeholder));
}

/* And nothing legitimate is refused, including the shortest length the guard
   allows and a secret pasted with the dashes an authenticator app shows.
   generateSecret() checks its own output against usable(), so this also
   proves that loop terminates. */
$shortSecret = Totp::generateSecret(10);
is_true('a generated 10-byte secret is usable', Totp::usable($shortSecret));
$fullSecret = Totp::generateSecret();
is_true('a generated 20-byte secret is usable', Totp::usable($fullSecret));
is_true('and so is the same secret pasted with dashes',
    Totp::usable(implode('-', str_split($fullSecret, 4))));
$step = intdiv(time(), 30);
is_same('a dashed paste verifies against the undashed codes', $step,
    Totp::verify(implode('-', str_split($fullSecret, 4)), Totp::at($fullSecret, $step)));

section('The enrolment tool is the only thing that writes recovery codes');

/* tools/enrol-totp.php had no coverage at all, and it is load-bearing.
 *
 * It is the only correct way to enrol the second factor, and the only thing
 * that writes the ten recovery codes. A developer-perspective audit found
 * that site/README.md offered a hand-rolled alternative instead, which
 * produces a working TOTP with ZERO recovery codes -- and with one admin
 * account, a lost phone is then a permanent lockout of the admin screen,
 * discovered at the worst possible moment. If this tool ever silently stops
 * writing them the same thing happens, so it needs a test of its own.
 *
 * The tool resolves its config as __DIR__/../api/config.php, so it runs
 * against a copied tree with its own database. */
$enrolRoot = $tmp . '/enrol';
mkdir($enrolRoot, 0700, true);
exec('cp -R ' . escapeshellarg($root . '/api') . ' ' . escapeshellarg($enrolRoot . '/api'));
exec('cp -R ' . escapeshellarg($root . '/tools') . ' ' . escapeshellarg($enrolRoot . '/tools'));
$enrolDb = $tmp . '/enrol.sqlite';
$seedEnrol = new PDO('sqlite:' . $enrolDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$seedEnrol->exec($schemaSql);
/* A used step, so the reset is observable rather than coinciding with the
   seeded zero. */
$seedEnrol->exec('UPDATE admin_state SET last_totp_step = 999999 WHERE id = 1');
unset($seedEnrol);
file_put_contents($enrolRoot . '/api/config.php',
    "<?php return ['dsn' => 'sqlite:" . $enrolDb . "',"
    . " 'allowed_origins' => ['" . $origin . "'], 'totp_secret' => ''];");

$enrolOut = (string) shell_exec('cd ' . escapeshellarg($enrolRoot . '/tools')
    . ' && php enrol-totp.php 2>&1');
is_true('the tool runs and prints a secret',
    preg_match('/TOTP_SECRET=([A-Z2-7]+)/', $enrolOut, $enrolMatch) === 1);
$enrolSecret = $enrolMatch[1] ?? '';
is_true('and the secret it printed is one the API will accept',
    $enrolSecret !== '' && Totp::usable($enrolSecret));
is_true('it prints an otpauth URI to scan',
    strpos($enrolOut, 'otpauth://totp/') !== false);

$enrolPdo = new PDO('sqlite:' . $enrolDb, null, null,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
     PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
is_same('ten recovery codes are stored', 10,
    (int) value($enrolPdo, 'SELECT COUNT(*) FROM admin_recovery_codes'));
is_same('and the replay guard is reset, so the first code is not refused', 0,
    (int) value($enrolPdo, 'SELECT last_totp_step FROM admin_state WHERE id = 1'));

/* Only hashes, never the codes themselves. The tool says "only their hashes
   are stored", and that promise is the whole reason it is safe to print them
   once on a terminal. */
$codeRows = $enrolPdo->query('SELECT code_hash FROM admin_recovery_codes')
    ->fetchAll(PDO::FETCH_COLUMN);
$plaintextStored = 0;
foreach ($codeRows as $storedHash) {
    if (password_get_info((string) $storedHash)['algo'] === null) {
        $plaintextStored++;
    }
}
is_same('every stored recovery code is a password hash, not the code', 0,
    $plaintextStored);
/* The real format: ten lowercase hex characters, one per line, no dashes.
   An earlier version of this check guessed a dashed shape and failed,
   which is the right way round for a test to be wrong. */
preg_match_all('/^\s*([0-9a-f]{10})\s*$/m', $enrolOut, $printedCodes);
is_same('the tool printed all ten codes for the person to keep', 10,
    count($printedCodes[1] ?? []));
$leaked = 0;
foreach (($printedCodes[1] ?? []) as $printed) {
    foreach ($codeRows as $storedHash) {
        if ((string) $storedHash === $printed) {
            $leaked++;
        }
    }
}
is_same('and none of them is in the database in the clear', 0, $leaked);

section('A password hash that is not a hash says so');

/* admin_password_hash is a string whether it holds a bcrypt hash or the
   password itself, so the type table cannot tell them apart -- and pasting
   the password is the obvious slip at the step whose whole job is "run this
   and paste what it prints". password_verify against a non-hash always
   returns false, signIn's empty-check passes so it does not report
   not_configured, and the only admin account refuses the correct password for
   ever with nothing in the log. */
$hashProbe = $tmp . '/hash-probe.php';
file_put_contents($hashProbe, "<?php return ["
    . "'dsn' => 'sqlite:" . $dbFile . "',"
    . "'allowed_origins' => ['" . $origin . "'],"
    . "'admin_password_hash' => 'correct horse battery staple',"
    . "];");
$prevLog = ini_get('error_log');
$capture = $tmp . '/config-warnings.log';
ini_set('error_log', $capture);
Config::load($hashProbe);
ini_set('error_log', (string) $prevLog);
$warned = (string) @file_get_contents($capture);
is_true('a plaintext password in admin_password_hash is logged',
    strpos($warned, 'admin_password_hash') !== false);
is_true('and the log says what to re-run',
    strpos($warned, 'make-admin-hash.php') !== false);

@unlink($capture);
file_put_contents($hashProbe, "<?php return ["
    . "'dsn' => 'sqlite:" . $dbFile . "',"
    . "'allowed_origins' => ['" . $origin . "'],"
    . "'admin_password_hash' => " . var_export($adminHash, true) . ","
    . "];");
ini_set('error_log', $capture);
Config::load($hashProbe);
ini_set('error_log', (string) $prevLog);
is_true('and a real bcrypt hash is not complained about',
    strpos((string) @file_get_contents($capture), 'admin_password_hash') === false);

section('Db::flag reads a boolean from any of the three databases');

/* Nothing exercised this, and its failure mode is a security one.
 *
 * Each database hands back a boolean differently: SQLite and MySQL give 1 or
 * 0, and on PHP 7.4 the Postgres driver gives the STRINGS 't' and 'f'. The
 * trap is that 'f' is a non-empty string, so (bool) 'f' is TRUE -- a false
 * flag read as true. Db::flag exists for exactly that, and the suite could
 * not see it: an audit replaced the whole function body with
 * `return (bool) $value;` and all 184 checks stayed green, because SQLite
 * never produces 't' or 'f' for the suite to trip over.
 *
 * These are direct calls rather than requests, because the value the real
 * Postgres driver returns cannot be produced from here. The flag that matters
 * is second_factor: read as true when it is false, a password-only session
 * would pass the guard the card-reveal routes are specified to use. */
require_once $root . '/api/lib/Db.php';

is_same("Postgres false ('f') is false", false, Db::flag('f'));
is_same("Postgres true ('t') is true", true, Db::flag('t'));
is_same('MySQL and SQLite 0 is false', false, Db::flag(0));
is_same('MySQL and SQLite 1 is true', true, Db::flag(1));
is_same("a stringified 0 is false", false, Db::flag('0'));
is_same("a stringified 1 is true", true, Db::flag('1'));
is_same('a real false is false', false, Db::flag(false));
is_same('a real true is true', true, Db::flag(true));
is_same('null is false', false, Db::flag(null));
is_same('an empty string is false', false, Db::flag(''));
is_same("the word 'false' is false", false, Db::flag('false'));
is_same("the word 'true' is true", true, Db::flag('true'));

section('Route coverage');

$routeSrc = file_get_contents($root . '/api/index.php');
preg_match('/\$routes\s*=\s*\[(.*?)\n\];/s', $routeSrc, $tableMatch);
preg_match_all("/\\['([A-Z]+)',\\s*'#\\^(.*?)\\\$#'/", $tableMatch[1] ?? '', $declared,
    PREG_SET_ORDER);

$logSoFar = @file_get_contents($tmp . '/server.log') ?: '';

/* php -S logs one line per request: "[200]: GET /admin/applications".
   The status matters as well as the path: a route whose only hit is a 401 has
   had its guard exercised and its handler never run, which is half a test and
   was counted as a whole one. */
$requests = [];
foreach (explode("\n", $logSoFar) as $line) {
    if (!preg_match('/\[(\d{3})\]:\s*([A-Z]+)\s+(\S+)/', $line, $hit)) {
        continue;
    }
    $path = parse_url($hit[3], PHP_URL_PATH) ?: '/';
    $path = '/' . trim($path, '/');
    if (strncmp($path, '/api/', 5) === 0) {
        $path = substr($path, 4);
    }
    $requests[] = ['status' => (int) $hit[1], 'verb' => $hit[2], 'path' => $path];
}

is_true('the server log recorded requests', count($requests) > 0);

/* And it recorded ONLY the instance under test.
 *
 * Route coverage reads the main instance's log. When all the instances wrote
 * to one file, a route exercised solely by the legacy-config instance --
 * different config, different database -- counted as coverage for the main
 * one: an audit stubbed out the main instance's lookup route entirely and
 * both coverage checks stayed green. php -S logs the client address on each
 * line, not its own port, so the lines cannot be separated after the fact.
 * These two checks fail if the files are ever merged back together, which is
 * the only way the property can be guarded directly. */
$silentLogs = [];
foreach (['legacy', 'no-secret', 'proxy', 'bad-config',
          'junk-secret', 'relative-photo', 'no-support', 'ports',
          'sloppy', 'secure'] as $instance) {
    $instanceLog = $tmp . '/server-' . $instance . '.log';
    if (!preg_match('/\[\d{3}\]:/', (string) @file_get_contents($instanceLog))) {
        $silentLogs[] = $instance;
    }
}
is_same('every other instance logged its own requests to its own file',
    [], $silentLogs);


$neverCalled = [];
$neverSucceeded = [];
foreach ($declared as $route) {
    list(, $verb, $pattern) = $route;
    $called = false;
    $succeeded = false;
    foreach ($requests as $req) {
        if ($req['verb'] === $verb && preg_match('#^' . $pattern . '$#', $req['path'])) {
            $called = true;
            if ($req['status'] >= 200 && $req['status'] < 300) {
                $succeeded = true;
            }
        }
    }
    if (!$called) {
        $neverCalled[] = $verb . ' ' . $pattern;
    } elseif (!$succeeded) {
        $neverSucceeded[] = $verb . ' ' . $pattern;
    }
}

is_same('every route in index.php was called: ' . count($declared) . ' declared',
    [], $neverCalled);

/* Routes that were only ever refused. email-reference belongs here honestly:
   there is no mail transport in a container, so its success branch -- the one
   that composes the message, which must never carry the security question or
   the answer -- cannot run. Anything else appearing here is a test that only
   checks a guard. */
$expectedNo2xx = ['POST /application/email-reference'];
$unexpected = array_values(array_diff($neverSucceeded, $expectedNo2xx));
is_same('and every route except the mail one reached a 2xx', [], $unexpected);
/* And the list has to stay honest in the other direction too.

   This was a printed note, which meant the list could only ever grow: an
   audit added two routes that DO reach a 2xx and got two friendly notes and
   exit 0. An entry that is no longer needed is a hole, because it suppresses
   the 2xx requirement for a route that could then quietly regress to
   guard-only coverage. Failing here costs one line to fix and keeps the
   exemption list down to the routes that genuinely cannot succeed. */
$stillRefusedOnly = array_values(array_intersect($neverSucceeded, $expectedNo2xx));
$staleExemptions = array_values(array_diff($expectedNo2xx, $stillRefusedOnly));
is_same('and no route is exempted from that which no longer needs to be',
    [], $staleExemptions);

section('The server log');
$wholeLog = (string) @file_get_contents($tmp . '/server.log');
is_true('no card number reached the server log',
    strpos($wholeLog, $visa) === false && strpos($wholeLog, $mc) === false
    && strpos($wholeLog, $amex) === false);
is_true('no security code, and not even the word, reached the server log',
    stripos($wholeLog, 'cvv') === false && strpos($wholeLog, '"0373"') === false
    && strpos($wholeLog, '"737"') === false);
if ($fatals) {
    bad('no fatals in the server log', implode("\n        ", array_slice($fatals, 0, 5)));
} else {
    ok('no fatals in the server log');
}

echo "\n";
echo str_repeat('-', 56) . "\n";
printf("  %d passed, %d failed\n", $passed, $failed);
echo str_repeat('-', 56) . "\n";

if ($failed > 0) {
    echo "\nServer log:\n" . $log . "\n";
}

exit($failed > 0 ? 1 : 0);
