<?php
declare(strict_types=1);
class Good {
    private static ?PDO $pdo = null;
    private array $rows = [];
    public function run(string $s): ?array {
        $f = static fn($x) => $x + 1;
        $g = function ($x) { return $x * 2; };
        if (substr($s, 0, 1) === 'a') { return [$f(1), $g(2)]; }
        if (strpos($s, 'c') !== false) { return null; }
        $this->rows ??= [];
        foreach ([[1,2],[3,4]] as [$a, $b]) { $this->rows[] = $a + $b; }
        setcookie('n', 'v', ['samesite' => 'Lax', 'httponly' => true]);
        return array_map(function ($r) { return ['v' => $r]; }, $this->rows);
    }
}
