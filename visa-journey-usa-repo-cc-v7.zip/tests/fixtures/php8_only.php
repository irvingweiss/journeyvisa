<?php
/* NOT VALID PHP 7.4. DO NOT LINT THIS FILE, DO NOT DEPLOY IT.
 *
 * It is the fixture for `node php74_check.js --self-test`, and it exists to
 * contain one of every construct that check is supposed to catch. If the
 * check stops detecting something, --self-test says which, and that is the
 * only reason this file is here.
 *
 * It parses on PHP 8.x and is rejected by a PHP 7.4 parser, which is the
 * point. Add a line here whenever you add a rule to the checker.
 */
declare(strict_types=1);
#[SomeAttribute]
class Bad {
    public readonly int $frozen;
    public function __construct(private string $promoted, public ?int $also = null) {}
    public function a(): int|string { return 1; }
    public function b(): mixed { return null; }
    public function c(): never { throw new ValueError('x'); }
    public function d(object $o): string { return $o::class; }
}
function uses_new_functions(string $s): bool {
    if (str_starts_with($s, 'a')) return true;
    if (str_ends_with($s, 'b')) return true;
    if (str_contains($s, 'c')) return true;
    if (array_is_list([1,2])) return true;
    if (json_validate($s)) return true;
    echo get_debug_type($s);
    echo fdiv(1.0, 0.0);
    return false;
}
function uses_syntax($a) {
    $v = $a?->prop;
    $w = match($a) { 1 => 'one', default => 'other' };
    try { uses_new_functions('x'); } catch (Exception) {}
    return [$v, $w];
}

/* Added after an audit found the checker blind to these. */
function reached_indirectly(string $s): bool {
    $f = 'str_contains';
    if (call_user_func('str_starts_with', $s, 'a')) { return true; }
    if (array_map('mb_ucfirst', [$s])) { return true; }
    return (bool) $f($s, 'x');
}
class LowerCaseNames {
    public function go() {
        $a = new valueerror('x');      // PHP is case-insensitive about this
        $b = new FIBER(function () {});
        $c = new Random\Randomizer();
        return [$a, $b, $c];
    }
}
function newer_types(): false { return false; }
class StaticReturn {
    /* Inside a class: `: static` outside one is a fatal on every PHP version,
       which would make this fixture invalid rather than merely PHP 8. */
    public function self_(): static { return $this; }
}

/* Constructs the checker has rules for and this fixture had no example of, so
 * deleting those rules left --self-test green. Added after an audit showed it. */
enum Suit: string {
    case Hearts = 'H';
    case Spades = 'S';
}

interface Countable2 {}
interface Stringable2 {}

readonly class FrozenThing {
    public function __construct(public int $n) {}
}

class TypedConstants {
    final public const int LIMIT = 5;          // final const 8.1, typed const 8.3
    public function both(Countable2&Stringable2 $x): void {}   // intersection, 8.1
}

function named_arguments(): void {
    str_pad(string: 'x', length: 4);           // named arguments, 8.0
}

function newer_constant(): bool {
    return filter_var('1', FILTER_VALIDATE_BOOL) === true;   // 8.0
}
