#!/usr/bin/env node
/* Does this PHP run on 7.4?
 *
 * Two passes, because neither alone is enough:
 *
 *   1. Parse every file against a PHP 7.4 grammar. Catches match, ?->, named
 *      arguments, enum, catch without a variable, trailing commas in parameter
 *      lists.
 *   2. Walk the tree. Catches what the 7.4 grammar wrongly accepts
 *      (constructor promotion, attributes, readonly, union and intersection
 *      types, never/mixed, $obj::class) and the thing no grammar can catch:
 *      calls to functions that did not exist until 8.0.
 *
 * Usage: node php74_check.js <dir-or-file> [...]
 * Exits non-zero on any finding, so it can sit in a test run.
 */

"use strict";

const fs = require("fs");
const path = require("path");
const engine = require("php-parser");

/* Functions added after 7.4. A call to one of these parses perfectly well and
 * then fatals on the server, which is the worst way to find out. */
const ADDED_AFTER_74 = {
  // 8.0
  str_contains: "8.0",
  str_starts_with: "8.0",
  str_ends_with: "8.0",
  fdiv: "8.0",
  get_debug_type: "8.0",
  preg_last_error_msg: "8.0",
  get_resource_id: "8.0",
  // 8.1
  array_is_list: "8.1",
  enum_exists: "8.1",
  fsync: "8.1",
  fdatasync: "8.1",
  // 8.2
  mysqli_execute_query: "8.2",
  curl_upkeep: "8.2",
  ini_parse_quantity: "8.2",
  memory_reset_peak_usage: "8.2",
  openssl_cipher_key_length: "8.2",
  // 8.3
  json_validate: "8.3",
  mb_str_pad: "8.3",
  str_increment: "8.3",
  str_decrement: "8.3",
  stream_context_set_options: "8.3",
  // 8.4
  array_find: "8.4",
  array_find_key: "8.4",
  array_any: "8.4",
  array_all: "8.4",
  mb_trim: "8.4",
  mb_ltrim: "8.4",
  mb_rtrim: "8.4",
  mb_ucfirst: "8.4",
  mb_lcfirst: "8.4",
  bcdivmod: "8.4",
  http_get_last_response_headers: "8.4",
  request_parse_body: "8.4",
};

/* Classes and constants that arrived with 8.0 or later. */
/* Compared case-insensitively: PHP class names are not case sensitive, so
 * `new valueerror()` is the same class as `new ValueError()`. Checking these
 * as written let both spellings of every one of them through. */
const CLASSES_AFTER_74 = {
  ValueError: "8.0",
  UnhandledMatchError: "8.0",
  WeakMap: "8.0",
  Stringable: "8.0",
  Attribute: "8.0",
  PhpToken: "8.0",
  ReflectionUnionType: "8.0",
  ReflectionIntersectionType: "8.1",
  ReturnTypeWillChange: "8.1",
  Fiber: "8.1",
  FiberError: "8.1",
  "Random\\Randomizer": "8.2",
  "Random\\Engine\\Mt19937": "8.2",
  "Random\\Engine\\Xoshiro256StarStar": "8.2",
  "Random\\Engine\\PcgOneseq128XslRr64": "8.2",
  "Random\\Engine\\Secure": "8.2",
  AllowDynamicProperties: "8.2",
  SensitiveParameter: "8.2",
  Override: "8.3",
  Deprecated: "8.4",
  NoDiscard: "8.5",
};

/* The same map, keyed lowercase, which is how PHP resolves a class name. */
const CLASSES_AFTER_74_LC = {};
for (const [name, version] of Object.entries(CLASSES_AFTER_74)) {
  CLASSES_AFTER_74_LC[name.toLowerCase()] = { name, version };
}

const CONSTANTS_AFTER_74 = {
  FILTER_VALIDATE_BOOL: "8.0",
  MYSQLI_REFRESH_REPLICA: "8.1",
  CURLSTRING: "8.1",
  ROUND_HALF_UP: null, // old, ignore
};

/* Types that only exist from 8.0. 'mixed' is 8.0, 'never' is 8.1,
 * 'false'/'null' as standalone types are 8.2, 'true' is 8.2. */
const TYPES_AFTER_74 = {
  mixed: "8.0",
  static: "8.0",
  never: "8.1",
  true: "8.2",
  false: "8.2",
  null: "8.2",
};

const findings = [];

function note(file, line, kind, detail) {
  findings.push({ file, line: line || 0, kind, detail });
}

function phpFiles(target) {
  const st = fs.statSync(target);
  /* .php is not the only extension PHP gets served under, and a file the
     checker silently skips is worse than one it fails on. */
  const PHP_EXT = [".php", ".inc", ".phtml", ".php5", ".php7", ".phps"];
  if (st.isFile()) {
    return PHP_EXT.some((e) => target.toLowerCase().endsWith(e)) ? [target] : [];
  }
  const out = [];
  for (const entry of fs.readdirSync(target, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name.startsWith(".")) continue;
    /* tests/fixtures holds deliberately broken PHP for --self-test. Scanning
       it as real code reports findings that are the file's whole purpose.
       Matched by path, not by name: skipping every directory called
       "fixtures" anywhere in a tree would quietly skip real code. */
    if (entry.isDirectory() &&
        path.resolve(path.join(target, entry.name)) ===
        path.resolve(path.join(__dirname, "fixtures"))) continue;
    out.push(...phpFiles(path.join(target, entry.name)));
  }
  return out.sort();
}

/* ---- pass 2: walk the tree ---------------------------------------------- */

function typeNames(node) {
  /* A type is either one node or, for a union/intersection, a list. */
  if (!node) return [];
  if (Array.isArray(node)) return node.flatMap(typeNames);
  if (node.kind === "uniontype" || node.kind === "intersectiontype") {
    return typeNames(node.types);
  }
  if (node.kind === "typereference" || node.kind === "name") {
    return [{ name: String(node.name || "").toLowerCase(), node }];
  }
  return [];
}

function checkType(file, node, where) {
  if (!node) return;
  if (node.kind === "uniontype") {
    note(file, node.loc && node.loc.start.line, "union type",
      `${where}: union types are PHP 8.0`);
  }
  if (node.kind === "intersectiontype") {
    note(file, node.loc && node.loc.start.line, "intersection type",
      `${where}: intersection types are PHP 8.1`);
  }
  for (const t of typeNames(node)) {
    if (TYPES_AFTER_74[t.name]) {
      note(file, t.node.loc && t.node.loc.start.line, "type",
        `${where}: the '${t.name}' type is PHP ${TYPES_AFTER_74[t.name]}`);
    }
  }
}

function walk(node, file, parentName) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    for (const child of node) walk(child, file, parentName);
    return;
  }

  const line = node.loc && node.loc.start ? node.loc.start.line : 0;

  switch (node.kind) {
    case "call": {
      const w = node.what;
      if (w && w.kind === "name") {
        const fn = String(w.name || "").replace(/^\\/, "").toLowerCase();
        if (ADDED_AFTER_74[fn]) {
          note(file, line, "function",
            `${fn}() was added in PHP ${ADDED_AFTER_74[fn]}`);
        }
      }
      /* A newer function reached by name rather than by calling it:
         call_user_func('str_contains', ...), array_map('str_starts_with', ...),
         $f = 'str_ends_with'. The call node says nothing newer than 7.4,
         because the newness is inside a string, so look at the strings. */
      for (const arg of node.arguments || []) {
        if (arg && arg.kind === "string" && typeof arg.value === "string") {
          const named = ADDED_AFTER_74[arg.value.replace(/^\\/, "").toLowerCase()];
          if (named) {
            note(file, line, "function",
              `${arg.value}() was added in PHP ${named}, named as a string here`);
          }
        }
      }

      /* Named arguments, in case the grammar let one through. */
      for (const arg of node.arguments || []) {
        if (arg && arg.kind === "namedargument") {
          note(file, line, "named argument", "named arguments are PHP 8.0");
        }
      }
      break;
    }

    case "new": {
      const w = node.what;
      if (w && (w.kind === "name" || w.kind === "classreference")) {
        const cls = String(w.name || "").replace(/^\\/, "");
        const hit = CLASSES_AFTER_74_LC[cls.toLowerCase()];
        if (hit) {
          note(file, line, "class",
            `${hit.name} was added in PHP ${hit.version}`);
        }
      }
      break;
    }

    case "staticlookup": {
      /* $obj::class is PHP 8.0; Foo::class has been fine since 5.5. */
      const off = node.offset;
      if (off && (off.kind === "name" || off.kind === "identifier") &&
          String(off.name).toLowerCase() === "class") {
        const w = node.what;
        if (w && w.kind !== "name" && w.kind !== "classreference" &&
            w.kind !== "staticreference" && w.kind !== "selfreference" &&
            w.kind !== "parentreference") {
          note(file, line, "::class on an object",
            "$object::class is PHP 8.0; use get_class($object)");
        }
      }
      break;
    }

    case "nullsafepropertylookup":
    case "nullsafemethodlookup":
      note(file, line, "nullsafe operator", "?-> is PHP 8.0");
      break;

    case "match":
      note(file, line, "match", "match expressions are PHP 8.0");
      break;

    case "enum":
      note(file, line, "enum", "enums are PHP 8.1");
      break;

    case "parameter": {
      /* Constructor property promotion: a parameter carrying a visibility
       * flag. php-parser exposes it as flags/visibility on the parameter. */
      const promoted =
        (node.flags && node.flags !== 0) ||
        (node.visibility !== undefined && node.visibility !== null && node.visibility !== "");
      if (promoted) {
        note(file, line, "constructor promotion",
          "promoted constructor parameters are PHP 8.0");
      }
      if (node.readonly) {
        note(file, line, "readonly", "readonly parameters are PHP 8.1");
      }
      if (node.variadic && node.byref) {
        /* fine, just here so the branch is not empty-looking */
      }
      checkType(file, node.type, `parameter $${node.name && node.name.name ? node.name.name : node.name}`);
      break;
    }

    case "propertystatement":
    case "property": {
      if (node.readonly) {
        note(file, line, "readonly", "readonly properties are PHP 8.1");
      }
      checkType(file, node.type, "property");
      break;
    }

    case "classconstant":
      if (node.type) {
        note(file, line, "typed constant", "typed class constants are PHP 8.3");
      }
      break;

    case "function":
    case "method":
    case "closure":
    case "arrowfunc":
      checkType(file, node.type, "return type");
      break;

    case "class":
      if (node.isReadonly || node.readonly) {
        note(file, line, "readonly class", "readonly classes are PHP 8.2");
      }
      break;

    case "attrgroup":
    case "attribute":
      note(file, line, "attribute", "attributes (#[...]) are PHP 8.0");
      break;

    case "try":
      for (const c of node.catches || []) {
        if (!c.variable) {
          note(file, c.loc ? c.loc.start.line : line,
            "catch without a variable",
            "catch (Exception) with no variable is PHP 8.0");
        }
      }
      break;

    case "assign": {
      const r = node.right;
      if (r && r.kind === "string" && typeof r.value === "string") {
        const named = ADDED_AFTER_74[r.value.replace(/^\\/, "").toLowerCase()];
        if (named) {
          note(file, line, "function",
            `${r.value}() was added in PHP ${named}, assigned as a string here`);
        }
      }
      break;
    }

    case "name": {
      const n = String(node.name || "").replace(/^\\/, "");
      const nHit = CLASSES_AFTER_74_LC[n.toLowerCase()];
      if (nHit && parentName !== "call") {
        note(file, line, "class",
          `${nHit.name} was added in PHP ${nHit.version}`);
      }
      if (CONSTANTS_AFTER_74[n]) {
        note(file, line, "constant",
          `${n} was added in PHP ${CONSTANTS_AFTER_74[n]}`);
      }
      break;
    }
  }

  for (const key of Object.keys(node)) {
    if (key === "loc" || key === "leadingComments" || key === "trailingComments") continue;
    walk(node[key], file, node.kind);
  }
}

/* ---- the scan ------------------------------------------------------------ */

/**
 * Scan one file's source. BOTH the real run and --self-test go through here.
 *
 * They used to build their own parser engines separately, so --self-test never
 * exercised the configuration the real scan used. An audit set the real pass-1
 * grammar to 8.3 and --self-test still printed its reassuring message, while a
 * trailing comma in a parameter list -- a fatal on 7.4 -- planted in api/ went
 * undetected. One code path means the self-test can see that.
 */
function scanSource(file, code) {
  /* Pass 1: does it parse as 7.4 at all? */
  const strict = new engine({
    parser: { version: 704, suppressErrors: false },
    ast: { withPositions: true },
  });
  let parsedStrict = true;
  try {
    strict.parseCode(code, file);
  } catch (e) {
    parsedStrict = false;
    const msg = String(e.message).split("\n")[0];
    const m = msg.match(/on line (\d+)/);
    note(file, m ? Number(m[1]) : 0, "syntax", msg);
  }

  /* Pass 2: walk it. Parse at 8.3 so a file that failed pass 1 still gets
   * walked and reports the rest of its problems in the same run. */
  const loose = new engine({
    parser: { version: 803, suppressErrors: true },
    ast: { withPositions: true },
  });
  try {
    walk(loose.parseCode(code, file), file, null);
  } catch (e) {
    if (parsedStrict) {
      note(file, 0, "internal", "could not walk: " + e.message);
    }
  }
}

/* ---- run ---------------------------------------------------------------- */

let targets = process.argv.slice(2);

/* --self-test: check the checker. A checker that has quietly stopped detecting
 * anything reports a clean run, which looks exactly like success. The two
 * fixtures guard against that: one file full of PHP 8, one file of 7.4 code
 * that uses the constructs most likely to be mistaken for PHP 8 (arrow
 * functions, typed properties, ??=, array spread, list destructuring). */
if (targets[0] === "--self-test") {
  const dir = path.join(__dirname, "fixtures");
  const run = (file) => {
    const saved = findings.splice(0, findings.length);
    scanSource(file, fs.readFileSync(path.join(dir, file), "utf8"));
    const got = findings.splice(0, findings.length);
    findings.push(...saved);
    return got;
  };

  const bad = run("php8_only.php");
  const good = run("php74_clean.php");
  const kinds = new Set(bad.map((f) => f.kind));
  /* "syntax" is in this list on purpose. Every other kind comes from the tree
     walk, so without it the PHP 7.4 grammar pass could be broken outright --
     or quietly parsing at 8.3 -- and --self-test would still print its
     reassuring message. That is the exact failure this mode exists to catch,
     so it has to assert that pass 1 produced something. */
  const wanted = [
    "syntax",
    "function", "match", "nullsafe operator", "attribute", "readonly",
    "constructor promotion", "union type", "type", "class",
    "catch without a variable", "::class on an object",
    /* Added once the fixture had an example of each. Without an example, a
       kind cannot be in this list, and a rule with neither is a rule nothing
       checks: an audit deleted the enum, named-argument and intersection-type
       rules one at a time and --self-test stayed green. */
    "enum", "named argument", "intersection type", "typed constant",
    "readonly class", "constant",
  ];
  const missed = wanted.filter((k) => !kinds.has(k));

  /* The count, not only the kinds. Deleting one rule from a kind that has
     other examples left every kind present, so an audit removed the
     string-named-function rule, then the case-insensitive class lookup, then
     six of the seven 8.0 functions, and --self-test stayed green each time.
     The fixture is fixed, so its finding count is a fact: if it drops, a rule
     has gone. Raise this number when you add to the fixture, and never lower
     it to make a red run green. */
  const EXPECTED_FINDINGS = 41;

  console.log("php74_check --self-test\n");
  console.log(`  php8_only.php    ${bad.length} finding(s) across ${kinds.size} kind(s)`);
  console.log(`  php74_clean.php  ${good.length} finding(s) (want 0)`);
  if (missed.length) {
    console.log(`\n  FAILED: no longer detects: ${missed.join(", ")}\n`);
    process.exit(1);
  }
  if (bad.length < EXPECTED_FINDINGS) {
    console.log(`\n  FAILED: php8_only.php should produce at least `
      + `${EXPECTED_FINDINGS} findings and produced ${bad.length}.`);
    console.log("  A rule has been removed, or the fixture has shrunk.\n");
    process.exit(1);
  }
  if (good.length) {
    console.log("\n  FAILED: false positives on 7.4-clean code:");
    for (const f of good) console.log(`    ${f.file}:${f.line} [${f.kind}] ${f.detail}`);
    console.log();
    process.exit(1);
  }
  console.log("\n  The checker detects every construct it is meant to, and");
  console.log("  reports nothing on valid 7.4 code.\n");
  process.exit(0);
}

if (targets.length === 0) {
  console.error("usage: node php74_check.js <dir-or-file> [...]");
  console.error("       node php74_check.js --self-test");
  process.exit(2);
}

/* A target that does not exist is a typo, and it used to come out as a raw
 * node stack trace with exit 1. The claim made for this was "exits 2 with the
 * paths it tried", which only held for a directory that existed and happened
 * to contain no PHP. Check first, so the message names the mistake. */
const missingTargets = targets.filter((t) => !fs.existsSync(t));
if (missingTargets.length) {
  console.error(
    `php74_check: no such path: ${missingTargets.join(", ")}\n` +
      `  tried from ${process.cwd()}\n` +
      `  usage: node php74_check.js <dir-or-file> [...]   (e.g. ../api ../tools)`
  );
  process.exit(2);
}

let files = [];
for (const t of targets) files.push(...phpFiles(t));
files = [...new Set(files)];

/* A run that looked at nothing is not a clean run. Without this, a PHP_EXT
 * that matches no file, or a path typo, prints "No PHP 8-only syntax" and
 * exits 0 -- the gate passes by scanning zero bytes. */
if (files.length === 0) {
  console.error(
    `php74_check: no PHP files found under ${targets.join(", ")}`
  );
  process.exit(2);
}

/* scanSource, the same function --self-test drives. These two used to be
 * separate copies of the same twenty lines, which is exactly how the real
 * pass-1 grammar could be set to 8.3 while --self-test went on reporting that
 * the checker worked. One code path, so the self-test covers the real run. */
for (const file of files) {
  scanSource(file, fs.readFileSync(file, "utf8"));
}

/* De-duplicate: pass 1 and pass 2 can both report the same construct. */
const seen = new Set();
const unique = findings.filter((f) => {
  const key = `${f.file}:${f.line}:${f.kind}:${f.detail}`;
  if (seen.has(key)) return false;
  seen.add(key);
  return true;
});

unique.sort((a, b) => a.file.localeCompare(b.file) || a.line - b.line);

console.log(`php74_check: ${files.length} file(s)\n`);
if (unique.length === 0) {
  console.log("  No PHP 8-only syntax, functions, classes or types found.");
  console.log("  Parses against the PHP 7.4 grammar.\n");
  process.exit(0);
}
for (const f of unique) {
  console.log(`  ${f.file}:${f.line}  [${f.kind}]  ${f.detail}`);
}
console.log(`\n  ${unique.length} finding(s).\n`);
process.exit(1);
