#!/usr/bin/env python3
"""Does every API call the front end makes actually exist in the API?

    python3 tests/api_contract.py

This is the gap between the two other suites. The site tests run with the DEMO
flags on, so every network call is stubbed and a wrong URL is never sent. The
API test drives the API directly, so it only ever calls the routes the API
already has. A page that posts to a path the router does not implement passes
both and 404s in production.

That happened: application.html's "Save and exit" button posted to
/api/application/resume-link while the API implemented
/api/application/email-reference. The answers saved, the email did not send,
and the applicant was told so. Nothing in either suite could see it.

So this compares the two sides directly: it reads the router table out of
api/index.php and every live fetch() and post() out of the built pages, and
fails if a page calls something the API does not serve, or serves it under a
different verb.

Deliberately-absent routes go in NOT_BUILT_YET below, with the reason. That
list is the point: a path missing by design is recorded, and any other missing
path is a failure.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Paths the front end calls that the API deliberately does not implement yet.
# Each one must be behind a DEMO flag, which the check below verifies.
NOT_BUILT_YET = {
    # Empty since 2026-10-22: POST /api/application/card, the card-reveal route
    # and mark-charged are built (Application::saveCard, Admin::revealCard,
    # Admin::markCharged). Anything added here must say why.
}

# Both the sources and what actually ships. deploy/ is the folder that goes on
# the server, and a check that only reads src/ would miss a stale build.
PAGES = [
    "site/src/application.html",
    "site/src/admin.html",
    "site/src/resume.html",
    "site/src/payment.html",
    "site/src/site.js",
    "site/src/admin.js",
    "site/src/payment-step.js",
    # The form engine, 3,000 lines, loaded by three of the pages above. It was
    # not in this list, so a broken fetch() planted in it was invisible.
    "site/src/visa-application-form.js",
    "site/deploy/application.html",
    "site/deploy/admin.html",
    "site/deploy/resume.html",
    "site/deploy/payment.html",
    "site/deploy/site.js",
    "site/deploy/admin.js",
    "site/deploy/payment-step.js",
    "site/deploy/visa-application-form.js",
]


def strip_comments(text):
    """Drop /* */ blocks and // lines.

    The sources carry worked examples for the developer inside comments --
    site.js documents the contact endpoint that way -- and counting those as
    real calls would report failures that do not exist.
    """
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"^\s*//.*$", "", text, flags=re.M)
    return text


def routes_from_index():
    """Read the router table out of api/index.php."""
    src = (ROOT / "api/index.php").read_text()
    table = re.search(r"\$routes\s*=\s*\[(.*?)\n\];", src, re.S)
    if not table:
        sys.exit("Could not find the $routes table in api/index.php. "
                 "If the router was restructured, update this check.")

    found = []
    for verb, pattern in re.findall(
            r"\['([A-Z]+)',\s*'#\^(.*?)\$#'", table.group(1)):
        found.append((verb, pattern))
    if not found:
        sys.exit("Found the $routes table but parsed no routes out of it.")
    return found


def path_matches_route(path, pattern):
    """Does a concrete path match a router pattern?

    The API is mounted so that /api/x is routed as /x, which index.php does by
    stripping the prefix, so compare against the stripped form.
    """
    stripped = path[4:] if path.startswith("/api/") else path
    return re.fullmatch(pattern, stripped) is not None


def calls_from_pages():
    """Every live method+path pair the pages send."""
    calls = []
    for rel in PAGES:
        f = ROOT / rel
        if not f.exists():
            continue
        src = strip_comments(f.read_text())

        # fetch(<path>, { method: "..." })  -- GET when no method is given
        for m in re.finditer(r"\bfetch\(", src):
            args = call_args(src, m.end() - 1)
            if not args:
                continue
            # Either quote style: real code here uses double, but a single
            # would have been read as no method at all and defaulted to GET.
            verb = re.search(r"""method:\s*["'](\w+)["']""",
                             args[1] if len(args) > 1 else "")
            for path in literal_paths(args[0]):
                calls.append((verb.group(1) if verb else "GET", path, rel))

        # the page's own helpers. get() is a GET, post() is a POST.
        for name, verb in (("post", "POST"), ("get", "GET")):
            for m in re.finditer(r"\b" + name + r"\(", src):
                args = call_args(src, m.end() - 1)
                if not args:
                    continue
                for path in literal_paths(args[0]):
                    calls.append((verb, path, rel))
    return calls


def call_args(src, open_paren):
    """Split a call's arguments, respecting nesting and quotes.

    A regex cannot do this: the paths are built by concatenation across lines
    and the second argument is an object literal with its own braces. Reading
    only as far as the first comma or the first brace loses the tail of the
    path, which then matches the wrong route and reports a failure that is not
    real. So scan properly.
    """
    depth = 0
    quote = None
    args = []
    current = ""
    i = open_paren
    while i < len(src):
        c = src[i]
        if quote:
            current += c
            if c == quote and src[i - 1] != "\\":
                quote = None
        elif c in "\"'`":
            quote = c
            current += c
        elif c in "([{":
            depth += 1
            if depth > 1:
                current += c
        elif c in ")]}":
            depth -= 1
            if depth == 0:
                args.append(current)
                return args
            current += c
        elif c == "," and depth == 1:
            args.append(current)
            current = ""
        else:
            current += c
        i += 1
        if i - open_paren > 4000:    # runaway: unbalanced source
            return args
    return args


REF = "ABC123XYZ9"


def literal_paths(expr):
    """Pull /api/... paths out of a JS expression.

    A path is often built by concatenation, sometimes across lines:

        fetch("/api/admin/applications/" +
              encodeURIComponent(reference) + "/status", {...})

    Taking only the first literal would lose the "/status" and leave a path
    that matches the wrong route, so rebuild the whole expression: keep every
    string literal in order and put a stand-in reference wherever a variable
    part sits between them. The result is a concrete path that can be matched
    against a route pattern's capture group.
    """
    # Split into string literals and the expressions between them.
    # Backticks too. A template literal is the idiomatic way to interpolate a
    # reference into a URL, and leaving them out of this split made every
    # `/api/${x}/y` call invisible -- which is exactly the class of bug this
    # check exists for.
    expr = re.sub(r"\$\{[^}]*\}", "\x00", expr)
    pieces = re.split(r"[\"'`]([^\"'`]*)[\"'`]", expr)
    # re.split with one group alternates: between, literal, between, literal...
    literals = pieces[1::2]
    betweens = pieces[0::2]
    if not literals or not literals[0].startswith("/api/"):
        return []

    path = ""
    for i, lit in enumerate(literals):
        # A non-empty expression between two literals is a variable segment.
        if i > 0 and betweens[i].strip(" \t\r\n+"):
            path += REF
        # \x00 marks where a ${...} stood inside a template literal.
        path += lit.replace("\x00", REF)
    # A trailing variable part (…"/applications/" + ref) ends the path.
    if len(betweens) > len(literals) and betweens[-1].strip(" \t\r\n+,{"):
        if path.endswith("/"):
            path += REF
    elif path.endswith("/"):
        path += REF

    return [path.split("?")[0]]


def demo_guarded(rel, path):
    """Is the call to this path behind a DEMO flag?

    Comments are stripped first. These files document the unbuilt endpoints in
    a comment above the call ("DEVELOPER: POST /api/application/card"), and
    matching that occurrence instead of the real one looks past the guard.
    """
    src = strip_comments((ROOT / rel).read_text())
    # The path carries a {ref} placeholder where the reference is concatenated
    # in, so it never appears verbatim. Look for its last literal segment,
    # which is what distinguishes the route.
    needle = [part for part in path.split("{ref}") if part.strip("/")][-1]
    i = src.find(needle)
    if i == -1:
        return False
    # The guard is an `if (DEMO)` shortly above the call that RETURNS, so the
    # call is never reached. Three things this has to get right, each of which
    # an audit got past an earlier version:
    #
    #  - Match the shape `if (DEMO)`, not any identifier containing "DEMO":
    #    DEMO_REVEAL_LOG sits between the real guard and the call.
    #  - Only the NEAREST preceding guard counts. With any of them accepted,
    #    disabling the real one and putting an unrelated
    #    `if (DEMO) { console.log(...) }` above the call still passed, because
    #    a genuine guard further up matched.
    #  - That nearest guard has to return. A guard that only logs does not
    #    stop anything.
    #
    # It is still proximity rather than control flow, so it can be fooled by
    # someone determined to. It is here to catch an honest mistake.
    window = src[max(0, i - 1200):i]
    guards = list(re.finditer(r"if\s*\(\s*DEMO\s*\)\s*", window))
    if not guards:
        return False
    m = guards[-1]
    rest = window[m.end():]

    if rest.startswith("{"):
        depth, k = 0, 0
        while k < len(rest):
            if rest[k] == "{":
                depth += 1
            elif rest[k] == "}":
                depth -= 1
                if depth == 0:
                    break
            k += 1
        return "return" in rest[:k]

    # A one-line guard: `if (DEMO) return ...;`
    return rest.split(";")[0].lstrip().startswith("return")


def main():
    routes = routes_from_index()
    calls = calls_from_pages()

    print(f"api_contract: {len(routes)} routes, "
          f"{len(set((v, p) for v, p, _ in calls))} distinct front-end calls\n")

    failures = []
    expected_missing = dict(NOT_BUILT_YET)
    reported_ok = set()

    # Every (call, FILE) pair, not every distinct call. The sources and the
    # built copy in deploy/ are both listed, and deduplicating across them
    # meant whichever sorted first was the only one checked -- so a broken
    # src/ file was masked by an intact deploy/ copy, which is backwards:
    # src/ is what gets edited and deploy/ is what ships, and both have to be
    # right. The guard check in particular is per file.
    for verb, path, rel in sorted(set(calls)):
        key = (verb, path.replace(REF, "{ref}"))

        path_hit = any(path_matches_route(path, p) for _, p in routes)
        verb_hit = any(verb == v and path_matches_route(path, p) for v, p in routes)

        if verb_hit:
            if key not in reported_ok:
                print(f"  ok    {verb:6} {key[1]}")
                reported_ok.add(key)
        elif key in NOT_BUILT_YET:
            if demo_guarded(rel, key[1]):
                if key not in reported_ok:
                    print(f"  ok    {verb:6} {key[1]}  (not built yet, behind DEMO)")
                    reported_ok.add(key)
            else:
                failures.append(
                    f"{verb} {key[1]} is not implemented and is NOT behind a "
                    f"DEMO flag in {rel}. It will reach a real applicant.")
            expected_missing.pop(key, None)
        elif path_hit:
            served = [v for v, p in routes if path_matches_route(path, p)]
            failures.append(
                f"{verb} {key[1]} called from {rel}, but the API serves that "
                f"path only as {', '.join(served)}. A verb mismatch is a 405.")
        else:
            failures.append(
                f"{verb} {key[1]} called from {rel}, but no route in "
                f"api/index.php matches it. This is a 404 in production.")

    # A route recorded as not-built that the front end no longer calls, or that
    # has since been built, means this list is stale.
    for (verb, path), why in expected_missing.items():
        served = any(verb == v and path_matches_route(path.replace("{ref}", REF), p)
                     for v, p in routes)
        if served:
            failures.append(
                f"{verb} {path} is listed in NOT_BUILT_YET but the API now "
                f"serves it. Remove the entry: while it is there, this check "
                f"will excuse the next thing that genuinely goes missing "
                f"under that path.")
        else:
            print(f"  note  {verb:6} {path} is listed as not built and the "
                  f"front end no longer calls it. Remove it from NOT_BUILT_YET.")

    print()
    if failures:
        print(f"  {len(failures)} failure(s):\n")
        for f in failures:
            print(f"  FAIL  {f}")
        print()
        return 1
    print("  Every live front-end call is served by the API, under the same verb.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
