<?php
/* The applicant's half of the API: create, save a step, submit, come back.
 *
 * These are what application.html and resume.html call once DEMO is false.
 * Shapes are fixed by the front end; README.md records them under "What you
 * need to build".
 */

class Application
{
    private PDO $db;
    private array $cfg;

    public function __construct(PDO $db, array $cfg)
    {
        $this->db = $db;
        $this->cfg = $cfg;
    }

    /* ---------------------------------------------- POST /api/application */

    public function create(): void
    {
        $in = Http::body();
        $prompt = trim((string) ($in['securityPrompt'] ?? ''));
        $answer = (string) ($in['securityAnswer'] ?? '');

        if ($prompt === '' || trim($answer) === '') {
            Http::fail(400, 'incomplete', 'Choose a question and give an answer.');
        }

        /* Normalised the same way the form normalises it before checking, so
           "Smith " and "smith" are the same answer months later. */
        $hash = password_hash(self::normalise($answer), PASSWORD_BCRYPT);

        /* A collision is vanishingly unlikely, but a duplicate key would
           otherwise surface to an applicant as a failure at step one. */
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $reference = Http::reference();
            try {
                $st = $this->db->prepare(
                    'INSERT INTO applications (reference, security_prompt, security_hash,
                                               answers, step_index, status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, 0, ?, ?, ?)'
                );
                $st->execute([$reference, $prompt, $hash, '{}', 'New', Db::now(), Db::now()]);
                $id = (int) $this->db->lastInsertId();
                Sessions::startApplicant($this->db, $this->cfg, $id);
                Http::json(['applicationId' => $reference]);
            } catch (PDOException $e) {
                if ($attempt === 4) {
                    throw $e;
                }
            }
        }
    }

    /* ------------------------------------------ PATCH /api/application/:id */

    public function saveStep(string $reference): void
    {
        $row = $this->mine($reference);
        $in = Http::body();
        $data = $in['data'] ?? null;
        if (!is_array($data)) {
            Http::fail(400, 'no_data', 'Nothing to save.');
        }

        /* The step arrives as a patch of the whole answer set. Merge rather
           than replace: a later step must not wipe an earlier one if the
           front end ever sends a partial payload. */
        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        $answers = array_merge($answers, $data);

        /* Never store the security answer with the answers. It is a hash in
           its own column; a copy in here would be plaintext. */
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        $stepIndex = isset($in['stepIndex']) ? (int) $in['stepIndex'] : (int) $row['step_index'];

        $st = $this->db->prepare(
            'UPDATE applications
                SET answers = ?, step_index = ?, applicant_name = ?, email = ?, updated_at = ?
              WHERE id = ?'
        );
        $st->execute([
            json_encode($answers, JSON_UNESCAPED_UNICODE),
            max($stepIndex, (int) $row['step_index']),
            self::nameFrom($answers),
            self::emailFrom($answers),
            Db::now(),
            $row['id'],
        ]);

        /* 204 and nothing else. The form treats any non-2xx as "could not
           save" and keeps the answers on screen, which is the safety net. */
        Http::noContent();
    }

    /* ----------------------------------------- POST /api/application/card */

    /**
     * Save the card for the fee, which is charged later by hand.
     *
     * in:  { applicationId, card: { name, number, expMonth, expYear, postal,
     *                               brand, last4 } }
     * out: 204
     *
     * The browser has already checked all of this, and every check is done
     * again here, because anything a browser checks a browser can skip. brand
     * and last4 from the browser are ignored: both are worked out from the
     * number, so a page that sends the wrong ones cannot store a mismatch.
     *
     * NOTHING ON THIS PATH MAY LOG THE BODY. The messages below name the
     * field that is wrong and never its value, and the catch in index.php
     * logs exception messages only, none of which carry card data. Turn off
     * request-body logging for this URL in the web server and any proxy or
     * error tracker in front of it; see DEVELOPER-INSTRUCTIONS.md.
     */
    public function saveCard(): void
    {
        $ip = Http::ip();
        $limit = (int) $this->cfg['card_save_rate_limit'];
        $window = (int) $this->cfg['card_save_rate_window'];
        /* A page that takes card numbers is a page card testers find. A
           handful of attempts per address is plenty for a real applicant
           correcting a typo. */
        if (Guard::countRecent($this->db, 'card-save', $ip, $window, false) >= $limit) {
            header('Retry-After: ' . $window);
            Http::fail(429, 'rate_limited',
                'Too many attempts. Wait a few minutes and try again.');
        }
        Guard::record($this->db, 'card-save', $ip, true);

        $in = Http::body();
        $row = $this->mine((string) ($in['applicationId'] ?? ''));

        if (!CardVault::configured($this->cfg)) {
            /* Refused before the card is even read. The log line names the
               setting; the applicant is told to try later, not why. */
            error_log('[vj] POST /application/card refused: card_key is not set or is not'
                . ' a base64 encoding of 32 bytes. Set the CARD_KEY environment variable;'
                . ' see DEVELOPER-INSTRUCTIONS.md.');
            Http::fail(503, 'card_storage_off',
                'We cannot save card details right now. Please try again later or email us.');
        }

        if (!empty($row['charged_on'])) {
            Http::fail(409, 'already_paid', 'The fee for this application has already been paid.');
        }

        $card = $in['card'] ?? null;
        if (!is_array($card)) {
            Http::fail(400, 'no_card', 'Enter your card details.');
        }

        /* The security code (CVV) travels as card.cvv and nowhere else. A
           copy under any other name, or outside the card, is refused, so it
           cannot slip past the encryption below into a field that is stored
           or logged as it is. */
        foreach (['cvc', 'cvv2', 'cvc2', 'cid', 'securityCode', 'csc'] as $k) {
            if (array_key_exists($k, $card)) {
                Http::fail(400, 'cvv_misplaced', 'Send the security code as card.cvv only.');
            }
        }
        foreach (['cvv', 'cvc', 'cvv2', 'cvc2', 'cid', 'securityCode', 'csc'] as $k) {
            if (array_key_exists($k, $in)) {
                Http::fail(400, 'cvv_misplaced', 'Send the security code as card.cvv only.');
            }
        }

        $number = preg_replace('/[\s-]+/', '', (string) ($card['number'] ?? ''));
        $brand = CardVault::brand((string) $number);
        if ($number === '' || !preg_match('/^[0-9]{12,19}$/', (string) $number)) {
            Http::fail(400, 'bad_number', 'That card number is not valid. Check it against your card.');
        }
        if ($brand === '') {
            Http::fail(400, 'bad_brand',
                'We accept Visa, Mastercard, Discover and American Express. Check the number or use one of those.');
        }
        if (!CardVault::lengthOk($brand, $number) || !CardVault::luhn($number)) {
            Http::fail(400, 'bad_number', 'That card number is not valid. Check it against your card.');
        }

        /* 4 digits on an American Express card, 3 on the others. A string,
           so a leading zero survives: 012 is a real code. */
        $cvv = $card['cvv'] ?? null;
        if ($cvv === null || (is_string($cvv) && trim($cvv) === '')) {
            Http::fail(400, 'no_cvv', 'Enter the security code from your card.');
        }
        $cvv = is_string($cvv) ? trim($cvv) : '';
        $cvvLength = $brand === 'Amex' ? 4 : 3;
        if (!preg_match('/^[0-9]+$/', $cvv) || strlen($cvv) !== $cvvLength) {
            $cvv = '';
            Http::fail(400, 'bad_cvv', $brand === 'Amex'
                ? 'The security code on an American Express card is the 4 digits on the front.'
                : 'The security code is the 3 digits on the back of your card.');
        }

        $month = $card['expMonth'] ?? null;
        $year = $card['expYear'] ?? null;
        $month = is_numeric($month) ? (int) $month : 0;
        $year = is_numeric($year) ? (int) $year : 0;
        if ($month < 1 || $month > 12 || $year < 2000 || $year > 2100) {
            Http::fail(400, 'bad_expiry', 'Choose the month and year printed on the card.');
        }
        /* A card is good to the end of its expiry month. The comparison uses
           yesterday in UTC, so an applicant a timezone ahead of the server on
           the 1st is not told their card from last month expired a day
           early. */
        $then = time() - 86400;
        $nowYear = (int) gmdate('Y', $then);
        $nowMonth = (int) gmdate('n', $then);
        if ($year < $nowYear || ($year === $nowYear && $month < $nowMonth)) {
            Http::fail(400, 'expired', 'This card has expired. Use a card that is still valid.');
        }
        if ($year > $nowYear + 20) {
            Http::fail(400, 'bad_expiry', 'Choose the month and year printed on the card.');
        }

        $name = trim(preg_replace('/\s+/', ' ', (string) ($card['name'] ?? '')));
        if ($name === '' || mb_strlen($name) > 120) {
            Http::fail(400, 'bad_name', 'Enter the name exactly as it appears on the card.');
        }
        $postal = trim((string) ($card['postal'] ?? ''));
        if ($postal !== '' && !preg_match('/^[A-Za-z0-9][A-Za-z0-9 -]{1,9}$/', $postal)) {
            Http::fail(400, 'bad_postal',
                'Check the postal code. Use letters, numbers, spaces or hyphens only.');
        }

        $sealed = CardVault::seal($this->cfg, $row['reference'], $number, $name, $postal);
        $sealedCvv = CardVault::sealCvv($this->cfg, $row['reference'], $cvv);
        $last4 = substr($number, -4);
        $number = str_repeat('0', strlen($number));
        $cvv = str_repeat('0', strlen($cvv));
        $card = null;
        $in = null;

        $now = Db::now();
        $purgeAfter = Db::inFuture(((int) $this->cfg['card_retention_days']) * 86400);

        /* One transaction: the vault row and the summary on the application
           either both change or neither does. Saving a second card replaces
           the first. */
        $this->db->beginTransaction();
        try {
            /* A second card replaces the first; the old code is destroyed
               the same way as on a recorded charge before its row goes. */
            CardVault::wipeCvv($this->db, (int) $row['id']);
            $this->db->prepare('DELETE FROM card_vault WHERE application_id = ?')
                     ->execute([$row['id']]);
            $this->db->prepare(
                'INSERT INTO card_vault (application_id, ciphertext, nonce, wrapped_key,
                                         kms_key_id, cvv_ciphertext, cvv_wrapped_key,
                                         created_at, purge_after)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
            )->execute([$row['id'], $sealed['ciphertext'], $sealed['nonce'],
                        $sealed['wrapped_key'], $sealed['kms_key_id'],
                        $sealedCvv['cvv_ciphertext'], $sealedCvv['cvv_wrapped_key'],
                        $now, $purgeAfter]);
            $this->db->prepare(
                'UPDATE applications
                    SET card_brand = ?, card_last4 = ?, card_exp_month = ?, card_exp_year = ?,
                        number_on_file = 1, updated_at = ?
                  WHERE id = ?'
            )->execute([$brand, $last4, $month, $year, $now, $row['id']]);
            /* No digits in the activity line, not even the last four. */
            $this->activity((int) $row['id'], 'Applicant', 'Saved a card for the fee');
            $this->db->commit();
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }

        Http::noContent();
    }

    /* -------------------------------------------- GET /api/application/:id */

    public function get(string $reference): void
    {
        $row = $this->mine($reference);
        $answers = json_decode($row['answers'] ?: '{}', true);
        Http::json([
            'applicationId' => $row['reference'],
            'data'          => is_array($answers) ? $answers : [],
            'stepIndex'     => (int) $row['step_index'],
        ]);
    }

    /* --------------------------------------- POST /api/application/submit */

    public function submit(): void
    {
        $in = Http::body();
        $reference = (string) ($in['applicationId'] ?? '');
        $row = $this->mine($reference);

        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        foreach ($in as $k => $v) {
            if ($k !== 'applicationId') {
                $answers[$k] = $v;
            }
        }
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        /* The photograph arrives as a data URL. Decode it to a file: base64 in
           a database column is three times the size and shows up in every
           dump, backup and query log that touches the row. */
        /* strncmp rather than str_starts_with: PHP 7.4 has no str_starts_with. */
        if (!empty($answers['photo'])
            && strncmp((string) $answers['photo'], 'data:', 5) === 0) {
            $problem = $this->savePhoto($row['reference'], (string) $answers['photo']);
            unset($answers['photo']);
            if ($problem !== '') {
                /* Say so rather than carrying on. This used to drop the
                   photograph and answer 200, so an applicant whose photo was
                   too large submitted a visa application with no photograph in
                   it and was told everything had gone through.

                   Note what refusing costs: the UPDATE below has not run, so
                   anything in this submit body that was not already PATCHed
                   step by step is not stored. The form does PATCH every step
                   and keeps the answers on screen, so in practice they lose
                   nothing and simply attach a different photograph. */
                Http::fail(400, 'bad_photo', $problem);
            }
            $answers['photoStored'] = true;
        }

        $st = $this->db->prepare(
            'UPDATE applications
                SET answers = ?, status = ?, applicant_name = ?, email = ?,
                    submitted_at = ?, updated_at = ?
              WHERE id = ?'
        );
        $st->execute([
            json_encode($answers, JSON_UNESCAPED_UNICODE),
            'New',
            self::nameFrom($answers),
            self::emailFrom($answers),
            Db::now(),
            Db::now(),
            $row['id'],
        ]);

        $this->activity((int) $row['id'], 'Applicant', 'Application submitted');
        Http::json(['applicationId' => $row['reference']]);
    }

    /* --------------------------------------- POST /api/application/lookup */

    public function lookup(): void
    {
        $ip = Http::ip();
        if (Guard::countRecent($this->db, 'lookup', $ip, (int) $this->cfg['lookup_rate_window'], false)
            >= (int) $this->cfg['lookup_rate_limit']) {
            Http::fail(429, 'rate_limited', 'Too many attempts. Try again later.');
        }
        Guard::record($this->db, 'lookup', $ip, true);

        $in = Http::body();
        $reference = strtoupper(trim((string) ($in['applicationId'] ?? '')));
        $row = $this->byReference($reference);

        /* A wrong reference and a locked application answer the same way, so
           this cannot be used to find out which references exist. The lock is
           timed, so lockRemaining clears an expired one and the reference
           resolves again from here on. */
        if (!$row || $this->lockRemaining($row) > 0) {
            Http::fail(404, 'not_found', 'We could not find that reference number.');
        }
        Http::json(['securityPrompt' => $row['security_prompt']]);
    }

    /* --------------------------------------- POST /api/application/resume */

    public function resume(): void
    {
        $ip = Http::ip();

        /* Per IP, before the per-application counter below gets a chance to
           lock anybody out.

           Every failure here was already being recorded in the 'resume'
           bucket and nothing ever read it, so the only limit was the
           per-application one: five wrong answers and that application is
           locked, with no unlock anywhere in this API. Since the reference
           number is printed on the applicant's screen and emailed to them, it
           is not a secret, and anyone holding one could lock a named person's
           application out of spite in five requests. An audit found it. */
        if (Guard::countRecent($this->db, 'resume', $ip,
                (int) $this->cfg['resume_rate_window'], false)
            >= (int) $this->cfg['resume_rate_limit']) {
            Http::fail(429, 'rate_limited',
                'Too many attempts from this connection. Try again later.');
        }

        $in = Http::body();
        $reference = strtoupper(trim((string) ($in['applicationId'] ?? '')));
        $answer = (string) ($in['answer'] ?? '');
        $row = $this->byReference($reference);

        if (!$row) {
            Guard::record($this->db, 'resume', $ip, false);
            Http::fail(401, 'wrong', 'That answer did not match.');
        }

        /* The lock expires. It used to be permanent, which made it a weapon:
           the reference number is printed on the applicant's screen and
           emailed to them, so it is not a secret, and five wrong answers from
           anyone holding one locked a named person out of their own
           application for good, with no unlock in this API and only the
           support mailbox as a way back.

           A lock that heals itself keeps the thing it is actually for -- the
           security answer cannot be ground down by repeated guessing -- and
           turns a permanent lockout into a wait. It does not make a targeted
           attack impossible: somebody who holds the reference can re-lock it
           whenever the window lapses, and the rate limit above only slows
           that down. Resume would need a second factor to close it properly,
           which is a bigger change than this. What it does do is stop that
           attack being irreversible, and stop an applicant who has simply
           forgotten the answer from being locked out forever. */
        $left = $this->lockRemaining($row);
        if ($left > 0) {
            Guard::record($this->db, 'resume', $ip, false);
            header('Retry-After: ' . $left);
            Http::fail(429, 'locked',
                'For your security this application is locked for '
                . ceil($left / 60) . ' more minutes.'
                . self::supportLine($this->cfg),
                ['attemptsRemaining' => 0, 'lockedForSeconds' => $left]);
        }

        $limit = (int) $this->cfg['resume_fail_limit'];
        $failures = (int) $row['failed_answers'];

        if (!password_verify(self::normalise($answer), $row['security_hash'])) {
            $failures++;
            $lock = $failures >= $limit ? Db::now() : null;
            $st = $this->db->prepare(
                'UPDATE applications SET failed_answers = ?, locked_at = ? WHERE id = ?'
            );
            $st->execute([$failures, $lock, $row['id']]);
            Guard::record($this->db, 'resume', $ip, false);

            if ($lock) {
                $wait = (int) $this->cfg['resume_lockout'];
                header('Retry-After: ' . $wait);
                Http::fail(429, 'locked',
                    'For your security this application is locked for '
                    . ceil($wait / 60) . ' minutes.'
                    . self::supportLine($this->cfg),
                    ['attemptsRemaining' => 0, 'lockedForSeconds' => $wait]);
            }
            Http::fail(401, 'wrong', 'That answer did not match.',
                ['attemptsRemaining' => max(0, $limit - $failures)]);
        }

        /* Right answer: clear the count and hand the browser a session, which
           is what every later read is authorised by. */
        $this->db->prepare('UPDATE applications SET failed_answers = 0 WHERE id = ?')
                 ->execute([$row['id']]);
        Sessions::startApplicant($this->db, $this->cfg, (int) $row['id']);

        $answers = json_decode($row['answers'] ?: '{}', true);
        Http::json([
            'applicationId' => $row['reference'],
            'data'          => is_array($answers) ? $answers : [],
            'stepIndex'     => (int) $row['step_index'],
        ]);
    }

    /* ------------------------------- POST /api/application/email-reference */

    public function emailReference(): void
    {
        $ip = Http::ip();
        if (Guard::countRecent($this->db, 'email-ref', $ip, 3600, false) >= 5) {
            Http::fail(429, 'rate_limited', 'Too many emails requested. Try again later.');
        }
        Guard::record($this->db, 'email-ref', $ip, true);

        $in = Http::body();
        $row = $this->mine((string) ($in['applicationId'] ?? ''));
        $to = trim((string) ($in['email'] ?? ''));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            Http::fail(400, 'bad_email', 'That does not look like a complete email address.');
        }

        /* The reference and nothing else. Never the security question and
           never the answer: both in one mailbox is the whole credential. */
        $subject = 'Your Visa Journey USA reference number';
        $body = "Your reference number is {$row['reference']}.\r\n\r\n"
              . "Keep it somewhere safe. You will also be asked your security question "
              . "when you come back, and we will never ask you for that answer by email "
              . "or on the phone.\r\n\r\n"
              . "Come back to your application: https://www.visajourneyusa.com/resume\r\n";
        /* support_email has to be a real address before it goes in a header.
         *
         * It was interpolated straight in, and its documented default is the
         * empty string, which built "From: \r\nReply-To: \r\n..." -- headers
         * most MTAs reject outright. So on any install that had not set it,
         * mail() failed, the applicant was told to write their reference down
         * instead, and nothing anywhere named the setting. INSTALL.md
         * described support_email as cosmetic, which is how it stayed unset.
         *
         * filter_var also refuses an address containing CR or LF, which is
         * what a header-injection attempt looks like. config.php is not
         * attacker-controlled, but a typo that silently truncates the headers
         * is worth refusing too. */
        $from = trim((string) ($this->cfg['support_email'] ?? ''));
        if (!filter_var($from, FILTER_VALIDATE_EMAIL)) {
            error_log('[vj] cannot send the reference email: support_email in'
                . ' config.php is ' . var_export($this->cfg['support_email'] ?? null, true)
                . ', which is not a usable address. See step 3 of INSTALL.md.');
            Http::fail(502, 'send_failed',
                'We could not send that email. Please write the number down.');
        }
        $headers = 'From: ' . $from . "\r\n"
                 . 'Reply-To: ' . $from . "\r\n"
                 . 'Content-Type: text/plain; charset=utf-8';

        if (!@mail($to, $subject, $body, $headers)) {
            error_log('[vj] mail() refused the reference email for '
                . $row['reference'] . '; check the MTA on this host.');
            Http::fail(502, 'send_failed', 'We could not send that email. Please write the number down.');
        }
        Http::json(['sent' => true]);
    }

    /* ----------------------------------------------------------- helpers */

    private function byReference(string $reference): ?array
    {
        $st = $this->db->prepare('SELECT * FROM applications WHERE reference = ?');
        $st->execute([$reference]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /**
     * The application this browser is allowed to touch.
     *
     * Authorised by the session cookie set at create or resume, never by the
     * reference in the URL. Answering 401 rather than 403 is what makes
     * application.html send the person to /resume with the reference
     * prefilled, so a lost session is one question rather than a dead end.
     */
    private function mine(string $reference): array
    {
        $row = $this->byReference(strtoupper(trim($reference)));
        $sessionId = Sessions::applicantId($this->db);
        if (!$row || $sessionId === null || $sessionId !== (int) $row['id']) {
            Http::fail(401, 'no_session', 'Sign back in to your application.');
        }
        return $row;
    }

    /** Why this returns a reason rather than a bool: submit() has to tell the
     *  applicant which thing went wrong, and it used to discard the
     *  photograph and answer 200 whatever happened. Returns '' on success. */
    private function savePhoto(string $reference, string $dataUrl): string
    {
        if (!preg_match('#^data:image/(jpeg|jpg|png);base64,#i', $dataUrl, $m)) {
            return 'That photograph was not a JPEG or a PNG.';
        }
        $bytes = base64_decode(substr($dataUrl, strpos($dataUrl, ',') + 1), true);
        if ($bytes === false) {
            return 'That photograph did not arrive intact. Please attach it again.';
        }
        if (strlen($bytes) > 2 * 1024 * 1024) {
            return 'That photograph is larger than 2MB. Please attach a smaller one.';
        }

        /* Check the bytes, not the label. The data: prefix is whatever the
           caller typed, so without this any content at all could be written
           under a .jpg name. getimagesizefromstring parses the actual header
           and tells us what it really is; if it disagrees with the prefix,
           refuse rather than trusting either. */
        $info = @getimagesizefromstring($bytes);
        if ($info === false || empty($info[2])) {
            return 'That file is not an image.';
        }
        $realType = $info[2];
        $declared = strtolower($m[1]) === 'png' ? IMAGETYPE_PNG : IMAGETYPE_JPEG;
        if ($realType !== $declared) {
            return 'That photograph is not the format it says it is.';
        }
        $ext = $realType === IMAGETYPE_PNG ? 'png' : 'jpg';

        /* Config::photoDir, not a cast: it is shared with the read side in
           Admin::photo so the two cannot drift, and it refuses a relative
           path. A bare (string) cast here turned photo_dir => ['/var/photos']
           into the literal directory name "Array", created it relative to
           api/ -- inside the document root under PHP-FPM -- wrote the
           passport photograph into it and answered 200. */
        $dir = Config::photoDir($this->cfg);
        if ($dir === '') {
            /* Name the setting. This used to log an empty path, which read as
               "photo_dir is not writable: " and told whoever was debugging it
               nothing at all. photo_dir has no safe default: there is nowhere
               sensible to put somebody's passport photograph by guesswork. */
            error_log('[vj] photo_dir is not usable, so there is '
                . 'nowhere to put the photograph. See step 7 of INSTALL.md.');
            return 'We could not store that photograph. Please try again.';
        }
        if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
            error_log('[vj] photo_dir is not writable: ' . $dir);
            return 'We could not store that photograph. Please try again.';
        }
        if (!@file_put_contents($dir . '/' . $reference . '.' . $ext, $bytes)) {
            error_log('[vj] could not write the photograph for ' . $reference);
            return 'We could not store that photograph. Please try again.';
        }
        return '';
    }

    private function activity(int $applicationId, string $author, string $action): void
    {
        $st = $this->db->prepare(
            'INSERT INTO application_activity (application_id, author, action, at)
             VALUES (?, ?, ?, ?)'
        );
        $st->execute([$applicationId, $author, $action, Db::now()]);
    }

    /**
     * Seconds left on an application's lock, or 0 if it is not locked.
     *
     * An expired lock is cleared here rather than left lying around, so the
     * row goes back to a clean state and the applicant gets their full set of
     * attempts again rather than one.
     */
    private function lockRemaining(array &$row): int
    {
        if (empty($row['locked_at'])) {
            /* Not locked -- but if the failure count is sitting at the limit
               with no timestamp beside it, the row is in a state resume()
               would turn straight back into a lock on the next wrong answer.
               Heal it here, the same as an expired lock.

               This is the one path into this function that did not heal the
               row, and it is reachable: a support person hand-running an
               "unlock" UPDATE that sets locked_at = '' rather than NULL
               leaves exactly this shape, and the applicant then gets one
               attempt and is locked out again for ever. */
            if ((int) $row['failed_answers'] >= (int) $this->cfg['resume_fail_limit']) {
                $this->clearLock($row);
            }
            return 0;
        }
        $lockedAt = strtotime((string) $row['locked_at'] . ' UTC');
        if ($lockedAt === false) {
            /* An unreadable timestamp is a data problem, not a security
               signal: only this code ever writes the column. Holding the
               lock would make it permanent with no way out, which is the
               thing this whole mechanism exists to stop, so clear it and say
               so in the log. */
            error_log('[vj] unreadable locked_at on application ' . $row['id']
                . ', clearing it: ' . (string) $row['locked_at']);
            $this->clearLock($row);
            return 0;
        }
        $left = ($lockedAt + (int) $this->cfg['resume_lockout']) - time();
        if ($left > 0) {
            return $left;
        }
        $this->clearLock($row);
        return 0;
    }

    /**
     * Clear an expired lock, in the database AND in the caller's copy of the row.
     *
     * $row by reference is the whole point. Clearing only the database left
     * resume() holding the row it had fetched a moment earlier, with
     * failed_answers still at the limit: the applicant came back after the
     * window, got their answer wrong once, and that one mistake took the
     * count from five to six and locked them straight out again. The counter
     * ratcheted up for ever and the lock was still effectively permanent, so
     * the fix that was supposed to make it temporary did not. An audit caught
     * it. The comment that promised "their full set of attempts again" was
     * describing one attempt.
     */
    private function clearLock(array &$row): void
    {
        $this->db->prepare(
            'UPDATE applications SET locked_at = NULL, failed_answers = 0 WHERE id = ?'
        )->execute([$row['id']]);
        $row['locked_at'] = null;
        $row['failed_answers'] = 0;
    }

    /**
     * " If you are not sure of the answer, email x." -- or nothing at all.
     *
     * support_email defaults to empty, and interpolating it unguarded put
     * "email ." in front of an applicant who was already locked out.
     */
    private static function supportLine(array $cfg): string
    {
        $to = trim((string) ($cfg['support_email'] ?? ''));
        if ($to === '') {
            return '';
        }
        return ' If you are not sure of the answer, email ' . $to . '.';
    }

    /** Same normalisation the form uses, so the answer matches months later. */
    public static function normalise(string $v): string
    {
        return preg_replace('/\s+/u', ' ', trim(mb_strtolower($v)));
    }

    private static function nameFrom(array $a): ?string
    {
        $given = trim((string) ($a['givenNames'] ?? ''));
        $sur = trim((string) ($a['surnames'] ?? ''));
        $name = trim($given . ' ' . $sur);
        return $name === '' ? null : mb_substr($name, 0, 120);
    }

    private static function emailFrom(array $a): ?string
    {
        $email = trim((string) ($a['email'] ?? ''));
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    }
}
