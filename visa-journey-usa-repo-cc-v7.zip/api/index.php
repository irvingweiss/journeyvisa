<?php
/* Visa Journey USA — API front controller.
 *
 * Every /api/ request lands here. Plain PHP 7.4 or newer, PDO, no framework and
 * no composer, so it drops onto an ordinary host with nothing to install.
 *
 * Routing: send /api/* here. The .htaccess beside this file does it on Apache;
 * INSTALL.md has the nginx and IIS equivalents.
 *
 * On PHP 7.4 specifically: this file deliberately avoids arrow functions and
 * typed properties, which 7.3 and older cannot parse. PHP parses a whole file
 * before it runs a line of it, so if this file used them the version check
 * below could never report anything — the server would answer a blank 500 and
 * the log would say "syntax error" with no hint about why. Keep this file
 * parseable by old PHP so it can explain itself. The rest of api/ is only
 * reached past the check and may use 7.4 syntax.
 */

declare(strict_types=1);

/* Never print a stack trace to a caller: these requests carry applicants'
 * answers, and a trace can echo the parameters back. Log it, answer generically. */
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

/* Say what is wrong in words rather than fatalling on the first unknown
 * function or unparseable file. These run before any require, so they cannot
 * use Http::fail — and they build their JSON by hand rather than with
 * json_encode, because one of the things they report is a missing json
 * extension. The only interpolated values are PHP_VERSION and names from the
 * literal list below, so neither can break the quoting.
 *
 * The shape is {"code":...,"message":...}, matching Http::fail, so the admin
 * screen and the form show the real message instead of a generic failure. */
if (PHP_VERSION_ID < 70400) {
    header('Content-Type: application/json; charset=utf-8', true, 500);
    header('Cache-Control: no-store');
    echo '{"code":"php_too_old","message":"This API needs PHP 7.4 or newer. This server is running '
        . PHP_VERSION . '."}';
    exit;
}
$missing = [];
foreach (['pdo', 'mbstring', 'json', 'filter'] as $ext) {
    if (!extension_loaded($ext)) {
        $missing[] = $ext;
    }
}
if (!extension_loaded('pdo_mysql') && !extension_loaded('pdo_sqlite') && !extension_loaded('pdo_pgsql')) {
    $missing[] = 'pdo_mysql';
}
if ($missing) {
    /* mbstring is the one that catches people out: on PHP 7.4 it is a separate
       package and a stock install often does not have it. */
    error_log('[vj] missing PHP extensions: ' . implode(', ', $missing));
    header('Content-Type: application/json; charset=utf-8', true, 500);
    header('Cache-Control: no-store');
    echo '{"code":"missing_extension","message":"The server is missing PHP extensions: '
        . implode(', ', $missing) . '."}';
    exit;
}

require __DIR__ . '/lib/Http.php';
require __DIR__ . '/lib/Config.php';
require __DIR__ . '/lib/Db.php';
require __DIR__ . '/lib/Guard.php';
require __DIR__ . '/lib/Totp.php';
require __DIR__ . '/lib/Sessions.php';
require __DIR__ . '/lib/CardVault.php';
require __DIR__ . '/routes/Application.php';
require __DIR__ . '/routes/Admin.php';

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    Http::fail(500, 'no_config', 'The API is not configured yet.');
}
/* Config::load, not a bare require: it fills in a default for every setting
 * config.php does not name, so adding a setting later cannot turn into a zero
 * on an install that already has a config file. See lib/Config.php. */
$cfg = Config::load($configFile);

$missingConfig = Config::missing($cfg);
if ($missingConfig) {
    error_log('[vj] config.php is missing: ' . implode(', ', $missingConfig));
    Http::fail(500, 'config_incomplete',
        'The API is not configured yet: ' . implode(', ', $missingConfig) . '.');
}

/* Before anything reads Http::ip(), which every rate limit is keyed on. */
Http::configure($cfg);

/* A request that changes something has to come from this site. See
 * Http::sameOrigin for why this plus SameSite cookies is enough. */
if (!Http::sameOrigin($cfg['allowed_origins'])) {
    Http::fail(403, 'bad_origin', 'Request refused.');
}

try {
    $db = Db::pdo($cfg);
} catch (Throwable $e) {
    error_log('[vj] database: ' . $e->getMessage());
    Http::fail(503, 'no_database', 'The service is temporarily unavailable.');
}

Guard::sweep($db);

/* The retention purge for stored card numbers, on one request in ten. The
 * reveal and detail routes run it themselves before reading, and
 * tools/purge-cards.php runs it from cron, so this is only the backstop for an
 * install with no cron job. A failure here must not take the site down, so it
 * is logged and the request carries on. */
if (random_int(1, 10) === 1) {
    try {
        CardVault::purgeExpired($db);
    } catch (Throwable $e) {
        error_log('[vj] card purge: ' . $e->getMessage());
    }
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = '/' . trim($path, '/');

/* Tolerate the API being mounted at /api or at the document root.
 * strncmp rather than str_starts_with: PHP 7.4 has no str_starts_with. */
if (strncmp($path, '/api/', 5) === 0) {
    $path = substr($path, 4);
} elseif ($path === '/api') {
    $path = '/';
}

$applications = new Application($db, $cfg);
$admin = new Admin($db, $cfg);

/* A tiny router. Each handler is an [object, method] pair rather than a
 * closure: array callables parse on any PHP, which keeps the version check at
 * the top of this file able to run. Any capture group in the pattern becomes
 * the method's argument, so a route with ([A-Za-z0-9]+) calls a method taking
 * the reference and a route without one calls a method taking nothing. */
$routes = [
    ['POST',   '#^/application$#',                              [$applications, 'create']],
    ['POST',   '#^/application/submit$#',                       [$applications, 'submit']],
    ['POST',   '#^/application/lookup$#',                       [$applications, 'lookup']],
    ['POST',   '#^/application/resume$#',                       [$applications, 'resume']],
    ['POST',   '#^/application/email-reference$#',              [$applications, 'emailReference']],
    /* Before the two (:id) routes below, whose pattern "card" also matches. */
    ['POST',   '#^/application/card$#',                         [$applications, 'saveCard']],
    ['PATCH',  '#^/application/([A-Za-z0-9]+)$#',               [$applications, 'saveStep']],
    ['GET',    '#^/application/([A-Za-z0-9]+)$#',               [$applications, 'get']],

    ['POST',   '#^/admin/session$#',                            [$admin, 'signIn']],
    ['POST',   '#^/admin/session/verify$#',                     [$admin, 'verifyCode']],
    ['GET',    '#^/admin/session$#',                            [$admin, 'currentSession']],
    ['DELETE', '#^/admin/session$#',                            [$admin, 'signOut']],
    ['GET',    '#^/admin/applications$#',                       [$admin, 'listApplications']],
    ['GET',    '#^/admin/applications/([A-Za-z0-9]+)$#',        [$admin, 'getApplication']],
    ['PATCH',  '#^/admin/applications/([A-Za-z0-9]+)/status$#', [$admin, 'setStatus']],
    ['POST',   '#^/admin/applications/([A-Za-z0-9]+)/notes$#',  [$admin, 'addNote']],
    ['GET',    '#^/admin/applications/([A-Za-z0-9]+)/photo$#',  [$admin, 'photo']],
    ['POST',   '#^/admin/applications/([A-Za-z0-9]+)/card/reveal$#',  [$admin, 'revealCard']],
    ['POST',   '#^/admin/applications/([A-Za-z0-9]+)/mark-charged$#', [$admin, 'markCharged']],
];

try {
    $pathMatched = false;
    foreach ($routes as $route) {
        /* list() rather than [$a, $b] = : short list destructuring is PHP 7.1,
           and this file has to parse on anything old enough to need the
           version message above. */
        list($verb, $pattern, $handler) = $route;
        if (preg_match($pattern, $path, $m)) {
            $pathMatched = true;
            if ($verb === $method) {
                /* $m[0] is the whole match; the capture groups after it are the
                   handler's arguments, so a route with no groups calls a method
                   with none. */
                call_user_func_array($handler, array_slice($m, 1));
                exit;
            }
        }
    }
    /* A path that exists under another verb is a 405, not a 404: it is a
       different mistake and says so. */
    if ($pathMatched) {
        Http::fail(405, 'bad_method', 'That is not how this endpoint is called.');
    }
    Http::fail(404, 'no_route', 'No such endpoint.');
} catch (Throwable $e) {
    /* The message goes to the server log, never to the caller. */
    error_log('[vj] ' . $method . ' ' . $path . ': ' . $e->getMessage());
    Http::fail(500, 'server_error', 'Something went wrong at our end.');
}
