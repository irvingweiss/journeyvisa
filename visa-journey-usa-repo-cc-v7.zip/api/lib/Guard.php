<?php
/* Rate limiting and lockout.
 *
 * Two different jobs in one table. Rate limiting answers "too many of these
 * from this address", and is about load and scraping. Lockout answers "too
 * many failures against this account", and is what stops someone working
 * through a password list or guessing a six-digit code. The admin sign in uses
 * both.
 */

class Guard
{
    public static function record(PDO $db, string $bucket, string $ip, bool $ok = false): void
    {
        $st = $db->prepare(
            'INSERT INTO rate_events (bucket, ip, succeeded, at) VALUES (?, ?, ?, ?)'
        );
        $st->execute([$bucket, $ip, $ok ? 1 : 0, Db::now()]);
    }

    public static function countRecent(PDO $db, string $bucket, string $ip, int $windowSeconds, bool $failuresOnly = true): int
    {
        $since = gmdate('Y-m-d H:i:s', time() - $windowSeconds);
        $sql = 'SELECT COUNT(*) FROM rate_events WHERE bucket = ? AND ip = ? AND at >= ?';
        if ($failuresOnly) {
            $sql .= ' AND succeeded = 0';
        }
        $st = $db->prepare($sql);
        $st->execute([$bucket, $ip, $since]);
        return (int) $st->fetchColumn();
    }

    /**
     * Is this address locked out of a bucket?
     *
     * Returns the seconds remaining, or 0. The caller answers 429 with
     * Retry-After and does no comparison at all: checking the password anyway
     * tells an attacker whether they got it right, which is the whole thing
     * the lockout exists to hide.
     */
    public static function lockedFor(PDO $db, string $bucket, string $ip, int $limit, int $window, int $lockout): int
    {
        $since = gmdate('Y-m-d H:i:s', time() - $window);
        $st = $db->prepare(
            'SELECT at FROM rate_events
              WHERE bucket = ? AND ip = ? AND succeeded = 0 AND at >= ?
              ORDER BY at DESC'
        );
        $st->execute([$bucket, $ip, $since]);
        $rows = $st->fetchAll(PDO::FETCH_COLUMN);
        if (count($rows) < $limit) {
            return 0;
        }
        /* The clock runs from the most recent failure, so trying again while
           locked out extends it rather than waiting it out. */
        $newest = strtotime($rows[0] . ' UTC');
        $left = ($newest + $lockout) - time();
        return $left > 0 ? $left : 0;
    }

    /** Clear a bucket for this address after a success, so one bad afternoon
     *  does not follow the right person around. */
    public static function clear(PDO $db, string $bucket, string $ip): void
    {
        $st = $db->prepare('DELETE FROM rate_events WHERE bucket = ? AND ip = ?');
        $st->execute([$bucket, $ip]);
    }

    /** Housekeeping. Called occasionally rather than on a cron, so a small
     *  install needs no scheduler. */
    public static function sweep(PDO $db): void
    {
        if (random_int(1, 50) !== 1) {
            return;
        }
        $cutoff = gmdate('Y-m-d H:i:s', time() - 86400 * 2);
        $db->prepare('DELETE FROM rate_events WHERE at < ?')->execute([$cutoff]);
        $db->prepare('DELETE FROM admin_sessions WHERE expires_at < ?')->execute([Db::now()]);
        $db->prepare('DELETE FROM applicant_sessions WHERE expires_at < ?')->execute([Db::now()]);
    }
}
