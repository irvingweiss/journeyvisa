<?php
/* Two kinds of session, kept apart on purpose.
 *
 * An applicant session says "this browser may read this one application". An
 * admin session says "this browser may read all of them". They live in
 * different tables, under different cookies, and nothing converts one into the
 * other.
 *
 * Neither is ever authorised by the reference number. The reference is printed
 * on the applicant's screen and emailed to them on request, so it is an
 * identifier, not a credential. That distinction is the whole reason these
 * tables exist.
 */

class Sessions
{
    public const APPLICANT_COOKIE = 'vj_app';
    public const ADMIN_COOKIE     = 'vj_admin';

    /* ------------------------------------------------------- applicant -- */

    public static function startApplicant(PDO $db, array $cfg, int $applicationId): void
    {
        $token = Http::token();
        $seconds = ((int) $cfg['applicant_session_hours']) * 3600;
        $st = $db->prepare(
            'INSERT INTO applicant_sessions (token, application_id, created_at, expires_at)
             VALUES (?, ?, ?, ?)'
        );
        $st->execute([$token, $applicationId, Db::now(), Db::inFuture($seconds)]);
        /* Lax, not Strict: the applicant comes back to the site from the
           payment provider, and a Strict cookie is not sent on that
           cross-site navigation, which would drop them at the resume screen
           holding a valid reference and wondering why. */
        Http::cookie(self::APPLICANT_COOKIE, $token, $seconds, $cfg, 'Lax');
    }

    /** The application id this browser may read, or null. */
    public static function applicantId(PDO $db): ?int
    {
        $token = $_COOKIE[self::APPLICANT_COOKIE] ?? '';
        if ($token === '') {
            return null;
        }
        $st = $db->prepare(
            'SELECT application_id FROM applicant_sessions
              WHERE token = ? AND expires_at > ?'
        );
        $st->execute([$token, Db::now()]);
        $id = $st->fetchColumn();
        return $id === false ? null : (int) $id;
    }

    /* ----------------------------------------------------------- admin -- */

    /**
     * The half session.
     *
     * Issued when the password is right and a second factor is enrolled.
     * Five minutes, and it can do nothing except present a code. The password
     * is not held by the browser between the two steps and is not sent again.
     */
    public static function startAdminHalf(PDO $db, array $cfg, string $email): void
    {
        $token = Http::token();
        $st = $db->prepare(
            'INSERT INTO admin_sessions (token, email, mfa_passed, created_at, expires_at)
             VALUES (?, ?, 0, ?, ?)'
        );
        $st->execute([$token, $email, Db::now(), Db::inFuture(300)]);
        Http::cookie(self::ADMIN_COOKIE, $token, 300, $cfg, 'Strict');
    }

    /**
     * The real session.
     *
     * A NEW token, never the half one promoted in place. If the half token was
     * captured during the first step, it is worth nothing after the second.
     *
     * $secondFactor records whether a code was actually presented. Pass false
     * from the no-secret-enrolled path in Admin::signIn and true from
     * Admin::verifyCode. It is NOT the same as mfa_passed, which only says the
     * sign in finished: see the comment on admin_sessions in
     * schema.mysql.sql. The card routes turn on this distinction.
     */
    public static function startAdminFull(PDO $db, array $cfg, string $email,
                                          bool $secondFactor): void
    {
        $old = $_COOKIE[self::ADMIN_COOKIE] ?? '';
        if ($old !== '') {
            $db->prepare('DELETE FROM admin_sessions WHERE token = ?')->execute([$old]);
        }
        $token = Http::token();
        $seconds = ((int) $cfg['admin_session_hours']) * 3600;
        $st = $db->prepare(
            'INSERT INTO admin_sessions
                 (token, email, mfa_passed, second_factor, created_at, expires_at)
             VALUES (?, ?, 1, ?, ?, ?)'
        );
        $st->execute([$token, $email, $secondFactor ? 1 : 0,
                      Db::now(), Db::inFuture($seconds)]);
        Http::cookie(self::ADMIN_COOKIE, $token, $seconds, $cfg, 'Strict');
    }

    /** The admin session row, or null. Includes half sessions: callers that
     *  need a complete one check mfa_passed. */
    public static function admin(PDO $db): ?array
    {
        $token = $_COOKIE[self::ADMIN_COOKIE] ?? '';
        if ($token === '') {
            return null;
        }
        $st = $db->prepare(
            'SELECT token, email, mfa_passed, second_factor FROM admin_sessions
              WHERE token = ? AND expires_at > ?'
        );
        $st->execute([$token, Db::now()]);
        $row = $st->fetch();
        return $row ?: null;
    }

    public static function endAdmin(PDO $db, array $cfg): void
    {
        $token = $_COOKIE[self::ADMIN_COOKIE] ?? '';
        if ($token !== '') {
            /* Destroyed on the server, not just dropped from the browser.
               Clearing the cookie alone leaves a token that still works for
               anyone who copied it. */
            $db->prepare('DELETE FROM admin_sessions WHERE token = ?')->execute([$token]);
        }
        Http::cookie(self::ADMIN_COOKIE, '', -1, $cfg, 'Strict');
    }

    /**
     * Require a signed-in admin, or stop the request.
     *
     * Every admin route needs a complete session, so that check is
     * unconditional: a half session, created by the password step and waiting
     * for a code, gets no further than /admin/session/verify, which reads the
     * session itself rather than calling this.
     *
     * $needMfa is the card routes' guard and it is a SECOND, stricter check: it
     * requires that a code was actually presented, not merely that the sign in
     * finished. The two differ exactly when no TOTP secret is enrolled, because
     * then the password alone completes the sign in. That session has
     * mfa_passed = 1 and second_factor = 0, so a card route passing true here
     * refuses it and an ordinary admin route still works.
     *
     * This used to test mfa_passed for both, which meant $needMfa did nothing
     * at all and a password-only session would have been handed a card number.
     * Do not merge the two columns back together.
     *
     * Both go through Db::flag rather than a plain truth test. The drivers
     * disagree about how a flag column comes back, and on one of them the
     * naive test fails open. Db::flag says which representations count.
     */
    public static function requireAdmin(PDO $db, bool $needMfa = false): array
    {
        $session = self::admin($db);
        if (!$session) {
            Http::fail(401, 'not_signed_in', 'Sign in again.');
        }
        if (!Db::flag($session['mfa_passed'] ?? 0)) {
            Http::fail(401, 'mfa_required', 'Finish signing in.');
        }
        if ($needMfa && !Db::flag($session['second_factor'] ?? 0)) {
            Http::fail(403, 'second_factor_required',
                'This needs a second factor. Enrol one and sign in again.');
        }
        return $session;
    }
}
