<?php
/* Request and response plumbing. Everything this API answers is JSON, and
 * everything it answers is no-store: these responses carry applicants' answers
 * and must not sit in a proxy or a browser cache. */

class Http
{
    /** The decoded JSON body, or [] when there is none. */
    public static function body(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === '' || $raw === false) {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    public static function json($payload, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        /* Applicant answers and card summaries travel on these responses. A
           cached copy on a shared machine or in a proxy is the same leak as a
           cached copy anywhere else. */
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function noContent(): void
    {
        http_response_code(204);
        header('Cache-Control: no-store');
        exit;
    }

    /** The shape the front end reads: err.code and err.userMessage. */
    public static function fail(int $status, string $code, string $message, array $extra = []): void
    {
        self::json(array_merge(['code' => $code, 'message' => $message], $extra), $status);
    }

    /** Set once from index.php, so ip() knows whether a forwarded header can
     *  be believed. Empty means it cannot. */
    private static $trustedProxyHeader = '';

    /** How many proxies of your own sit in front of this API. See ip(). */
    private static $trustedProxyHops = 1;

    /* The forwarded headers this code knows how to reason about. A name that
       is not here is refused rather than used, because ip() has to know
       whether the header APPENDS (read the right-hand end) or is SET outright
       (read the left), and it cannot know that about a header it has never
       heard of. Refusing falls back to the connection address, which is
       always safe. */
    const KNOWN_PROXY_HEADERS = [
        'X_FORWARDED_FOR',
        'CF_CONNECTING_IP',
        'X_REAL_IP',
        'TRUE_CLIENT_IP',
    ];

    public static function configure(array $cfg): void
    {
        self::$trustedProxyHeader = '';
        self::$trustedProxyHops = 1;

        $raw = $cfg['trusted_proxy_header'] ?? '';
        if (!is_string($raw) || trim($raw) === '') {
            return;
        }
        $h = strtoupper(str_replace('-', '_', trim($raw)));
        /* Accept either spelling. Writing the PHP variable name rather than
           the header name is the obvious mistake, and left alone it builds
           HTTP_HTTP_X_FORWARDED_FOR, never matches, and falls back silently
           to the connection address -- safe, but a confusing afternoon. */
        if (strncmp($h, 'HTTP_', 5) === 0) {
            $h = substr($h, 5);
        }
        if (!in_array($h, self::KNOWN_PROXY_HEADERS, true)) {
            /* Two names at once is the mistake this catches most often --
               INSTALL.md says "name one header, not both", which invites
               writing both -- and the result was a key of
               HTTP_X_FORWARDED_FOR,_CF_CONNECTING_IP that matched nothing, so
               every caller behind the edge shared a single rate-limit
               bucket. Silently. */
            error_log('[vj] config.php has trusted_proxy_header = ' . var_export($raw, true)
                . ', which is not a header this API knows how to read. Name exactly one of: '
                . implode(', ', self::KNOWN_PROXY_HEADERS)
                . '. Ignoring it and using the connection address.');
            return;
        }
        self::$trustedProxyHeader = $h;
        $hops = $cfg['trusted_proxy_hops'] ?? 1;
        self::$trustedProxyHops = is_numeric($hops) && (int) $hops >= 1 ? (int) $hops : 1;
    }

    /**
     * The caller's address, for the rate limit and lockout buckets.
     *
     * This is a security decision, not a convenience. Every Guard bucket is
     * keyed on the value returned here, so whoever controls it controls the
     * rate limit. A client can put anything in X-Forwarded-For, and
     * filter_var only proves the value looks like an address, not that it came
     * from your edge.
     *
     * So the default is to ignore those headers entirely and use the address
     * the connection actually came from. Believing them by default meant
     * anyone could pick their own bucket, guess the admin password without
     * ever tripping the lockout, and lock the real admin out at will by
     * sending the manager's address instead. This was found in an audit, and
     * the comment that used to sit here told the installer to delete the block
     * if they were not behind a proxy, which is the wrong way round: the safe
     * setting has to be the one you get by doing nothing.
     *
     * Set trusted_proxy_header in config.php ONLY if an edge you control sets
     * that header on every request and strips any copy the client sent.
     * Name the one header, not both: if your edge sets CF-Connecting-IP,
     * trusting X-Forwarded-For as well just reopens the hole.
     */
    public static function ip(): string
    {
        $remote = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (self::$trustedProxyHeader === '') {
            return $remote;
        }
        $key = 'HTTP_' . self::$trustedProxyHeader;
        if (empty($_SERVER[$key])) {
            return $remote;
        }

        $parts = array_map('trim', explode(',', (string) $_SERVER[$key]));

        /* Which end of the list to believe depends on the header, and getting
           it the wrong way round hands the bucket back to the caller.

           X-Forwarded-For is an APPENDING header. nginx's near-universal
           `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for` and
           every AWS ALB keep whatever the client sent and add the peer on the
           RIGHT. So the leftmost entry is attacker-supplied: a client sending
           "9.9.9.1, 203.0.113.7" picks its own bucket, and reading leftmost
           reopened unlimited admin password guesses and locking the manager
           out on demand -- the two things this function was rewritten to
           stop. The rightmost entry is the one the edge itself wrote.

           CF-Connecting-IP is a SINGLE-VALUE header that Cloudflare sets
           outright, replacing anything the client sent, so there is nothing
           to choose between.

           An audit found this, after INSTALL.md had already been written
           telling nginx and ALB users to set X-Forwarded-For. */
        if (self::$trustedProxyHeader === 'X_FORWARDED_FOR') {
            /* Count in from the right by the number of proxies you run.

               With one proxy the rightmost entry is the one it wrote, so it
               is the caller. With two -- Cloudflare in front of your own
               nginx, which INSTALL.md describes in a single breath -- the
               rightmost is the INNER proxy's address, identical for every
               visitor, so all of them collapse into one rate-limit bucket:
               one person's five bad passwords lock the only manager account
               out for everybody. Hence trusted_proxy_hops, which defaults to
               1 and must be set to the number of proxies of your own that
               append to this header. */
            $index = count($parts) - self::$trustedProxyHops;
            if ($index < 0) {
                /* Fewer entries than there are supposed to be proxies, so the
                   chain is not what the configuration describes and no entry
                   in it can be trusted. Fall back to the connection address,
                   which is always true even when it is less specific.
                   Falling back to $parts[0] here would be the opposite: the
                   leftmost entry is the one a caller can write. */
                return $remote;
            }
            $value = $parts[$index];
        } else {
            $value = $parts[0];
        }

        /* Strip a port before validating. IIS with ARR and Azure App Service
           both append "ip:port" rather than a bare address, and this repo
           ships an IIS configuration -- so filter_var rejected the whole
           header, ip() fell back to the connection address, and every
           visitor behind that edge shared one bucket with nothing in the log
           to say so. */
        if (preg_match('/^\[(.+)\](?::\d+)?$/', $value, $b)) {
            $value = $b[1];
        } elseif (preg_match('/^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/', $value, $b)) {
            $value = $b[1];
        }

        if (filter_var($value, FILTER_VALIDATE_IP)) {
            return $value;
        }
        /* A configured header that yields nothing usable is worth one log
           line: the alternative is silently rate-limiting every visitor as
           if they were the proxy. */
        error_log('[vj] ' . $key . ' held no usable address ('
            . substr((string) $_SERVER[$key], 0, 200)
            . '); using the connection address. Check trusted_proxy_header'
            . ' and trusted_proxy_hops in config.php.');
        return $remote;
    }

    /**
     * Cross-site request forgery, cheaply.
     *
     * The session cookies are SameSite, which already stops a form on another
     * site posting as the signed-in person. This is the second lock: a request
     * that changes something must come from an origin we know. A browser will
     * not let another site send Content-Type: application/json cross-origin
     * without a preflight, and the preflight is not answered here, so between
     * the two there is no path in.
     */
    public static function sameOrigin(array $allowed): bool
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if ($method === 'GET' || $method === 'HEAD') {
            return true;
        }
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === '') {
            /* Same-origin requests from older browsers may omit Origin. Fall
               back to Referer, and if neither is there, refuse: every caller
               of this API is a page on the site. */
            $referer = $_SERVER['HTTP_REFERER'] ?? '';
            if ($referer === '') {
                return false;
            }
            $parts = parse_url($referer);
            if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
                return false;
            }
            $origin = $parts['scheme'] . '://' . $parts['host'] .
                      (isset($parts['port']) ? ':' . $parts['port'] : '');
        }
        return in_array($origin, $allowed, true);
    }

    public static function cookie(string $name, string $value, int $maxAge, array $cfg, string $sameSite = 'Strict'): void
    {
        setcookie($name, $value, [
            'expires'  => $maxAge > 0 ? time() + $maxAge : 1,
            'path'     => '/',
            'secure'   => (bool) ($cfg['secure_cookies'] ?? true),
            'httponly' => true,
            'samesite' => $sameSite,
        ]);
    }

    /** A URL-safe random token. 32 bytes, so guessing is not a strategy. */
    public static function token(): string
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    /**
     * A reference number.
     *
     * Same alphabet the form uses: no O/0 and no I/1, because applicants read
     * these over the phone and write them down. Ten characters of it is about
     * 50 bits, which is not guessable, but the reference is still not treated
     * as a secret anywhere in this API: it is printed on screen and emailed.
     */
    public static function reference(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $out = '';
        for ($i = 0; $i < 10; $i++) {
            $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        return $out;
    }
}
