<?php
/* The stored card number: encryption, and the retention purge.
 *
 * Why this file exists. The fee is charged later, by hand, on a processor this
 * site is not connected to, so the site keeps the card number until then.
 * "Storing full card numbers" in site/README.md sets out the rules; this is
 * the code for the ones that are code.
 *
 * Envelope encryption, with the master key held by the server, not by a KMS.
 * Each card gets its own random 32-byte data key. The card details (number,
 * name on card, billing postal code) are encrypted with that data key using
 * AES-256-GCM, and the data key is itself encrypted ("wrapped") with the
 * master key, also AES-256-GCM. Only the wrapped copy is stored, beside the
 * ciphertext, in card_vault. The master key is never in the database, the
 * repository or a log: it comes from the CARD_KEY environment variable
 * (through api/config.php, 'card_key').
 *
 * The application reference is the additional authenticated data on both
 * layers. A ciphertext copied onto another application's row then fails to
 * decrypt, rather than showing the wrong card to the person charging it.
 *
 * GCM is authenticated encryption: a changed byte anywhere (ciphertext, nonce,
 * tag, wrapped key) makes decryption fail outright. It never returns garbage.
 *
 * Moving to a real KMS later (AWS KMS, Google Cloud KMS, Azure Key Vault) is
 * a change to wrapKey() and unwrapKey() only: the KMS wraps the data key
 * instead of the local master key, and kms_key_id names the KMS key. Nothing
 * else in the API changes.
 *
 * Rules this file keeps, and that whoever edits it next must keep:
 *
 *   - open() is called from exactly one place, Admin::revealCard. Nothing
 *     else decrypts. Not a report, not an export, not a support script.
 *   - No card number, security code, name or postal code is ever passed to error_log, put
 *     in an exception message, or written anywhere but card_vault as
 *     ciphertext. The errors below name what went wrong, never the data.
 *   - The CVV (security code) is sealed by sealCvv() on its own, with its
 *     own data key, into card_vault.cvv_ciphertext / cvv_wrapped_key, and
 *     opened by openCvv() from the same one place as open(). wipeCvv() puts
 *     both columns to NULL, after overwriting them, and runs when the charge
 *     is recorded and in the purge. PCI DSS does not allow a CVV to be kept
 *     after the charge in any form, so nothing may skip or delay the wipe.
 *     Like the number, it is never logged or put in an exception message.
 */

class CardVault
{
    const CIPHER = 'aes-256-gcm';
    const TAG_BYTES = 16;
    const NONCE_BYTES = 12;

    /* ------------------------------------------------------------ keys -- */

    /**
     * Decode one key from its base64 text. Returns the 32 raw bytes, or null
     * when the text is not exactly a base64 encoding of 32 bytes.
     *
     * Strict on purpose. A key that is a few characters short, or has a
     * newline pasted into the middle, or is the hex form of the bytes, decodes
     * to something that is not 32 bytes, and openssl would pad or truncate it
     * without a word. Refusing here is what turns that into a clear message.
     */
    public static function decodeKey(string $text): ?string
    {
        $text = trim($text);
        if ($text === '' || !preg_match('#^[A-Za-z0-9+/]+={0,2}$#', $text)) {
            return null;
        }
        $raw = base64_decode($text, true);
        if ($raw === false || strlen($raw) !== 32) {
            return null;
        }
        return $raw;
    }

    /** Is a usable master key configured? */
    public static function configured(array $cfg): bool
    {
        return self::decodeKey((string) ($cfg['card_key'] ?? '')) !== null;
    }

    /** The id stored beside each wrapped key, so a rotated key can be found. */
    private static function currentKeyId(array $cfg): string
    {
        $id = trim((string) ($cfg['card_key_id'] ?? ''));
        return $id === '' ? 'k1' : $id;
    }

    /**
     * The master key with this id: the current one, or one of the previous
     * keys kept for decrypting during a rotation. Previous keys are written in
     * config as "id:base64key". Null when there is no such key.
     */
    private static function keyFor(array $cfg, string $id): ?string
    {
        if ($id === self::currentKeyId($cfg)) {
            return self::decodeKey((string) ($cfg['card_key'] ?? ''));
        }
        foreach ((array) ($cfg['card_previous_keys'] ?? []) as $entry) {
            $entry = (string) $entry;
            $colon = strpos($entry, ':');
            if ($colon === false) {
                continue;
            }
            if (substr($entry, 0, $colon) === $id) {
                return self::decodeKey(substr($entry, $colon + 1));
            }
        }
        return null;
    }

    /* ------------------------------------------------- the two layers -- */

    /** AES-256-GCM. Returns nonce . tag . ciphertext, raw bytes. */
    private static function encrypt(string $key, string $plain, string $aad): string
    {
        $nonce = random_bytes(self::NONCE_BYTES);
        $tag = '';
        $ct = openssl_encrypt($plain, self::CIPHER, $key, OPENSSL_RAW_DATA,
                              $nonce, $tag, $aad, self::TAG_BYTES);
        if ($ct === false || strlen($tag) !== self::TAG_BYTES) {
            throw new RuntimeException('card encryption failed');
        }
        return $nonce . $tag . $ct;
    }

    /** The reverse of encrypt(). Null when anything has been tampered with,
     *  the key is wrong, or the AAD (the reference) does not match. */
    private static function decrypt(string $key, string $blob, string $aad): ?string
    {
        if (strlen($blob) < self::NONCE_BYTES + self::TAG_BYTES) {
            return null;
        }
        $nonce = substr($blob, 0, self::NONCE_BYTES);
        $tag = substr($blob, self::NONCE_BYTES, self::TAG_BYTES);
        $ct = substr($blob, self::NONCE_BYTES + self::TAG_BYTES);
        $plain = openssl_decrypt($ct, self::CIPHER, $key, OPENSSL_RAW_DATA,
                                 $nonce, $tag, $aad);
        return $plain === false ? null : $plain;
    }

    /* Swap these two for KMS Encrypt / Decrypt calls to move the master key
       into a KMS. */
    private static function wrapKey(array $cfg, string $dataKey, string $reference): array
    {
        $master = self::decodeKey((string) ($cfg['card_key'] ?? ''));
        if ($master === null) {
            throw new RuntimeException('card_key is not configured');
        }
        return [
            base64_encode(self::encrypt($master, $dataKey, 'vj-dek|' . $reference)),
            self::currentKeyId($cfg),
        ];
    }

    private static function unwrapKey(array $cfg, string $wrapped, string $keyId,
                                      string $reference): ?string
    {
        $master = self::keyFor($cfg, $keyId);
        if ($master === null) {
            return null;
        }
        $blob = base64_decode($wrapped, true);
        if ($blob === false) {
            return null;
        }
        return self::decrypt($master, $blob, 'vj-dek|' . $reference);
    }

    /* ---------------------------------------------------------- public -- */

    /**
     * Encrypt the card details for one application.
     *
     * Returns the columns for card_vault: ciphertext, nonce, wrapped_key and
     * kms_key_id. The nonce column holds the payload's nonce on its own as
     * well, as the README's table describes; the copy inside the ciphertext
     * blob is the one that is used.
     */
    public static function seal(array $cfg, string $reference,
                                string $number, string $name, string $postal): array
    {
        $dataKey = random_bytes(32);
        $plain = json_encode(['number' => $number, 'name' => $name, 'postal' => $postal],
                             JSON_UNESCAPED_UNICODE);
        $blob = self::encrypt($dataKey, (string) $plain, 'vj-card|' . $reference);
        list($wrapped, $keyId) = self::wrapKey($cfg, $dataKey, $reference);
        /* PHP has no portable way to wipe memory without sodium, which a 7.4
           host may not have. Overwriting the variables at least keeps the
           plaintext out of anything that dumps locals on an error. */
        $dataKey = str_repeat("\0", 32);
        $plain = '';
        return [
            'ciphertext'  => base64_encode($blob),
            'nonce'       => bin2hex(substr($blob, 0, self::NONCE_BYTES)),
            'wrapped_key' => $wrapped,
            'kms_key_id'  => $keyId,
        ];
    }

    /**
     * Decrypt one card_vault row. THE ONLY CALLER IS Admin::revealCard.
     *
     * Returns ['number' => ..., 'name' => ..., 'postal' => ...], or null when
     * the row cannot be decrypted: the key it was wrapped with is gone, the
     * row was moved to another application, or a byte was changed.
     */
    public static function open(array $cfg, string $reference, array $row): ?array
    {
        $dataKey = self::unwrapKey($cfg, (string) $row['wrapped_key'],
                                   (string) $row['kms_key_id'], $reference);
        if ($dataKey === null) {
            return null;
        }
        $blob = base64_decode((string) $row['ciphertext'], true);
        if ($blob === false) {
            return null;
        }
        $plain = self::decrypt($dataKey, $blob, 'vj-card|' . $reference);
        $dataKey = str_repeat("\0", 32);
        if ($plain === null) {
            return null;
        }
        $card = json_decode($plain, true);
        $plain = '';
        if (!is_array($card) || !isset($card['number'])) {
            return null;
        }
        return [
            'number' => (string) $card['number'],
            'name'   => (string) ($card['name'] ?? ''),
            'postal' => (string) ($card['postal'] ?? ''),
        ];
    }

    /* ------------------------------------------------------------ CVV -- */

    /**
     * Encrypt the security code for one application, with its own data key
     * and its own additional data, so it can be destroyed on its own when
     * the charge is recorded. Wrapped with the current master key, the same
     * one seal() uses for the card in the same request, so the row's
     * kms_key_id covers both.
     *
     * Returns the columns for card_vault: cvv_ciphertext and cvv_wrapped_key.
     */
    public static function sealCvv(array $cfg, string $reference, string $cvv): array
    {
        $dataKey = random_bytes(32);
        $blob = self::encrypt($dataKey, $cvv, 'vj-cvv|' . $reference);
        list($wrapped, ) = self::wrapKey($cfg, $dataKey, 'cvv|' . $reference);
        $dataKey = str_repeat("\0", 32);
        $cvv = '';
        return [
            'cvv_ciphertext'  => base64_encode($blob),
            'cvv_wrapped_key' => $wrapped,
        ];
    }

    /**
     * Decrypt the security code on one card_vault row. Like open(), THE ONLY
     * CALLER IS Admin::revealCard. Null when there is none (wiped, or a card
     * saved before the code was collected) or it cannot be decrypted.
     */
    public static function openCvv(array $cfg, string $reference, array $row): ?string
    {
        if (empty($row['cvv_ciphertext']) || empty($row['cvv_wrapped_key'])) {
            return null;
        }
        $dataKey = self::unwrapKey($cfg, (string) $row['cvv_wrapped_key'],
                                   (string) $row['kms_key_id'], 'cvv|' . $reference);
        if ($dataKey === null) {
            return null;
        }
        $blob = base64_decode((string) $row['cvv_ciphertext'], true);
        if ($blob === false) {
            return null;
        }
        $plain = self::decrypt($dataKey, $blob, 'vj-cvv|' . $reference);
        $dataKey = str_repeat("\0", 32);
        if ($plain === null || !preg_match('/^[0-9]{3,4}$/', $plain)) {
            return null;
        }
        return $plain;
    }

    /**
     * Destroy the stored security code for one application: overwrite both
     * columns with random bytes of the same length, then set them to NULL.
     * Irreversible. Returns whether a code was there to wipe.
     *
     * Called from Admin::markCharged inside its transaction, and from
     * purgeExpired(). The overwrite first is belt and braces: the encrypted
     * code is unreadable without the key anyway, and the NULL is what
     * matters, but a page or row image taken between the two statements
     * then holds random bytes rather than the ciphertext.
     */
    public static function wipeCvv(PDO $db, int $applicationId): bool
    {
        $st = $db->prepare('SELECT cvv_ciphertext, cvv_wrapped_key FROM card_vault
                             WHERE application_id = ?');
        $st->execute([$applicationId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        $st->closeCursor();
        if (!$row || ($row['cvv_ciphertext'] === null && $row['cvv_wrapped_key'] === null)) {
            return false;
        }
        $junk = function ($v): string {
            $n = max(16, strlen((string) $v));
            return substr(base64_encode(random_bytes($n)), 0, $n);
        };
        $db->prepare('UPDATE card_vault SET cvv_ciphertext = ?, cvv_wrapped_key = ?
                       WHERE application_id = ?')
           ->execute([$junk($row['cvv_ciphertext']), $junk($row['cvv_wrapped_key']), $applicationId]);
        $db->prepare('UPDATE card_vault SET cvv_ciphertext = NULL, cvv_wrapped_key = NULL
                       WHERE application_id = ?')
           ->execute([$applicationId]);
        $row = null;
        return true;
    }

    /**
     * Wipe the code on every application that is already marked paid but
     * still has one: a charge recorded by something other than
     * Admin::markCharged, or a database restored from before the charge.
     * Part of purgeExpired(), so it runs on the same schedule.
     */
    public static function wipeChargedCvvs(PDO $db): int
    {
        $st = $db->query('SELECT v.application_id FROM card_vault v
                            JOIN applications a ON a.id = v.application_id
                           WHERE a.charged_on IS NOT NULL
                             AND (v.cvv_ciphertext IS NOT NULL OR v.cvv_wrapped_key IS NOT NULL)');
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        $st->closeCursor();
        $n = 0;
        foreach ($ids as $id) {
            if (self::wipeCvv($db, $id)) {
                $n++;
            }
        }
        return $n;
    }

    /* ----------------------------------------------------------- purge -- */

    /**
     * Delete every stored number whose retention period has ended, and mark
     * those applications as having no number on file.
     *
     * purge_after is set when the card is saved, card_retention_days after
     * (90 unless config.php says otherwise). Charged applications are purged
     * at once by mark-charged; this is the backstop for the ones that never
     * get charged.
     *
     * Runs from three places, so a small install needs no scheduler but a
     * proper one gets a guarantee: the reveal route and the admin detail
     * route before they read anything, a 1-in-10 chance on any other request
     * (index.php), and tools/purge-cards.php, which is the daily cron job
     * INSTALL.md asks for.
     *
     * Returns how many numbers were deleted.
     */
    public static function purgeExpired(PDO $db): int
    {
        /* First, any security code still stored for an application that is
           already paid. markCharged wipes it in the same transaction as the
           charge, so this normally finds nothing; it is the backstop. */
        self::wipeChargedCvvs($db);

        $now = Db::now();
        $st = $db->prepare('SELECT application_id FROM card_vault WHERE purge_after <= ?');
        $st->execute([$now]);
        $ids = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
        $st->closeCursor();
        if (!$ids) {
            return 0;
        }
        $db->beginTransaction();
        try {
            $del = $db->prepare('DELETE FROM card_vault WHERE application_id = ? AND purge_after <= ?');
            $flag = $db->prepare('UPDATE applications SET number_on_file = 0 WHERE id = ?');
            $note = $db->prepare(
                'INSERT INTO application_activity (application_id, author, action, at)
                 VALUES (?, ?, ?, ?)'
            );
            $count = 0;
            foreach ($ids as $id) {
                /* The code is overwritten and nulled before the row goes, so
                   it is destroyed the same way as on a recorded charge. */
                self::wipeCvv($db, $id);
                $del->execute([$id, $now]);
                if ($del->rowCount() < 1) {
                    continue;
                }
                $count++;
                $flag->execute([$id]);
                $note->execute([$id, 'System',
                    'Deleted the full card number and security code (retention period ended)', $now]);
            }
            $db->commit();
            return $count;
        } catch (Throwable $e) {
            $db->rollBack();
            throw $e;
        }
    }

    /* ------------------------------------------------- card checks -- */

    /** The same four brands and prefixes as payment-step.js cardBrand(). */
    public static function brand(string $digits): string
    {
        $four = (int) substr($digits, 0, 4);
        $six = (int) substr($digits, 0, 6);
        if (preg_match('/^4/', $digits)) {
            return 'Visa';
        }
        if (preg_match('/^3[47]/', $digits)) {
            return 'Amex';
        }
        if (preg_match('/^5[1-5]/', $digits)
            || (strlen($digits) >= 4 && $four >= 2221 && $four <= 2720)) {
            return 'Mastercard';
        }
        if (preg_match('/^(6011|65|64[4-9])/', $digits)
            || (strlen($digits) >= 6 && $six >= 622126 && $six <= 622925)) {
            return 'Discover';
        }
        return '';
    }

    /** The same lengths as payment-step.js LENGTHS. */
    public static function lengthOk(string $brand, string $digits): bool
    {
        $lengths = [
            'Visa'       => [13, 16, 19],
            'Mastercard' => [16],
            'Amex'       => [15],
            'Discover'   => [16, 17, 18, 19],
        ];
        return isset($lengths[$brand]) && in_array(strlen($digits), $lengths[$brand], true);
    }

    public static function luhn(string $digits): bool
    {
        if (!preg_match('/^[0-9]+$/', $digits)) {
            return false;
        }
        $sum = 0;
        $double = false;
        for ($i = strlen($digits) - 1; $i >= 0; $i--) {
            $n = ord($digits[$i]) - 48;
            if ($double) {
                $n *= 2;
                if ($n > 9) {
                    $n -= 9;
                }
            }
            $sum += $n;
            $double = !$double;
        }
        return $sum % 10 === 0;
    }
}
