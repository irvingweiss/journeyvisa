<?php
/* One PDO connection, in exceptions mode, with emulated prepares off so the
 * driver sends real parameters and an injected string can never become SQL.
 * Every query in this file set is parameterised; none builds SQL by
 * concatenation. */

class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(array $cfg): PDO
    {
        if (self::$pdo === null) {
            self::$pdo = new PDO($cfg['dsn'], $cfg['db_user'], $cfg['db_pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                /* Off in production. It exists so the test suite can make a
                   modern PHP return every column as a string, which is what
                   PHP 7.4's drivers do for SQLite and Postgres, and for MySQL
                   whenever emulated prepares are on. Running the suite both
                   ways is what proves the code does not quietly depend on
                   getting native integers back. Never set this in config.php
                   for a real install. */
                PDO::ATTR_STRINGIFY_FETCHES  => !empty($cfg['stringify_fetches']),
            ]);
            /* strncmp rather than str_starts_with: this has to run on PHP 7.4,
               where that function does not exist yet. */
            if (strncmp($cfg['dsn'], 'sqlite:', 7) === 0) {
                self::$pdo->exec('PRAGMA foreign_keys = ON');
            }
        }
        return self::$pdo;
    }

    /**
     * Is a flag column set? True for 1, '1', true and 't'; false otherwise.
     *
     * Reading these straight with `if ($row['flag'])` is wrong on one of the
     * three databases this API supports, and wrong in the dangerous
     * direction. The flag columns are TINYINT, and PDO hands them back as a
     * native int on MySQL and as the string '0' or '1' on Postgres and
     * SQLite; both work with a plain truth test, because PHP treats '0' as
     * false.
     *
     * But the porting note in schema.mysql.sql sends people to Postgres, which
     * has no TINYINT, and BOOLEAN is the obvious column to reach for. On
     * PHP 7.4 the pgsql driver returns booleans as the strings 't' and 'f'
     * (native bool only arrives in 8.1), and 'f' is a non-empty string, so it
     * is TRUE in PHP. Every flag would read as set. For admin_sessions that
     * means a half session passing as complete and a password-only session
     * passing the card-reveal guard.
     *
     * Casting to int does not save you either: (int) 't' and (int) 'f' are
     * both 0, so a strict comparison would reject a session that is genuinely
     * set. Hence this, which names every representation the drivers actually
     * produce. The schema keeps these columns as integers, which is the real
     * fix; this is here so that a database that got ported anyway cannot fail
     * open.
     */
    public static function flag($value): bool
    {
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return (int) $value === 1;
        }
        $v = strtolower(trim((string) $value));
        return $v === '1' || $v === 't' || $v === 'true' || $v === 'yes';
    }

    /** UTC everywhere. Applicants and staff are in different time zones and
     *  the front end formats for display. */
    public static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    public static function inFuture(int $seconds): string
    {
        return gmdate('Y-m-d H:i:s', time() + $seconds);
    }

    /** ISO 8601 for the browser, which is what the admin screen formats. */
    public static function iso(?string $sqlTime): ?string
    {
        if (!$sqlTime) {
            return null;
        }
        $ts = strtotime($sqlTime . ' UTC');
        return $ts ? gmdate('Y-m-d\TH:i:s\Z', $ts) : null;
    }
}
