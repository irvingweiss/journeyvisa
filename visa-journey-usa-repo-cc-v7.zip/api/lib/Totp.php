<?php
/* TOTP, RFC 6238, in about sixty lines and with no dependency.
 *
 * SHA1, six digits, thirty seconds. Those are not preferences: they are what
 * every authenticator app assumes when it scans a QR code, and changing them
 * produces codes this will reject.
 */

class Totp
{
    public const PERIOD = 30;
    public const DIGITS = 6;

    /** RFC 4648 base32, which is how authenticator apps take a secret. */
    public static function base32Decode(string $secret): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $secret));
        $bits = '';
        for ($i = 0, $n = strlen($secret); $i < $n; $i++) {
            $pos = strpos($alphabet, $secret[$i]);
            if ($pos === false) {
                continue;
            }
            $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $out .= chr(bindec($byte));
            }
        }
        return $out;
    }

    /** The code for one 30-second step. */
    public static function at(string $secret, int $step): string
    {
        $key = self::base32Decode($secret);
        /* The counter is a 64-bit big-endian integer. */
        $counter = pack('J', $step);
        $hash = hash_hmac('sha1', $counter, $key, true);
        $offset = ord($hash[19]) & 0x0f;
        $value = ((ord($hash[$offset]) & 0x7f) << 24)
               | ((ord($hash[$offset + 1]) & 0xff) << 16)
               | ((ord($hash[$offset + 2]) & 0xff) << 8)
               | (ord($hash[$offset + 3]) & 0xff);
        $code = $value % (10 ** self::DIGITS);
        return str_pad((string) $code, self::DIGITS, '0', STR_PAD_LEFT);
    }

    /**
     * Check a code and return the step it matched, or null.
     *
     * One step either side of now, so a code is good for about ninety seconds.
     * People's phones drift. Widening it further widens the window an attacker
     * has with a code they watched being typed.
     *
     * The caller must refuse a step it has already accepted. Without that, a
     * code read over a shoulder or captured on a phishing page works a second
     * time until it expires, and the second factor stops being one.
     */
    /**
     * Whether a secret from config.php can actually be used.
     *
     * Callers that branch on "is a second factor enrolled" must use this
     * rather than testing the string for emptiness, so that a placeholder is
     * treated as a broken setting and not as a working one.
     *
     * Three tests, and the history of each is the reason it is here.
     *
     * 1. The decoded key is at least 10 bytes. The first version of this
     *    guard tested trim($secret) !== '', which '0' or '000000' passes --
     *    no digit is in the base32 alphabet, so those decode to a ZERO-length
     *    key, and the codes from an empty key are what anybody can compute.
     *
     * 2. The base32 string is not one character repeated. Testing the decoded
     *    LENGTH alone was the second version, and it was not enough:
     *    'AAAAAAAAAAAAAAAA' decodes to ten bytes of 0x00, so it passed, and
     *    an audit computed the code for the current step from that known key
     *    and signed in with it -- ending up with second_factor = 1, the flag
     *    the card routes are specified to check.
     *
     * 3. The decoded key has at least 6 distinct byte values. This catches
     *    the repeating placeholders that rule 2 misses because they repeat a
     *    group rather than a character: 'ABABABABABABABAB' and
     *    'CHANGEMECHANGEME' both decode to 5 or fewer distinct bytes. The
     *    threshold is measured rather than guessed: over 200,000 secrets from
     *    generateSecret(10) the lowest distinct count seen was 6, and
     *    generateSecret() now rejects its own output below the floor, so no
     *    legitimate secret is refused.
     *
     * What this does NOT do is judge whether a secret is guessable in
     *    general. 'SECRETSECRETSECR' decodes to ten distinct bytes and passes
     *    every test here. There is no way to detect that from the value, so
     *    the real defence is generating it with tools/enrol-totp.php rather
     *    than by hand, which is also what writes the recovery codes.
     */
    public static function usable(string $secret): bool
    {
        $key = self::base32Decode($secret);
        if (strlen($key) < 10) {
            return false;
        }
        /* Rule 2, on the base32 input rather than the key, because that is
           what a person types and 'AAAA...' is the shape they type. */
        $normalised = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $secret));
        if ($normalised !== '' && strlen(count_chars($normalised, 3)) === 1) {
            return false;
        }
        return strlen(count_chars($key, 3)) >= 6;
    }

    public static function verify(string $secret, string $code, int $drift = 1, ?int $now = null): ?int
    {
        /* A secret that is not usable must never verify. See usable() for
           the three tests and why each one is there.
           
           Note what is NOT a problem: a secret pasted WITH its dashes, as
           authenticator apps display it. base32Decode strips every character
           outside the alphabet, so 'DFJF-7O4R-...' decodes identically to
           'DFJF7O4R...' and verifies against the same codes. An earlier
           version of this comment claimed a dashed paste decoded to nothing;
           an audit disproved it by decoding both and comparing. The strings
           that really do decode to nothing are the all-digit ones. */
        if (!self::usable($secret)) {
            return null;
        }
        $code = preg_replace('/\D/', '', $code);
        if (strlen($code) !== self::DIGITS) {
            return null;
        }
        $current = intdiv($now ?? time(), self::PERIOD);
        for ($i = -$drift; $i <= $drift; $i++) {
            /* hash_equals, not ==. A length-safe constant-time compare keeps
               the answer from leaking how much of the code was right. */
            if (hash_equals(self::at($secret, $current + $i), $code)) {
                return $current + $i;
            }
        }
        return null;
    }

    /** A new secret, for tools/enrol-totp.php. */
    public static function generateSecret(int $bytes = 20): string
    {
        /* Loop until the result passes usable(). The distinct-byte floor there
           is set just below what random output produces, so this practically
           always returns on the first pass -- but "practically always" is not
           "always", and a one-in-a-hundred-thousand secret that the API then
           refuses would be an unreproducible enrolment failure. Checking our
           own output costs nothing and removes the whole question. */
        for ($attempt = 0; $attempt < 100; $attempt++) {
            $candidate = self::randomSecret($bytes);
            if (self::usable($candidate)) {
                return $candidate;
            }
        }
        /* Unreachable with a working CSPRNG. If it ever happens, failing is
           the right answer: a secret that cannot pass our own check would be
           refused at sign-in anyway, and silently returning it would turn
           that into a mystery. */
        throw new RuntimeException('could not generate a usable TOTP secret');
    }

    private static function randomSecret(int $bytes): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $raw = random_bytes($bytes);
        $bits = '';
        for ($i = 0; $i < strlen($raw); $i++) {
            $bits .= str_pad(decbin(ord($raw[$i])), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            if (strlen($chunk) === 5) {
                $out .= $alphabet[bindec($chunk)];
            }
        }
        return $out;
    }

    /** The URI an authenticator app scans. */
    public static function uri(string $secret, string $account, string $issuer): string
    {
        return 'otpauth://totp/' . rawurlencode($issuer) . ':' . rawurlencode($account)
             . '?secret=' . $secret
             . '&issuer=' . rawurlencode($issuer)
             . '&algorithm=SHA1&digits=' . self::DIGITS . '&period=' . self::PERIOD;
    }
}
