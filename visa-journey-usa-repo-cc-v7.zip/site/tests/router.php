<?php
/* A router for `php -S`, so the site and the API answer on ONE origin.
 *
 *   php -S 127.0.0.1:PORT -t <docroot> site/tests/router.php
 *
 * Used by browser.js. The pages fetch relative paths like /api/application, so
 * a browser test has to see the site and the API on the same host and port --
 * two servers would make every request cross-origin, which the API refuses by
 * design and which browsers would not send the session cookies on anyway. One
 * server with this in front of it is the arrangement a real host has: static
 * files, plus one rewrite sending /api/ at index.php.
 *
 * It also does the clean URLs deploy/ expects (/about-us -> about-us.html), so
 * the pages are exercised at the paths they are actually linked by.
 *
 * Test-only. It is not a deployment artifact and deploy/server-config/ holds
 * the real host configurations.
 */

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$root = $_SERVER['DOCUMENT_ROOT'];

/* The API. Everything under /api/ runs index.php, which does its own routing. */
if (strpos($path, '/api/') === 0 || $path === '/api') {
    $index = $root . '/api/index.php';
    if (!is_file($index)) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo '{"code":"no_api","message":"api/index.php is not in the docroot."}';
        return true;
    }
    /* index.php reads REQUEST_URI itself, so leave it alone. */
    require $index;
    return true;
}

/* Static files, as they are. */
$file = $root . $path;
if ($path !== '/' && is_file($file)) {
    return false;
}

/* Clean URLs. */
if ($path === '/' && is_file($root . '/index.html')) {
    $_SERVER['SCRIPT_NAME'] = '/index.html';
    readfile($root . '/index.html');
    header('Content-Type: text/html; charset=utf-8');
    return true;
}
if (is_file($file . '.html')) {
    header('Content-Type: text/html; charset=utf-8');
    readfile($file . '.html');
    return true;
}

http_response_code(404);
if (is_file($root . '/404.html')) {
    header('Content-Type: text/html; charset=utf-8');
    readfile($root . '/404.html');
}
return true;
