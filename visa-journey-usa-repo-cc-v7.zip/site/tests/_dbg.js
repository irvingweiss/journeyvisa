
const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", args: ["--no-sandbox"] });
  const page = await browser.newPage();
  const errs = []; page.on("pageerror", e => errs.push(String(e))); page.on("console", m => errs.push("console:" + m.text()));
  await page.goto("http://127.0.0.1:8897/visa-journey-admin.html");
  await page.waitForTimeout(1500);
  console.log(page.url()); console.log((await page.textContent("body")).slice(0, 800));
  console.log(errs.slice(0,5));
  await page.screenshot({ path: process.argv[2] + "/dbg.png" });
  await browser.close();
})();
