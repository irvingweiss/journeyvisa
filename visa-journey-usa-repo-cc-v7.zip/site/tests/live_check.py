#!/usr/bin/env python3
"""
live_check.py — point this at the deployed site and it tells you what is missing.

    python3 tests/live_check.py https://www.visajourneyusa.com

It does three things:

1. Requests every URL this build is meant to serve and reports the status code.
   A 404 here means that file did not reach the server, not that the build is
   wrong — the same URL will be fine locally.
2. Reads the build marker off the live homepage and compares it with BUILD.txt
   in the folder, so you can see at a glance whether the deploy actually went out.
3. Follows the nav and footer links on each live page, so a link pointing at a
   page that was never uploaded shows up as a broken link rather than as a
   surprise for a visitor.

Exit code is 0 only if every URL answers 200 and the build marker matches.

No dependencies. Runs on any machine with Python 3.
"""

import os
import re
import sys
import html as htmllib
import urllib.request
import urllib.error
from urllib.parse import urljoin, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(os.path.dirname(HERE), "deploy")

ATTR = re.compile(r'(?:href|src)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)
MARKER = re.compile(r'<meta\s+name="vj-build"\s+content="([^"]*)"', re.I)


def expected_urls():
    """Every path this build should answer, worked out from the folder itself."""
    urls = []
    for name in sorted(os.listdir(DEPLOY)):
        if not os.path.isfile(os.path.join(DEPLOY, name)):
            continue
        if name in ("netlify.toml", "DEPLOY.md", "BUILD.txt"):
            continue
        if name == "index.html":
            urls.append("/")
        elif name == "404.html":
            continue
        elif name.endswith(".html"):
            urls.append("/" + name[:-5])
        else:
            urls.append("/" + name)
    return urls


def local_build():
    path = os.path.join(DEPLOY, "BUILD.txt")
    if not os.path.exists(path):
        return None
    m = re.search(r"build\s+(\S+)", open(path, encoding="utf-8").read())
    return m.group(1) if m else None


SECURITY_HEADERS = [
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
    "Strict-Transport-Security",
]


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "vj-live-check"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            ctype = r.headers.get("Content-Type", "")
            body = r.read().decode("utf-8", "replace") if "html" in ctype else ""
            return r.status, body, dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, "", dict(e.headers or {})
    except Exception as e:
        return 0, str(e), {}


def get_raw(url, limit=65536):
    """Status and body, whatever the content type.

    get() only reads the body when the Content-Type mentions html, which is
    right for pages but useless for the one check that has to look inside a
    file: a web server handing out config.php labels it something like
    application/x-httpd-php or text/plain, so get() returned an empty body and
    the search for "db_pass" could never match. Status alone catches a file
    being served, but finding the password in the response is the difference
    between "this ought not to be reachable" and "your database password is
    public", and that distinction is worth the few extra lines.
    """
    req = urllib.request.Request(url, headers={"User-Agent": "vj-live-check"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, r.read(limit).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            return e.code, (e.read(limit) or b"").decode("utf-8", "replace")
        except Exception:
            return e.code, ""
    except Exception:
        return 0, ""


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """So a 301 is reported as a 301 rather than silently followed."""
    def redirect_request(self, *a, **k):
        return None


def head_only(url):
    """Status and Location without following the redirect."""
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "vj-live-check"})
    try:
        with opener.open(req, timeout=20) as r:
            return r.status, r.headers.get("Location")
    except urllib.error.HTTPError as e:
        return e.code, (e.headers or {}).get("Location")
    except Exception:
        return 0, None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    base = sys.argv[1].rstrip("/")

    print("== live check: %s ==\n" % base)

    missing = []
    bodies = {}
    home_headers = {}

    print("  URLs this build should serve")
    for path in expected_urls():
        status, body, headers = get(base + path)
        flag = "ok " if status == 200 else "MISSING"
        print("    %-7s %-5s %s" % (flag, status or "---", path))
        if status != 200:
            missing.append((path, status))
        else:
            if path == "/":
                home_headers = headers
            if body:
                bodies[path] = body

    # ---------------------------------------------------------- build marker

    print("\n  Build marker")
    want = local_build()
    home = bodies.get("/", "")
    m = MARKER.search(home)
    live = m.group(1).split()[-1] if m else None
    stale = False
    if want is None:
        print("    no BUILD.txt in deploy/ to compare against")
    elif live is None:
        print("    live homepage carries no vj-build marker — it is not this build")
        stale = True
    elif live == want:
        print("    matches: %s" % live)
    else:
        print("    MISMATCH — live is %s, this folder is %s" % (live, want))
        print("    The deploy has not gone out, or only part of it has.")
        stale = True

    # ---------------------------------------------------- the custom 404 page

    print("\n  Error page")
    status, body, _ = get(base + "/no-such-page-" + "x" * 8)
    bad404 = False
    if status == 404:
        print("    unknown path answers 404")
    elif status == 200:
        print("    WRONG — an unknown path answers 200. Search engines will index")
        print("    every typo as a real page, and a broken link looks like a good one.")
        bad404 = True
    else:
        print("    unknown path answers %s, expected 404" % (status or "no response"))
        bad404 = True

    # ------------------------------------------------------ security headers

    print("\n  Security headers on the homepage")
    missing_headers = []
    if not home_headers:
        print("    could not read them, homepage did not answer")
    else:
        lower = {k.lower(): v for k, v in home_headers.items()}
        for h in SECURITY_HEADERS:
            if h.lower() in lower:
                print("    ok      %s" % h)
            else:
                print("    absent  %s" % h)
                missing_headers.append(h)
        if missing_headers:
            print("    These come from netlify.toml, which only Netlify reads. On any")
            print("    other host use the matching file in deploy/server-config/.")

    # -------------------------------------------- redirects from .html paths

    print("\n  Redirects from the old .html paths")
    bad_redirects = []
    samples = ["/index.html", "/about-us.html", "/b1-b2-visitor-visa.html"]
    for path in samples:
        status, loc = head_only(base + path)
        want = "/" if path == "/index.html" else path[:-5]
        if status == 301 and loc and urlparse(loc).path == want:
            print("    ok      %-28s 301 -> %s" % (path, want))
        elif status == 301:
            print("    WRONG   %-28s 301 -> %s, expected %s"
                  % (path, urlparse(loc or "").path or "?", want))
            bad_redirects.append(path)
        elif status == 200:
            print("    absent  %-28s serves 200, so the page sits at two URLs"
                  % path)
            bad_redirects.append(path)
        else:
            print("    absent  %-28s answers %s" % (path, status or "no response"))
            bad_redirects.append(path)

    # -------------------------------------------------------- link following

    print("\n  Links on the live pages")
    broken = {}
    for path, body in bodies.items():
        for mm in ATTR.finditer(body):
            raw = mm.group(1) if mm.group(1) is not None else mm.group(2)
            link = htmllib.unescape(raw).strip()
            if not link or link.startswith(("mailto:", "tel:", "data:",
                                            "javascript:", "#")):
                continue
            target = urljoin(base + path, link)
            if urlparse(target).netloc != urlparse(base).netloc:
                continue
            tp = urlparse(target).path or "/"
            status, _, _ = get(target)
            if status != 200:
                broken.setdefault((tp, status), set()).add(path)

    if not broken:
        print("    every internal link answers 200")
    else:
        for (tp, status), where in sorted(broken.items()):
            print("    BROKEN %-5s %-34s linked from %s"
                  % (status, tp, ", ".join(sorted(where))))

    # ----------------------------------------- DEMO flags and the preview

    # A site serving fixture data looks completely fine. Every page renders,
    # every link works, the admin screen signs in and lists applications --
    # they are just invented. Nothing else in this check would notice, because
    # nothing else looks at what the pages are talking to.
    print("\n  DEMO flags")
    live_demo = []
    no_body = []
    # POST /api/application/card is built (2026-10-22), but payment.html can
    # only come off DEMO once the server has CARD_KEY, the migration and the
    # second factor (DEVELOPER-INSTRUCTIONS.md). Until then DEMO on /payment is
    # a reminder, not a failure: turning it off early posts card numbers at a
    # route that answers 503 card_storage_off.
    expected_demo = {"/payment"}
    for path in ("/application", "/resume", "/admin", "/payment"):
        body = bodies.get(path)
        if body is None:
            print("    %-14s could not read the page" % path)
            no_body.append(path)
            continue
        on = re.search(r"var\s+DEMO\s*=\s*true", body) is not None
        if on and path in expected_demo:
            print("    %-14s DEMO = true   flip it once CARD_KEY, the migration and the"
                  " second factor are in place (DEVELOPER-INSTRUCTIONS.md)" % path)
        elif on:
            print("    %-14s DEMO = true   WRONG for a live site" % path)
            live_demo.append(path)
        elif path in expected_demo:
            print("    %-14s DEMO = false  ok: cards go to POST /api/application/card"
                  % path)
        else:
            print("    %-14s DEMO = false  ok" % path)

    admin_body = bodies.get("/admin", "") or ""
    preview_signin = "DEMO_ADMIN_PASSWORD_SHA256" in admin_body
    if preview_signin:
        print("    the preview sign in is still in admin.html (step 8 of INSTALL.md)")
    elif admin_body:
        print("    the preview sign in has been removed")

    # --------------------------------------------- the API's own files
    #
    # This is the one check worth running even if you skip everything else.
    #
    # api/config.php holds the database password and the admin password hash.
    # Three separate server configurations in this package have, at one point
    # or another, served it as a plain file: nginx through `try_files $uri`
    # under a `location ^~` that made the blocking rules unreachable, Apache
    # through `RewriteCond %{REQUEST_FILENAME} !-f`, and IIS through
    # `matchType="IsFile" negate="true"`. All three are fixed, and INSTALL.md
    # carries curl commands to prove it by hand.
    #
    # But this script is the gate the documentation points at for a deployed
    # site, and it never looked at /api/ at all, so it printed "OK" with the
    # database password downloadable. An audit found that, and it is exactly
    # the failure this file exists to prevent: a check that reports success
    # without having looked.

    print("\n  The API's own files are not readable")
    exposed = []
    api_unrouted = False
    secret_markers = ("db_pass", "admin_password_hash", "totp_secret",
                      "admin_email")
    for path in ("/api/config.php", "/api/config.example.php",
                 "/api/lib/Config.php", "/api/routes/Admin.php",
                 "/api/index.php", "/api/.htaccess"):
        status, body = get_raw(base + path)
        leaked = [m for m in secret_markers if body and m in body]
        # 404 from the router is the right answer for everything except
        # index.php, which the router serves as the API itself.
        served = status == 200 and path != "/api/index.php"
        if leaked or served:
            exposed.append((path, status, leaked))
            print("    EXPOSED %-5s %s%s" % (
                status or "---", path,
                "  contains " + ", ".join(leaked) if leaked else ""))
        else:
            print("    ok     %-5s %s" % (status or "---", path))

    # And is the API actually routed? An unknown path under /api/ should come
    # back as the router's own JSON, not as the site's 404 page. Without this,
    # "nothing under /api/ is readable" is also true of a server where the API
    # was never wired up at all, which is a different problem with the same
    # shape of evidence.
    status, body = get_raw(base + "/api/vj-live-check-probe")
    if not (body and '"no_route"' in body):
        api_unrouted = True
        print("    note   %-5s /api/ is not routed to index.php on this host"
              % (status or "---"))
        print("           (an unknown API path should answer the router's own")
        print("            JSON with code \"no_route\"; see INSTALL.md step 5)")
    else:
        # 404 is the CORRECT answer here: the probe path does not exist, and
        # the router saying so in its own JSON is the proof that it ran.
        print("    ok     %-5s the API is routed and answering"
              " (404 no_route, which is the right answer to a probe)" % status)

    # ------------------------------------------------------------- verdict

    print("\n" + "=" * 62)
    if exposed:
        print("  CREDENTIALS READABLE: %d file(s) under /api/ are being served."
              % len(exposed))
        print("  Anyone can download them. If config.php is among them, the")
        print("  database password and the admin password hash are public:")
        print("  change both, then fix the web server. INSTALL.md step 5 has")
        print("  the correct block for Apache, nginx and IIS, and the reason")
        print("  each one is shaped the way it is.")
    if missing:
        print("  BREAKS THE SITE: %d URL(s) are not on the server." % len(missing))
        print("  Upload the whole deploy/ folder, not a subset of it. Every file")
        print("  in that folder is linked from somewhere in the site.")
    if broken:
        print("  BREAKS THE SITE: %d link target(s) are dead for visitors."
              % len(broken))
    if stale:
        print("  The live build marker does not match this folder, so what is")
        print("  deployed is not what is in deploy/.")
    if bad404:
        print("  The error page is not answering 404.")
    if missing_headers:
        print("  %d security header(s) absent. Nothing breaks; a review will ask."
              % len(missing_headers))
    if bad_redirects:
        print("  %d .html path(s) are not redirecting. Each one is a second URL"
              % len(bad_redirects))
        print("  serving the same page, which splits it in search results.")
    if live_demo:
        print("  SHOWING FIXTURE DATA: %s still %s DEMO on."
              % (", ".join(live_demo), "has" if len(live_demo) == 1 else "have"))
        print("  Nothing is reaching the API. An applicant's answers are not being")
        print("  saved anywhere, and the applications on the admin screen are")
        print("  invented. Step 8 of INSTALL.md.")
    if preview_signin:
        print("  The preview sign in is still in admin.html. Its password is")
        print("  published in the repository on purpose, so while DEMO is on,")
        print("  anyone who finds /admin can sign in and browse what look like")
        print("  real applications. Step 8 of INSTALL.md removes it.")
    if not (missing or stale or broken or bad404 or missing_headers
            or bad_redirects or live_demo or preview_signin):
        print("  OK — the live site matches this build, every link works,")
        print("  it is talking to the API rather than to fixture data, and")
        print("  nothing under /api/ is readable as a file.")
        if api_unrouted:
            print("")
            print("  But /api/ is not routed to index.php on this host, so the")
            print("  pages above have nothing to talk to. That is not counted")
            print("  as a failure here because the API may live on another")
            print("  host, but if it is meant to be this one, see step 5.")
    print("=" * 62)

    serious = (missing or stale or broken or bad404 or missing_headers
               or bad_redirects or live_demo or preview_signin or exposed)
    return 1 if serious else 0


if __name__ == "__main__":
    sys.exit(main())
