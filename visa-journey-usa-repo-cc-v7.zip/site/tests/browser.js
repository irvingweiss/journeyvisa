/* The real pages, in a real browser, against the real API, with DEMO off.
 *
 *   node browser.js            # uses ../deploy, which is what ships
 *   node browser.js ../src/    # or the sources
 *
 * Needs playwright and a chromium it can find. Exits NON-ZERO if either is
 * missing, because this is the only suite covering the page-to-API seam and a
 * silent skip reads exactly like a pass. VJ_ALLOW_NO_BROWSER=1 opts out.
 *
 * WHY THIS EXISTS, given there are already five suites.
 *
 * None of the others puts a browser in front of this. The jsdom suites run the
 * pages with DEMO on, so no request is ever made: they prove the form's own
 * logic and nothing about the seam. The API suite drives the API over HTTP,
 * which proves the endpoints and nothing about the pages. api_contract.py
 * compares the two statically.
 *
 * That seam has broken twice, and in both cases every suite was green:
 *
 *  - "Save and exit" posted to /api/application/resume-link while the API
 *    implemented /api/application/email-reference. Answers saved, the email
 *    never sent.
 *  - The pages threw away the API's error messages and showed "request
 *    failed", including for a locked application that the server had
 *    explained in full.
 *
 * Both would have shown up here in the first thirty seconds. So this walks the
 * journey a person actually takes: start an application, fill some of it in,
 * close the tab, come back with the reference and the security answer, then
 * sign in to the admin screen with a password and a real TOTP code and look at
 * what the applicant typed.
 *
 * It is slower than the others and it is the only one that can see the whole
 * thing working. Run it before a handover and after any change to a page's
 * callbacks or to an endpoint's shape.
 */

"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFileSync, spawn } = require("child_process");
const net = require("net");

const SRC = process.argv[2] || "../deploy/";
const ROOT = path.resolve(__dirname, "..", "..");

let pass = 0, fail = 0;
const failures = [];

function ok(name, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else {
    fail++;
    failures.push(name + (detail ? " -> " + detail : ""));
    console.log("  FAIL  " + name + (detail ? " -> " + detail : ""));
  }
}
function group(t) { console.log("\n" + t); }

/* Watch one page for errors that are the PAGE's fault.
 *
 * Three kinds of noise have to be filtered or this reports failures that are
 * not real:
 *
 *  - An uncaught exception is always real. Those are what this is for.
 *  - "Failed to load resource: ... 401" is Chromium narrating an HTTP status.
 *    This test deliberately sends a wrong password and a wrong code, so those
 *    are expected; the assertions check the statuses directly.
 *  - A request to another host failing is the environment, not the site. The
 *    pages load a webfont from Google, and the container this runs in has no
 *    route to it. Worth knowing, not worth failing: the page renders without
 *    it, which the assertions below prove.
 *  - net::ERR_ABORTED on a 204 from `php -S`. Established by measurement, not
 *    assumed: a PATCH that saves a step logs the response (204) and THEN a
 *    requestfailed with ERR_ABORTED for the same request, and an independent
 *    in-page `await fetch(...)` against the same route returns
 *    "RESOLVED status=204". So the write happened, the response arrived, and
 *    the promise the page awaits resolves normally -- the abort is the
 *    single-threaded development server closing the connection after a
 *    body-less response, and it does not occur under PHP-FPM, which is what
 *    this ships on. Narrow deliberately: ONLY an aborted request that already
 *    produced a response is forgiven, so a genuinely cancelled or
 *    never-answered request still fails. Chasing this down is what turned up
 *    the "Could not save" bug on a successful save, so it was worth not
 *    silencing blindly.
 */
function watch(page, origin) {
  const errors = [];
  const offsite = [];
  const answered = new Set();
  page.on("pageerror", (e) => errors.push("uncaught: " + String(e.message)));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    if (/Failed to load resource/i.test(m.text())) return;
    errors.push("console: " + m.text());
  });
  page.on("response", (r) => {
    if (r.status() === 204) answered.add(r.request());
  });
  page.on("requestfailed", (r) => {
    const url = r.url();
    if (!url.startsWith(origin)) {
      offsite.push(url.replace(/\?.*$/, ""));
      return;
    }
    const why = (r.failure() || {}).errorText || "";
    if (why === "net::ERR_ABORTED" && answered.has(r)) return;
    errors.push("request failed: " + url + " " + why);
  });
  return { errors, offsite };
}

/* The form's own primary-action button. Its label changes from step to step
   ("Create my application", "Continue", "Sign and submit application"), so match the
   class the form puts on it rather than guessing words. */
async function clickPrimary(page, timeout = 15000) {
  const btn = page.locator("button.vj-btn.vj-primary:visible").last();
  await btn.waitFor({ state: "visible", timeout });
  await btn.click();
}

/* ---- TOTP, so the admin sign in can be completed for real --------------- */

function base32Decode(s) {
  const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const ch of s.replace(/=+$/, "").toUpperCase()) {
    const i = A.indexOf(ch);
    if (i < 0) continue;
    bits += i.toString(2).padStart(5, "0");
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

function totp(secret, step) {
  const counter = Buffer.alloc(8);
  counter.writeUInt32BE(Math.floor(step / 0x100000000), 0);
  counter.writeUInt32BE(step % 0x100000000, 4);
  const h = crypto.createHmac("sha1", base32Decode(secret)).update(counter).digest();
  const off = h[h.length - 1] & 0x0f;
  const bin = ((h[off] & 0x7f) << 24) | (h[off + 1] << 16)
            | (h[off + 2] << 8) | h[off + 3];
  return String(bin % 1000000).padStart(6, "0");
}

/* ---- a free port, by connecting rather than only binding ---------------- */

function freePort(from = 9500) {
  for (let p = from; p < from + 400; p++) {
    try {
      const s = net.createServer();
      let taken = false;
      s.on("error", () => { taken = true; });
      s.listen(p, "127.0.0.1");
      s.close();
      if (!taken) return p;
    } catch (e) { /* next */ }
  }
  throw new Error("no free port");
}

/* ---- set the whole thing up in a temp directory ------------------------- */

function sqliteSchema(mysql) {
  const kept = mysql.split("\n").filter((l) => !/^\s*(INDEX|KEY|UNIQUE KEY)\s/i.test(l));
  let s = kept.join("\n");
  s = s.replace(/BIGINT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY/gi,
                "INTEGER PRIMARY KEY AUTOINCREMENT");
  s = s.replace(/\)\s*ENGINE=\w+\s+DEFAULT\s+CHARSET=\w+\s*;/gi, ");");
  s = s.replace(/\bLONGTEXT\b/gi, "TEXT");
  s = s.replace(/\bVARCHAR\(\d+\)/gi, "TEXT");
  s = s.replace(/\bTINYINT\(1\)/gi, "INTEGER");
  s = s.replace(/\bDECIMAL\(\d+,\d+\)/gi, "REAL");
  s = s.replace(/\bDATETIME\b/gi, "TEXT");
  s = s.replace(/\bDATE\b/gi, "TEXT");
  s = s.replace(/,(\s*\))/g, "$1");
  /* The append-only triggers on card_reveal_log: MySQL's one-statement
     SIGNAL body becomes SQLite's RAISE inside BEGIN ... END, the same
     translation tests/api_test.php makes. */
  s = s.replace(/FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = ('[^']*');/gi,
                "FOR EACH ROW BEGIN SELECT RAISE(ABORT, $1); END;");
  return s;
}

/* Why this exits non-zero rather than skipping.
 *
 * It used to print a friendly line and exit 0 when playwright was missing,
 * which is the same shape as a gate that passes by checking nothing -- and
 * this is the one suite that drives the pages and the API together with DEMO
 * off, the seam where two bugs have shipped with every other suite green.
 *
 * Both reasons it cannot run come through here. The first version only caught
 * a missing MODULE, and since package.json now brings playwright, the case
 * that actually happens is a missing BROWSER BINARY: npm does not download
 * one, `npx playwright install chromium` does. That threw from launch() and
 * landed in the generic handler, so the documented VJ_ALLOW_NO_BROWSER opt-out
 * did nothing in the only situation anyone would reach for it. An audit found
 * that by running it. */
function cannotRun(reason) {
  console.log("");
  console.log("  browser.js DID NOT RUN: " + reason);
  console.log("  This is the only suite that drives the pages and the API");
  console.log("  together with DEMO off. Treat a run without it as a run");
  console.log("  with the page-to-API seam untested.");
  console.log("");
  console.log("    cd site/tests && npm install");
  console.log("    npx playwright install chromium");
  console.log("");
  if (process.env.VJ_ALLOW_NO_BROWSER === "1") {
    console.log("  VJ_ALLOW_NO_BROWSER=1 is set, so this is not a failure.");
    process.exit(0);
  }
  console.log("  Set VJ_ALLOW_NO_BROWSER=1 to make this a skip instead.");
  process.exit(2);
}

async function main() {
  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch (e) {
    cannotRun("playwright is not installed here.");
  }

  const tmp = fs.mkdtempSync("/tmp/vj-browser-");
  const docroot = path.join(tmp, "www");
  fs.mkdirSync(docroot, { recursive: true });

  /* The site, with DEMO turned off -- which is the whole point. */
  const siteDir = path.resolve(__dirname, SRC);
  for (const f of fs.readdirSync(siteDir)) {
    const from = path.join(siteDir, f);
    if (!fs.statSync(from).isFile()) continue;
    let body = fs.readFileSync(from);
    if (/\.(html|js)$/.test(f)) {
      body = Buffer.from(
        body.toString("utf8").replace(/var DEMO = true;/g, "var DEMO = false;")
      );
    }
    fs.writeFileSync(path.join(docroot, f), body);
  }
  const demoLeft = fs.readdirSync(docroot)
    .filter((f) => /\.(html|js)$/.test(f))
    .filter((f) => /var DEMO = true;/.test(
      fs.readFileSync(path.join(docroot, f), "utf8")));

  /* The API, beside it, so everything is one origin. */
  execFileSync("cp", ["-R", path.join(ROOT, "api"), path.join(docroot, "api")]);

  const dbFile = path.join(tmp, "t.sqlite");
  const photoDir = path.join(tmp, "photos");
  fs.mkdirSync(photoDir);

  const port = freePort();
  const origin = `http://127.0.0.1:${port}`;
  const adminEmail = "manager@example.com";
  const adminPassword = "correct horse battery staple";

  /* The hash and the TOTP secret come from the shipped code, not from a
     reimplementation of it here. */
  const adminHash = execFileSync("php", ["-r",
    `echo password_hash(${JSON.stringify(adminPassword)}, PASSWORD_BCRYPT, ['cost' => 4]);`
  ]).toString();
  const totpSecret = execFileSync("php", ["-r",
    `require ${JSON.stringify(path.join(ROOT, "api/lib/Totp.php"))}; echo Totp::generateSecret();`
  ]).toString().trim();

  fs.writeFileSync(path.join(docroot, "api", "config.php"), `<?php
return [
    'dsn'      => 'sqlite:${dbFile}',
    'db_user'  => null,
    'db_pass'  => null,
    'admin_email'         => '${adminEmail}',
    'admin_password_hash' => '${adminHash}',
    'totp_secret'         => '${totpSecret}',
    'admin_fail_limit'   => 5,
    'admin_fail_window'  => 900,
    'admin_lockout'      => 900,
    'resume_fail_limit'  => 5,
    'resume_lockout'     => 1800,
    'resume_rate_limit'  => 50,
    'resume_rate_window' => 600,
    'lookup_rate_limit'  => 50,
    'lookup_rate_window' => 600,
    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,
    'photo_dir' => '${photoDir}',
    'service_fee' => 185,
    'currency'    => 'USD',
    'support_email' => 'support@example.com',
    'allowed_origins' => ['${origin}'],
    'secure_cookies' => false,
    'card_key' => '${crypto.randomBytes(32).toString("base64")}',
];
`);

  execFileSync("php", ["-r", `
    $db = new PDO('sqlite:${dbFile}', null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $db->exec(file_get_contents('php://stdin'));
  `], { input: sqliteSchema(fs.readFileSync(path.join(ROOT, "schema.mysql.sql"), "utf8")) });

  const logFile = path.join(tmp, "server.log");
  const log = fs.openSync(logFile, "a");
  const server = spawn("php", [
    "-S", `127.0.0.1:${port}`, "-t", docroot, path.join(__dirname, "router.php"),
  ], { stdio: ["ignore", log, log] });

  let browser = null;
  const stop = () => {
    try { if (browser) browser.close(); } catch (e) {}
    try { server.kill("SIGKILL"); } catch (e) {}
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
  };
  process.on("exit", stop);
  process.on("SIGINT", () => { stop(); process.exit(130); });
  process.on("SIGTERM", () => { stop(); process.exit(143); });

  /* Wait for it, and check what answers is ours. */
  let up = false;
  for (let i = 0; i < 100; i++) {
    try {
      const r = await fetch(`${origin}/api/vj-probe`);
      const body = await r.json().catch(() => null);
      if (body && body.code === "no_route") { up = true; break; }
    } catch (e) { /* not yet */ }
    await new Promise((r) => setTimeout(r, 100));
  }

  console.log("Visa Journey USA — the real pages, a real browser, the real API");
  console.log(`${SRC}, DEMO off, one origin on ${origin}\n`);

  group("Setup");
  ok("the server is up and it is this API", up);
  ok("no page is left on DEMO", demoLeft.length === 0, demoLeft.join(", "));
  if (!up) {
    console.log(fs.readFileSync(logFile, "utf8").slice(-800));
    process.exit(1);
  }

  try {
    browser = await chromium.launch({
      executablePath: fs.existsSync("/opt/pw-browsers/chromium/chrome-linux/chrome")
        ? "/opt/pw-browsers/chromium/chrome-linux/chrome" : undefined,
      args: ["--no-sandbox"],
    });
  } catch (e) {
    /* No browser binary. Same treatment as no module: see cannotRun. */
    stop();
    cannotRun("no browser binary was found for playwright to launch.\n"
      + "  (" + String(e && e.message ? e.message : e).split("\n")[0] + ")");
  }

  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const page = await ctx.newPage();

  /* A page error is a failure in its own right: the suites that run with DEMO
     on cannot see one that only happens on a real response. */
  const main = watch(page, origin);
  const pageErrors = main.errors;

  /* ---- the applicant ---------------------------------------------------- */

  group("Starting an application");

  await page.goto(`${origin}/application`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(600);

  const fallbackShown = await page.locator("#app-fallback").isVisible().catch(() => false);
  ok("the form mounted rather than showing the fallback", !fallbackShown);

  const bodyText = await page.locator("body").innerText();
  ok("the first screen is on the page", bodyText.length > 200);

  /* The security question and answer, which is what the resume flow needs. */
  const prompt = page.locator("#securityPrompt");
  const hasPrompt = await prompt.count() > 0;
  ok("the security question field is there", hasPrompt);

  if (hasPrompt) {
    await prompt.selectOption({ index: 1 }).catch(async () => {
      await prompt.fill("What was the name of your first pet?");
    });
    await page.fill("#securityAnswer", "Rex");
    const confirm = page.locator("#securityAnswerConfirm");
    if (await confirm.count() > 0) await page.fill("#securityAnswerConfirm", "Rex");

    await clickPrimary(page);
    await page.waitForTimeout(1200);
  }

  /* The reference screen comes next, and the reference has to be read HERE,
     before clicking on. Reading it later matched a ten-character run of
     capitals from whatever screen happened to be showing, and every check
     downstream then used the wrong string -- which looked like six unrelated
     failures rather than one ordering mistake. */
  const afterStart = await page.locator("body").innerText();
  const refMatch = afterStart.match(/\b([A-Z0-9]{10})\b/);
  ok("a reference number was issued and shown", refMatch !== null,
    afterStart.slice(0, 160).replace(/\n/g, " "));
  const reference = refMatch ? refMatch[1] : null;

  /* Then on past it, and fill in a name, so there is something for the
     manager to read later. Without it the detail view is empty and "the
     manager sees what the applicant typed" cannot be tested at all -- which
     is what the admin screen is for. */
  const wroteItDown = page.getByRole("button", { name: /written it down/i });
  if (await wroteItDown.count() > 0) {
    await wroteItDown.first().click();
    await page.waitForTimeout(1200);
  }

  const surnames = page.locator("#surnames");
  const haveName = await surnames.count() > 0;
  ok("the next screen asks for the applicant's name", haveName,
    (await page.locator("body").innerText()).slice(0, 160).replace(/\n/g, " "));

  if (haveName) {
    await surnames.fill("Ionescu");
    const given = page.locator("#givenNames");
    if (await given.count() > 0) await given.fill("Andrei");

    /* "Save and finish later" rather than Continue. Step 2 has a dozen
       required fields and completing it is not the point; saving is. And this
       is the button whose endpoint was wrong -- it posted to
       /api/application/resume-link while the API implemented
       /api/application/email-reference, so answers saved and the email never
       sent. Clicking it here exercises both halves: the PATCH that stores the
       answers, and the send that follows. */
    await page.getByRole("button", { name: /save and finish later/i }).first().click();
    await page.waitForTimeout(1600);

    const savedName = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      $st = $db->prepare('SELECT answers FROM applications WHERE reference = ?');
      $st->execute([${JSON.stringify(reference)}]);
      echo (string) $st->fetchColumn();
    `]).toString();
    ok("the answers reached the server as they were typed",
      savedName.includes("Ionescu"), savedName.slice(0, 200));

    /* And the applicant is told the truth about it.
     *
     * No email address has been entered at this point, so the resume link
     * cannot be sent -- but the PATCH returned 204 and every answer is in the
     * database, as the check above just proved. The page used to set its save
     * state to "error" here, which renders "Could not save. Check your
     * connection." in red, while the real explanation went into a message
     * that is only rendered on the screen where the reference number is
     * issued -- so from step two onwards the applicant saw the false message
     * and nothing else. Telling someone their visa application failed to save
     * when it saved is how you get them re-typing it or walking away. */
    const afterSave = (await page.locator("body").innerText()).replace(/\s+/g, " ");
    ok("a successful save is not reported as a failure",
      !/could not save/i.test(afterSave),
      afterSave.slice(0, 240));
    ok("and the applicant is told their answers are saved",
      /answers are saved/i.test(afterSave),
      afterSave.slice(0, 240));

    /* No email address was given, so the send cannot happen and the form says
       so. What it must NOT say is "request failed", and it must not claim
       something was sent. */
    const savedText = await page.locator("body").innerText();
    ok("save and finish later does not report a generic failure",
      !/request failed/i.test(savedText), savedText.slice(0, 240).replace(/\n/g, " "));
    ok("and does not claim an email was sent when none could be",
      !/sent to|we have emailed/i.test(savedText),
      savedText.slice(0, 240).replace(/\n/g, " "));
  }

  ok("no page errors so far", pageErrors.length === 0, pageErrors.slice(0, 2).join(" | "));

  /* ---- it reached the database ----------------------------------------- */

  group("It reached the API, not a stub");

  if (reference) {
    const stored = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
           PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
      $st = $db->prepare('SELECT reference, security_hash FROM applications WHERE reference = ?');
      $st->execute([${JSON.stringify(reference)}]);
      echo json_encode($st->fetch() ?: null);
    `]).toString();
    const row = JSON.parse(stored);
    ok("the application is in the database", row !== null);
    if (row) {
      ok("and the security answer was hashed, not stored",
        !String(row.security_hash).includes("Rex"));
    }
  }

  /* ---- coming back ----------------------------------------------------- */

  group("Coming back with the reference and the answer");

  if (reference) {
    const fresh = await ctx.newPage();
    const freshErrors = watch(fresh, origin).errors;
    await fresh.goto(`${origin}/resume`, { waitUntil: "domcontentloaded" });
    await fresh.waitForTimeout(500);

    const refField = fresh.locator("#vj-resume-id");
    ok("the resume page offers a reference field", await refField.count() > 0);

    if (await refField.count() > 0) {
      await refField.fill(reference);
      await clickPrimary(fresh);
      await fresh.waitForTimeout(1200);

      const askedText = await fresh.locator("body").innerText();
      ok("it asks the security question back",
        /first pet|security question/i.test(askedText),
        askedText.slice(0, 160).replace(/\n/g, " "));

      /* Assert the field is there rather than skipping if it is not. An
         earlier version of this file wrapped the next three checks in
         `if (count > 0)`, the selector matched nothing, and the checks simply
         did not run -- no failure, no mention, just two fewer lines of
         output than there should have been. A skipped assertion is worse
         than a failing one: nobody counts the passes. */
      const answerField = fresh.locator("#vj-resume-answer");
      const haveAnswerField = await answerField.count() > 0;
      ok("the security answer field is there", haveAnswerField);

      /* The wrong answer first: the message has to be the server's, which is
         the thing that regressed once already. */
      await answerField.fill("not the answer");
      await clickPrimary(fresh);
      await fresh.waitForTimeout(1300);
      const wrongText = await fresh.locator("body").innerText();
      ok("a wrong answer is refused with words, not \"request failed\"",
        !/request failed/i.test(wrongText) && /did not match/i.test(wrongText),
        wrongText.slice(0, 220).replace(/\n/g, " "));

      await fresh.locator("#vj-resume-answer").fill("Rex");
      await clickPrimary(fresh);
      await fresh.waitForTimeout(1600);
      const backText = await fresh.locator("body").innerText();
      ok("and the right answer lets the applicant back in",
        !/did not match/i.test(backText),
        backText.slice(0, 220).replace(/\n/g, " "));
      ok("with the answers that were typed earlier",
        /Ionescu/.test(backText) || /your application/i.test(backText),
        backText.slice(0, 220).replace(/\n/g, " "));
    }
    ok("no page errors on the resume page", freshErrors.length === 0,
      freshErrors.slice(0, 2).join(" | "));
    await fresh.close();
  }

  /* ---- a locked application, which is where the message mattered ------- */

  group("A locked application explains itself");

  /* This is the case the old code got wrong, and the reason the three checks
     above were not enough to catch it. The pages used to read exactly one
     status: 401 became "That answer did not match" and EVERYTHING ELSE became
     "request failed". A wrong answer is a 401, so it looked fine. A locked
     application answers 429 with the minutes remaining, and that is what came
     out as "request failed" -- the server's careful message thrown away at the
     last step, in the one situation where the applicant most needs to know
     what to do. So lock one and read the screen. */
  if (reference) {
    execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      $db->prepare('UPDATE applications SET failed_answers = 5, locked_at = ? WHERE reference = ?')
         ->execute([gmdate('Y-m-d H:i:s'), ${JSON.stringify(reference)}]);
    `]);

    const locked = await ctx.newPage();
    const lockedErrors = watch(locked, origin).errors;
    await locked.goto(`${origin}/resume`, { waitUntil: "domcontentloaded" });
    await locked.waitForTimeout(600);
    await locked.fill("#vj-resume-id", reference);
    await clickPrimary(locked);
    await locked.waitForTimeout(1300);

    /* A locked application answers lookup as "not found", on purpose, so the
       reference cannot be used to find out which ones exist. Either screen is
       acceptable; what is not acceptable is "request failed". */
    let lockedText = await locked.locator("body").innerText();
    const answerBox = locked.locator("#vj-resume-answer");
    if (await answerBox.count() > 0) {
      await answerBox.fill("Rex");
      await clickPrimary(locked);
      await locked.waitForTimeout(1300);
      lockedText = await locked.locator("body").innerText();
    }

    ok("a locked application never shows \"request failed\"",
      !/request failed/i.test(lockedText),
      lockedText.slice(0, 260).replace(/\n/g, " "));
    ok("it says something a person can act on",
      /locked|minutes|could not find|not find that reference/i.test(lockedText),
      lockedText.slice(0, 260).replace(/\n/g, " "));
    ok("no page errors while locked out", lockedErrors.length === 0,
      lockedErrors.slice(0, 2).join(" | "));
    await locked.close();

    execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      $db->exec('UPDATE applications SET failed_answers = 0, locked_at = NULL');
    `]);
  }

  /* ---- the manager ----------------------------------------------------- */

  group("The manager signs in with a password and a real code");

  const admin = await ctx.newPage();
  const adminErrors = watch(admin, origin).errors;

  await admin.goto(`${origin}/admin`, { waitUntil: "domcontentloaded" });
  await admin.waitForTimeout(600);

  ok("the admin screen asks for a sign in",
    /sign in/i.test(await admin.locator("body").innerText()));

  /* A wrong password first, to see the server's message reach the screen. */
  await admin.fill("#vja-email", adminEmail);
  await admin.fill("#vja-pass", "not the password");
  await admin.getByRole("button", { name: /sign in/i }).first().click();
  await admin.waitForTimeout(800);
  const badText = await admin.locator("body").innerText();
  ok("a wrong password says what happened, not \"request failed\"",
    !/request failed/i.test(badText) && /not recognised|not recognized/i.test(badText),
    badText.slice(0, 200).replace(/\n/g, " "));

  await admin.fill("#vja-email", adminEmail);
  await admin.fill("#vja-pass", adminPassword);
  await admin.getByRole("button", { name: /sign in/i }).first().click();
  await admin.waitForTimeout(900);

  const codeBox = admin.locator("#vja-code-input");
  ok("the second step asks for a code", await codeBox.count() > 0);

  if (await codeBox.count() > 0) {
    const pwField = await admin.locator("#vja-pass").count();
    ok("and the password field is gone by then", pwField === 0);

    await codeBox.fill("000000");
    await admin.getByRole("button", { name: /verify|continue|sign in/i }).first().click();
    await admin.waitForTimeout(800);
    const wrongCode = await admin.locator("body").innerText();
    ok("a wrong code is refused in words",
      !/request failed/i.test(wrongCode),
      wrongCode.slice(0, 160).replace(/\n/g, " "));

    await admin.locator("#vja-code-input").fill(totp(totpSecret, Math.floor(Date.now() / 30000)));
    await admin.getByRole("button", { name: /verify|continue|sign in/i }).first().click();
    await admin.waitForTimeout(1500);
  }

  group("And sees what the applicant typed");

  const listText = await admin.locator("body").innerText();
  ok("the application list loaded", !/sign in/i.test(listText) || listText.length > 400,
    listText.slice(0, 200).replace(/\n/g, " "));
  if (reference) {
    ok("the applicant's reference is on it", listText.includes(reference),
      listText.slice(0, 300).replace(/\n/g, " "));
  }

  ok("no page errors on the admin screen", adminErrors.length === 0,
    adminErrors.slice(0, 3).join(" | "));

  /* ---- what the managers actually do all day --------------------------- */

  group("Opening it, changing the status, adding a note");

  /* This is the part of the job the admin screen exists for: a manager reads
     every answer, talks to the applicant, and comes back to the same
     application repeatedly. Signing in and seeing a list proves none of that
     works. */
  const refLink = admin.locator("a.vja-ref").first();
  ok("the reference on the list is a link into the application",
    await refLink.count() > 0);

  await refLink.click();
  await admin.waitForTimeout(1300);
  const detail = await admin.locator("body").innerText();

  ok("the detail view opened", /Status|Step \d+ of 22/i.test(detail),
    detail.slice(0, 220).replace(/\n/g, " "));
  ok("and shows the answer the applicant typed", /Ionescu/.test(detail),
    detail.slice(0, 260).replace(/\n/g, " "));
  ok("but never the security answer", !/\bRex\b/.test(detail),
    detail.slice(0, 260).replace(/\n/g, " "));

  const statusSel = admin.locator("#vja-setstatus");
  ok("there is a status control", await statusSel.count() > 0);
  await statusSel.selectOption("In review");
  await admin.waitForTimeout(1200);

  const afterStatus = await admin.locator("body").innerText();
  ok("the status change reports back, not \"request failed\"",
    !/request failed/i.test(afterStatus), afterStatus.slice(0, 200).replace(/\n/g, " "));

  const statusInDb = execFileSync("php", ["-r", `
    $db = new PDO('sqlite:${dbFile}', null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $st = $db->prepare('SELECT status FROM applications WHERE reference = ?');
    $st->execute([${JSON.stringify(reference)}]);
    echo (string) $st->fetchColumn();
  `]).toString().trim();
  ok("and it reached the database", statusInDb === "In review", statusInDb);

  const noteBox = admin.locator("#vja-note");
  ok("there is a note box", await noteBox.count() > 0);
  await noteBox.fill("Called the applicant about the employer letter.");
  await admin.getByRole("button", { name: /add note/i }).first().click();
  await admin.waitForTimeout(1300);

  const afterNote = await admin.locator("body").innerText();
  ok("the note appears on screen",
    /employer letter/i.test(afterNote), afterNote.slice(0, 220).replace(/\n/g, " "));

  const noteCount = execFileSync("php", ["-r", `
    $db = new PDO('sqlite:${dbFile}', null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    echo (string) $db->query('SELECT COUNT(*) FROM application_notes')->fetchColumn();
  `]).toString().trim();
  ok("and it was stored", noteCount === "1", noteCount);

  /* A reload, because a manager comes back to the same application: anything
     held only in the page's memory would disappear here. */
  await admin.reload({ waitUntil: "domcontentloaded" });
  await admin.waitForTimeout(1500);
  const afterReload = await admin.locator("body").innerText();
  /* Assert on something only the signed-in view renders, and drop the
     "|| length > 400" that used to be here: the sign-in screen carries the
     whole second-factor explainer, so it comfortably exceeds 400 characters
     and that disjunct made the check pass whether or not the session
     survived. An audit found it passing with the feature broken. */
  ok("after a reload the manager is still signed in",
    !/Sign in/i.test(afterReload),
    afterReload.slice(0, 200).replace(/\n/g, " "));
  ok("and the page names who is signed in",
    /signed in as manager@example\.com/i.test(afterReload),
    afterReload.replace(/\s+/g, " ").slice(0, 200));
  ok("and the application it was looking at is still open, with its controls",
    await admin.locator("#vja-setstatus").count() > 0
    && await admin.locator("#vja-note").count() > 0);
  ok("and the sign out button is there",
    await admin.getByRole("button", { name: /sign out/i }).count() > 0);
  ok("and the new status survived it", /In review/i.test(afterReload),
    afterReload.slice(0, 260).replace(/\n/g, " "));

  group("The card: saved on the payment page, revealed once, then charged");

  /* The one path nothing else drives end to end: a real browser posting a card
     to POST /api/application/card with DEMO off, and the admin screen
     revealing it through the real route and recording the charge. */
  if (reference) {
    const pay = await ctx.newPage();
    const payErrors = watch(pay, origin).errors;
    await pay.goto(`${origin}/payment?ref=${encodeURIComponent(reference)}`,
                   { waitUntil: "domcontentloaded" });
    await pay.waitForSelector("#vjp-card-number", { timeout: 15000 });
    const appNo = (await pay.locator("#pay-appno").innerText().catch(() => "")).replace(/\s+/g, " ").trim();
    ok("the payment page shows Application Number with this application's reference",
      (await pay.locator("#pay-appno").isVisible()) && appNo === "Application Number: " + reference, appNo);
    ok("directly under the Your card details heading",
      await pay.evaluate(() => { const p = document.getElementById("pay-appno"); const h = p && p.previousElementSibling;
        return !!h && h.tagName === "H1" && /Your card details/.test(h.textContent); }));
    ok("the reference is bold monospace",
      await pay.evaluate(() => { const cs = getComputedStyle(document.getElementById("pay-ref"));
        return /monospace/.test(cs.fontFamily) && parseInt(cs.fontWeight, 10) >= 600; }));
    {
      const bare = await ctx.newPage();
      await bare.goto(`${origin}/payment`, { waitUntil: "domcontentloaded" });
      await bare.waitForSelector("#vjp-card-number", { timeout: 15000 });
      ok("opened with no application: no Application Number line, card form as before",
        !(await bare.locator("#pay-appno").isVisible()) && (await bare.locator("#pay-ref").innerText()) === "");
      await bare.close();
    }
    await pay.fill("#vjp-name-first", "Ana");
    await pay.fill("input[autocomplete=cc-family-name]", "Ionescu");
    await pay.fill("#vjp-card-number", "4242424242424242");
    await pay.selectOption("#vjp-exp-month", { index: 9 });
    await pay.locator("select[autocomplete=cc-exp-year]").selectOption({ index: 3 });
    ok("the card brand logos are inside the number field",
      await pay.locator(".vjp-numwrap .vjp-logos svg").count() === 4);
    await pay.fill("#vjp-cvv", "12");
    await pay.fill("#vjp-postal", "010101");
    await pay.getByRole("button", { name: /save my card/i }).first().click();
    await pay.waitForTimeout(600);
    ok("a 2 digit CVV is stopped in the browser",
      /3 digits on the back/.test(await pay.locator("body").innerText()));
    await pay.fill("#vjp-cvv", "737");
    await pay.getByRole("button", { name: /save my card/i }).first().click();
    await pay.waitForTimeout(1500);
    const payText = await pay.locator("body").innerText();
    ok("the payment page shows the thank-you screen", /Thank You! Your Payment Was Successful\./.test(payText),
      payText.slice(0, 240).replace(/\n/g, " "));
    ok("with the client's wording", /You're One Step Closer to Your U\.S\. Visa!/.test(payText) &&
      /What Happens Next\?/.test(payText) && /Questions\? We're Here to Help!/.test(payText) &&
      /Thank you for trusting VisaJourneyUSA\. We look forward to assisting you!/.test(payText));
    ok("the page head is hidden and no card field is left on the page",
      !(await pay.locator("#pay-head").isVisible()) && await pay.locator("#vjp-card-number, #vjp-cvv").count() === 0);
    ok("support team links to the support address",
      await pay.locator('.vj-thanks a[href="mailto:support@visajourneyusa.com"]', { hasText: "support team" }).count() === 1);
    ok("no page errors on the payment page", payErrors.length === 0,
      payErrors.slice(0, 2).join(" | "));
    const stored = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      $st = $db->prepare('SELECT a.card_last4, COUNT(v.id) FROM applications a
                           LEFT JOIN card_vault v ON v.application_id = a.id
                          WHERE a.reference = ? GROUP BY a.card_last4');
      $st->execute([${JSON.stringify(reference)}]);
      echo implode(',', $st->fetch(PDO::FETCH_NUM) ?: []);
    `]).toString().trim();
    ok("last four in the clear, one encrypted vault row", stored === "4242,1", stored);
    ok("and the number is not in the database file in the clear",
      !fs.readFileSync(dbFile).includes(Buffer.from("4242424242424242")));
    const cvvCols = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      echo (string) $db->query("SELECT COUNT(*) FROM card_vault WHERE cvv_ciphertext IS NOT NULL AND cvv_ciphertext <> '737' AND length(cvv_ciphertext) >= 40")->fetchColumn();
    `]).toString().trim();
    ok("the CVV is stored encrypted, in its own column", cvvCols === "1", cvvCols);
    await pay.close();

    await admin.reload({ waitUntil: "domcontentloaded" });
    await admin.waitForTimeout(1500);
    const masked = await admin.locator("body").innerText();
    ok("the admin sees the card masked", /4242/.test(masked) && !/4242 4242 4242 4242/.test(masked),
      masked.slice(0, 200).replace(/\n/g, " "));
    const revealBtn = admin.getByRole("button", { name: /show full number/i });
    ok("with a Show full number button", await revealBtn.count() > 0);
    if (await revealBtn.count() > 0) {
      await revealBtn.first().click();
      await admin.waitForTimeout(1200);
      const shown = await admin.locator("body").innerText();
      ok("pressing it shows the full number", /4242 4242 4242 4242/.test(shown),
        shown.slice(0, 260).replace(/\n/g, " "));
      ok("and the Activity list says so", /Viewed full card number/.test(shown));
      ok("the CVV shows on the same reveal", /Security code \(CVV\)\s*737/.test(shown),
        shown.replace(/\s+/g, " ").slice(0, 300));
      const logged = execFileSync("php", ["-r", `
        $db = new PDO('sqlite:${dbFile}', null, null,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        echo (string) $db->query("SELECT COUNT(*) FROM card_reveal_log WHERE outcome = 'allowed'")->fetchColumn();
      `]).toString().trim();
      ok("one allowed row in the reveal log", logged === "1", logged);
    }

    admin.once("dialog", (d) => d.accept());
    const markOpen = admin.getByRole("button", { name: /mark as charged/i });
    if (await markOpen.count() > 0) {
      await markOpen.first().click();
      await admin.waitForTimeout(300);
    }
    await admin.fill("#vja-mark-ref", "ch_browser_test");
    await admin.locator("form.vja-mark button[type=submit]").click();
    await admin.waitForTimeout(1500);
    const charged = await admin.locator("body").innerText();
    ok("recording the charge says the number is deleted",
      /deleted from our server/i.test(charged), charged.slice(0, 260).replace(/\n/g, " "));
    const left = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null,
          [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      echo (string) $db->query('SELECT COUNT(*) FROM card_vault')->fetchColumn() . ','
         . (string) $db->query('SELECT COUNT(*) FROM applications WHERE charged_on IS NOT NULL')->fetchColumn();
    `]).toString().trim();
    ok("the vault is empty and the application is paid", left === "0,1", left);
    ok("the activity says the CVV was wiped with the charge", /wiped the security code/i.test(charged),
      charged.replace(/\s+/g, " ").slice(0, 300));
    ok("no page errors on the admin screen during the card steps", adminErrors.length === 0,
      adminErrors.slice(0, 3).join(" | "));
  }

  group("Signing out");

  await admin.getByRole("button", { name: /sign out/i }).first().click();
  await admin.waitForTimeout(1200);
  ok("sign out returns to the sign in screen",
    /sign in/i.test(await admin.locator("body").innerText()));

  await admin.reload({ waitUntil: "domcontentloaded" });
  await admin.waitForTimeout(1200);
  ok("and a reload does not let the manager back in",
    /sign in/i.test(await admin.locator("body").innerText()));

  if (main.offsite.length) {
    console.log("  note  resources from other hosts did not load here, which is");
    console.log("        this container's network and not the site: "
      + [...new Set(main.offsite)].join(", "));
  }

  /* ---- the end --------------------------------------------------------- */

  const serverLog = fs.readFileSync(logFile, "utf8");
  const fatals = serverLog.split("\n").filter((l) =>
    /Fatal error|Parse error|Uncaught/i.test(l));
  group("The server log");
  ok("no fatals while the browser drove it", fatals.length === 0,
    fatals.slice(0, 3).join(" | "));
  ok("no CVV in the server log", !/cvv/i.test(serverLog));

  console.log("\n" + "=".repeat(62));
  console.log(`  ${pass} passed, ${fail} failed`);
  console.log("=".repeat(62));
  if (fail) {
    console.log("\nFailures:");
    for (const f of failures) console.log("  - " + f);
    console.log("\nLast of the server log:\n" + serverLog.slice(-1200));
  }
  stop();
  process.exit(fail ? 1 : 0);
}

main().catch((e) => {
  console.error("browser.js blew up: " + (e && e.stack ? e.stack : e));
  process.exit(1);
});
