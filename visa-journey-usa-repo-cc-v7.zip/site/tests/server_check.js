/* Fail once, with the command, when the page server is not running.
 *
 * The jsdom suites load each page with resources: 'usable', so jsdom fetches
 * site.js and visa-application-form.js over HTTP from BASE. With nothing
 * listening, those scripts never arrive, the form never mounts, and the suite
 * reports a couple of ordinary-looking assertion failures -- "form mounts",
 * "developer fallback stays hidden" -- out of a hundred and twenty passes.
 * Nothing in that output says the server is missing, and the two failures look
 * like a broken form, which is the opposite of what happened.
 *
 * Node has no synchronous HTTP, so the connect test runs in a short-lived
 * subprocess. No dependency, nothing to install, and it costs a few
 * milliseconds once per run.
 */
const { execFileSync } = require("child_process");

module.exports = function requireServer(base, suite, dirHint) {
  let url;
  try {
    url = new URL(base);
  } catch (e) {
    return; // not a URL we can test; let the suite run and fail on its own terms
  }
  const port = Number(url.port || (url.protocol === "https:" ? 443 : 80));
  const probe = `
    const net = require("net");
    const s = net.connect(${port}, ${JSON.stringify(url.hostname)});
    s.setTimeout(2000);
    s.on("connect", function () { s.destroy(); process.exit(0); });
    s.on("error", function () { process.exit(1); });
    s.on("timeout", function () { s.destroy(); process.exit(1); });
  `;
  try {
    execFileSync(process.execPath, ["-e", probe], { stdio: "ignore" });
    return;
  } catch (e) {
    /* fall through */
  }

  const dir = dirHint || "../src";
  console.log("");
  console.log(`  ${suite} needs a page server running at ${url.origin}.`);
  console.log("  Nothing is listening there. jsdom fetches each page's scripts");
  console.log("  over HTTP, so without it the form never mounts and you get a");
  console.log("  couple of failures that look like a broken form instead.");
  console.log("");
  console.log(`      python3 -m http.server ${port} --directory ${dir} &`);
  console.log("");
  console.log("  Then run this again. See site/tests/README.md.");
  process.exit(2);
};
