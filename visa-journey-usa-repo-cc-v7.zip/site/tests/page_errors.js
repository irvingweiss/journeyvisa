/* Do the pages put the API's own error message on screen?
 *
 *   node page_errors.js ../src/
 *   node page_errors.js ../deploy/
 *
 * The API answers every failure with { code, message }, and writes the message
 * for the person who will read it: "That photograph is larger than 2MB",
 * "this application is locked for 28 more minutes", "Too many attempts. Try
 * again in 15 minutes". All three pages used to throw that away and raise a
 * bare Error("request failed"), so none of it ever reached a screen.
 *
 * That went unnoticed because nothing tests this seam. The other suites run
 * the pages with DEMO on, so no request is ever made and no error body is ever
 * parsed; the API suite checks what the server sends, not what the page does
 * with it. It surfaced when the API started answering 429 for a locked
 * application where it had answered 401: resume.html had hard-coded "That
 * answer did not match" for 401 and "request failed" for everything else, so a
 * locked applicant went from a misleading message to a useless one.
 *
 * So this extracts each page's own failure() helper and runs it, the way
 * admin.js extracts and runs onSignIn.
 */

const fs = require('fs');
const path = require('path');

const DIR = process.argv[2] || '../src/';

let pass = 0, fail = 0;
const failures = [];

function ok(name, cond, detail) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else {
    fail++;
    failures.push(name + (detail ? ' -> ' + detail : ''));
    console.log('  FAIL  ' + name + (detail ? ' -> ' + detail : ''));
  }
}
function group(t) { console.log('\n' + t); }

/* A stand-in for fetch's Response: failure() only needs status and text(). */
function response(status, body) {
  return { status, ok: status >= 200 && status < 300, text: () => Promise.resolve(body) };
}

/** Pull the failure() function out of a page and make it callable. */
function failureFrom(html, file) {
  const start = html.indexOf('function failure(r) {');
  if (start === -1) return null;
  /* Walk the braces so the end of the function is found rather than guessed. */
  let depth = 0, i = html.indexOf('{', start), end = -1;
  for (; i < html.length; i++) {
    if (html[i] === '{') depth++;
    else if (html[i] === '}') {
      depth--;
      if (depth === 0) { end = i + 1; break; }
    }
  }
  if (end === -1) return null;
  const src = html.slice(start, end);
  // eslint-disable-next-line no-new-func
  return new Function(src + '; return failure;')();
}

const PAGES = ['application.html', 'resume.html', 'admin.html'];

(async function () {
  for (const page of PAGES) {
    const file = path.join(DIR, page);
    group(page);

    if (!fs.existsSync(file)) {
      ok('the page exists', false, file + ' not found');
      continue;
    }
    const html = fs.readFileSync(file, 'utf8');

    const failure = failureFrom(html, file);
    ok('it has a failure() helper', typeof failure === 'function');
    if (typeof failure !== 'function') continue;

    /* 1. The API's message, code and status all survive. */
    const body = JSON.stringify({
      code: 'locked',
      message: 'For your security this application is locked for 28 more minutes.',
      lockedForSeconds: 1680,
    });
    let err = null;
    try { await failure(response(429, body)); } catch (e) { err = e; }

    ok('a failed request rejects', err !== null);
    if (err) {
      ok('err.message is the API message, not a generic string',
        err.message === 'For your security this application is locked for 28 more minutes.',
        err.message);
      ok('err.userMessage carries it too, for the screens that read that',
        err.userMessage === err.message, String(err.userMessage));
      ok('err.code is the API code', err.code === 'locked', String(err.code));
      ok('err.status is the HTTP status', err.status === 429, String(err.status));
      ok('nothing says "request failed"', !/request failed/.test(err.message));
    }

    /* 2. A body that is not JSON must not throw a parse error of its own.
          A 502 from a proxy is an HTML page, and the applicant should still
          see something rather than the screen breaking. */
    let err2 = null;
    try { await failure(response(502, '<html><body>Bad Gateway</body></html>')); }
    catch (e) { err2 = e; }
    ok('a non-JSON body still rejects cleanly', err2 !== null && err2 instanceof Error);
    if (err2) {
      ok('and falls back to a plain message',
        err2.message === 'request failed', err2.message);
      ok('with the status kept', err2.status === 502, String(err2.status));
    }

    /* 3. An empty body, which is what a 500 with output buffering off can be. */
    let err3 = null;
    try { await failure(response(500, '')); } catch (e) { err3 = e; }
    ok('an empty body still rejects cleanly', err3 !== null && err3 instanceof Error);

    /* 4. The page must actually USE it. A helper nothing calls is decoration,
          and this is exactly the state the pages were in: the message was
          available and thrown away. */
    const callsIt = /if \(!r\.ok\) return failure\(r\);/.test(html);
    ok('the request helpers route failures through it', callsIt);

    /* 5. And no helper may still raise the generic error on a failed request.
          admin.html keeps one deliberate exception: a 401 or 403 on a read is
          "not signed in", which sends the manager back to the sign in screen
          rather than showing a message. */
    const stragglers = (html.match(/if \(!r\.ok\) throw new Error\(/g) || []).length;
    ok('no helper still throws a generic error instead', stragglers === 0,
      stragglers + ' left');
  }

  console.log('\n' + '='.repeat(60));
  console.log(`  ${pass} passed, ${fail} failed`);
  console.log('='.repeat(60));
  if (fail) {
    console.log('\nFailures:');
    for (const f of failures) console.log('  - ' + f);
  }
  process.exit(fail ? 1 : 0);
})();
