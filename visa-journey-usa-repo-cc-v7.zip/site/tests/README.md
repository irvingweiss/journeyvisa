# Tests

Runs the real pages in a headless DOM and asserts the behaviour, rather than
eyeballing it. Every bug fixed during the build has a test here, so a later change
that reintroduces one gets caught.

Two dependencies. Install them from this folder so the pinned versions are used,
and fetch the browser `browser.js` needs:

    npm install
    npx playwright install chromium

**If you forget to start a server, the suite tells you so.** Most of these need
one: the jsdom suites load each page's scripts over HTTP, and `crawl.py` and
`deploy_checks.py` request real URLs. With nothing listening they used to report
a handful of ordinary-looking assertion failures, or every page as unreachable,
and nothing in that output said the server was the problem. They now check for
it first and exit 2 with the exact command to run. `page_errors.js` needs no
server, because it calls each page's error handler directly rather than loading
the page.

That check lives in `server_check.js`, which is a helper rather than a suite and
produces no count of its own. A new jsdom suite should call it on the line after
it works out its own `BASE` and `DIR`, and in that order: an earlier version of
this passed `DIR` to it one line before `DIR` was declared, which `node --check`
accepts as valid syntax and which then crashes the suite on load.

`package.json` pins jsdom to 26.x deliberately. From jsdom 27 onward,
`element.querySelector('#someId')` resolves through the document's id map rather
than the element's own subtree, so a second element with that id anywhere in the
document makes a correctly scoped lookup return `null`. The suites mount the form
more than once per document, so on 27+ they would fail on code that works. The
harness now also keeps one mount live at a time (`host.js`), which makes the suites
pass on 29 as well, but the pin stays so a fresh checkout is not at the mercy of
the next change in that area.

## Run them

From this folder. Start with the two cheapest checks: the rebuild check catches a
build script quietly losing a page, and the link check catches a link going nowhere.
Neither needs a server or Node.

    # clean-room rebuild
    python3 rebuild_check.py

    # every link in all three builds
    python3 link_check.py deploy
    python3 link_check.py src
    python3 link_check.py preview

    # the source build
    python3 -m http.server 8899 --directory ../src &
    node suite.js ../src/
    kill %1

    # the deploy build, served with clean URLs the way Netlify does
    python3 serve_clean.py ../deploy &
    node suite.js ../deploy/ http://127.0.0.1:8898/
    python3 deploy_checks.py ../deploy
    python3 crawl.py
    kill %1

    # the draft cache and the reference email, both need the source build served
    python3 -m http.server 8899 --directory ../src &
    node draft.js ../src/
    node email.js ../src/
    node dates.js ../src/
    node persona.js ../src/
    node branches.js ../src/
    node scenarios.js ../src/
    kill %1

    # the admin screen
    python3 -m http.server 8899 --directory ../src &
    node admin.js ../src/
    kill %1

    # the single-file preview, which needs no server
    node single.js ../preview/visa-journey-usa.html

    # the API's error messages reaching the screen, no server needed
    node page_errors.js ../src/
    node page_errors.js ../deploy/

    # the whole thing in a real browser against the real API, DEMO off
    node browser.js ../deploy/
    node browser.js ../src/

## After deploying

Everything above tests the build. This one tests the server, which is a different
thing and the one that has actually gone wrong:

    python3 live_check.py https://www.visajourneyusa.com

## What each covers

- `link_check.py` resolves every `href` and `src` in a build, plus every in-page
  anchor, plus the navigation performed from inline scripts, which no crawl of
  href attributes would see. For `deploy` it works out which clean URLs Netlify
  will serve and checks against that, reads `netlify.toml` so a link that only
  works via a 301 is reported as such, and cross-checks the sitemap both ways: a
  listed URL that nothing serves, and a real page that is missing from it. For
  `preview` it checks every hash link against the router's own route list, and
  every route against the sections in the file. 582 links in the deploy build, 513
  in the source build, 60 in the preview.

- `crawl.py` requests every URL for real against `serve_clean.py`, starting at `/`
  and following links until it runs out of new ones. `link_check.py` reasons about
  paths; this one would catch a mistake in that reasoning. It also reports any page
  in the folder that nothing links to.

- `live_check.py` is the only one that runs against a deployed site. It requests
  every URL the folder should serve, compares the live build marker with
  `BUILD.txt`, checks that an unknown path answers 404 and not 200, checks the five
  security headers, checks that the old `.html` paths 301 to the clean ones, and
  follows the links on each live page. It exists because the build was correct while
  production was not: six pages were missing from the server and every page in the
  site linked to them. It is host-neutral, so it is also how you confirm a
  non-Netlify host picked up the config in `deploy/server-config/`.

  It also checks the **DEMO flags on the live site**, which nothing else could.
  A site serving fixture data looks entirely fine: every page renders, every
  link works, the admin screen signs in and lists applications. They are just
  invented, nothing reaches the API, and an applicant's answers are saved
  nowhere. `/payment` is expected to stay on DEMO until
  `POST /api/application/card` exists, so that one is reported as expected
  rather than wrong. It also reports whether the preview sign in is still in
  `admin.html`: its password is published in this repository on purpose, so
  while DEMO is on, anyone who finds `/admin` can sign in and browse what look
  like real applications.

- `rebuild_check.py` (109 checks) copies the package to a temp directory, deletes
  every generated file, runs all three build scripts, and asserts everything comes
  back byte-identical. It also parses the generated host configs in
  `deploy/server-config/`, since a config that does not parse takes a site down on
  reload rather than failing visibly at build time, and checks that each one sends
  `/index.html` to `/` rather than to `/index`. This one found two real bugs the day
  it was written and a third the day the host configs were added.

- `suite.js` (121 checks) the form's 22 steps and schema rules, typing and Tab and
  click behaviour, the spouse and photo steps, submit and payment handoff, surviving
  a refresh, the resume flow, the payment page, and every site page including the
  contact form.
- `deploy_checks.py` (83 checks) files present, internal links and asset paths,
  robots tags per page, sitemap contents, `netlify.toml`, and a real HTTP fetch of
  every public URL plus the 404, which must answer with a 404 status and not a 200.
- `draft.js` (17 checks) a refresh restores what was typed, and the fields that
  must never reach the browser (security answer, passport and ID numbers, the
  photograph) are absent from the stored draft.
- `email.js` (21 checks) the reference-number email is opt-in, validates the
  address, reports failures, and never puts the security answer in the payload.
- `dates.js` (28 checks) every date is a day / month / year control rather than a
  native picker, partial dates never reach the answer data, and impossible dates,
  silly years and future birth dates are all caught. Also covers the standalone year field.
- `branches.js` (24 checks) every answer that opens a follow-up page on the
  DS-160 actually opens one here: divorced, widowed, legally separated, and a
  company paying for the trip.
- `persona.js` (31 checks) walks a deliberately awkward applicant through the form:
  a dual Algerian and French national with accented and Arabic-script names, a
  previous refusal, conscript military service, an address with no state, a +213
  phone and a US contact in a territory. This is the suite that catches
  assumptions baked in by a US or western European author.
- `scenarios.js` (22 checks) three more awkward applicants: a single-name
  Indonesian worker applying from a third country with her employer paying, a
  six-year-old whose mother is doing the typing, and a stateless applicant on a
  travel document with no expiry date and no postal address.
- `admin.js` (211 checks) the admin screen: sign in, the list with its search
  and status filter, and the detail view. The detail checks are the ones worth
  keeping: that every question put to this applicant appears including the ones
  left blank, that questions the applicant never saw are left out rather than
  listed as unanswered, that the labels are the schema's own rather than a
  prettified key name, that the DS-160 country and occupation codes sit beside
  the answers, and that the security answer never reaches the page. It also
  checks the answers are read-only, since the applicant signed them.

  It also covers the card. On the admin side: that the number is masked until
  asked for, that a reveal shows it in fours in a monospace font, copies it
  without the spaces, and logs "Viewed full card number" each time, that it is
  wiped after 60 seconds and on Hide, navigation, sign out and print, that a
  number arriving on onGet is never drawn, and that a reveal answering after the
  admin has left is dropped. Then recording a charge: the processor reference
  is required, the date cannot be in the future, it asks first, the button
  disables on the press, and a paid application offers no way to charge or
  reveal again. An expired card is caught before anyone charges it, and a mount
  given onCharge still gets a working Charge button. On the card step (v5): that the
  copy the client removed is gone, the brand logos sit inside the number field,
  the order panel reads as approved with the MRV sentence last, Luhn, brand,
  expiry and the CVV (3 digits, 4 for Amex) are checked before anything is
  sent, the CVV goes as card.cvv and is cleared once saved, the reveal shows it,
  and nothing reaches localStorage or sessionStorage.

  And the single admin account. The preview checks a SHA-256 of the password
  against the hash in `admin.html`, and the password itself is in no file here,
  these tests included. jsdom has no WebCrypto, so each page is given Node's,
  with one seam: a fixed test-only input is answered with the stored hash, which
  stands in for "the compare matched". Every other input is hashed for real. So
  the suite checks that a wrong email is refused even with a matching password,
  that a wrong or empty password is refused, that both refusals read the same,
  that the password is hashed even when the email is wrong, that the right
  account signs in whatever the case of the email, that the bar then shows the
  account email, that notes are written by "Admin" and no demo record names a
  second person, that there is no "last opened by" column, that a page with no
  WebCrypto says why it cannot sign in, and that the production `onSignIn`
  posts to `/api/admin/session` and shows the server's message for a 401 and a
  429 lockout. It also checks that `admin.js` itself carries no account and no
  hash, and that the preview hash is marked for removal with the DEMO flag.

  Every content assertion reads the mount container, not `document.body`. A
  page's `body.textContent` includes the text of its `<script>` tags, and the
  demo applications live in one of those, so asserting against the body passes
  even when the page renders nothing at all. That mistake was in the first
  version of this suite.

- `single.js` (26 checks) the preview file is genuinely self-contained and every
  route, the form, payment and resume all work inside it.

- `browser.js` (51 checks) **the only suite that sees the whole thing
  working.** It starts the real API on a throwaway SQLite database, serves the
  pages and the API on one origin with `router.php`, turns every DEMO flag
  off, and drives Chromium through the journey a person actually takes: start
  an application, get a reference, come back with the reference and the
  security answer, then sign in to the admin screen with a password and a real
  TOTP code and find the applicant's reference on the list.

  It exists because the seam between the pages and the API has broken twice
  while every other suite was green. The jsdom suites run with DEMO on, so no
  request is ever made; the API suite drives the API directly, so it never
  asks what a page does with the answer. Both of those bugs are now covered
  here, and both were confirmed by putting them back and watching this fail:
  a page posting to an endpoint that does not exist, and a locked application
  showing "request failed" instead of the server's explanation.

  Note which case catches the second one. A wrong security answer is a 401 and
  the old code handled that status correctly, so testing only the wrong answer
  passes. It took a LOCKED application -- a 429 -- to show the bug, which is
  the general lesson: exercise the status the code does not special-case.

  It needs playwright and a browser binary. `npm install` in this folder brings
  playwright; the browser is a separate download that npm does not do:

      npx playwright install chromium

  Without both, this suite **exits 2 rather than 0**, because it used to exit 0
  with a friendly message -- and a silent skip of the only suite that covers
  the page-to-API seam reads exactly like a pass. Two bugs have shipped through
  that seam with every other suite green. Both reasons it cannot run go
  through the same path: no playwright module, and no browser binary. The
  second is the one that actually happens, because `npm install` brings the
  module and nothing downloads a browser for you; an earlier version of this
  only caught the first, so the opt-out below did nothing in the only case
  anyone would reach for it. If you are on a machine that
  genuinely has no browser, set `VJ_ALLOW_NO_BROWSER=1` to turn it back into a
  skip, and know that the seam is untested in that run.

  It is slower than the others. Run it before a handover, and after any change
  to a page's callbacks or to an endpoint's shape.

- `router.php` is not a test. It is the `php -S` router `browser.js` uses to
  serve the site and the API on ONE origin, which a browser test needs: the
  pages fetch relative paths, and two servers would make every request
  cross-origin, which the API refuses by design and which a browser would not
  send session cookies on. The real host configurations are in
  `deploy/server-config/`.

- `page_errors.js` (39 checks per directory) the API's own error message reaches
  the screen. The API answers every failure with `{ code, message }` and writes
  the message for the person reading it; all three pages used to throw that away
  and raise `Error("request failed")`, so none of it was ever shown. Nothing
  tested this seam: these suites run with DEMO on, so no request is made and no
  error body is parsed, and the API suite checks what the server sends rather
  than what the page does with it. It surfaced when the API started answering
  429 for a locked application where it had answered 401, and resume.html --
  which hard-coded one message for 401 and "request failed" for everything else
  -- went from misleading to useless. Run it against both `../src/` and
  `../deploy/`: it needs no server.

## Why the rebuild check exists

An edit to `build.py` silently deleted the generator for the two legal pages, and
nothing noticed for several rounds of changes, because stale copies of those pages
were sitting in `src/` and being copied through to `deploy/`. The site was correct
by accident. Anyone running `build.py` on a fresh checkout would have lost both
pages.

No test that runs against already-built output can catch that. Run this one after
any change to a build script.

## If a test fails

The name says what broke. The ones most likely to fail after a careless edit are
the input-behaviour checks in section 2 of `suite.js` and the button colour checks
in section 8. Both are guarding fixes explained in the main README under
"Two things not to undo".
