/* submit_real.js -- the whole form, Sign and submit, against the REAL API.
 *
 *   node submit_real.js [../deploy/]          desktop and iPhone viewport
 *
 * Why this exists (26 October 2026): on the live site every real submit
 * answered 401 no_session and nobody reached the payment page. The form sent
 * the answers to onSubmit without the applicationId, and the API finds the
 * application by that id. Every suite was green: the site suites run with
 * DEMO on, browser.js drives the real API but never presses Sign and submit,
 * and the test preview's mock API fell back to "the latest application" when
 * the id was missing. This walks all the steps with DEMO off against
 * api/index.php on sqlite, presses the button, and checks the applicant lands
 * on /payment?ref=<their reference> and the row is marked submitted.
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFileSync, spawn } = require("child_process");
const net = require("net");

const SRC = process.argv[2] || "../deploy/";
const ROOT = path.resolve(__dirname, "..", "..");

let pass = 0, fail = 0;
const failures = [];

function ok(name, cond, detail) {
  if (cond) { pass++; console.log("  PASS  " + name); }
  else {
    fail++;
    failures.push(name + (detail ? " -> " + detail : ""));
    console.log("  FAIL  " + name + (detail ? " -> " + detail : ""));
  }
}
function group(t) { console.log("\n" + t); }

/* Watch one page for errors that are the PAGE's fault.
 *
 * Three kinds of noise have to be filtered or this reports failures that are
 * not real:
 *
 *  - An uncaught exception is always real. Those are what this is for.
 *  - "Failed to load resource: ... 401" is Chromium narrating an HTTP status.
 *    This test deliberately sends a wrong password and a wrong code, so those
 *    are expected; the assertions check the statuses directly.
 *  - A request to another host failing is the environment, not the site. The
 *    pages load a webfont from Google, and the container this runs in has no
 *    route to it. Worth knowing, not worth failing: the page renders without
 *    it, which the assertions below prove.
 *  - net::ERR_ABORTED on a 204 from `php -S`. Established by measurement, not
 *    assumed: a PATCH that saves a step logs the response (204) and THEN a
 *    requestfailed with ERR_ABORTED for the same request, and an independent
 *    in-page `await fetch(...)` against the same route returns
 *    "RESOLVED status=204". So the write happened, the response arrived, and
 *    the promise the page awaits resolves normally -- the abort is the
 *    single-threaded development server closing the connection after a
 *    body-less response, and it does not occur under PHP-FPM, which is what
 *    this ships on. Narrow deliberately: ONLY an aborted request that already
 *    produced a response is forgiven, so a genuinely cancelled or
 *    never-answered request still fails. Chasing this down is what turned up
 *    the "Could not save" bug on a successful save, so it was worth not
 *    silencing blindly.
 */
function watch(page, origin) {
  const errors = [];
  const offsite = [];
  const answered = new Set();
  page.on("pageerror", (e) => errors.push("uncaught: " + String(e.message)));
  page.on("console", (m) => {
    if (m.type() !== "error") return;
    if (/Failed to load resource/i.test(m.text())) return;
    errors.push("console: " + m.text());
  });
  page.on("response", (r) => {
    if (r.status() === 204) answered.add(r.request());
  });
  page.on("requestfailed", (r) => {
    const url = r.url();
    if (!url.startsWith(origin)) {
      offsite.push(url.replace(/\?.*$/, ""));
      return;
    }
    const why = (r.failure() || {}).errorText || "";
    if (why === "net::ERR_ABORTED" && answered.has(r)) return;
    errors.push("request failed: " + url + " " + why);
  });
  return { errors, offsite };
}

/* The form's own primary-action button. Its label changes from step to step
   ("Create my application", "Continue", "Sign and submit application"), so match the
   class the form puts on it rather than guessing words. */
async function clickPrimary(page, timeout = 15000) {
  const btn = page.locator("button.vj-btn.vj-primary:visible").last();
  await btn.waitFor({ state: "visible", timeout });
  await btn.click();
}

/* ---- TOTP, so the admin sign in can be completed for real --------------- */

function base32Decode(s) {
  const A = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = "";
  for (const ch of s.replace(/=+$/, "").toUpperCase()) {
    const i = A.indexOf(ch);
    if (i < 0) continue;
    bits += i.toString(2).padStart(5, "0");
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) {
    bytes.push(parseInt(bits.slice(i, i + 8), 2));
  }
  return Buffer.from(bytes);
}

function totp(secret, step) {
  const counter = Buffer.alloc(8);
  counter.writeUInt32BE(Math.floor(step / 0x100000000), 0);
  counter.writeUInt32BE(step % 0x100000000, 4);
  const h = crypto.createHmac("sha1", base32Decode(secret)).update(counter).digest();
  const off = h[h.length - 1] & 0x0f;
  const bin = ((h[off] & 0x7f) << 24) | (h[off + 1] << 16)
            | (h[off + 2] << 8) | h[off + 3];
  return String(bin % 1000000).padStart(6, "0");
}

/* ---- a free port, by connecting rather than only binding ---------------- */

function freePort(from = 9500) {
  for (let p = from; p < from + 400; p++) {
    try {
      const s = net.createServer();
      let taken = false;
      s.on("error", () => { taken = true; });
      s.listen(p, "127.0.0.1");
      s.close();
      if (!taken) return p;
    } catch (e) { /* next */ }
  }
  throw new Error("no free port");
}

/* ---- set the whole thing up in a temp directory ------------------------- */

function sqliteSchema(mysql) {
  const kept = mysql.split("\n").filter((l) => !/^\s*(INDEX|KEY|UNIQUE KEY)\s/i.test(l));
  let s = kept.join("\n");
  s = s.replace(/BIGINT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY/gi,
                "INTEGER PRIMARY KEY AUTOINCREMENT");
  s = s.replace(/\)\s*ENGINE=\w+\s+DEFAULT\s+CHARSET=\w+\s*;/gi, ");");
  s = s.replace(/\bLONGTEXT\b/gi, "TEXT");
  s = s.replace(/\bVARCHAR\(\d+\)/gi, "TEXT");
  s = s.replace(/\bTINYINT\(1\)/gi, "INTEGER");
  s = s.replace(/\bDECIMAL\(\d+,\d+\)/gi, "REAL");
  s = s.replace(/\bDATETIME\b/gi, "TEXT");
  s = s.replace(/\bDATE\b/gi, "TEXT");
  s = s.replace(/,(\s*\))/g, "$1");
  /* The append-only triggers on card_reveal_log: MySQL's one-statement
     SIGNAL body becomes SQLite's RAISE inside BEGIN ... END, the same
     translation tests/api_test.php makes. */
  s = s.replace(/FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = ('[^']*');/gi,
                "FOR EACH ROW BEGIN SELECT RAISE(ABORT, $1); END;");
  return s;
}

/* Why this exits non-zero rather than skipping.
 *
 * It used to print a friendly line and exit 0 when playwright was missing,
 * which is the same shape as a gate that passes by checking nothing -- and
 * this is the one suite that drives the pages and the API together with DEMO
 * off, the seam where two bugs have shipped with every other suite green.
 *
 * Both reasons it cannot run come through here. The first version only caught
 * a missing MODULE, and since package.json now brings playwright, the case
 * that actually happens is a missing BROWSER BINARY: npm does not download
 * one, `npx playwright install chromium` does. That threw from launch() and
 * landed in the generic handler, so the documented VJ_ALLOW_NO_BROWSER opt-out
 * did nothing in the only situation anyone would reach for it. An audit found
 * that by running it. */
function cannotRun(reason) {
  console.log("");
  console.log("  browser.js DID NOT RUN: " + reason);
  console.log("  This is the only suite that drives the pages and the API");
  console.log("  together with DEMO off. Treat a run without it as a run");
  console.log("  with the page-to-API seam untested.");
  console.log("");
  console.log("    cd site/tests && npm install");
  console.log("    npx playwright install chromium");
  console.log("");
  if (process.env.VJ_ALLOW_NO_BROWSER === "1") {
    console.log("  VJ_ALLOW_NO_BROWSER=1 is set, so this is not a failure.");
    process.exit(0);
  }
  console.log("  Set VJ_ALLOW_NO_BROWSER=1 to make this a skip instead.");
  process.exit(2);
}


const TEXT = { contactSurnames: "PATEL", contactGivenNames: "MEERA", contactOrganization: "ACME TRADING INC", contactPhone: "2125551234", contactStreet1: "200 PARK AVENUE", contactCity: "NEW YORK", contactEmail: "meera.patel@example.com", nationalId: "ABCPS1234K", stateOfBirth: "MAHARASHTRA", surnames: "SHARMA", givenNames: "RAVI KUMAR", cityOfBirth: "PUNE", usStreet: "350 FIFTH AVENUE", usCity: "NEW YORK",
  usZip: "10118", arrivalCity: "NEW YORK", departureCity: "NEW YORK", location: "NEW YORK CITY", email: "ravi.sharma@example.com", securityAnswer: "Bruno", securityAnswerConfirm: "Bruno" };
function textFor(id, type, label) {
  if (TEXT[id]) return TEXT[id];
  const k = (id + " " + label).toLowerCase();
  if (type === "email" || /email/.test(k)) return "ravi.sharma@example.com";
  if (type === "tel" || /phone|tel\b/.test(k)) return "+91 98765 43210";
  if (/passport.*(number|no)|passportnumber/.test(k)) return "Z1234567";
  if (/zip/.test(k)) return "10001";
  if (/postal/.test(k)) return "411001";
  if (/street|address/.test(k)) return "12 MG ROAD";
  if (/city|town/.test(k)) return "PUNE";
  if (/surname/.test(k)) return "SHARMA";
  if (/given/.test(k)) return "ANITA";
  if (/name/.test(k)) return "INFOSYS LIMITED";
  if (/salary|income/.test(k)) return "1200000";
  if (/duties|describe|explain|details|reason/.test(k)) return "Software engineer working on banking systems.";
  return "TEST";
}
function dateFor(id, label) {
  const k = (id + " " + label).toLowerCase();
  if (/dob|birth/.test(k)) return "1988-04-12";
  if (/expir/.test(k)) return "2032-01-15";
  if (/depart|leav|return/.test(k)) return "2027-03-24";
  if (/arriv|intend|travel/.test(k)) return "2027-03-10";
  if (/issu/.test(k)) return "2022-01-15";
  return "2018-06-01";
}
const SELECT = { securityPrompt: 2, sex: "Male", maritalStatus: "Single", countryOfBirth: "INDIA", nationality: "INDIA", usState: "New York", payer: "Myself" };

async function fillStep(page, root) {
  const tried = new Set();
  for (let pass = 0; pass < 120; pass++) {
    const list = await page.$$eval(root + " input, " + root + " select, " + root + " textarea", els => els.map((e, i) => {
      const lab = e.id ? document.querySelector('label[for="' + e.id + '"]') : null;
      const fld = e.closest(".vj-field"); const dg = e.closest(".vj-date");
      let checkedGroup = false;
      if (e.type === "radio") checkedGroup = !!document.querySelector('input[type=radio][name="' + e.name + '"]:checked');
      return { i, tag: e.tagName.toLowerCase(), type: e.type, id: e.id, name: e.name, value: e.value, checked: e.checked, checkedGroup,
        cls: e.className, dateId: dg ? (dg.querySelector(".vj-date-day") || {}).id || "" : null,
        label: (lab ? lab.textContent : (fld ? fld.textContent.slice(0, 80) : "")).trim(),
        disabled: e.disabled, visible: !!(e.offsetParent || e.getClientRects().length) }; }));
    const key = f => (f.id || f.name || f.label) + "|" + f.type + "|" + f.cls + "|" + f.i;
    const ids = new Map(list.map(x => [x.id, x]));
    const naOf = id => ids.get(id + "__na") || ids.get(id.replace(/\d+$/, "") + "__na");
    const baseFilled = naId => { const b = naId.replace(/__na$/, ""); const x = ids.get(b) || ids.get(b + "1"); return x && x.value; };
    const KEEP = /^(nationalId|stateOfBirth)$/;
    const f = list.find(f => !f.disabled && !tried.has(key(f)) && (f.visible || f.type === "file" || f.type === "radio") && (
      (f.tag === "select" && !f.value) ||
      (f.type === "radio" && !f.checkedGroup) ||
      (f.type === "checkbox" && !f.checked && /__na$/.test(f.id) && !baseFilled(f.id)) ||
      (f.type === "checkbox" && !f.checked && !/__na|__unknown|none/i.test(f.name + f.id) && /certify|agree|confirm|declar|true|accurate/i.test(f.name + f.id + f.label)) ||
      (f.type === "file" && !/photoStored/.test("")) ||
      (["text", "email", "tel", "number", "date", "search", "textarea"].includes(f.tag === "textarea" ? "textarea" : f.type) && !f.value && !(naOf(f.id) && !KEEP.test(f.id) && !TEXT[f.id]))));
    if (!f) return;
    tried.add(key(f));
    const h = page.locator(root + " input, " + root + " select, " + root + " textarea").nth(f.i);
    try {
      if (f.dateId !== null && f.tag === "select") {
        const [Y, M, D] = dateFor(f.dateId, f.label).split("-");
        const v = /day/.test(f.cls) ? D : /month/.test(f.cls) ? M : Y;
        await h.selectOption(v);
      } else if (f.dateId !== null) {
        await h.fill(dateFor(f.dateId, f.label).slice(0, 4));
      } else if (f.tag === "select") {
        const want = SELECT[f.id] !== undefined ? SELECT[f.id] : (/country|nationality/i.test(f.id + f.label) ? "INDIA" : null);
        if (typeof want === "number") await h.selectOption({ index: want });
        else if (want) { try { await h.selectOption({ label: want }, { timeout: 3000 }); } catch (e) { await h.selectOption({ index: 1 }); } }
        else {
          const opts = await h.locator("option").allTextContents();
          let i = opts.findIndex((o, j) => j > 0 && /^(no|none|myself|single|self)/i.test(o));
          await h.selectOption({ index: i > 0 ? i : 1 });
        }
      } else if (f.type === "radio") {
        const prefYes = /specificPlans/.test(f.name);
        const want = prefYes ? "Yes" : "No";
        const group = list.filter(x => x.type === "radio" && x.name === f.name);
        const pick = group.find(x => x.value === want) || group[0];
        await page.locator(root + ' input[type=radio][name="' + f.name + '"][value="' + pick.value + '"]').first().check({ force: true, timeout: 4000 });
      } else if (f.type === "checkbox") {
        await h.check({ force: true });
      } else if (f.type === "file") {
        await h.setInputFiles(process.env.PHOTO); await page.waitForTimeout(1500);
      } else if (f.type === "date") {
        await h.fill(dateFor(f.id, f.label));
      } else if (f.type === "number") {
        await h.fill(/stay/i.test(f.id) ? "14" : "1");
      } else {
        await h.fill(textFor(f.id, f.type, f.label));
      }
    } catch (e) { console.log("    fill problem", f.id || f.name, f.type, String(e).split("\n")[0]); }
    await page.waitForTimeout(25);
  }
}

async function main() {
  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch (e) {
    cannotRun("playwright is not installed here.");
  }

  const tmp = fs.mkdtempSync("/tmp/vj-browser-");
  const docroot = path.join(tmp, "www");
  fs.mkdirSync(docroot, { recursive: true });

  /* The site, with DEMO turned off -- which is the whole point. */
  const siteDir = path.resolve(__dirname, SRC);
  for (const f of fs.readdirSync(siteDir)) {
    const from = path.join(siteDir, f);
    if (!fs.statSync(from).isFile()) continue;
    let body = fs.readFileSync(from);
    if (/\.(html|js)$/.test(f)) {
      body = Buffer.from(
        body.toString("utf8").replace(/var DEMO = true;/g, "var DEMO = false;")
      );
    }
    fs.writeFileSync(path.join(docroot, f), body);
  }
  const demoLeft = fs.readdirSync(docroot)
    .filter((f) => /\.(html|js)$/.test(f))
    .filter((f) => /var DEMO = true;/.test(
      fs.readFileSync(path.join(docroot, f), "utf8")));

  /* The API, beside it, so everything is one origin. */
  execFileSync("cp", ["-R", path.join(ROOT, "api"), path.join(docroot, "api")]);

  const dbFile = path.join(tmp, "t.sqlite");
  const photoDir = path.join(tmp, "photos");
  fs.mkdirSync(photoDir);

  const port = freePort();
  const origin = `http://127.0.0.1:${port}`;
  const adminEmail = "manager@example.com";
  const adminPassword = "correct horse battery staple";

  /* The hash and the TOTP secret come from the shipped code, not from a
     reimplementation of it here. */
  const adminHash = execFileSync("php", ["-r",
    `echo password_hash(${JSON.stringify(adminPassword)}, PASSWORD_BCRYPT, ['cost' => 4]);`
  ]).toString();
  const totpSecret = execFileSync("php", ["-r",
    `require ${JSON.stringify(path.join(ROOT, "api/lib/Totp.php"))}; echo Totp::generateSecret();`
  ]).toString().trim();

  fs.writeFileSync(path.join(docroot, "api", "config.php"), `<?php
return [
    'dsn'      => 'sqlite:${dbFile}',
    'db_user'  => null,
    'db_pass'  => null,
    'admin_email'         => '${adminEmail}',
    'admin_password_hash' => '${adminHash}',
    'totp_secret'         => '${totpSecret}',
    'admin_fail_limit'   => 5,
    'admin_fail_window'  => 900,
    'admin_lockout'      => 900,
    'resume_fail_limit'  => 5,
    'resume_lockout'     => 1800,
    'resume_rate_limit'  => 50,
    'resume_rate_window' => 600,
    'lookup_rate_limit'  => 50,
    'lookup_rate_window' => 600,
    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,
    'photo_dir' => '${photoDir}',
    'service_fee' => 185,
    'currency'    => 'USD',
    'support_email' => 'support@example.com',
    'allowed_origins' => ['${origin}'],
    'secure_cookies' => false,
    'card_key' => '${crypto.randomBytes(32).toString("base64")}',
];
`);

  execFileSync("php", ["-r", `
    $db = new PDO('sqlite:${dbFile}', null, null,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $db->exec(file_get_contents('php://stdin'));
  `], { input: sqliteSchema(fs.readFileSync(path.join(ROOT, "schema.mysql.sql"), "utf8")) });

  const logFile = path.join(tmp, "server.log");
  const log = fs.openSync(logFile, "a");
  const server = spawn("php", [
    "-S", `127.0.0.1:${port}`, "-t", docroot, path.join(__dirname, "router.php"),
  ], { stdio: ["ignore", log, log] });

  let browser = null;
  const stop = () => {
    try { if (browser) browser.close(); } catch (e) {}
    try { server.kill("SIGKILL"); } catch (e) {}
    try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
  };
  process.on("exit", stop);
  process.on("SIGINT", () => { stop(); process.exit(130); });
  process.on("SIGTERM", () => { stop(); process.exit(143); });

  /* Wait for it, and check what answers is ours. */
  let up = false;
  for (let i = 0; i < 100; i++) {
    try {
      const r = await fetch(`${origin}/api/vj-probe`);
      const body = await r.json().catch(() => null);
      if (body && body.code === "no_route") { up = true; break; }
    } catch (e) { /* not yet */ }
    await new Promise((r) => setTimeout(r, 100));
  }

  console.log("Visa Journey USA — the real pages, a real browser, the real API");
  console.log(`${SRC}, DEMO off, one origin on ${origin}\n`);

  group("Setup");
  ok("the server is up and it is this API", up);
  ok("no page is left on DEMO", demoLeft.length === 0, demoLeft.join(", "));
  if (!up) {
    console.log(fs.readFileSync(logFile, "utf8").slice(-800));
    process.exit(1);
  }

  try {
    browser = await chromium.launch({
      executablePath: fs.existsSync("/opt/pw-browsers/chromium/chrome-linux/chrome")
        ? "/opt/pw-browsers/chromium/chrome-linux/chrome" : undefined,
      args: ["--no-sandbox"],
    });
  } catch (e) {
    /* No browser binary. Same treatment as no module: see cannotRun. */
    stop();
    cannotRun("no browser binary was found for playwright to launch.\n"
      + "  (" + String(e && e.message ? e.message : e).split("\n")[0] + ")");
  }


  const { devices } = require("playwright");
  const photo = path.join(tmp, "photo.jpg");
  execFileSync("python3", ["-c", "from PIL import Image; Image.new('RGB',(600,600),(200,210,220)).save(" + JSON.stringify(photo) + ", quality=80)"]);
  process.env.PHOTO = photo;
  const serverLog = () => fs.readFileSync(logFile, "utf8");

  for (const MOBILE of [false, true]) {
    group(MOBILE ? "iPhone 13 viewport" : "Desktop 1280x900");
    const ctx = await browser.newContext(MOBILE ? { ...devices["iPhone 13"] } : { viewport: { width: 1280, height: 900 } });
    const page = await ctx.newPage();
    const w = watch(page, origin);
    page.on("dialog", (d) => d.accept());
    const submits = [];
    page.on("response", async (r) => {
      if (/\/api\/application\/submit$/.test(r.url())) {
        let b = ""; try { b = await r.text(); } catch (e) {}
        let sent = {}; try { sent = JSON.parse(r.request().postData() || "{}"); } catch (e) {}
        submits.push({ status: r.status(), body: b, applicationId: sent.applicationId });
      }
    });
    await page.goto(`${origin}/application`, { waitUntil: "domcontentloaded" });
    await page.waitForTimeout(600);
    let reference = null, guard = 0, last = "", same = 0, sawCouldNotSave = "", signStepSeen = false, signStepWarn = "";
    while (guard++ < 80) {
      if (/\/payment$/.test(page.url().split("?")[0])) break;
      const refEl = (await page.locator(".vj-bar .vj-ref").first().innerText().catch(() => "")).trim();
      if (/^[A-Z0-9]{10}$/.test(refEl)) reference = refEl;
      if (!reference) { const m = (await page.locator("main").innerText()).match(/\b([A-HJ-NP-Z2-9]{10})\b/); if (m) reference = m[1]; }
      const written = page.getByRole("button", { name: /written it down/i });
      if (await written.count()) { await written.first().click(); await page.waitForTimeout(500); continue; }
      await fillStep(page, "main");
      const step = ((await page.locator("main").innerText()).match(/Step \d+ of \d+: [^\n]+/) || [""])[0];
      if (step === last) same++; else { same = 0; last = step; }
      if (same >= 3) { console.log("    stuck on " + step); break; }
      const cont = page.locator("main button.vj-primary:visible").last();
      if (!(await cont.count())) { await page.waitForTimeout(500); continue; }
      if (/Sign and submit application/.test(await cont.innerText().catch(() => ""))) {
        signStepSeen = true;
        const t = await page.locator("main").innerText();
        if (/not the DS-160 signature/i.test(t) || await page.locator("main .vj-warnbox").count()) signStepWarn = "yellow box present";
      }
      await cont.evaluate((e) => e.scrollIntoView({ block: "center" }));
      await cont.click({ timeout: 5000 }).catch(() => cont.dispatchEvent("click"));
      await page.waitForTimeout(900);
      const bar = await page.locator(".vj-bar").first().innerText().catch(() => "");
      if (/Could not save/.test(bar) && !sawCouldNotSave) sawCouldNotSave = step;
    }
    await page.waitForSelector("#vjp-card-number", { timeout: 10000 }).catch(() => {});
    ok("a reference was issued", !!reference, reference);
    ok("the sign step was reached and has no yellow DS-160 box", signStepSeen && !signStepWarn, signStepWarn || "sign step not reached");
    ok("Sign and submit was pressed once and the API accepted it",
      submits.length === 1 && submits[0].status === 200, JSON.stringify(submits).slice(0, 300));
    ok("the submit body carried the applicationId", submits.length > 0 && submits[0].applicationId === reference, submits[0] && submits[0].applicationId);
    ok("never showed Could not save", !sawCouldNotSave, sawCouldNotSave);
    ok("landed on /payment?ref=<reference>", /\/payment$/.test(page.url().split("?")[0]) && page.url().includes("ref=" + reference), page.url());
    ok("Application Number shows the reference",
      ((await page.locator("#pay-appno").innerText().catch(() => "")).replace(/\s+/g, " ").trim()) === "Application Number: " + reference);
    const row = execFileSync("php", ["-r", `
      $db = new PDO('sqlite:${dbFile}', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
      $st = $db->prepare('SELECT status, submitted_at, answers FROM applications WHERE reference = ?');
      $st->execute([${JSON.stringify(reference || "")}]);
      $r = $st->fetch(PDO::FETCH_ASSOC);
      $a = $r ? (json_decode($r['answers'], true) ?: []) : [];
      echo json_encode($r ? ['status' => $r['status'], 'submitted' => !empty($r['submitted_at']), 'idInAnswers' => array_key_exists('applicationId', $a), 'photo' => !empty($a['photoStored'])] : null);
    `]).toString();
    const dbRow = JSON.parse(row || "null") || {};
    ok("the row is marked submitted (status New, submitted_at set)", dbRow.status === "New" && dbRow.submitted, row);
    ok("applicationId is not stored inside the answers", dbRow.idInAnswers === false, row);
    ok("the photograph was stored", dbRow.photo === true, row);
    if (MOBILE) { const ov = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok("payment page: no sideways overflow", ov <= 1, ov); }
    ok("no page errors", w.errors.length === 0, w.errors.join(" | "));
    if (process.env.SHOTS) await page.screenshot({ path: path.join(process.env.SHOTS, (MOBILE ? "m" : "d") + "-real-payment.png") });
    await ctx.close();
  }

  console.log("\n" + "=".repeat(62));
  console.log(`submit_real: ${pass} passed, ${fail} failed`);
  if (fail) { console.log("\nFailures:"); for (const f of failures) console.log("  - " + f); console.log("\nServer log:\n" + serverLog().slice(-1200)); }
  stop();
  process.exit(fail ? 1 : 0);
}

main().catch((e) => { console.error("submit_real.js blew up: " + (e && e.stack ? e.stack : e)); process.exit(1); });
