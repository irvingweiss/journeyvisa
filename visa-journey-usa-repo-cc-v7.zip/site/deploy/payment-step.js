/* =====================================================================
   Visa Journey USA: payment step (vanilla JavaScript)
   =====================================================================

   The card step of the application: card details on the left, the order
   summary on the right. The card is saved, encrypted, by the server, and the
   fee is charged later by hand from the admin on a processor this site is
   not connected to.

   WHAT TO KNOW BEFORE EDITING

   1. THIS IS THE ONLY PAYMENT PAGE.
      Version 5 (October 2026) removed the other two ways this widget could
      take a card: the hosted redirect to a payment provider ("Pay $185 and
      Submit") and the Stripe Elements mount points. Card capture is the only
      mode. The old hostedRedirect, mountCardFields, onPay, chargeLater and
      collectCard options are ignored if passed.

   2. THE CARD DETAILS ARE TAKEN ON THIS PAGE, WHICH MEANS PCI SAQ D.
      The fields are plain inputs and the details go to your server through
      onSaveCard. That puts the whole site in PCI SAQ D: quarterly ASV scans,
      encryption with real key management, access logging, formal policies,
      annual validation. Read "Storing full card numbers" in README.md and
      DEVELOPER-INSTRUCTIONS.md before changing the server end.

   3. THE SECURITY CODE (CVV).
      The client asked for it (October 2026), so the processor can be given
      it at charge time. PCI DSS forbids keeping it after the card has been
      authorised, even encrypted. So the server encrypts it on its own,
      shows it only on the admin's one-time reveal beside the card, and wipes
      it automatically when the admin marks the application charged, and in
      the retention purge. It is never logged. Keep it that way.

      Card data lives in this function's memory and nowhere else. It is never
      written to localStorage or sessionStorage, never logged, and the number
      and code are wiped from memory once the server has accepted them.

   4. THE BUTTON DOES NOT SAY "OBTAIN YOUR VISA NOW".
      You prepare applications. A consular officer decides the outcome.

   5. NO VERISIGN OR "GUARANTEED SAFE CHECKOUT" BADGES.
      That seal is no longer issued, and the others had no certifying body
      behind them. Pass `sealHtml` to drop in a real seal your actual
      provider issues to you.

   6. THE CARD BRAND LOGOS AND THE ORDER IMAGE ARE INLINE SVG IN THIS FILE.
      No image is fetched from anywhere. The brand marks are the simple,
      public-domain (CC0) marks from the Simple Icons set, drawn on card
      shaped badges; the names and marks belong to Visa, Mastercard, American
      Express and Discover. Pass `brandLogos: { Visa: "url", ... }` to use
      your own image files instead.

   USAGE

     VisaJourneyPayment.mount(document.getElementById("payment"), {
       applicationId: "AB3K9QRTVX",
       serviceFee: 185,          // our fee, shown as Service Fee and Total
       governmentFee: 185,       // the MRV fee, named in the panel's last line
       currency: "USD",
       supportEmail: "support@visajourneyusa.com",
       onBack: () => { ... },    // "Edit" and "Back to review"
       onSaveCard: async ({ applicationId, card }) => { ... },
     });

   onSaveCard receives

       { applicationId, nameOnCard,
         card: { name, number, cvv, expMonth, expYear, postal, brand, last4 } }

   number is digits only, already Luhn-checked. cvv is 3 digits, or 4 for
   American Express. expMonth is 1-12, expYear is four digits, postal may be
   empty. brand is "Visa", "Mastercard", "Discover" or "Amex". Reject the
   promise to show an error; set err.userMessage to choose the wording.
   Resolve it once the server has the card; what the page shows next is up
   to the caller (payment.html shows the thank-you screen).
   ===================================================================== */

var VisaJourneyPayment = (function () {
  "use strict";

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k === "html") node.innerHTML = v;
      else if (k.slice(0, 2) === "on") node.addEventListener(k.slice(2).toLowerCase(), v);
      else node.setAttribute(k, v === true ? "" : v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  var STYLE_ID = "vjp-styles";
  var CSS = [
    ".vjp{--navy:#17356b;--navy-line:#1b3a6b;--green:#3ea63e;--green-dark:#348a34;",
    "--ink:#1f2937;--muted:#4b5563;--line:#cbd5e1;--amber:#b45309;--amber-bg:#fffbeb;",
    "font-family:system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:var(--ink);",
    "background:#fff;padding:1.5rem 1rem 4rem;box-sizing:border-box}",
    ".vjp *,.vjp *:before,.vjp *:after{box-sizing:inherit}",
    ".vjp-wrap{max-width:64rem;margin:0 auto}",
    ".vjp-title{text-align:center;font-size:1.5rem;font-weight:400;color:var(--ink);margin:0 0 1.5rem}",
    ".vjp-steps{display:flex;justify-content:center;gap:3rem;flex-wrap:wrap;margin-bottom:1.75rem;padding:0;list-style:none}",
    ".vjp-step{text-align:center}",
    ".vjp-dot{width:2rem;height:2rem;border-radius:999px;display:flex;align-items:center;justify-content:center;",
    "margin:0 auto .5rem;font-size:.875rem;font-weight:600;color:#fff;background:#9ca3af}",
    ".vjp-step.vjp-now .vjp-dot{background:var(--navy)}",
    ".vjp-step p{margin:0;font-size:.875rem;color:var(--muted)}",
    ".vjp-step.vjp-now p{color:var(--navy);font-weight:600}",
    ".vjp-banner{background:var(--navy);color:#fff;text-align:center;padding:1.25rem 1rem;margin-bottom:1.75rem}",
    ".vjp-banner p{margin:0;font-size:1.0625rem;font-weight:600}",
    ".vjp-banner p+p{margin-top:.375rem;font-size:.9375rem;font-weight:400;color:#c7d5ee}",
    ".vjp-cols{display:grid;grid-template-columns:1fr;gap:1.5rem}",
    "@media(min-width:820px){.vjp-cols{grid-template-columns:1.15fr .85fr;align-items:start}}",
    ".vjp-box{border:2px solid var(--navy-line);padding:1.5rem}",
    ".vjp-boxhead{color:var(--navy);font-size:1rem;font-weight:700;letter-spacing:.02em;margin:0 0 1.25rem;text-transform:uppercase}",
    ".vjp-method{font-weight:600;font-size:.9375rem;color:var(--ink);margin:0 0 1.25rem}",
    ".vjp-disclosure{font-size:.875rem;line-height:1.6;color:var(--ink);margin:1.25rem 0 0}",
    ".vjp-line{display:grid;grid-template-columns:9rem 1fr;gap:1rem;align-items:center;margin-bottom:1rem}",
    "@media(max-width:560px){.vjp-line{grid-template-columns:1fr;gap:.375rem}}",
    ".vjp-line>label{font-size:.9375rem;color:var(--ink)}",
    ".vjp-in{width:100%;border:1px solid var(--line);border-radius:2px;padding:.5rem .625rem;font-size:1rem;",
    "font-family:inherit;background:#fff;color:var(--ink);min-height:2.375rem}",
    ".vjp-in:focus{outline:none;border-color:var(--navy);box-shadow:0 0 0 2px rgba(23,53,107,.25)}",
    ".vjp-pair{display:grid;grid-template-columns:1fr 1fr;gap:1rem}",
    ".vjp-pay{display:block;width:100%;background:var(--green);color:#fff;border:0;padding:1rem;font-size:1.125rem;",
    "font-weight:700;cursor:pointer;font-family:inherit;margin-top:1.25rem}",
    ".vjp-pay:hover{background:var(--green-dark)}",
    ".vjp-pay[disabled]{opacity:.6;cursor:default}",
    ".vjp-seal{margin-top:1.25rem;text-align:center}",
    ".vjp-note{font-size:.8125rem;color:var(--muted);line-height:1.55;margin:1rem 0 0}",
    ".vjp-consent{display:flex;gap:.625rem;margin:1.25rem 0 0;cursor:pointer}",
    ".vjp-consent span{font-size:.8125rem;line-height:1.55;color:var(--ink)}",
    ".vjp-err{color:#b91c1c;font-size:.875rem;margin:.75rem 0 0}",
    ".vjp-back{background:none;border:0;color:var(--navy);text-decoration:underline;font-size:.875rem;",
    "cursor:pointer;font-family:inherit;padding:0;margin-top:1rem}",
    ".vjp-ref{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:600}",
    /* collectCard mode: plain inputs, so they carry their own error state. */
    ".vjp-in[aria-invalid=true]{border-color:#b91c1c}",
    ".vjp-ferr{color:#b91c1c;font-size:.8125rem;margin:.375rem 0 0}",
    ".vjp-fhint{color:var(--muted);font-size:.75rem;margin:.375rem 0 0;line-height:1.5}",
    ".vjp-num{font-variant-numeric:tabular-nums;letter-spacing:.04em}",
    ".vjp-exp{display:grid;grid-template-columns:1fr 1fr;gap:1rem;max-width:16rem}",
    ".vjp-postal{max-width:10rem}",
    /* card number with the brand logos inside the right end of the field.
       The padding on the input is what stops the digits running under the
       logos; it is set from how many logos are showing. */
    ".vjp-numwrap{position:relative}",
    ".vjp-numwrap .vjp-num{padding-right:10.25rem}",
    ".vjp-numwrap.vjp-one .vjp-num{padding-right:3.5rem}",
    ".vjp-logos{position:absolute;top:0;bottom:0;right:.5rem;display:flex;align-items:center;gap:.25rem;pointer-events:none}",
    ".vjp-logos>span,.vjp-logos>img{display:block;width:2rem;height:1.3125rem;line-height:0}",
    ".vjp-logos svg{width:100%;height:100%;display:block}",
    ".vjp-logos .vjp-hide{display:none}",
    "@media(max-width:480px){.vjp-logos{right:.375rem;gap:.1875rem}.vjp-logos>span,.vjp-logos>img{width:1.5rem;height:1rem}",
    ".vjp-numwrap .vjp-num{padding-right:7.125rem;padding-left:.5rem;letter-spacing:0}.vjp-numwrap.vjp-one .vjp-num{padding-right:2.75rem}",
    ".vjp-numwrap .vjp-num::placeholder{font-size:.8125rem}}",
    ".vjp-cvv{max-width:7rem}",
    /* order summary: a white card */
    ".vjp-order{background:#fff;border:1px solid #dbe2ea;border-radius:.75rem;padding:1.375rem 1.375rem 1.25rem;",
    "box-shadow:0 1px 3px rgba(15,23,42,.06)}",
    ".vjp-ohead{display:flex;justify-content:space-between;align-items:center;margin:0 0 1rem}",
    ".vjp-ohead h2{margin:0;font-size:1.1875rem;font-weight:700;color:var(--ink)}",
    ".vjp-edit{background:none;border:0;padding:0;color:#0f766e;font:inherit;font-size:.9375rem;font-weight:600;cursor:pointer;text-decoration:none}",
    ".vjp-edit:hover{text-decoration:underline}",
    ".vjp-prod{display:flex;gap:.875rem;align-items:flex-start;padding-bottom:1rem;border-bottom:1px solid #e5e9ef}",
    ".vjp-prodimg{flex:0 0 4rem;width:4rem;height:4rem;line-height:0}",
    ".vjp-prodimg svg,.vjp-prodimg img{width:100%;height:100%;display:block;border-radius:.625rem}",
    ".vjp-prod h3{margin:.125rem 0 .25rem;font-size:1rem;font-weight:700;color:var(--ink)}",
    ".vjp-prod p{margin:0;font-size:.8125rem;line-height:1.5;color:var(--muted)}",
    ".vjp-orow{display:flex;justify-content:space-between;gap:1rem;padding:.875rem 0;font-size:.9375rem;color:var(--ink)}",
    ".vjp-orow .vjp-amt{font-weight:600;white-space:nowrap}",
    ".vjp-ototal{display:flex;justify-content:space-between;gap:1rem;align-items:center;background:#f0f7f6;",
    "border-radius:.5rem;padding:.75rem .875rem;font-weight:700;font-size:1.0625rem;color:var(--ink)}",
    ".vjp-ototal .vjp-amt{color:#0f766e;white-space:nowrap}",
    ".vjp-feats{list-style:none;margin:1.125rem 0 0;padding:0}",
    ".vjp-feats li{display:flex;gap:.75rem;align-items:flex-start;margin:0 0 .875rem}",
    ".vjp-ico{flex:0 0 2.25rem;width:2.25rem;height:2.25rem;border-radius:999px;background:#e7f3f1;color:#0f766e;",
    "display:flex;align-items:center;justify-content:center}",
    ".vjp-feats strong{display:block;font-size:.9375rem;color:var(--ink);margin:.0625rem 0 .125rem}",
    ".vjp-feats span.vjp-ftext{display:block;font-size:.8125rem;line-height:1.5;color:var(--muted)}",
    ".vjp-feats a{color:#0f766e;font-weight:600;text-decoration:none;word-break:break-word}",
    ".vjp-feats a:hover{text-decoration:underline}",
    ".vjp-mrv{margin:.25rem 0 0;padding-top:1rem;border-top:1px solid #e5e9ef;font-size:.8125rem;line-height:1.6;color:var(--ink);background:#fff}",
    ".vjp-side .vjp-note{margin-top:1rem}",
  ].join("");

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID; s.textContent = CSS;
    document.head.appendChild(s);
  }

  var BRANDS = ["Visa", "Mastercard", "Amex", "Discover"];

  var BRAND_SVG = {
    Visa: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 38 24\" width=\"38\" height=\"24\" role=\"img\" aria-label=\"Visa\"><rect x=\".5\" y=\".5\" width=\"37\" height=\"23\" rx=\"3.5\" fill=\"#fff\" stroke=\"#d6dbe3\"/><path transform=\"translate(4 -3) scale(1.25)\" fill=\"#1434CB\" d=\"M9.112 8.262L5.97 15.758H3.92L2.374 9.775c-.094-.368-.175-.503-.461-.658C1.447 8.864.677 8.627 0 8.479l.046-.217h3.3a.904.904 0 01.894.764l.817 4.338 2.018-5.102zm8.033 5.049c.008-1.979-2.736-2.088-2.717-2.972.006-.269.262-.555.822-.628a3.66 3.66 0 011.913.336l.34-1.59a5.207 5.207 0 00-1.814-.333c-1.917 0-3.266 1.02-3.278 2.479-.012 1.079.963 1.68 1.698 2.04.756.367 1.01.603 1.006.931-.005.504-.602.725-1.16.734-.975.015-1.54-.263-1.992-.473l-.351 1.642c.453.208 1.289.39 2.156.398 2.037 0 3.37-1.006 3.377-2.564m5.061 2.447H24l-1.565-7.496h-1.656a.883.883 0 00-.826.55l-2.909 6.946h2.036l.405-1.12h2.488zm-2.163-2.656l1.02-2.815.588 2.815zm-8.16-4.84l-1.603 7.496H8.34l1.605-7.496z\"/></svg>",
    Mastercard: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 38 24\" width=\"38\" height=\"24\" role=\"img\" aria-label=\"Mastercard\"><rect x=\".5\" y=\".5\" width=\"37\" height=\"23\" rx=\"3.5\" fill=\"#fff\" stroke=\"#d6dbe3\"/><circle cx=\"15\" cy=\"12\" r=\"7\" fill=\"#EB001B\"/><circle cx=\"23\" cy=\"12\" r=\"7\" fill=\"#F79E1B\"/><path d=\"M19 6.255A7 7 0 0 1 19 17.745A7 7 0 0 1 19 6.255Z\" fill=\"#FF5F00\"/></svg>",
    Amex: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 38 24\" width=\"38\" height=\"24\" role=\"img\" aria-label=\"American Express\"><rect x=\".5\" y=\".5\" width=\"37\" height=\"23\" rx=\"3.5\" fill=\"#016FD0\" stroke=\"#016FD0\"/><clipPath id=\"vjp-amex-clip\"><rect x=\"0\" y=\"0\" width=\"23.2\" height=\"24\"/></clipPath><path clip-path=\"url(#vjp-amex-clip)\" transform=\"translate(2.6 -4.8) scale(1.4)\" fill=\"#fff\" fill-rule=\"evenodd\" d=\"M0 0H24V24H0ZM16.015 14.378c0-.32-.135-.496-.344-.622-.21-.12-.464-.135-.81-.135h-1.543v2.82h.675v-1.027h.72c.24 0 .39.024.478.125.12.13.104.38.104.55v.35h.66v-.555c-.002-.25-.017-.376-.108-.516-.06-.08-.18-.18-.33-.234l.02-.008c.18-.072.48-.297.48-.747zm-.87.407l-.028-.002c-.09.053-.195.058-.33.058h-.81v-.63h.824c.12 0 .24 0 .33.05.098.048.156.147.15.255 0 .12-.045.215-.134.27zM20.297 15.837H19v.6h1.304c.676 0 1.05-.278 1.05-.884 0-.28-.066-.448-.187-.582-.153-.133-.392-.193-.73-.207l-.376-.015c-.104 0-.18 0-.255-.03-.09-.03-.15-.105-.15-.21 0-.09.017-.166.09-.21.083-.046.177-.066.272-.06h1.23v-.602h-1.35c-.704 0-.958.437-.958.84 0 .9.776.855 1.407.87.104 0 .18.015.225.06.046.03.082.106.082.18 0 .077-.035.15-.08.18-.06.053-.15.07-.277.07zM0 0v10.096L.81 8.22h1.75l.225.464V8.22h2.043l.45 1.02.437-1.013h6.502c.295 0 .56.057.756.236v-.23h1.787v.23c.307-.17.686-.23 1.12-.23h2.606l.24.466v-.466h1.918l.254.465v-.466h1.858v3.948H20.87l-.36-.6v.585h-2.353l-.256-.63h-.583l-.27.614h-1.213c-.48 0-.84-.104-1.08-.24v.24h-2.89v-.884c0-.12-.03-.12-.105-.135h-.105v1.036H6.067v-.48l-.21.48H4.69l-.202-.48v.465H2.235l-.256-.624H1.4l-.256.624H0V24h23.786v-7.108c-.27.135-.613.18-.973.18H21.09v-.255c-.21.165-.57.255-.914.255H14.71v-.9c0-.12-.018-.12-.12-.12h-.075v1.022h-1.8v-1.066c-.298.136-.643.15-.928.136h-.214v.915h-2.18l-.54-.617-.57.6H4.742v-3.93h3.61l.518.602.554-.6h2.412c.28 0 .74.03.942.225v-.24h2.177c.202 0 .644.045.903.225v-.24h3.265v.24c.163-.164.508-.24.803-.24h1.89v.24c.194-.15.464-.24.84-.24h1.176V0H0zM21.156 14.955c.004.005.006.012.01.016.01.01.024.01.032.02l-.042-.035zM23.828 13.082h.065v.555h-.065zM23.865 15.03v-.005c-.03-.025-.046-.048-.075-.07-.15-.153-.39-.215-.764-.225l-.36-.012c-.12 0-.194-.007-.27-.03-.09-.03-.15-.105-.15-.21 0-.09.03-.16.09-.204.076-.045.15-.05.27-.05h1.223v-.588h-1.283c-.69 0-.96.437-.96.84 0 .9.78.855 1.41.87.104 0 .18.015.224.06.046.03.076.106.076.18 0 .07-.034.138-.09.18-.045.056-.136.07-.27.07h-1.288v.605h1.287c.42 0 .734-.118.9-.36h.03c.09-.134.135-.3.135-.523 0-.24-.045-.39-.135-.526zM18.597 14.208v-.583h-2.235V16.458h2.235v-.585h-1.57v-.57h1.533v-.584h-1.532v-.51M13.51 8.787h.685V11.6h-.684zM13.126 9.543l-.007.006c0-.314-.13-.5-.34-.624-.217-.125-.47-.135-.81-.135H10.43v2.82h.674v-1.034h.72c.24 0 .39.03.487.12.122.136.107.378.107.548v.354h.677v-.553c0-.25-.016-.375-.11-.516-.09-.107-.202-.19-.33-.237.172-.07.472-.3.472-.75zm-.855.396h-.015c-.09.054-.195.056-.33.056H11.1v-.623h.825c.12 0 .24.004.33.05.09.04.15.128.15.25s-.047.22-.134.266zM15.92 9.373h.632v-.6h-.644c-.464 0-.804.105-1.02.33-.286.3-.362.69-.362 1.11 0 .512.123.833.36 1.074.232.238.645.31.97.31h.78l.255-.627h1.39l.262.627h1.36v-2.11l1.272 2.11h.95l.002.002V8.786h-.684v1.963l-1.18-1.96h-1.02V11.4L18.11 8.744h-1.004l-.943 2.22h-.3c-.177 0-.362-.03-.468-.134-.125-.15-.186-.36-.186-.662 0-.285.08-.51.194-.63.133-.135.272-.165.516-.165zm1.668-.108l.464 1.118v.002h-.93l.466-1.12zM2.38 10.97l.254.628H4V9.393l.972 2.205h.584l.973-2.202.015 2.202h.69v-2.81H6.118l-.807 1.904-.876-1.905H3.343v2.663L2.205 8.787h-.997L.01 11.597h.72l.26-.626h1.39zm-.688-1.705l.46 1.118-.003.002h-.915l.457-1.12zM11.856 13.62H9.714l-.85.923-.825-.922H5.346v2.82H8l.855-.932.824.93h1.302v-.94h.838c.6 0 1.17-.164 1.17-.945l-.006-.003c0-.78-.598-.93-1.128-.93zM7.67 15.853l-.014-.002H6.02v-.557h1.47v-.574H6.02v-.51H7.7l.733.82-.764.824zm2.642.33l-1.03-1.147 1.03-1.108v2.253zm1.553-1.258h-.885v-.717h.885c.24 0 .42.098.42.344 0 .243-.15.372-.42.372zM9.967 9.373v-.586H7.73V11.6h2.237v-.58H8.4v-.564h1.527V9.88H8.4v-.507\"/></svg>",
    Discover: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 38 24\" width=\"38\" height=\"24\" role=\"img\" aria-label=\"Discover\"><rect x=\".5\" y=\".5\" width=\"37\" height=\"23\" rx=\"3.5\" fill=\"#fff\" stroke=\"#d6dbe3\"/><g transform=\"translate(2.2 -4.8) scale(1.4)\"><path fill=\"#231F20\" d=\"M14.58 12m-5.2-2.001c-1.124 0-2.025.884-2.025 1.99 0 1.118.878 1.984 2.007 1.984.319 0 .593-.063.93-.221v-.873c-.296.297-.559.416-.895.416-.747 0-1.277-.542-1.277-1.312 0-.73.547-1.306 1.243-1.306.354 0 .622.126.93.428v-.873a1.898 1.898 0 0 0-.913-.233zm-3.352 1.545c-.445-.165-.576-.273-.576-.479 0-.239.233-.422.553-.422.222 0 .405.091.598.308l.388-.508a1.665 1.665 0 0 0-1.117-.422c-.673 0-1.186.467-1.186 1.089 0 .524.239.792.936 1.043.291.103.438.171.513.217a.456.456 0 0 1 .222.394c0 .308-.245.536-.576.536-.354 0-.639-.177-.809-.507l-.479.461c.342.502.752.724 1.317.724.771 0 1.311-.513 1.311-1.249-.002-.603-.252-.876-1.095-1.185zM24 10.3a.29.29 0 0 1-.288.291.29.29 0 0 1-.291-.291v-.003A.29.29 0 1 1 24 10.3zm-.059.001a.235.235 0 0 0-.231-.239.234.234 0 0 0-.232.239c0 .132.104.239.232.239a.235.235 0 0 0 .231-.239zM3.472 13.887h.742v-3.803h-.742v3.803zm12.702-1.248l-1.014-2.554h-.81l1.614 3.9h.399l1.643-3.9h-.804l-1.028 2.554zm2.166 1.248h2.104v-.644h-1.362v-1.027h1.312v-.644h-1.312v-.844h1.362v-.644H18.34v3.803zm5.409-3.557l.11.138h-.097l-.094-.13v.13h-.08v-.334h.107c.081 0 .126.036.126.103.001.046-.025.08-.072.093zm-.006-.092c0-.029-.021-.043-.06-.043h-.014v.087h.014c.039 0 .06-.014.06-.044zm-1.228 2.047l1.197 1.602H22.8l-1.027-1.528h-.097v1.528h-.741v-3.803h1.1c.855 0 1.346.411 1.346 1.123 0 .583-.308.965-.866 1.078zm.103-1.038c0-.37-.251-.563-.713-.563h-.228v1.152h.217c.473-.001.724-.207.724-.589zm-19.487.742a1.91 1.91 0 0 1-.69 1.46c-.365.303-.781.439-1.357.439H.001v-3.803H1.09c1.202 0 2.041.781 2.041 1.904zm-.764-.006c0-.364-.154-.718-.411-.947-.245-.222-.536-.308-1.015-.308H.742v2.515h.199c.479 0 .782-.092 1.015-.302.256-.228.411-.593.411-.958z\"/><path fill=\"#FF6000\" d=\"M14.58 12a2.023 2.023 0 1 1-2.025-2.023h.002c1.118 0 2.023.906 2.023 2.023z\"/></g></svg>"
  };

  var ORDER_SVG = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 64 64\" width=\"64\" height=\"64\" aria-hidden=\"true\" focusable=\"false\"><rect width=\"64\" height=\"64\" rx=\"10\" fill=\"#eef4f8\"/><g transform=\"translate(30 7) rotate(8)\"><rect x=\"0\" y=\"0\" width=\"22\" height=\"16\" fill=\"#fff\" stroke=\"#cbd5e1\" stroke-width=\".6\"/><g fill=\"#b91c1c\"><rect y=\"0\" width=\"22\" height=\"1.23\"/><rect y=\"2.46\" width=\"22\" height=\"1.23\"/><rect y=\"4.92\" width=\"22\" height=\"1.23\"/><rect y=\"7.38\" width=\"22\" height=\"1.23\"/><rect y=\"9.84\" width=\"22\" height=\"1.23\"/><rect y=\"12.3\" width=\"22\" height=\"1.23\"/><rect y=\"14.77\" width=\"22\" height=\"1.23\"/></g><rect width=\"9.5\" height=\"8.6\" fill=\"#1e3a8a\"/><g fill=\"#fff\"><circle cx=\"2\" cy=\"2\" r=\".55\"/><circle cx=\"4.7\" cy=\"2\" r=\".55\"/><circle cx=\"7.4\" cy=\"2\" r=\".55\"/><circle cx=\"3.3\" cy=\"4.3\" r=\".55\"/><circle cx=\"6\" cy=\"4.3\" r=\".55\"/><circle cx=\"2\" cy=\"6.6\" r=\".55\"/><circle cx=\"4.7\" cy=\"6.6\" r=\".55\"/><circle cx=\"7.4\" cy=\"6.6\" r=\".55\"/></g></g><g transform=\"translate(10 14) rotate(-6)\"><rect width=\"30\" height=\"42\" rx=\"3\" fill=\"#17356b\"/><rect x=\"2.2\" y=\"2.2\" width=\"25.6\" height=\"37.6\" rx=\"2\" fill=\"none\" stroke=\"#c9a54a\" stroke-width=\".6\"/><circle cx=\"15\" cy=\"18\" r=\"6.2\" fill=\"none\" stroke=\"#c9a54a\" stroke-width=\"1.1\"/><ellipse cx=\"15\" cy=\"18\" rx=\"2.6\" ry=\"6.2\" fill=\"none\" stroke=\"#c9a54a\" stroke-width=\".8\"/><path d=\"M8.8 18h12.4M9.8 14.9h10.4M9.8 21.1h10.4\" fill=\"none\" stroke=\"#c9a54a\" stroke-width=\".8\"/><rect x=\"8\" y=\"29\" width=\"14\" height=\"1.5\" rx=\".75\" fill=\"#c9a54a\"/><rect x=\"10\" y=\"32.4\" width=\"10\" height=\"1.1\" rx=\".55\" fill=\"#c9a54a\" opacity=\".75\"/></g></svg>";

  var ICON_SVG = {
    lock: "<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4.5\" y=\"10.5\" width=\"15\" height=\"10\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"M8 10.5V7.8a4 4 0 0 1 8 0v2.7\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\"/><circle cx=\"12\" cy=\"15.5\" r=\"1.4\" fill=\"currentColor\"/></svg>",
    shield: "<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 3.2l7 2.6v5.3c0 4.5-3 8.2-7 9.7-4-1.5-7-5.2-7-9.7V5.8z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linejoin=\"round\"/><path d=\"M8.8 12.2l2.2 2.2 4.3-4.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>",
    help: "<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"8.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"M9.6 9.6a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .8-1 1.5v.6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\" stroke-linecap=\"round\"/><circle cx=\"12\" cy=\"16.9\" r=\"1.1\" fill=\"currentColor\"/></svg>"
  };

  /* ---------------------------------------------------- card checks ----
     Used only in collectCard mode. They catch typing mistakes before the
     number is stored, which matters more than usual here: nobody tries the
     card until weeks later, and by then the applicant has moved on. They are
     not a substitute for the processor's own checks at charge time. */

  function digitsOnly(v) { return String(v || "").replace(/\D/g, ""); }

  /* Prefixes for the four brands shown on the page. Mastercard includes the
     2221-2720 range issued since 2017, which older checks still miss. Discover
     includes the UnionPay ranges it accepts in the US. */
  function cardBrand(digits) {
    var d = digitsOnly(digits);
    var four = Number(d.slice(0, 4));
    var six = Number(d.slice(0, 6));
    if (/^4/.test(d)) return "Visa";
    if (/^3[47]/.test(d)) return "Amex";
    if (/^5[1-5]/.test(d) || (d.length >= 4 && four >= 2221 && four <= 2720)) return "Mastercard";
    if (/^(6011|65|64[4-9])/.test(d) || (d.length >= 6 && six >= 622126 && six <= 622925)) return "Discover";
    return "";
  }

  /* American Express prints a 4 digit code on the front; the others a 3
     digit code on the back. */
  function cvvLength(brand) { return brand === "Amex" ? 4 : 3; }

  var LENGTHS = { Visa: [13, 16, 19], Mastercard: [16], Amex: [15], Discover: [16, 17, 18, 19] };

  function luhn(digits) {
    var d = digitsOnly(digits), sum = 0, dbl = false;
    for (var i = d.length - 1; i >= 0; i--) {
      var n = d.charCodeAt(i) - 48;
      if (dbl) { n *= 2; if (n > 9) n -= 9; }
      sum += n; dbl = !dbl;
    }
    return d.length > 0 && sum % 10 === 0;
  }

  /* Shown in fours as it is typed, so the applicant can check it against the
     card in groups rather than as one run of sixteen digits. */
  function groupDigits(digits) {
    return digitsOnly(digits).replace(/(\d{4})(?=\d)/g, "$1 ");
  }

  /* A card is good until the last day of its expiry month. */
  function expired(month, year, now) {
    now = now || new Date();
    var y = Number(year), m = Number(month);
    return y < now.getFullYear() || (y === now.getFullYear() && m < now.getMonth() + 1);
  }

  /* Returns { field: message } for everything wrong, empty when all is well. */
  function checkCard(c, now) {
    var errs = {};
    var num = digitsOnly(c.number);
    var brand = cardBrand(num);
    if (!String(c.nameFirst || "").trim() || !String(c.nameLast || "").trim()) {
      errs.name = "Enter the name exactly as it appears on the card.";
    }
    if (!num) errs.number = "Enter the card number.";
    else if (!brand) errs.number = "We accept Visa, Mastercard, Discover and American Express. Check the number or use one of those.";
    else if (LENGTHS[brand].indexOf(num.length) === -1 || !luhn(num)) {
      errs.number = "That card number is not valid. Check it against your card.";
    }
    if (!c.expMonth || !c.expYear) errs.expiry = "Choose the month and year printed on the card.";
    else if (expired(c.expMonth, c.expYear, now)) errs.expiry = "This card has expired. Use a card that is still valid.";
    /* The security code: 4 digits on the front of an Amex, 3 on the back of
       the others. Before the brand is known, either length passes here and
       the number's own error is the one shown. */
    var cvv = String(c.cvv == null ? "" : c.cvv).trim();
    if (!cvv) errs.cvv = "Enter the security code from your card.";
    else if (!/^[0-9]+$/.test(cvv) || cvv.length !== cvvLength(brand) && !(brand === "" && (cvv.length === 3 || cvv.length === 4))) {
      errs.cvv = brand === "Amex"
        ? "The security code on an American Express card is the 4 digits on the front."
        : "The security code is the 3 digits on the back of your card.";
    }
    var postal = String(c.postal || "").trim();
    if (postal && !/^[A-Za-z0-9][A-Za-z0-9 -]{1,9}$/.test(postal)) {
      errs.postal = "Check the postal code. Use letters, numbers, spaces or hyphens only.";
    }
    return errs;
  }

  function money(n) {
    var v = Number(n);
    return "$" + (Math.round(v) === v ? String(v) : v.toFixed(2));
  }

  function svgSpan(cls, markup) {
    var s = el("span", { class: cls });
    s.innerHTML = markup;
    return s;
  }

  function mount(container, options) {
    options = options || {};
    injectStyles();

    /* Both figures come from the mount call in payment.html, which is the one
       place they are set. Nothing below hard-codes an amount. */
    var serviceFee = options.serviceFee == null ? 185 : options.serviceFee;
    var governmentFee = options.governmentFee == null ? 185 : options.governmentFee;
    var currency = options.currency || "USD";
    var supportEmail = options.supportEmail || "support@visajourneyusa.com";

    var state = { busy: false, error: "", nameFirst: "", nameLast: "",
                  number: "", cvv: "", expMonth: "", expYear: "", postal: "", fieldErrors: {} };

    /* ------------------------------------------------------ card fields --
       Plain inputs, deliberately outside any form element so a stray Enter or
       a browser extension cannot submit them anywhere. Typing updates state
       without redrawing, so the cursor stays put; the page only redraws on
       the button. */
    function cardInputs(left) {
      var errs = state.fieldErrors || {};

      function errFor(key, id) {
        return errs[key] ? el("p", { class: "vjp-ferr", id: id, text: errs[key] }) : null;
      }

      var f = el("input", { class: "vjp-in", id: "vjp-name-first", "aria-label": "First name on card",
        autocomplete: "cc-given-name", "aria-invalid": errs.name ? "true" : null,
        "aria-describedby": errs.name ? "vjp-err-name" : null,
        oninput: function () { state.nameFirst = f.value; } });
      var l = el("input", { class: "vjp-in", "aria-label": "Last name on card",
        autocomplete: "cc-family-name", "aria-invalid": errs.name ? "true" : null,
        oninput: function () { state.nameLast = l.value; } });
      f.value = state.nameFirst; l.value = state.nameLast;
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-name-first", text: "Name on Card" }),
        el("div", {}, [el("div", { class: "vjp-pair" }, [f, l]), errFor("name", "vjp-err-name")]),
      ]));

      /* The four brand logos sit inside the right end of the number field.
         Once the number shows which brand it is, only that logo stays, which
         also gives the digits more room on a phone. */
      var logos = el("span", { class: "vjp-logos", "aria-hidden": "true" });
      BRANDS.forEach(function (b) {
        if (options.brandLogos && options.brandLogos[b]) {
          logos.appendChild(el("img", { src: options.brandLogos[b], alt: "", "data-brand": b }));
        } else {
          var s = svgSpan("", BRAND_SVG[b]);
          s.setAttribute("data-brand", b);
          logos.appendChild(s);
        }
      });
      var numWrap = el("div", { class: "vjp-numwrap" });
      function lightBrand(digits) {
        var b = cardBrand(digits);
        Array.prototype.forEach.call(logos.children, function (node) {
          node.className = b && node.getAttribute("data-brand") !== b ? "vjp-hide" : "";
        });
        numWrap.className = "vjp-numwrap" + (b ? " vjp-one" : "");
        if (cvvIn) {
          cvvIn.setAttribute("maxlength", String(b ? cvvLength(b) : 4));
          cvvIn.setAttribute("placeholder", b === "Amex" ? "1234" : "123");
        }
      }
      var cvvIn = null;

      /* type=text with inputmode, not type=number: a number input drops
         leading zeros, shows spinners, and lets a scroll wheel change the
         value. autocomplete=cc-number lets the browser or a password manager
         fill it, which is fewer typos than any check below. */
      var num = el("input", { class: "vjp-in vjp-num", id: "vjp-card-number", type: "text",
        inputmode: "numeric", autocomplete: "cc-number", spellcheck: "false",
        maxlength: "23", placeholder: "1234 1234 1234 1234",
        "aria-invalid": errs.number ? "true" : null,
        "aria-describedby": errs.number ? "vjp-err-number" : null,
        oninput: function () {
          var before = num.value.slice(0, num.selectionStart || 0);
          var keep = digitsOnly(before).length;
          var digits = digitsOnly(num.value).slice(0, 19);
          num.value = groupDigits(digits);
          state.number = digits;
          lightBrand(digits);
          /* Put the cursor back after the same number of digits, so editing
             the middle of the number does not throw it to the end. */
          var pos = 0, seen = 0;
          while (pos < num.value.length && seen < keep) {
            if (/\d/.test(num.value.charAt(pos))) seen++;
            pos++;
          }
          try { num.setSelectionRange(pos, pos); } catch (e) { /* not focused */ }
        } });
      num.value = groupDigits(state.number);
      numWrap.appendChild(num);
      numWrap.appendChild(logos);
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-card-number", text: "Credit Card Number" }),
        el("div", {}, [numWrap, errFor("number", "vjp-err-number")]),
      ]));

      /* Two selects rather than an MM/YY text box. Nothing to mistype, and
         nobody has to guess whether the year is two digits or four. */
      var month = el("select", { class: "vjp-in", id: "vjp-exp-month", "aria-label": "Expiry month",
        autocomplete: "cc-exp-month", "aria-invalid": errs.expiry ? "true" : null,
        "aria-describedby": errs.expiry ? "vjp-err-expiry" : null,
        onchange: function () { state.expMonth = month.value; } },
        [el("option", { value: "", text: "Month" })].concat(
          [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(function (m) {
            var mm = (m < 10 ? "0" : "") + m;
            return el("option", { value: String(m), text: mm, selected: String(m) === String(state.expMonth) });
          })));
      var thisYear = new Date().getFullYear();
      var years = [];
      for (var y = thisYear; y <= thisYear + 15; y++) years.push(y);
      var year = el("select", { class: "vjp-in", "aria-label": "Expiry year",
        autocomplete: "cc-exp-year", "aria-invalid": errs.expiry ? "true" : null,
        onchange: function () { state.expYear = year.value; } },
        [el("option", { value: "", text: "Year" })].concat(years.map(function (yy) {
          return el("option", { value: String(yy), text: String(yy), selected: String(yy) === String(state.expYear) });
        })));
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-exp-month", text: "Expiration Date" }),
        el("div", {}, [el("div", { class: "vjp-exp" }, [month, year]), errFor("expiry", "vjp-err-expiry")]),
      ]));

      /* The security code. Digits only, 3 (4 for American Express). See note
         3 at the top of this file for what the server does with it. It is a
         plain text field rather than a masked one, so a typo can be seen,
         and it is cleared with the rest once the server has the card. */
      cvvIn = el("input", { class: "vjp-in vjp-num vjp-cvv", id: "vjp-cvv", type: "text",
        inputmode: "numeric", autocomplete: "cc-csc", spellcheck: "false",
        maxlength: "4", placeholder: "123",
        "aria-invalid": errs.cvv ? "true" : null,
        "aria-describedby": errs.cvv ? "vjp-err-cvv" : null,
        oninput: function () {
          var d = digitsOnly(cvvIn.value).slice(0, Number(cvvIn.getAttribute("maxlength")) || 4);
          if (cvvIn.value !== d) cvvIn.value = d;
          state.cvv = d;
        } });
      cvvIn.value = state.cvv;
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-cvv", text: "Security Code (CVV)" }),
        el("div", {}, [cvvIn, errFor("cvv", "vjp-err-cvv")]),
      ]));
      lightBrand(state.number);

      /* Optional. Many applicants live where postal codes are not used, and
         a required field there gets filled with 00000, which is worse than
         nothing when the processor checks it against the bank's records. */
      var postal = el("input", { class: "vjp-in vjp-postal", id: "vjp-postal", type: "text",
        autocomplete: "postal-code", maxlength: "10",
        "aria-invalid": errs.postal ? "true" : null,
        "aria-describedby": errs.postal ? "vjp-err-postal" : null,
        oninput: function () { state.postal = postal.value; } });
      postal.value = state.postal;
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-postal", text: "Billing Postal Code" }),
        el("div", {}, [postal, errFor("postal", "vjp-err-postal")]),
      ]));
    }

    function focusFirstError() {
      var bad = container.querySelector("[aria-invalid=true]");
      if (bad && bad.focus) bad.focus();
    }

    function back() {
      if (typeof options.onBack === "function") options.onBack();
    }

    /* ------------------------------------------------ the order summary -- */
    function orderPanel() {
      var panel = el("div", { class: "vjp-order", "aria-label": "Your order" });

      panel.appendChild(el("div", { class: "vjp-ohead" }, [
        el("h2", { text: "Your Order" }),
        typeof options.onBack === "function"
          ? el("button", { type: "button", class: "vjp-edit", text: "Edit", onclick: back })
          : null,
      ]));

      var img;
      if (options.productImage) {
        img = el("span", { class: "vjp-prodimg" }, [el("img", { src: options.productImage, alt: "" })]);
      } else {
        img = svgSpan("vjp-prodimg", ORDER_SVG);
      }
      panel.appendChild(el("div", { class: "vjp-prod" }, [
        img,
        el("div", {}, [
          el("h3", { text: "U.S. Visitor Visa Assistance" }),
          el("p", { text: "Professional guidance with your DS-160 application and interview preparation." }),
        ]),
      ]));

      panel.appendChild(el("div", { class: "vjp-orow" }, [
        el("span", { text: "Service Fee" }),
        el("span", { class: "vjp-amt", text: money(serviceFee) + " " + currency }),
      ]));
      panel.appendChild(el("div", { class: "vjp-ototal" }, [
        el("span", { text: "Total" }),
        el("span", { class: "vjp-amt", text: money(serviceFee) + " " + currency }),
      ]));

      function feat(icon, title, body) {
        return el("li", {}, [
          svgSpan("vjp-ico", ICON_SVG[icon]),
          el("div", {}, [el("strong", { text: title }), body]),
        ]);
      }
      panel.appendChild(el("ul", { class: "vjp-feats" }, [
        feat("lock", "Secure Payment",
          el("span", { class: "vjp-ftext", text: "Your payment information is encrypted and processed securely." })),
        feat("shield", "Your Information is Safe",
          el("span", { class: "vjp-ftext", text: "Your card details are encrypted and stored securely." })),
        feat("help", "Need Help?",
          el("span", { class: "vjp-ftext" }, ["Contact us at ",
            el("a", { href: "mailto:" + supportEmail, text: supportEmail })])),
      ]));

      if (options.sealHtml) {
        panel.appendChild(el("div", { class: "vjp-seal", html: options.sealHtml }));
      }

      /* The government fee, last, on white, at the client's request (October
         2026). It replaced the separate government fee panel: this is the
         line on this page that tells the applicant the MRV fee exists and is
         not ours. Do not remove it without putting that back somewhere. */
      panel.appendChild(el("p", { class: "vjp-mrv",
        text: "The " + money(governmentFee) + " MRV (visa application) fee is paid directly to the U.S. " +
              "Department of State, not to us. It is not included in the service fee above." }));
      return panel;
    }

    function render() {
      container.className = "vjp";
      container.innerHTML = "";

      /* ---- header ---- */
      var steps = el("ol", { class: "vjp-steps" });
      ["Complete the Form", "Review", "Payment"].forEach(function (label, i) {
        var now = i === 2;
        steps.appendChild(el("li", { class: "vjp-step" + (now ? " vjp-now" : "") }, [
          el("div", { class: "vjp-dot", text: String(i + 1) }),
          el("p", { text: label }),
        ]));
      });

      var banner = el("div", { class: "vjp-banner" }, [
        el("p", { text: "Your card details are handled over a secure, encrypted connection." }),
      ]);

      /* ---- left column: the card ---- */
      var left = el("div", { class: "vjp-box" }, [
        el("p", { class: "vjp-boxhead", text: "Card details" }),
        el("p", { class: "vjp-method", text: "Credit or debit card" })]);
      cardInputs(left);

      /* Stated as a plain disclosure before the button: the fee is ours. */
      left.appendChild(el("p", { class: "vjp-disclosure",
        text: "The " + money(serviceFee) + " we will charge is a preparation service fee paid to Visa Journey USA." }));

      var payBtn = el("button", { type: "button", class: "vjp-pay",
        text: state.busy ? "Saving" : "Save my card and Submit",
        onclick: function () {
          if (state.busy) return;
          state.fieldErrors = checkCard(state);
          if (Object.keys(state.fieldErrors).length) {
            state.error = "Some card details need attention. Check the highlighted fields above.";
            render();
            focusFirstError();
            return;
          }
          var num = digitsOnly(state.number);
          var nameOnCard = (state.nameFirst + " " + state.nameLast).trim();
          var payload = {
            applicationId: options.applicationId || "",
            nameOnCard: nameOnCard,
            card: {
              name: nameOnCard, number: num, cvv: digitsOnly(state.cvv),
              expMonth: Number(state.expMonth), expYear: Number(state.expYear),
              postal: state.postal.trim(), brand: cardBrand(num), last4: num.slice(-4),
            },
          };
          state.error = ""; state.busy = true; render();
          Promise.resolve(options.onSaveCard && options.onSaveCard(payload)).then(function () {
            /* Accepted by the server, so this page has no further use for the
               number or the code. Dropping them means nothing is left in
               memory for a browser extension or a later script to find. */
            state.number = ""; state.cvv = "";
            payload.card.number = ""; payload.card.cvv = "";
            var n = container.querySelector("#vjp-card-number");
            var v = container.querySelector("#vjp-cvv");
            if (n) n.value = "";
            if (v) v.value = "";
          }).catch(function (err) {
            state.busy = false;
            state.error = (err && err.userMessage) ||
              "We could not save your card. Nothing has been charged. Please check your details and try again.";
            render();
          });
        } });
      payBtn.disabled = state.busy;
      left.appendChild(payBtn);
      if (state.error) left.appendChild(el("p", { class: "vjp-err", role: "alert", text: state.error }));

      /* ---- right column: the order ---- */
      var right = el("div", { class: "vjp-side" }, [orderPanel()]);
      if (options.applicationId) {
        right.appendChild(el("p", { class: "vjp-note" }, [
          "Application ", el("span", { class: "vjp-ref", text: options.applicationId }),
        ]));
      }
      if (typeof options.onBack === "function") {
        right.appendChild(el("button", { type: "button", class: "vjp-back", text: "Back to review", onclick: back }));
      }

      container.appendChild(el("div", { class: "vjp-wrap" }, [
        el("h1", { class: "vjp-title", text: "Prepare your visa application in 3 easy steps" }),
        steps, banner,
        el("div", { class: "vjp-cols" }, [left, right]),
      ]));
    }

    render();
    return { setBusy: function (v) { state.busy = v; render(); },
             setError: function (m) { state.error = m; state.busy = false; render(); } };
  }

  /* The card checks are exposed so they can be tested on their own, and so the
     server can be compared against them. The server must repeat them: anything
     a browser checks, a browser can skip. */
  return { mount: mount, luhn: luhn, cardBrand: cardBrand, checkCard: checkCard, cvvLength: cvvLength };
})();

if (typeof module !== "undefined" && module.exports) module.exports = VisaJourneyPayment;
