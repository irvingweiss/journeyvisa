/* =====================================================================
   Visa Journey USA — admin screen (vanilla JavaScript)
   =====================================================================

   No framework, no build step, no dependencies beyond the application form,
   which must be on the page first:

       script src="/visa-application-form.js"
       script src="/admin.js"

   in that order (no closing tags written here on purpose: this file gets
   inlined into a single-file preview, and a literal closing script tag in a
   comment ends the tag early and takes the whole page down with it).

   It needs that file for VJ_SCHEMA. The detail view is drawn by walking the
   same 22-step schema the applicant filled in, so the admin reads the exact
   wording the applicant answered. Change a question in the form and this page
   follows, with nothing to keep in sync.

       VisaJourneyAdmin.mount(document.getElementById("admin"), {
         onSignIn:     ({ email, password }) => fetch(...).then(...),
         onVerifyCode: ({ code }) => fetch(...).then(...),
         onSignOut:   () => fetch("/api/admin/session", { method: "DELETE" }),
         onList:      ({ query, status }) => fetch(...).then(r => r.json()),
         onGet:       (reference) => fetch(...).then(r => r.json()),
         onSetStatus: ({ reference, status }) => fetch(...),
         onAddNote:   ({ reference, body }) => fetch(...).then(r => r.json()),
         onRevealCard:  ({ reference }) => fetch(...).then(r => r.json()),
         onMarkCharged: ({ reference, amount, ... }) => fetch(...).then(r => r.json()),
       });

   WHAT THE SERVER OWES EACH CALLBACK

   onSignIn    in  { email, password }
               out { email, name }                 signed in, no second factor
               or  { mfaRequired: true }           ask for the code next

               Two steps, two calls. This one takes the password. If the
               account has a second factor, answer { mfaRequired: true } and
               set a SHORT-LIVED HALF SESSION cookie (five minutes, marked
               as not yet MFA-passed) instead of a real one. The page then
               shows the code field and calls onVerifyCode. The password is
               not held in the browser between the two and is not sent again.

               Answering { email, name } signs the page straight in, so the
               password step can ship before TOTP is built. The card-reveal
               route is the one thing that must stay off until it is.

   onVerifyCode in { code }
               out { email, name }                 now fully signed in
               The six-digit TOTP code, or a recovery code: same field, and
               the server decides which it got. Upgrade the half session to a
               real one with BOTH mfa_passed and second_factor set, and issue
               a new session token rather than reusing the half one, so a
               token captured during the first step is worth nothing after
               the second. second_factor is the one the card routes check:
               see renderSignIn below for why the two are not the same.

               Rejects with err.code and err.userMessage, which the page's
               own request helper fills in from the server's { code, message }
               body. It did not, for a while, so every failure here showed
               "Those details were not recognised" whatever had happened --
               including a lockout.

               The codes: "locked" for the
               lockout (with Retry-After), "expired" when the half session has
               run out, anything else shows the message as given. Count wrong
               codes in their OWN lockout bucket, separate from the one that
               counts wrong passwords, and refuse a code that has already been
               used, even inside its time window.

               Two buckets, not one. The shipped API keys them on the caller's
               address as "admin-signin" and "admin-code". One shared bucket
               is wrong in both directions: clearing it on a correct password
               lets anyone holding the password refill the code budget at
               will, four guesses at a time, and not clearing it makes four
               password typos plus one mistyped code five failures, so the
               only admin account locks itself out and then refuses the
               correct code that follows. Separate buckets answer both.

               Full server instructions are in README.md under "The second
               factor".
               There is exactly one admin login, and it is not a row in a
               users table. The server checks it against two environment
               variables:

                 ADMIN_EMAIL          compared trimmed and case-insensitively
                 ADMIN_PASSWORD_HASH  a bcrypt hash, checked with the bcrypt
                                      library's own compare, which runs in
                                      constant time. Never decode it, never
                                      compare strings with == or ===.

               Run the bcrypt compare even when the email is wrong, so a wrong
               email takes as long as a wrong password. Answer both with the
               same 401 and the same message: saying which half was wrong tells
               an attacker they have the email right.

               Rate limit it and lock out repeated failures (README.md, "The
               admin account" has the numbers). Once the limit is hit, answer
               429 with { code: "locked", message } and a Retry-After header,
               without running the compare at all. This page shows
               err.userMessage when one is given, and "Those details were not
               recognised." otherwise.

               On success, issue a new session id (never promote the one the
               browser arrived with) in a cookie that is Secure, HttpOnly and
               SameSite=Strict, and answer { email, name: "Admin" }. The email
               goes in the "Signed in as" bar. The name goes on notes, activity
               and "charged by", and it is a role rather than a person on
               purpose: with one shared login the server cannot tell people
               apart, so nothing here should pretend it can.

   onSignOut   in  nothing
               Destroy the session server side, not just the cookie.

   onList      in  { query, status }               both may be empty
               out { applications: [ {
                       reference, applicantName, status, stepIndex,
                       createdAt, updatedAt
                     } ] }

   onGet       in  reference
               out { reference, applicantName, status, stepIndex,
                     createdAt, updatedAt, submittedAt,
                     data: { ...the answers... },
                     photoUrl,                     signed and expiring
                     notes:    [ { author, at, body } ],
                     activity: [ { author, at, action } ] }

               `data` is the same shape onSaveStep has been receiving from the
               form. Never include securityAnswer: it is a hash on your side and
               has no business here. This page drops it defensively anyway.

               Also on it: payment: { status, amount, currency, chargedAt,
               chargedOn, chargedBy, processorReference, receiptUrl,
               card: { brand, last4, expMonth, expYear, numberOnFile } }
               status is "none", "authorised" or "paid". numberOnFile is false
               once the full number has been purged (after the charge, or at
               the end of the retention period), and the reveal button goes.

               NEVER put the full card number on this response. onGet runs on
               every page view and its responses end up in browser history,
               proxies and error reports. The number only comes through
               onRevealCard, so every sight of it is a logged event. This page
               deletes card.number from the response defensively, but by then
               it has already crossed the wire.

   onSetStatus in  { reference, status }
   onAddNote   in  { reference, body }   out { author, at, body }

   onCharge    in  { reference }
               out { status, chargedAt, amount, receiptUrl }  on success
               Rejects with err.code and err.userMessage otherwise. The codes
               this screen understands are "declined", "expired_card" and
               "authentication_required"; anything else shows the message as
               given.

               THREE RULES FOR WHOEVER WRITES THIS ONE.

               The amount comes from your server, never from this page. A price
               posted from a browser is a price the customer can edit.

               It must be idempotent. Charging twice is the failure that costs
               you a customer and a chargeback, and a double click is the normal
               way it happens. Key the idempotency on the application, not on
               the request, so a retry after a timeout cannot take the money
               again.

               It must refuse to charge an application that is already paid, and
               say so, rather than relying on this page to hide the button.

   onRevealCard in  { reference }
               out { number, name, expMonth, expYear, postal, cvv }
               number is digits only. cvv is the security code while one is
               stored, null once the charge has been recorded (the server
               wipes it then). Rejects with err.code and
               err.userMessage otherwise; "rate_limited" and "not_on_file" are
               understood, anything else shows the message as given.

               THIS IS THE ONLY ROUTE THAT EVER DECRYPTS A CARD NUMBER. The
               rules for it are in README.md under "Storing full card
               numbers". In short: the admin session, signed in with a
               second factor, rate limited, and an
               append-only log row for every call (who, when, IP, reference,
               and whether it was allowed) written BEFORE the number is
               returned. If the log write fails, refuse the reveal. Send
               Cache-Control: no-store on the response, and keep the body out
               of request logging and error tracking.

               This page adds "Viewed full card number" to the Activity list
               when the reveal succeeds, so whoever holds the login sees the
               trail they are leaving. That is a courtesy. The server's log is the record.

               The number is shown for 60 seconds, then wiped from the page.
               It is also wiped on navigation, sign out, printing and when the
               page is closed. It is never stored in this page's state: once
               hidden it is gone, and seeing it again is another logged
               reveal. That is deliberate. Do not "cache it for convenience".

   onMarkCharged in  { reference, amount, currency, chargedOn, processorReference }
               out { status, amount, chargedOn, processorReference }
               The fee is charged on a separate processor, outside this
               screen. This records that it happened. chargedOn is yyyy-mm-dd,
               amount is a number in the application's currency, and
               processorReference is the transaction id the other processor
               gave. Store all three, with when it was recorded.

               Refuse an application that is already paid, rather than
               relying on this page to hide the button. And purge the stored
               card number in the same transaction that marks it paid: once
               the fee is taken there is no reason left to hold it, and every
               day it sits there is risk with nothing on the other side.

   onCharge    is still honoured when it is supplied, for a setup where the
               card is a saved token with a processor this site can call.
               Supply onMarkCharged, onCharge or both; the screen shows what
               it has been given.

   Every one of these must check the admin session server side. A route that
   is merely hard to guess is not access control.

   ONE THING THIS DELIBERATELY CANNOT DO

   It does not edit an applicant's answers. The applicant signed them
   electronically, and an admin quietly changing them afterwards would make
   that signature meaningless. Corrections go back through the applicant, or get
   recorded as a note.
   ===================================================================== */

var VisaJourneyAdmin = (function () {
  "use strict";

  var STYLE_ID = "vja-styles";

  var CSS = [
    ".vja{--a-ink:#0f172a;--a-mut:#64748b;--a-line:#e2e8f0;--a-bg:#f8fafc;",
    "--a-teal:#0f766e;--a-bad:#b91c1c;color:var(--a-ink);",
    "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;font-size:16px}",
    ".vja *{box-sizing:border-box}",
    ".vja-bar{display:flex;align-items:center;gap:1rem;padding:.875rem 1.25rem;",
    "border-bottom:1px solid var(--a-line);background:#fff;position:sticky;top:0;z-index:5}",
    ".vja-bar h1{font-size:1rem;margin:0;font-weight:600}",
    ".vja-bar .vja-who{margin-left:auto;font-size:.8125rem;color:var(--a-mut)}",
    ".vja-wrap{max-width:62rem;margin:0 auto;padding:1.5rem 1.25rem 4rem}",
    ".vja-wide{max-width:72rem}",

    /* sign in */
    ".vja-signin{max-width:22rem;margin:4rem auto;padding:2rem;border:1px solid var(--a-line);",
    "border-radius:.5rem;background:#fff}",
    ".vja-signin h2{margin:0 0 .375rem;font-size:1.125rem}",
    ".vja-signin p{margin:0 0 1.5rem;font-size:.875rem;color:var(--a-mut)}",
    /* .vja-signin p above would otherwise turn the error grey and lose it. */
    ".vja-signin .vja-err{color:var(--a-bad);margin:.75rem 0 0;font-size:.8125rem}",

    ".vja-f{margin-bottom:1rem}",
    ".vja-f label{display:block;font-size:.8125rem;font-weight:500;margin-bottom:.375rem}",
    ".vja-f input,.vja-f select,.vja-f textarea{width:100%;padding:.5rem .625rem;font-size:.875rem;",
    "font-family:inherit;border:1px solid #cbd5e1;border-radius:.375rem;background:#fff;color:var(--a-ink)}",
    ".vja-f input:focus,.vja-f select:focus,.vja-f textarea:focus{outline:2px solid var(--a-teal);",
    "outline-offset:-1px;border-color:var(--a-teal)}",
    ".vja-btn{border-radius:.375rem;padding:.5rem 1rem;font-size:.875rem;font-weight:500;",
    "font-family:inherit;cursor:pointer;border:1px solid transparent;background:var(--a-teal);color:#fff}",
    ".vja-btn:hover{background:#115e59}",
    ".vja-btn[disabled]{opacity:.55;cursor:default}",
    ".vja-btn-q{background:#fff;color:var(--a-ink);border-color:#cbd5e1}",
    ".vja-btn-q:hover{background:var(--a-bg)}",
    ".vja-err{color:var(--a-bad);font-size:.8125rem;margin:.5rem 0 0}",
    ".vja-note-msg{font-size:.8125rem;color:var(--a-mut);margin:.5rem 0 0}",

    /* list */
    ".vja-tools{display:flex;gap:.75rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:1.25rem}",
    ".vja-tools .vja-f{margin:0}",
    ".vja-tools .vja-f:first-child{flex:1 1 16rem}",
    ".vja-table{width:100%;border-collapse:collapse;font-size:.875rem;background:#fff;",
    "border:1px solid var(--a-line);border-radius:.5rem;overflow:hidden}",
    ".vja-table th{text-align:left;font-size:.75rem;text-transform:uppercase;letter-spacing:.04em;",
    "color:var(--a-mut);font-weight:600;padding:.625rem .875rem;border-bottom:1px solid var(--a-line);",
    "background:var(--a-bg);white-space:nowrap}",
    ".vja-table td{padding:.75rem .875rem;border-top:1px solid var(--a-line);vertical-align:top}",
    ".vja-table tbody tr:hover{background:var(--a-bg)}",
    "@media (max-width:40rem){.vja-table{display:block;overflow-x:auto;max-width:100%}.vja-table th:nth-child(4),.vja-table td:nth-child(4){display:none}.vja-table th,.vja-table td{padding:.5rem}}",
    ".vja-table a{color:var(--a-teal);font-weight:500;text-decoration:none}",
    ".vja-table a:hover{text-decoration:underline}",
    ".vja-ref{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.8125rem}",
    ".vja-empty{padding:3rem 1rem;text-align:center;color:var(--a-mut);font-size:.875rem;",
    "border:1px dashed var(--a-line);border-radius:.5rem}",

    /* status pill */
    ".vja-pill{display:inline-block;padding:.1875rem .5rem;border-radius:1rem;font-size:.75rem;",
    "font-weight:500;white-space:nowrap;border:1px solid var(--a-line);background:#fff;color:var(--a-mut)}",
    ".vja-pill-new{border-color:#99f6e4;background:#f0fdfa;color:#115e59}",
    ".vja-pill-review{border-color:#bfdbfe;background:#eff6ff;color:#1e40af}",
    ".vja-pill-client{border-color:#fde68a;background:#fffbeb;color:#92400e}",
    ".vja-pill-ready{border-color:#bbf7d0;background:#f0fdf4;color:#166534}",
    ".vja-pill-filed{border-color:#e2e8f0;background:#f8fafc;color:#475569}",

    /* detail */
    ".vja-head{display:flex;gap:1rem;align-items:flex-start;flex-wrap:wrap;margin-bottom:1.5rem}",
    ".vja-head h2{margin:0 0 .25rem;font-size:1.375rem}",
    ".vja-head .vja-sub{font-size:.8125rem;color:var(--a-mut);margin:0}",
    ".vja-actions{margin-left:auto;display:flex;gap:.5rem;align-items:center;flex-wrap:wrap}",
    ".vja-cols{display:grid;grid-template-columns:1fr 19rem;gap:2rem;align-items:start}",
    "@media (max-width:52rem){.vja-cols{grid-template-columns:1fr}}",
    ".vja-side{position:sticky;top:5rem;display:flex;flex-direction:column;gap:1.25rem}",
    ".vja-card{border:1px solid var(--a-line);border-radius:.5rem;background:#fff;padding:1rem}",
    ".vja-card h3{margin:0 0 .75rem;font-size:.8125rem;text-transform:uppercase;",
    "letter-spacing:.04em;color:var(--a-mut);font-weight:600}",
    ".vja-photo img{width:100%;border-radius:.375rem;border:1px solid var(--a-line);display:block}",

    ".vja-step{margin-bottom:2rem;border:1px solid var(--a-line);border-radius:.5rem;background:#fff;",
    "overflow:hidden;break-inside:avoid}",
    ".vja-step > h3{margin:0;padding:.75rem 1rem;background:var(--a-bg);font-size:.9375rem;",
    "border-bottom:1px solid var(--a-line);display:flex;gap:.5rem;align-items:baseline}",
    ".vja-step > h3 span{font-size:.75rem;color:var(--a-mut);font-weight:400}",
    ".vja-sub-h{margin:0;padding:.625rem 1rem .25rem;font-size:.8125rem;font-weight:600;color:var(--a-mut)}",
    ".vja-qa{display:grid;grid-template-columns:22rem 1fr;gap:1rem;padding:.625rem 1rem;",
    "border-top:1px solid #f1f5f9;font-size:.875rem;break-inside:avoid}",
    "@media (max-width:40rem){.vja-qa{grid-template-columns:1fr;gap:.125rem}}",
    ".vja-qa:first-of-type{border-top:0}",
    ".vja-q{color:var(--a-mut)}",
    ".vja-a{color:var(--a-ink);word-break:break-word}",
    ".vja-a-none{color:#94a3b8;font-style:italic}",
    ".vja-code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.75rem;",
    "color:var(--a-mut);margin-left:.375rem}",
    ".vja-rowset{margin:.25rem 0 0;padding:0;list-style:none}",
    ".vja-rowset li{padding:.1875rem 0}",
    ".vja-official{display:inline-block;width:.375rem;height:.375rem;border-radius:50%;",
    "background:var(--a-teal);margin-right:.375rem;vertical-align:.1rem}",

    ".vja-notes{list-style:none;margin:0 0 1rem;padding:0;font-size:.8125rem}",
    ".vja-notes li{padding:.625rem 0;border-top:1px solid var(--a-line)}",
    ".vja-notes li:first-child{border-top:0;padding-top:0}",
    ".vja-notes .vja-meta{color:var(--a-mut);font-size:.75rem;margin-bottom:.1875rem}",
    ".vja-notes p{margin:0;white-space:pre-wrap}",

    ".vja-cardline{margin:0 0 .25rem;font-size:.875rem;font-weight:500}",
    ".vja-meta{color:var(--a-mut);font-size:.75rem;margin:0 0 .75rem;line-height:1.5}",
    ".vja-paid{margin:0 0 .5rem;font-size:.8125rem;color:#166534;background:#f0fdf4;",
    "border:1px solid #bbf7d0;border-radius:.375rem;padding:.5rem .625rem;line-height:1.5}",
    ".vja-warn{margin:0 0 .75rem;font-size:.75rem;color:#92400e;background:#fffbeb;",
    "border:1px solid #fde68a;border-radius:.375rem;padding:.5rem .625rem;line-height:1.5}",

    /* the full card number, while it is revealed */
    ".vja-cardline .vja-dots{letter-spacing:.06em}",
    ".vja-pan{margin:0 0 .75rem;padding:.75rem;border:1px solid #fde68a;background:#fffbeb;",
    "border-radius:.375rem}",
    ".vja-pan-num{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:1.0625rem;",
    "font-weight:600;letter-spacing:.06em;word-spacing:.2em;white-space:nowrap;margin:0 0 .5rem;",
    "font-variant-numeric:tabular-nums;color:var(--a-ink)}",
    ".vja-pan dl{display:grid;grid-template-columns:auto 1fr;gap:.125rem .75rem;margin:0 0 .625rem;",
    "font-size:.8125rem}",
    ".vja-pan dt{color:var(--a-mut)}",
    ".vja-pan dd{margin:0;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}",
    ".vja-pan-tools{display:flex;gap:.5rem;align-items:center;flex-wrap:wrap}",
    ".vja-pan-tools .vja-btn{padding:.3125rem .75rem;font-size:.8125rem}",
    ".vja-pan-clock{font-size:.75rem;color:#92400e;margin-left:auto}",
    ".vja-reveal{margin:0 0 .75rem;padding:.3125rem .75rem;font-size:.8125rem}",
    ".vja-mark{border-top:1px solid var(--a-line);margin-top:.75rem;padding-top:.75rem}",
    ".vja-mark .vja-f{margin-bottom:.625rem}",
    ".vja-mark-row{display:grid;grid-template-columns:1fr 1fr;gap:.5rem}",

    ".vja-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}",

    /* print: the admin is retyping this into the DS-160, so give them the
       answers and nothing else. */
    "@media print{",
    ".vja-bar,.vja-actions,.vja-side,.vja-back,.vja-noprint{display:none!important}",
    /* The side panel is already hidden above, so the card never prints today.
       Named again on its own in case someone brings the side panel back into
       print: a card number on paper cannot be logged, re-masked or purged.
       The number is also wiped from the page on beforeprint. */
    ".vja-pan,.vja-pan-num,.vja-reveal,.vja-cardline{display:none!important}",
    ".vja-wrap{max-width:none;padding:0}",
    ".vja-cols{display:block}",
    ".vja-step{border:0;margin-bottom:1rem;page-break-inside:auto}",
    ".vja-step > h3{background:none;border-bottom:1px solid #000;padding-left:0}",
    ".vja-qa{padding-left:0;padding-right:0}",
    ".vja{font-size:11pt}",
    "}",
  ].join("");

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  /* The form already ships these. Falling back keeps admin.js testable on its
     own, but in the browser the form is always there: it owns VJ_SCHEMA. */
  var base = (typeof VisaJourneyForm !== "undefined") ? VisaJourneyForm : null;

  function el(tag, attrs, children) {
    if (base && base.el) return base.el(tag, attrs, children);
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === "class") node.className = v;
        else if (k === "text") node.textContent = v;
        else if (k.slice(0, 2) === "on") node.addEventListener(k.slice(2).toLowerCase(), v);
        else node.setAttribute(k, v === true ? "" : v);
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  /* ------------------------------------------------------------ values ---- */

  var MONTHS = ["January", "February", "March", "April", "May", "June", "July",
                "August", "September", "October", "November", "December"];

  /* Dates are stored yyyy-mm-dd. Written out in full because 03/04 means two
     different days depending on who is reading it, and this form is filled in
     from everywhere. */
  function readableDate(v) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(v || ""));
    if (!m) return String(v || "");
    var month = MONTHS[Number(m[2]) - 1];
    if (!month) return String(v);
    return Number(m[3]) + " " + month + " " + m[1];
  }

  function readableDateTime(v) {
    if (!v) return "";
    var d = new Date(v);
    if (isNaN(d.getTime())) return String(v);
    var hh = d.getHours(), mm = d.getMinutes();
    return d.getDate() + " " + MONTHS[d.getMonth()].slice(0, 3) + " " + d.getFullYear() +
           ", " + (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
  }

  /* The DS-160 uses its own codes for country and occupation. The admin is
     retyping into that form, so show the code beside the answer rather than
     making them look it up. */
  function officialCode(fieldId, value) {
    if (!base) return "";
    var v = String(value || "").toUpperCase();
    if (base.OCCUPATION_CODES && /occupation/i.test(fieldId) && base.OCCUPATION_CODES[v]) {
      return base.OCCUPATION_CODES[v];
    }
    if (base.COUNTRY_CODES && base.COUNTRY_CODES[v]) return base.COUNTRY_CODES[v];
    return "";
  }

  function isBlank(v) { return v === null || v === undefined || String(v).trim() === ""; }

  /* One answer, as the admin should read it. Returns null when the question
     was never put to this applicant. */
  function answerFor(f, data) {
    if (f.na && data[f.na.key]) return { text: f.na.label || "Does not apply", muted: true };

    if (f.type === "ssn") {
      var parts = [data[f.id + "1"], data[f.id + "2"], data[f.id + "3"]];
      if (parts.every(isBlank)) return { text: "Not answered", muted: true };
      return { text: parts.map(function (p) { return isBlank(p) ? "?" : p; }).join("-") };
    }

    if (f.type === "consent") {
      return data[f.id] ? { text: "Confirmed" } : { text: "Not confirmed", muted: true };
    }

    var v = data[f.id];

    if (f.type === "file") {
      if (isBlank(v)) return { text: "No photograph uploaded", muted: true };
      return { text: data[f.id + "Name"] || "Photograph uploaded" };
    }

    if (isBlank(v)) return { text: "Not answered", muted: true };
    if (f.type === "date") return { text: readableDate(v) };

    return { text: String(v), code: f.official ? officialCode(f.id, v) : officialCode(f.id, v) };
  }

  /* A repeat block: each row summarised on its own line. */
  function repeatRows(f, data) {
    var rows = data[f.key];
    if (!rows || !rows.length) return null;
    var out = [];
    rows.forEach(function (row) {
      var bits = [];
      (f.fields || []).forEach(function (sub) {
        if (!sub.id) return;
        if (sub.na && row[sub.na.key]) { bits.push(sub.na.label || "does not apply"); return; }
        var v = row[sub.id];
        if (isBlank(v)) return;
        bits.push((sub.label ? sub.label + ": " : "") +
                  (sub.type === "date" ? readableDate(v) : String(v)));
      });
      if (bits.length) out.push(bits.join(" · "));
    });
    return out.length ? out : null;
  }

  /* ------------------------------------------------------- detail render ---- */

  /* Never render this, whatever arrives. The server stores it as a hash and has
     no reason to send it; if a misconfigured endpoint ever does, it stops here. */
  var NEVER_SHOWN = ["securityAnswer", "securityAnswerConfirm"];

  function qa(question, answer, code, official) {
    var q = el("div", { class: "vja-q" }, [
      official ? el("span", { class: "vja-official", "aria-hidden": "true" }) : null,
      question,
    ]);
    var a = el("div", { class: "vja-a" + (answer.muted ? " vja-a-none" : "") },
               [answer.text]);
    if (code) a.appendChild(el("span", { class: "vja-code", text: "DS-160: " + code }));
    return el("div", { class: "vja-qa" }, [q, a]);
  }

  /* Walks VJ_SCHEMA rather than the answer object, which is the whole point:
     questions appear in the order the applicant met them, under the step
     headings they saw, with the exact labels they read, and a question that was
     asked and left blank still shows as asked. Walking the answers instead would
     silently drop every unanswered question, which is the one thing a reviewer
     most needs to see. */
  function renderAnswers(data) {
    var wrap = el("div", { class: "vja-answers" });
    var steps = (typeof VJ_SCHEMA !== "undefined" && VJ_SCHEMA.STEPS) || [];

    steps.forEach(function (step, index) {
      if (step.isReview) return;

      var body = el("div");
      var shown = 0;
      var pendingHeading = null;

      (step.fields || []).forEach(function (f) {
        if (f.type === "note" || f.type === "warn") return;
        if (f.type === "heading") { pendingHeading = f.text; return; }

        /* showIf is the applicant's own path through the form. A question they
           were never shown is not an unanswered question, so it is left out
           rather than listed as blank. */
        if (f.showIf) {
          var visible = false;
          try { visible = !!f.showIf(data); } catch (err) { visible = false; }
          if (!visible) return;
        }

        if (f.type === "repeat") {
          var rows = repeatRows(f, data);
          if (pendingHeading) {
            body.appendChild(el("h4", { class: "vja-sub-h", text: pendingHeading }));
            pendingHeading = null;
          }
          var list = el("ul", { class: "vja-rowset" });
          (rows || []).forEach(function (line) { list.appendChild(el("li", { text: line })); });
          var cell = rows ? list : el("div", { class: "vja-a vja-a-none", text: "None given" });
          body.appendChild(el("div", { class: "vja-qa" }, [
            el("div", { class: "vja-q" }, [f.itemLabel ? f.itemLabel + "s" : "Entries"]),
            rows ? el("div", { class: "vja-a" }, [cell]) : cell,
          ]));
          shown++;
          return;
        }

        if (!f.id || NEVER_SHOWN.indexOf(f.id) !== -1) return;

        if (pendingHeading) {
          body.appendChild(el("h4", { class: "vja-sub-h", text: pendingHeading }));
          pendingHeading = null;
        }

        var ans = answerFor(f, data);
        body.appendChild(qa(f.label || f.id, ans, ans.code, f.official));
        shown++;
      });

      if (!shown) return;

      wrap.appendChild(el("section", { class: "vja-step" }, [
        el("h3", {}, [step.label || step.id,
                      el("span", { text: "Step " + (index + 1) + " of " + steps.length })]),
        body,
      ]));
    });

    return wrap;
  }

  /* --------------------------------------------------------------- status ---- */

  var STATUSES = ["New", "In review", "Waiting on client", "Ready to file", "Filed"];

  var PILL = {
    "New": "vja-pill-new",
    "In review": "vja-pill-review",
    "Waiting on client": "vja-pill-client",
    "Ready to file": "vja-pill-ready",
    "Filed": "vja-pill-filed",
  };

  function pill(status) {
    return el("span", { class: "vja-pill " + (PILL[status] || ""), text: status || "Unknown" });
  }

  /* ------------------------------------------------------------- payment ---- */

  function money(amount, currency) {
    if (amount == null) return "";
    var n = Number(amount);
    if (isNaN(n)) return String(amount);
    return (currency === "GBP" ? "\u00a3" : currency === "EUR" ? "\u20ac" : "$") +
           n.toFixed(2).replace(/\.00$/, "");
  }

  /* A card saved months before an interview can expire before anyone charges
     it, so the admin works this out rather than waiting for a decline. */
  function cardExpired(card) {
    if (!card || !card.expMonth || !card.expYear) return false;
    var now = new Date();
    var y = Number(card.expYear), m = Number(card.expMonth);
    if (y < 100) y += 2000;
    return y < now.getFullYear() ||
           (y === now.getFullYear() && m < now.getMonth() + 1);
  }

  function expiryText(month, year) {
    if (!month || !year) return "";
    var mm = String(month).length < 2 ? "0" + month : String(month);
    return mm + "/" + String(year).slice(-2);
  }

  /* Masked the way the number will look when revealed, so the admin can see
     which four digits they are going to get without revealing anything. */
  function cardLine(card) {
    if (!card || !card.last4) return null;
    var bits = [(card.brand || "Card") + " \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 \u2022\u2022\u2022\u2022 " + card.last4];
    if (card.expMonth && card.expYear) bits.push("expires " + expiryText(card.expMonth, card.expYear));
    return bits.join(", ");
  }

  /* Groups of four, whatever the brand. That is what the admin types into
     the other processor's terminal, and fours are what it expects. */
  function groupedNumber(number) {
    return String(number || "").replace(/\D/g, "").replace(/(\d{4})(?=\d)/g, "$1 ");
  }

  function todayIso() {
    var d = new Date();
    return d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1) +
           "-" + (d.getDate() < 10 ? "0" : "") + d.getDate();
  }

  /* The clipboard API needs a secure context, which production is. The
     fallback covers a plain-http preview. Either way the number then sits in
     the clipboard until something else is copied, which is outside anything
     this page can control: copy it, paste it into the processor, move on. */
  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed"; ta.style.top = "-1000px"; ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      var done = false;
      try { done = document.execCommand("copy"); } catch (e) { done = false; }
      ta.value = "";
      document.body.removeChild(ta);
      if (done) resolve(); else reject(new Error("copy failed"));
    });
  }

  /* ----------------------------------------------------------------- mount ---- */

  function mount(container, options) {
    options = options || {};
    injectStyles();
    container.className = (container.className || "") + " vja";

    var statuses = options.statuses || STATUSES;
    /* One admin account: { email, name }. email is what the bar shows, name
       is what goes on notes and activity ("Admin"). See onSignIn above. */
    var state = { admin: options.admin || null, filter: { query: "", status: "" } };

    function adminName() { return (state.admin && state.admin.name) || "Admin"; }

    /* -------------------------------------------------- revealed card --
       Deliberately not in `state`. While a number is on screen, the only
       copies are the text in the page and one variable inside the payment
       panel. hideCard() wipes both, and every way off this screen calls it:
       the 60 second timer, the Hide button, navigation, sign out, printing
       and closing the page. seq stops a reveal that answers late from
       drawing a number onto a screen the admin has already left. */
    var REVEAL_SECONDS = 60;
    var reveal = { seq: 0, timer: null, tick: null, wipe: null };

    function hideCard() {
      reveal.seq++;
      if (reveal.timer) clearTimeout(reveal.timer);
      if (reveal.tick) clearInterval(reveal.tick);
      reveal.timer = reveal.tick = null;
      var wipe = reveal.wipe;
      reveal.wipe = null;
      if (wipe) wipe();
    }

    window.addEventListener("pagehide", hideCard);
    window.addEventListener("beforeprint", hideCard);

    function call(name, arg) {
      var fn = options[name];
      if (typeof fn !== "function") {
        return Promise.reject(new Error("No " + name + " callback was supplied."));
      }
      try { return Promise.resolve(fn(arg)); }
      catch (err) { return Promise.reject(err); }
    }

    function shell(bodyNode, wide) {
      clear(container);
      if (state.admin) {
        container.appendChild(el("div", { class: "vja-bar" }, [
          el("h1", { text: "Visa Journey USA admin" }),
          el("span", { class: "vja-who", text: "Signed in as " + (state.admin.email || adminName()) }),
          el("button", {
            class: "vja-btn vja-btn-q", type: "button", text: "Sign out",
            onclick: function () {
              hideCard();
              call("onSignOut").catch(function () {}).then(function () {
                state.admin = null;
                location.hash = "";
                renderSignIn();
              });
            },
          }),
        ]));
      }
      container.appendChild(el("div", { class: "vja-wrap" + (wide ? " vja-wide" : "") },
                               [bodyNode]));
    }

    /* ------------------------------------------------------------ sign in -- */

    /* Sign in is two steps, and they are deliberately separate calls.

       Step one sends the email and password. Step two sends only the
       six-digit code. The password is never held in this page's memory
       between the two, and never travels a second time: the server answers
       step one by setting a short-lived half session, and step two upgrades
       that to a real one. PCI DSS requires a second factor for any access to
       card data, and this login can reveal card numbers, which is why this
       exists at all.

       The session carries two flags and they answer different questions.
       mfa_passed means the sign in finished. second_factor means a code was
       actually presented. The card-reveal route must check SECOND_FACTOR.

       The difference is the server with no TOTP secret configured yet: it
       resolves step one with { email, name } and no mfaRequired, and this page
       signs straight in, so the password step can ship before the TOTP step is
       built. That session has mfa_passed = 1 and second_factor = 0. They were
       one flag until an audit found that the reveal route, written as it was
       then documented, would have returned a full card number to a
       password-only session.

       The reveal route is the one thing that must not be switched on until the
       second factor is enrolled. */

    function renderSignIn(message) {
      var email = el("input", { type: "email", id: "vja-email", autocomplete: "username" });
      var pass = el("input", { type: "password", id: "vja-pass", autocomplete: "current-password" });
      var err = el("p", { class: "vja-err", text: message || "", hidden: !message });
      var btn = el("button", { class: "vja-btn", type: "submit", text: "Sign in" });

      var form = el("form", {
        class: "vja-signin",
        onsubmit: function (e) {
          e.preventDefault();
          err.hidden = true;
          btn.disabled = true;
          btn.textContent = "Signing in...";
          call("onSignIn", { email: email.value.trim(), password: pass.value })
            .then(function (who) {
              /* The server asks for the code by answering the password step
                 with mfaRequired. Nothing is signed in yet at this point. */
              if (who && who.mfaRequired) {
                renderMfa(email.value.trim());
                return;
              }
              state.admin = {
                email: (who && who.email) || email.value.trim().toLowerCase(),
                name: (who && who.name) || "Admin",
              };
              route();
            })
            .catch(function (e2) {
              btn.disabled = false;
              btn.textContent = "Sign in";
              err.textContent = (e2 && e2.userMessage) ||
                "Those details were not recognised.";
              err.hidden = false;
              pass.value = "";
              pass.focus();
            });
        },
      }, [
        el("h2", { text: "Admin sign in" }),
        el("p", { text: "This is separate from the applicant login. Applicant reference numbers do not work here." }),
        el("div", { class: "vja-f" }, [el("label", { "for": "vja-email", text: "Email" }), email]),
        el("div", { class: "vja-f" }, [el("label", { "for": "vja-pass", text: "Password" }), pass]),
        btn,
        err,
      ]);

      shell(form);
      email.focus();
    }

    /* Step two. The password is gone by the time this renders. */
    function renderMfa(signingInAs, message) {
      /* inputmode numeric brings up the number pad on a phone;
         autocomplete one-time-code lets iOS and Android offer the code from
         the authenticator app. No maxlength: a recovery code is longer than
         six characters and goes in the same box. */
      var code = el("input", {
        type: "text", id: "vja-code-input", inputmode: "numeric",
        autocomplete: "one-time-code", autocapitalize: "off",
        spellcheck: "false", "aria-describedby": "vja-code-hint",
      });
      var err = el("p", { class: "vja-err", text: message || "", hidden: !message });
      var btn = el("button", { class: "vja-btn", type: "submit", text: "Verify" });

      var form = el("form", {
        class: "vja-signin",
        onsubmit: function (e) {
          e.preventDefault();
          var value = code.value.replace(/\s+/g, "");
          if (!value) { code.focus(); return; }
          err.hidden = true;
          btn.disabled = true;
          btn.textContent = "Checking...";
          call("onVerifyCode", { code: value })
            .then(function (who) {
              state.admin = {
                email: (who && who.email) || signingInAs.toLowerCase(),
                name: (who && who.name) || "Admin",
              };
              route();
            })
            .catch(function (e2) {
              btn.disabled = false;
              btn.textContent = "Verify";
              /* A wrong code says so plainly: the password already succeeded,
                 so there is nothing left to keep ambiguous, and a vague
                 message here only gets the right person stuck. A lockout is
                 different and says what to do. */
              var c = e2 && e2.code;
              err.textContent =
                c === "locked"
                  ? ((e2 && e2.userMessage) ||
                     "Too many attempts. Wait a few minutes and start again.")
                : c === "expired"
                  ? "That took too long. Enter your password again."
                : (e2 && e2.userMessage) ||
                  "That code was not right. Check the app and try the current one.";
              err.hidden = false;
              code.value = "";
              code.focus();
            });
        },
      }, [
        el("h2", { text: "Enter your code" }),
        el("p", { id: "vja-code-hint",
          text: "Open your authenticator app and type the six-digit code for " +
                signingInAs + ". A recovery code works here too." }),
        el("div", { class: "vja-f" }, [
          el("label", { "for": "vja-code-input", text: "Six-digit code" }), code,
        ]),
        btn,
        err,
        el("p", { class: "vja-note-msg" }, [
          el("a", {
            href: "#", text: "Start again",
            onclick: function (ev) { ev.preventDefault(); renderSignIn(); },
          }),
        ]),
      ]);

      shell(form);
      code.focus();
    }

    /* --------------------------------------------------------------- list -- */

    function renderList() {
      var search = el("input", {
        type: "search", id: "vja-search", value: state.filter.query,
        placeholder: "Reference or surname",
      });
      var status = el("select", { id: "vja-status" }, [el("option", { value: "", text: "Any status" })]
        .concat(statuses.map(function (s) {
          return el("option", { value: s, text: s, selected: state.filter.status === s });
        })));

      var results = el("div", { class: "vja-results" }, [
        el("div", { class: "vja-empty", text: "Loading applications..." }),
      ]);

      function load() {
        state.filter.query = search.value.trim();
        state.filter.status = status.value;
        call("onList", { query: state.filter.query, status: state.filter.status })
          .then(function (res) {
            var rows = (res && res.applications) || [];
            clear(results);
            if (!rows.length) {
              results.appendChild(el("div", {
                class: "vja-empty",
                text: state.filter.query || state.filter.status
                  ? "No applications match that."
                  : "No applications yet.",
              }));
              return;
            }
            var tbody = el("tbody");
            rows.forEach(function (r) {
              tbody.appendChild(el("tr", {}, [
                el("td", {}, [el("a", {
                  class: "vja-ref", href: "#/a/" + encodeURIComponent(r.reference),
                  text: r.reference,
                })]),
                el("td", { text: r.applicantName || "Not yet named" }),
                el("td", {}, [pill(r.status)]),
                el("td", { text: typeof r.stepIndex === "number" ? (r.stepIndex + 1) + " of 22" : "" }),
                el("td", { text: readableDateTime(r.updatedAt) }),
              ]));
            });
            results.appendChild(el("table", { class: "vja-table" }, [
              el("thead", {}, [el("tr", {}, [
                el("th", { text: "Reference" }), el("th", { text: "Applicant" }),
                el("th", { text: "Status" }), el("th", { text: "Step" }),
                el("th", { text: "Updated" }),
              ])]),
              tbody,
            ]));
          })
          .catch(function (e) {
            clear(results);
            results.appendChild(el("div", { class: "vja-empty", text: "Could not load: " + e.message }));
          });
      }

      var timer = null;
      search.addEventListener("input", function () {
        clearTimeout(timer);
        timer = setTimeout(load, 200);
      });
      status.addEventListener("change", load);

      shell(el("div", {}, [
        el("div", { class: "vja-tools" }, [
          el("div", { class: "vja-f" }, [
            el("label", { "for": "vja-search", text: "Search" }), search,
          ]),
          el("div", { class: "vja-f" }, [
            el("label", { "for": "vja-status", text: "Status" }), status,
          ]),
        ]),
        results,
      ]), true);

      load();
    }

    /* ------------------------------------------------------------- detail -- */

    function renderDetail(reference) {
      hideCard();
      shell(el("div", { class: "vja-empty", text: "Loading application..." }), true);

      call("onGet", reference).then(function (app) {
        if (!app) throw new Error("not found");
        var data = app.data || {};
        NEVER_SHOWN.forEach(function (k) { delete data[k]; });

        var statusSel = el("select", { id: "vja-setstatus" },
          statuses.map(function (s) {
            return el("option", { value: s, text: s, selected: app.status === s });
          }));
        var statusMsg = el("span", { class: "vja-note-msg" });

        statusSel.addEventListener("change", function () {
          statusSel.disabled = true;
          statusMsg.textContent = "Saving...";
          call("onSetStatus", { reference: reference, status: statusSel.value })
            .then(function () { statusMsg.textContent = "Saved"; })
            .catch(function (e) { statusMsg.textContent = "Not saved: " + e.message; })
            .then(function () { statusSel.disabled = false; });
        });

        /* notes */
        var noteList = el("ul", { class: "vja-notes" });
        function drawNotes(notes) {
          clear(noteList);
          if (!notes || !notes.length) {
            noteList.appendChild(el("li", {}, [
              el("p", { class: "vja-a-none", text: "No notes yet." })]));
            return;
          }
          notes.forEach(function (n) {
            noteList.appendChild(el("li", {}, [
              el("div", { class: "vja-meta",
                          text: (n.author || "Unknown") + " · " + readableDateTime(n.at) }),
              el("p", { text: n.body }),
            ]));
          });
        }
        drawNotes(app.notes);

        var noteBox = el("textarea", { id: "vja-note", rows: "3",
                                       placeholder: "What was discussed, what is outstanding" });
        var noteBtn = el("button", { class: "vja-btn", type: "submit", text: "Add note" });
        var noteErr = el("p", { class: "vja-err", hidden: true });

        var noteForm = el("form", {
          class: "vja-noprint",
          onsubmit: function (e) {
            e.preventDefault();
            var body = noteBox.value.trim();
            if (!body) { noteBox.focus(); return; }
            noteBtn.disabled = true;
            noteErr.hidden = true;
            call("onAddNote", { reference: reference, body: body })
              .then(function (note) {
                app.notes = (app.notes || []).concat([
                  note || { author: adminName(), at: new Date().toISOString(), body: body }]);
                drawNotes(app.notes);
                noteBox.value = "";
              })
              .catch(function (e2) {
                noteErr.textContent = "Not saved: " + e2.message;
                noteErr.hidden = false;
              })
              .then(function () { noteBtn.disabled = false; });
          },
        }, [
          el("div", { class: "vja-f" }, [
            el("label", { "for": "vja-note", class: "vja-sr", text: "New note" }), noteBox,
          ]),
          noteBtn, noteErr,
        ]);

        var activity = el("ul", { class: "vja-notes" });
        function drawActivity() {
          clear(activity);
          ((app.activity && app.activity.length) ? app.activity : []).forEach(function (a) {
            activity.appendChild(el("li", {}, [
              el("div", { class: "vja-meta",
                          text: (a.author || "Unknown") + " · " + readableDateTime(a.at) }),
              el("p", { text: a.action }),
            ]));
          });
          if (!activity.firstChild) {
            activity.appendChild(el("li", {}, [
              el("p", { class: "vja-a-none", text: "Nothing recorded yet." })]));
          }
        }
        drawActivity();

        function logActivity(action) {
          app.activity = (app.activity || []).concat([{
            author: adminName(), at: new Date().toISOString(), action: action,
          }]);
          drawActivity();
        }

        /* ------------------------------------------------------- payment -- */
        /* The applicant authorised this card at the end of the form and was not
           charged. The fee is taken later on a separate processor, so this
           panel does three things: shows the full number on request, with a
           log entry each time, records the charge once it has been made, and
           (when onCharge is supplied) can still charge a saved card directly. */
        function paymentCard() {
          var pay = app.payment || {};
          var card = pay.card || null;
          var box = el("div", { class: "vja-card" }, [el("h3", { text: "Payment" })]);

          if (!card) {
            box.appendChild(el("p", { class: "vja-a-none",
              text: "No card on file. The applicant has not reached the card step yet, or left without completing it." }));
            return box;
          }

          /* onGet should never carry these. If it does, they go before
             anything is drawn, so the number only ever appears through a
             logged reveal. */
          delete card.number; delete card.cvc; delete card.cvv;

          var stored = typeof options.onRevealCard === "function";
          var onFile = stored && card.numberOnFile !== false && pay.status !== "paid";

          box.appendChild(el("p", { class: "vja-cardline",
            "aria-label": (card.brand || "Card") + " ending " + card.last4 +
              (card.expMonth && card.expYear ? ", expires " + expiryText(card.expMonth, card.expYear) : ""),
            text: cardLine(card) }));
          box.appendChild(el("p", { class: "vja-meta",
            text: !stored
              ? "Held by the payment provider. We do not store the number."
              : onFile
                ? "Full number stored encrypted on our server. Every view is logged."
                : "The full number has been deleted from our server." }));

          if (onFile) box.appendChild(revealPanel());

          var amount = money(pay.amount, pay.currency);

          if (pay.status === "paid") {
            box.appendChild(el("p", { class: "vja-paid" }, [
              el("strong", { text: "Charged " + amount }),
              /* chargedOn is the day the admin recorded, with no time of day.
                 Run through a Date it would shift a day for anyone west of UTC. */
              pay.chargedOn ? " on " + readableDate(pay.chargedOn)
                : pay.chargedAt ? " on " + readableDateTime(pay.chargedAt) : "",
              pay.chargedBy ? " by " + pay.chargedBy : "",
              pay.processorReference ? el("br") : null,
              pay.processorReference ? "Processor reference " : null,
              pay.processorReference ? el("span", { class: "vja-ref", text: pay.processorReference }) : null,
            ]));
            if (pay.receiptUrl) {
              box.appendChild(el("p", {}, [el("a", {
                href: pay.receiptUrl, target: "_blank", rel: "noopener",
                text: "Open the receipt",
              })]));
            }
            /* No button once it is paid. The server refuses a second charge
               anyway, but a button that must not be pressed should not be on
               the screen. */
            return box;
          }

          if (cardExpired(card)) {
            box.appendChild(el("p", { class: "vja-warn",
              text: "This card expired while the application was open. Charging it will fail. Ask the applicant for a new card before trying." }));
          }

          if (typeof options.onCharge === "function") box.appendChild(chargeButton(pay, card, amount));
          if (typeof options.onMarkCharged === "function") box.appendChild(markForm(pay, card, amount));
          return box;
        }

        /* --------------------------------------------- reveal the number -- */
        function revealPanel() {
          var wrap = el("div", { class: "vja-noprint" });
          var msg = el("p", { class: "vja-err", role: "alert", hidden: true });

          var btn = el("button", {
            class: "vja-btn vja-btn-q vja-reveal", type: "button", text: "Show full number",
            onclick: function () {
              if (btn.disabled) return;
              btn.disabled = true;
              btn.textContent = "Loading...";
              msg.hidden = true;
              var mine = ++reveal.seq;
              call("onRevealCard", { reference: reference })
                .then(function (res) {
                  /* The admin left, or hid it, while this was in flight. */
                  if (mine !== reveal.seq || !wrap.parentNode) return;
                  var number = String((res && res.number) || "").replace(/\D/g, "");
                  if (!number) throw new Error("No card number came back.");
                  logActivity("Viewed full card number");
                  show(number, res);
                })
                .catch(function (err) {
                  if (mine !== reveal.seq) return;
                  btn.disabled = false;
                  btn.textContent = "Show full number";
                  var code = err && err.code;
                  msg.textContent =
                    code === "rate_limited"
                      ? "Too many card views in a short time. Wait a few minutes and try again."
                    : code === "not_on_file"
                      ? "The full number is no longer stored for this application."
                    : "Could not show the number: " +
                      ((err && (err.userMessage || err.message)) || "unknown error");
                  msg.hidden = false;
                });
            },
          });

          function show(number, res) {
            var left = REVEAL_SECONDS;
            var clock = el("span", { class: "vja-pan-clock", "aria-live": "off" });
            var copied = el("span", { class: "vja-note-msg", role: "status", style: "margin:0" });
            function tickText() { clock.textContent = "Hides in " + left + "s"; }

            var numNode = el("p", { class: "vja-pan-num", text: groupedNumber(number) });
            var copyBtn = el("button", {
              class: "vja-btn", type: "button", text: "Copy",
              onclick: function () {
                if (!number) return;
                copyText(number).then(function () {
                  copied.textContent = "Copied";
                }, function () {
                  copied.textContent = "Copy failed. Select the number instead.";
                });
              },
            });
            var hideBtn = el("button", {
              class: "vja-btn vja-btn-q", type: "button", text: "Hide",
              onclick: function () { hideCard(); },
            });

            var panel = el("div", { class: "vja-pan", "aria-label": "Full card number" }, [
              numNode,
              el("dl", {}, [
                el("dt", { text: "Name" }), el("dd", { text: (res && res.name) || "Not given" }),
                el("dt", { text: "Expires" }),
                el("dd", { text: expiryText(res && res.expMonth, res && res.expYear) || "Not given" }),
                /* The security code, when one is still stored. The server
                   wipes it when the charge is recorded, so after that the
                   reveal returns none. Never copied anywhere by this page. */
                el("dt", { text: "Security code (CVV)" }),
                el("dd", { class: "vja-cvv", text: (res && res.cvv) || "Not stored" }),
                el("dt", { text: "Postal code" }), el("dd", { text: (res && res.postal) || "None given" }),
              ]),
              el("div", { class: "vja-pan-tools" }, [copyBtn, hideBtn, copied, clock]),
            ]);

            clear(wrap);
            wrap.appendChild(panel);
            tickText();

            reveal.tick = setInterval(function () {
              left--;
              if (left > 0) tickText();
            }, 1000);
            reveal.timer = setTimeout(hideCard, REVEAL_SECONDS * 1000);

            /* What hideCard() runs. Drops the number from the closure and the
               page, then puts the button back. */
            reveal.wipe = function () {
              number = null;
              if (res) res.cvv = "";
              res = null;
              numNode.textContent = "";
              clear(wrap);
              btn.disabled = false;
              btn.textContent = "Show full number";
              wrap.appendChild(btn);
              wrap.appendChild(msg);
            };
          }

          wrap.appendChild(btn);
          wrap.appendChild(msg);
          return wrap;
        }

        /* --------------------------------------------- charge, directly -- */
        /* Only drawn when onCharge is supplied: a card saved as a token with a
           processor this site can call. */
        function chargeButton(pay, card, amount) {
          var holder = el("div", {});
          var msg = el("p", { class: "vja-err", hidden: true });

          var btn = el("button", {
            class: "vja-btn", type: "button",
            text: amount ? "Charge " + amount : "Charge the fee",
            onclick: function () {
              /* Two guards against the same mistake. The button disables on the
                 first click so a double click cannot send twice, and the
                 endpoint is idempotent on the server so a retry after a timeout
                 cannot either. Either alone is not enough. */
              if (btn.disabled) return;
              if (!window.confirm(
                    "Charge " + (amount || "the fee") + " to the " +
                    (card.brand || "card") + " ending " + card.last4 + "?\n\n" +
                    "The applicant is not asked again. This takes the money now.")) {
                return;
              }
              btn.disabled = true;
              btn.textContent = "Charging...";
              msg.hidden = true;
              call("onCharge", { reference: reference })
                .then(function (res) {
                  app.payment = {
                    card: card, status: "paid",
                    amount: (res && res.amount) != null ? res.amount : pay.amount,
                    currency: pay.currency,
                    chargedAt: (res && res.chargedAt) || new Date().toISOString(),
                    chargedBy: adminName(),
                    receiptUrl: res && res.receiptUrl,
                  };
                  app.activity = (app.activity || []).concat([{
                    author: adminName(), at: new Date().toISOString(),
                    action: "Charged " + (amount || "the fee"),
                  }]);
                  renderDetail(reference);
                })
                .catch(function (err) {
                  btn.disabled = false;
                  btn.textContent = amount ? "Charge " + amount : "Charge the fee";
                  var code = err && err.code;
                  msg.textContent =
                    code === "declined"
                      ? "The card was declined. Nothing was taken. Ask the applicant for another card."
                    : code === "expired_card"
                      ? "The card has expired. Nothing was taken. Ask the applicant for a new card."
                    : code === "authentication_required"
                      ? "The applicant's bank wants them to confirm this payment. Nothing was taken. Send them a payment link so they can approve it."
                    : (err && err.userMessage) ||
                      "The charge did not go through. Nothing was taken. Try again, and check the payment provider before trying a third time.";
                  msg.hidden = false;
                });
            },
          });

          holder.appendChild(btn);
          holder.appendChild(msg);
          holder.appendChild(el("p", { class: "vja-meta", style: "margin-top:.75rem",
            text: "Charge once the application has been prepared and reviewed. The applicant authorised this and is not asked again." }));
          return holder;
        }

        /* -------------------------------------------- record the charge -- */
        /* The money is taken on the other processor, outside this screen.
           This records what was taken, when, and the processor's reference,
           so the application shows as paid and the server can purge the
           number. The amount is editable here, unlike the Charge button,
           because it records what the processor actually took; it starts at
           the fee so a typo is the exception. */
        function markForm(pay, card, amount) {
          var currency = pay.currency || "USD";
          var amt = el("input", { id: "vja-mark-amount", type: "text", inputmode: "decimal",
            value: pay.amount != null ? String(pay.amount) : "", autocomplete: "off" });
          var on = el("input", { id: "vja-mark-date", type: "date", value: todayIso(), max: todayIso() });
          var refIn = el("input", { id: "vja-mark-ref", type: "text", autocomplete: "off",
            spellcheck: "false", placeholder: "Transaction or receipt id" });
          var msg = el("p", { class: "vja-err", role: "alert", hidden: true });
          var go = el("button", { class: "vja-btn", type: "submit", text: "Mark as charged" });

          var form = el("form", {
            class: "vja-mark", hidden: true,
            onsubmit: function (e) {
              e.preventDefault();
              if (go.disabled) return;
              var value = Number(String(amt.value).replace(/[^0-9.]/g, ""));
              var problem =
                !(value > 0) ? "Enter the amount that was charged."
                : !/^\d{4}-\d{2}-\d{2}$/.test(on.value) ? "Enter the date it was charged."
                : on.value > todayIso() ? "The charge date cannot be in the future."
                : !refIn.value.trim() ? "Enter the reference the processor gave for this charge."
                : "";
              if (problem) { msg.textContent = problem; msg.hidden = false; return; }
              var shownAmount = money(value, currency);
              if (!window.confirm(
                    "Record " + shownAmount + " charged to the " + (card.brand || "card") +
                    " ending " + card.last4 + " on " + readableDate(on.value) + "?\n\n" +
                    "This marks the application as paid and deletes the stored card number. " +
                    "It does not take any money.")) {
                return;
              }
              go.disabled = true;
              go.textContent = "Saving...";
              msg.hidden = true;
              call("onMarkCharged", {
                reference: reference, amount: value, currency: currency,
                chargedOn: on.value, processorReference: refIn.value.trim(),
              })
                .then(function (res) {
                  hideCard();
                  app.payment = {
                    card: { brand: card.brand, last4: card.last4, expMonth: card.expMonth,
                            expYear: card.expYear, numberOnFile: false },
                    status: "paid",
                    amount: (res && res.amount) != null ? res.amount : value,
                    currency: currency,
                    chargedOn: on.value,
                    chargedAt: (res && res.chargedAt) || null,
                    chargedBy: adminName(),
                    processorReference: (res && res.processorReference) || refIn.value.trim(),
                  };
                  app.activity = (app.activity || []).concat([{
                    author: adminName(), at: new Date().toISOString(),
                    action: "Marked as charged " + shownAmount + " (" + refIn.value.trim() + ")",
                  }]);
                  renderDetail(reference);
                })
                .catch(function (err) {
                  go.disabled = false;
                  go.textContent = "Mark as charged";
                  msg.textContent = "Not saved: " +
                    ((err && (err.userMessage || err.message)) || "unknown error");
                  msg.hidden = false;
                });
            },
          }, [
            el("div", { class: "vja-mark-row" }, [
              el("div", { class: "vja-f" }, [
                el("label", { "for": "vja-mark-amount", text: "Amount (" + currency + ")" }), amt]),
              el("div", { class: "vja-f" }, [
                el("label", { "for": "vja-mark-date", text: "Charged on" }), on]),
            ]),
            el("div", { class: "vja-f" }, [
              el("label", { "for": "vja-mark-ref", text: "Processor reference" }), refIn]),
            go, msg,
          ]);

          var open = el("button", {
            class: "vja-btn", type: "button", text: "Mark as charged",
            onclick: function () {
              open.hidden = true;
              form.hidden = false;
              refIn.focus();
            },
          });

          return el("div", { class: "vja-noprint" }, [
            open, form,
            el("p", { class: "vja-meta", style: "margin-top:.75rem",
              text: "Charge " + (amount || "the fee") + " on the processor once the application has been prepared and reviewed, then record it here. The applicant authorised this and is not asked again." }),
          ]);
        }

        var side = el("aside", { class: "vja-side vja-noprint" }, [
          app.photoUrl ? el("div", { class: "vja-card vja-photo" }, [
            el("h3", { text: "Photograph" }),
            el("img", { src: app.photoUrl, alt: "The applicant's photograph" }),
          ]) : el("div", { class: "vja-card" }, [
            el("h3", { text: "Photograph" }),
            el("p", { class: "vja-a-none", text: "None on file. The applicant chose to bring a printed photo to the interview, or has not sent one yet." }),
          ]),
          el("div", { class: "vja-card" }, [
            el("h3", { text: "Status" }),
            el("div", { class: "vja-f" }, [statusSel]), statusMsg,
          ]),
          paymentCard(),
          el("div", { class: "vja-card" }, [
            el("h3", { text: "Notes" }), noteList, noteForm,
          ]),
          el("div", { class: "vja-card" }, [
            el("h3", { text: "Activity" }), activity,
          ]),
        ]);

        var head = el("div", { class: "vja-head" }, [
          el("div", {}, [
            el("h2", { text: app.applicantName || "Application " + reference }),
            el("p", { class: "vja-sub" }, [
              el("span", { class: "vja-ref", text: reference }),
              "  ·  started " + readableDateTime(app.createdAt) +
              (app.submittedAt ? "  ·  submitted " + readableDateTime(app.submittedAt)
                               : "  ·  not yet submitted") +
              /* Whether they electronically signed. The review step is not drawn
                 as a step, so without this the admin cannot see it at all. */
              (data.certify ? "  ·  signed by the applicant"
                            : "  ·  not signed, certification not confirmed"),
            ]),
          ]),
          el("div", { class: "vja-actions vja-noprint" }, [
            pill(app.status),
            el("button", {
              class: "vja-btn vja-btn-q", type: "button", text: "Print",
              onclick: function () { window.print(); },
            }),
          ]),
        ]);

        shell(el("div", {}, [
          el("p", { class: "vja-back vja-noprint" }, [
            el("a", { href: "#/", text: "Back to all applications" })]),
          head,
          el("div", { class: "vja-cols" }, [
            el("div", {}, [renderAnswers(data)]),
            side,
          ]),
        ]), true);
      }).catch(function (e) {
        shell(el("div", {}, [
          el("p", { class: "vja-back" }, [el("a", { href: "#/", text: "Back to all applications" })]),
          el("div", { class: "vja-empty", text: "Could not open " + reference + ": " + e.message }),
        ]), true);
      });
    }

    /* -------------------------------------------------------------- route -- */

    /* Shown for the moment it takes to ask whether a session exists. Without
       it the sign in form appears and is then replaced, which looks like the
       screen rejecting you and then changing its mind. */
    function renderRestoring() {
      hideCard();
      container.textContent = "";
      container.appendChild(el("div", { class: "vja-wrap" }, [
        el("p", { class: "vja-a-none", text: "Checking your session..." }),
      ]));
    }

    function route() {
      hideCard();
      if (!state.admin) { renderSignIn(); return; }
      var hash = (location.hash || "").replace(/^#/, "");
      var m = /^\/a\/(.+)$/.exec(hash);
      if (m) renderDetail(decodeURIComponent(m[1]));
      else renderList();
    }

    window.addEventListener("hashchange", route);

    /* Pick up a session that already exists, before deciding what to show.
     *
     * state.admin is set only by the sign in handlers, so without this every
     * page load rendered the sign in screen -- on a reload, in a second tab,
     * and when following a link to a particular application -- while the
     * session cookie sat there valid for twelve hours. A TOTP step is single
     * use, so a manager who reloaded twice inside thirty seconds could not
     * sign in again until the next code appeared. Managers read every answer
     * and come back repeatedly, so this is the main path through the screen,
     * and it was the one that did not work.
     *
     * onCurrentSession is optional: a host page that does not provide it
     * behaves as before. The callback resolves with { email, name } when a
     * session exists and rejects otherwise, and the API authorises it the same
     * way as every other admin route. Nothing here is trusted to decide
     * whether the manager is signed in; the server does that on every call. */
    if (typeof options.onCurrentSession === "function") {
      renderRestoring();
      Promise.resolve(options.onCurrentSession())
        .then(function (who) {
          if (who && who.email) {
            state.admin = { email: who.email, name: who.name || "Admin" };
          }
          route();
        })
        .catch(function () { route(); });
    } else {
      route();
    }

    return {
      refresh: route,
      signedInAs: function () { return state.admin && state.admin.email; },
    };
  }

  return {
    mount: mount,
    STATUSES: STATUSES,
    renderAnswers: renderAnswers,
    readableDate: readableDate,
    answerFor: answerFor,
  };
})();

if (typeof module !== "undefined" && module.exports) module.exports = VisaJourneyAdmin;
