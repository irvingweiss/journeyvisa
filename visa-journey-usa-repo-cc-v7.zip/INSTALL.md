# Visa Journey USA — the API

Plain PHP 7.4 or later and PDO. No framework, no composer, nothing to install.
It drops onto an ordinary host beside the static site.

**Written and tested for PHP 7.4, which is what the server runs today.** It also
runs unchanged on PHP 8.x, so upgrading the server later needs no change here.
`tests/php74_check.js` fails the build if anything PHP 8-only creeps in; see
`tests/README.md`. Please read "A word about PHP 7.4" at the end of this file
before go-live — it is a security matter, not a style preference.

**Extensions needed:** `pdo`, `pdo_mysql`, `mbstring`, `json`, `filter`. On PHP
7.4 `mbstring` is a separate package and a stock install often lacks it:

    sudo apt install php7.4-mbstring php7.4-mysql   # Debian/Ubuntu
    sudo yum install php-mbstring php-mysqlnd       # RHEL/CentOS

`index.php` checks for these on the first request and answers with the names of
any that are missing, rather than fatalling on the first `mb_strlen`. It accepts
any one of `pdo_mysql`, `pdo_sqlite` or `pdo_pgsql` and names `pdo_mysql` when
none is present, so if you are on Postgres read that message as "no PDO driver
at all".

Written against MySQL 8. For Postgres change one line in `config.php` (the DSN)
and use the Postgres notes at the top of `schema.mysql.sql`: every query here is
portable, so nothing else moves.

**What has NOT been tested, so you should be the one to check it:** every
automated check here runs against SQLite, because no MySQL server was available
where this was built. The SQL is written for MySQL 8 and the queries are
portable, but `schema.mysql.sql` and `schema.migrations.sql` have not been
loaded into a real MySQL. Step 1 below therefore ends with three `mysql`
commands that confirm the schema landed, and they are the only check anywhere
in this package that looks at a real MySQL. Run them when you get there, before
going any further: the rest of the install assumes that schema, and the failures
further down would not point back at it.

**This was tested end to end before it was sent, on SQLite.** The real admin
screen, with `DEMO` off, signed in through both steps, listed applications out
of a database, opened one, and saved a status change back — against SQLite, not
MySQL, for the reason just above. The logic and the portability are proven; the
MySQL driver and the MySQL-specific DDL are not. If something does not work
after you install it, the install is the place to look first.

You can run that test yourself in one command, before touching a server:

    php tests/api_test.php
    VJ_STRINGIFY=1 php tests/api_test.php
    python3 tests/api_contract.py

319 checks against the real API on a throwaway SQLite database, with the PHP 8
functions disabled so it runs as though on 7.4. The second run makes PDO hand
back every column as a string, which is what PHP 7.4 does, and the suite is
meant to pass both ways. The third compares the pages against the router, so a
page cannot call an endpoint that does not exist. `tests/README.md` says what
each covers and what none of them cover.

---

## What is here

    api/
      index.php            every /api/ request lands here
      config.example.php   copy to config.php and fill in
      .htaccess            Apache rewrite plus a block on config.php
      lib/Http.php         JSON in and out, no-store, origin check, tokens
      lib/Config.php       the settings, with a default for every one
      lib/Db.php           the PDO connection, UTC helpers
      lib/Guard.php        rate limiting and lockout
      lib/Totp.php         TOTP, RFC 6238, no dependency
      lib/Sessions.php     applicant and admin sessions
      routes/Application.php   the applicant endpoints
      routes/Admin.php         the admin endpoints
    tools/
      make-admin-hash.php  generates ADMIN_PASSWORD_HASH
      enrol-totp.php       generates the TOTP secret and recovery codes
    tests/
      api_test.php         the API end to end, on SQLite, 319 checks
      api_contract.py      the pages only call routes the API serves
      php74_check.js       fails if anything PHP 8-only gets in
      package.json         its one dependency; run npm install in tests/
      fixtures/            deliberately broken PHP, for the checker's self-test
      README.md            what each check covers and what it does not
    schema.mysql.sql       the database
    schema.migrations.sql  changes for a database made from an older version

`tools/` has to stay where it is, as a sibling of `api/`. `enrol-totp.php`
reaches the library and the configuration as `__DIR__ . '/../api/lib/...'` and
`__DIR__ . '/../api/config.php'`, so moving the folder — including moving it
*inside* `api/`, which looks tidier — makes it fail on its first `require`
before it can explain itself. It does not need to be inside the document root,
and should not be: run it from a shell on the server.

---

## Install

**1. Create the database** and load `schema.mysql.sql`.

    mysql -u root -p -e "CREATE DATABASE visajourney CHARACTER SET utf8mb4"
    mysql -u root -p visajourney < schema.mysql.sql

**Create the user the API connects as.** The commands above run as `root`;
the API does not. `config.example.php` expects `visajourney`:

    mysql -u root -p -e "CREATE USER IF NOT EXISTS 'visajourney'@'localhost' IDENTIFIED BY 'a-long-random-password'"
    mysql -u root -p -e "GRANT SELECT, INSERT, UPDATE, DELETE ON visajourney.* TO 'visajourney'@'localhost'"
    mysql -u root -p -e "FLUSH PRIVILEGES"

SELECT, INSERT, UPDATE and DELETE only. The API never creates or alters a
table, so there is no reason for it to be able to. Put that password in
`config.php` as `db_pass` at step 3.

`IF NOT EXISTS` is there because an install often gets as far as this and then
stops, and `CREATE USER` on an account that already exists is an error that
halts the command. Without it, re-running step 1 after a half-finished attempt
fails on a condition that is not a problem. Note that it leaves the existing
password alone rather than setting the one you just typed, so if you have
forgotten the password from the first attempt use
`ALTER USER 'visajourney'@'localhost' IDENTIFIED BY '...'` to set a new one.
`CREATE DATABASE` takes `IF NOT EXISTS` the same way if you want it.

**Now confirm the schema actually landed**, which is the check promised at the
top of this file. Nothing automated here has ever run against MySQL:

    mysql -u root -p visajourney -e "SHOW TABLES"
    mysql -u root -p visajourney -e "SHOW COLUMNS FROM admin_sessions"
    mysql -u root -p visajourney -e "SELECT * FROM admin_state"

Eight tables; `admin_sessions` with both `mfa_passed` and `second_factor`; and
one row in `admin_state` with `id = 1`. If any of those three is not right,
stop here rather than going on to step 2. The rest of the install assumes them,
and the failures further down would not point back here.

**If the database already exists** from an earlier version of this package,
load `schema.migrations.sql` instead of recreating it:

    mysql -u root -p visajourney < schema.migrations.sql

It adds the `admin_sessions.second_factor` column. Without it, signing in to
the admin screen fails with a generic 500 — at the **code step** if a TOTP
secret is enrolled, or at the password step if one is not — and the only clue
is the PHP error log, which names the column. That file says how to check
whether you need each change.

**2. Put `api/` where PHP can reach it.** Either inside the document root, or
better outside it with one rewrite pointing at `index.php`. Credentials live in
`config.php`, and a folder outside the web root cannot be served by accident.

**3. Copy `config.example.php` to `config.php`** and fill in the database
details. Every setting can come from the environment instead, which is the
better place for the credentials.

**Find the PHP error log before you go further.** Every diagnostic this API
produces goes there and nowhere else: a wrong setting type, a refused proxy
header, a `photo_dir` it will not use, a TOTP secret it cannot decode, a
`support_email` it cannot put in a mail header, and every caught exception.
None of it reaches the browser, on purpose, because a stack trace here would
quote somebody's passport number back at them. So a misconfigured install looks
like a quiet, unexplained failure until you read that file.

    php -i | grep error_log

Under PHP-FPM that is often overridden per pool, so check the pool's
`php_admin_value[error_log]` as well, in `/etc/php/7.4/fpm/pool.d/www.conf` or
wherever your distribution keeps it. If neither names a file, PHP sends the log
to the web server's own error log, which on Apache is the vhost's `ErrorLog`.
Lines from this package are prefixed `[vj]`, so `grep '\[vj\]'` finds them.

`Config::DEFAULTS` in `api/lib/Config.php` has an entry for every setting, so a
`config.php` that does not name one still loads and a setting added in a later
version cannot turn into a zero on an install whose config file predates it.

That is not the same as every setting having a *usable* default. The
credentials and the connection details default to empty, because there is no
sensible value to guess: `dsn` and `allowed_origins` stop the API outright, and
four more stop one feature each. The lists below say which is which.

**Every setting's type is checked as it loads**, against `Config::TYPES`. A
wrong type falls back to that setting's default and writes a line to the PHP
error log naming the setting, rather than being cast into something
plausible-looking. This matters because `config.php` is written by hand, and
PHP's casts turn a typo into a number instead of an error: `(int) [5]` is `1`,
so a fail limit written as `[5]` would lock the only manager out on the first
typo, and `(string) ['/photos']` is `"Array"`, so a photo directory written as
a list would write passport photographs to a relative folder called `Array`.

- A whole number of at least 1 for every limit, window and session length. A
  limit or window written as `0` is treated as a mistake for the same reason:
  `0 >= 0` is true, so a window of zero seconds refuses every request before
  checking anything.
- `service_fee` may be fractional, and must be above zero.
- `allowed_origins` must be a list of non-empty strings. A port number written
  without quotes passes `is_array` and then matches nothing, so every write
  answers 403 with nothing to say why.
- `secure_cookies` and `stringify_fetches` take `true` or `false`, and also
  accept `1`, `0`, `"true"`, `"false"`, `"yes"`, `"no"`, `"on"` and `"off"`.
  Anything else takes the default, because guessing wrong on `secure_cookies`
  would drop `Secure` from the cookie that authorises reading passport numbers.
- `photo_dir` must be an absolute path. See step 7.
- `trusted_proxy_header` must be one of four names. See below.

Two settings stop everything, so the API refuses to start without them and
names them: `dsn`, and `allowed_origins`, which must be a list rather than a
single string.

Four more stop one feature each, and each says so itself rather than blocking
the whole API — so you can test the applicant form before the admin account
exists, which is the order the steps below are in:

- `admin_email` and `admin_password_hash`: signing in answers
  `not_configured`. Step 4.
- `photo_dir`: submitting a photograph answers `bad_photo` and the log names
  the setting. Step 7. It must be an **absolute** path — Unix `/var/...`,
  Windows `C:\...` or a UNC `\\server\share`. A relative path is refused with a
  line in the log and no photograph is stored, because under PHP-FPM a relative
  path resolves against `api/` itself, which would put passport photographs
  inside the document root where anyone who guesses a filename can fetch them.
  `Config::photoDir()` is the one place this is decided, and both the write and
  the two read sites go through it.
- `support_email`: the reference-number email cannot be sent. It goes into the
  mail headers as `From:` and `Reply-To:`, so `Application::emailReference`
  checks it is a usable address before building them, and when it is not the
  applicant gets `send_failed` ("We could not send that email. Please write the
  number down.") and the log names the setting. Its default is empty, which is
  not a usable address, so the feature is off until you set it. Set it even if
  you think you do not need it: the only other thing that reads it is a line
  offering the address to an applicant who is locked out of their own
  application, and that sentence is simply left out when it is empty. It was
  described here as cosmetic for a round, which is how installs ended up with
  it unset and a reference email that silently never sent.

**`trusted_proxy_header` deserves a moment**, because getting it wrong goes
wrong in one of two opposite ways.

Every rate limit and the admin lockout are keyed on the caller's address, so
whoever controls that value controls the lockout. A client can put anything in
`X-Forwarded-For`. So the default is empty, meaning no forwarded header is
believed and the address the connection came from is used.

- **On an ordinary host, leave it empty.** Believing the header would let
  anyone guess the admin password without ever tripping the lockout, and lock
  your manager out at will by sending their address instead.
- **Behind Cloudflare, set it to `CF-Connecting-IP`. Behind your own nginx or
  a load balancer, set it to `X-Forwarded-For`.** If you leave it empty there,
  `REMOTE_ADDR` is the edge's address and **every applicant in the world
  shares one rate-limit bucket**, so the site starts answering 429 to
  everybody shortly after launch.

Name exactly one header. The setting takes one of four names and nothing else:
`X-Forwarded-For`, `CF-Connecting-IP`, `X-Real-IP` or `True-Client-IP`.
Anything else — a header this API has not heard of, or two names written into
one string, which an earlier wording of this guide invited — is refused with a
line in the log and the connection address is used instead. The whitelist is
there because `Http::ip()` has to know whether a header is *appended to* or
*set outright* before it can decide which end of the value to believe, and it
cannot know that about a name it has never seen. If your edge sets
`CF-Connecting-IP`, trusting `X-Forwarded-For` as well reopens the hole. And
the edge must strip any copy the client sent, which Cloudflare does and a
hand-rolled nginx config may not.

**If you set `X-Forwarded-For`, set `trusted_proxy_hops` as well.** It is the
number of proxies **of your own** that append to that header, and it defaults
to `1`. Only `X-Forwarded-For` reads it; the other three headers are set
outright by the edge, so there is nothing to count.

`X-Forwarded-For` is appended to, not replaced: nginx's
`proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for` and every AWS ALB
keep whatever the client sent and add the peer on the right. So `Http::ip()`
counts in from the right-hand end by `trusted_proxy_hops` entries.

- A single nginx, or a single AWS ALB, is `1` — the default. Leave it alone.
- Cloudflare in front of your own nginx is `2`.
- A proxy that *replaces* the header with the peer address
  (`proxy_set_header X-Forwarded-For $remote_addr`) leaves one value, which
  reads the same from either end, so `1` is right there too.

Both mistakes are quiet, and they fail in opposite directions. Too low and the
value read is your inner proxy's own address, identical for every visitor, so
all of them collapse into one rate-limit bucket: one person's five bad
passwords lock the only manager account out for everybody. Too high and the
value read is one the caller supplied, which hands the bucket back to them —
unlimited password guessing, and the ability to lock your manager out by
sending their address. If the header holds nothing usable, the log says so and
names both settings.

**Anything above `1` assumes your origin cannot be reached except through that
edge.** The hop count works because each of your own proxies appends on the
right, so a value a caller wrote can only ever sit further left. That stops
being true if someone can connect to your server directly, going around the
CDN: with `trusted_proxy_hops = 2` and a request sent straight to your origin
carrying its own `X-Forwarded-For`, the chain is one entry shorter than the
configuration says, and the entry two from the right is the caller's own. So if
you set this above `1`, restrict the origin to your CDN's address ranges — in a
firewall or in the web server — which is the standard advice for running behind
Cloudflare anyway. A chain *shorter* than the hop count is treated as not
matching the configuration at all and falls back to the connection address,
which is the safe direction, but that only covers the case where the header is
short; it cannot tell a genuine three-entry chain from a crafted one.

A `:port` suffix on the address is handled, for both IPv4 and a bracketed IPv6
address. IIS with Application Request Routing and Azure App Service both append
`ip:port` rather than a bare address, and this package ships an IIS
configuration, so without that the whole header was rejected as invalid, every
visitor behind that edge shared one bucket, and nothing in the log said why.

**4. Generate the admin password hash:**

    php tools/make-admin-hash.php

**At least 12 characters**, or it refuses and exits non-zero. It asks for the
password without echoing it, so it does not land in your shell
history. Paste the output into the environment or `config.php`, keeping the
single quotes: the hash is full of `$` and a shell or `.env` loader will eat it
otherwise.

**5. Route `/api/` to `index.php`.**

Apache: the `.htaccess` in `api/` already does it. Confirm the vhost has
`AllowOverride All` for that directory, or copy those directives into the vhost
instead.

**`AllowOverride All`, not just `FileInfo`.** The two directives in that file
need different override classes: `RewriteRule` needs `FileInfo`, and the
`<FilesMatch>` block with `Require all denied` in it needs `All`. On a host set
to `AllowOverride FileInfo`, which is a common hardened default and looks like
it ought to be enough, `Require` is not permitted in a `.htaccess` and Apache
answers 500 for the whole of `api/`. That at least fails loudly, but it fails
for a reason nothing on the page explains, so check the class rather than
checking that some override is allowed.

It needs Apache 2.4 and `mod_rewrite` enabled. `Require all denied` is 2.4
syntax; on 2.2 that line is an unrecognised directive and Apache answers 500
for the whole directory, which at least fails loudly rather than quietly. A
host still offering PHP 7.4 is old enough that this is worth checking with
`apachectl -v` and `apachectl -M | grep rewrite` before you assume. If
`mod_rewrite` is absent the routing silently does nothing, every path under
`/api/` 404s, and the deny block is what stops that turning into a leak.

Check it rather than assuming, because `AllowOverride` being off does two
things at once and only one of them is visible. The API 404s everywhere, which
you will notice immediately — and `api/config.php` is served as plain source,
database password and admin password hash included, which you will not. The
whole of `.htaccess` is ignored, so both the routing and the rules that keep
that file private go at the same time. If you cannot turn `AllowOverride` on,
copy the directives into the vhost; do not leave `api/` served without them.

The same two commands as for nginx below, after reloading Apache:

    curl -sS -o /dev/null -w '%{http_code}\n' https://yourdomain.com/api/config.php
    # 404 from the router. Anything that returns 200 is serving you the file.
    curl -sS https://yourdomain.com/api/config.php | head -c 200
    # Must not contain "db_pass" or "admin_password_hash".

Step 2's advice to put `api/` outside the document root removes this whole
class of problem, and is worth taking for that reason alone.

nginx. Note `$document_root` only works if `api/` is INSIDE the document root.
If you took step 2's advice and put it outside, write the absolute path
instead. There are **two** blocks and each carries its own commented line
showing where, so change both: nothing in the front end asks for a bare `/api`,
so a second block left pointing at a path that does not exist shows up only
when someone tries that URL by hand and gets a confusing 404.

    # Everything under /api/ is executed by index.php. Nothing under api/ is
    # ever served as a file, so config.php cannot be downloaded -- see the
    # warning below for why this block has no try_files in it.
    location ^~ /api/ {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php7.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root/api/index.php;
        # api/ outside the web root:
        # fastcgi_param SCRIPT_FILENAME /var/www/private/api/index.php;
    }
    # /api with no trailing slash, which the block above does not match.
    # If you change SCRIPT_FILENAME above, change it here too.
    location = /api {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php7.4-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root/api/index.php;
        # api/ outside the web root:
        # fastcgi_param SCRIPT_FILENAME /var/www/private/api/index.php;
    }

Do not add `try_files $uri @api;` to that first block, and do not try to block
`config.php` with a `location ~ \.php$` rule beside it. An earlier version of
this guide did both, and the combination served the database password to
anyone who asked for it.

Two nginx rules make that happen together. A `location` prefix marked `^~`
tells nginx to stop and not consider any regular-expression location at all,
so both `return 404` rules sat there as dead text. And `try_files $uri` means
"if a file of that name exists, send it as a file" — so a request for
`/api/config.php` found the file, skipped PHP entirely, and nginx returned the
source, including `db_pass` and the admin password hash.

The block above has no `try_files`, so every path under `/api/` goes to
`index.php` and the router answers 404 for anything it does not recognise.
Photographs are not an exception: they are read and streamed by the API after
it checks the session, never served off disk.

After reloading nginx, confirm it from outside:

    curl -sS -o /dev/null -w '%{http_code}\n' https://yourdomain.com/api/config.php
    # 404 from the router. Anything that returns 200 is serving you the file.
    curl -sS https://yourdomain.com/api/config.php | head -c 200
    # Must not contain "db_pass" or "admin_password_hash".

IIS. **Install the IIS URL Rewrite module first.** It is a separate download
from Microsoft and is not part of a stock IIS, and without it the `<rewrite>`
section below is ignored without complaint: the `<hiddenSegments>` rules still
work, so `config.php` stays blocked and nothing looks broken, but every
`/api/...` path answers 404 because nothing ever reaches `index.php`. There is
no error anywhere that points at the missing module. Confirm it is there in IIS
Manager — the server node shows a **URL Rewrite** icon — before going on.

Then the complete `web.config` inside `api\` — the wrappers matter, a bare
`<rule>` is not a valid config file:

    <?xml version="1.0" encoding="UTF-8"?>
    <configuration>
      <system.webServer>
        <security>
          <requestFiltering>
            <!-- config.php holds the database password and the admin hash. -->
            <hiddenSegments>
              <add segment="config.php" />
              <add segment="config.example.php" />
              <add segment="lib" />
              <add segment="routes" />
            </hiddenSegments>
          </requestFiltering>
        </security>
        <rewrite>
          <rules>
            <rule name="API" stopProcessing="true">
              <match url=".*" />
              <conditions>
                <!-- Only to stop the rewrite matching its own target. There is
                     deliberately NO IsFile condition here; see below. -->
                <add input="{URL}" pattern="(^|/)index\.php$" negate="true" />
              </conditions>
              <action type="Rewrite" url="index.php" />
            </rule>
          </rules>
        </rewrite>
      </system.webServer>
    </configuration>

**Note what is missing from that rule.** The usual IIS idiom adds
`<add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />`, which
means "if a file of this name exists, do not rewrite it". That is the same
thing as `try_files $uri` on nginx and `RewriteCond %{REQUEST_FILENAME} !-f` on
Apache, and it has the same consequence: `config.php` is then protected only by
the `<hiddenSegments>` block above, so one mistyped segment or one entry
dropped during a tidy-up and the database password is downloadable. Both of the
other configurations in this package had exactly that defect and it was
removed from both. Routing every path to `index.php` means the router answers
404 for anything it does not recognise and no file under `api/` is ever read
off disk, which makes `<hiddenSegments>` a second lock rather than the only
one. Nothing under `api/` needs to be served as a file: photographs are read
and streamed by the API after it checks the session.

This `web.config` has not been run against a real IIS, because there is none
in the environment it was written in. The reasoning matches the nginx and
Apache configurations, which were tested as far as they could be, but verify
it with the two `curl` commands above before you trust it, and check that a
normal API call still works: if the loop guard is wrong for your IIS version
you will see a redirect loop or a 500 immediately rather than anything subtle.

There is a working example in `site/deploy/server-config/iis-web.config` for
the site itself; this one is for `api/`.

**Whichever of the three you used, the same check is also automated**, once the
site is deployed:

    python3 site/tests/live_check.py https://your-domain

It requests `/api/config.php`, `/api/config.example.php`, `/api/lib/Config.php`,
`/api/routes/Admin.php`, `/api/index.php` and `/api/.htaccess`, reads each body
whatever content type the server labelled it, and fails with "CREDENTIALS
READABLE" naming which of `db_pass`, `admin_password_hash`, `totp_secret` and
`admin_email` it found. It also asks for an unknown path under `/api/` and
reports whether the API is routed at all, because "nothing is readable" is
equally true of a host where `/api/` was never wired up. Run it after any change
to the web server configuration, not only at launch: this is the one check that
asks the running server rather than reading the config you intended. Keep the
manual `curl` commands for the stage before anything is deployed, when there is
no site for the script to point at.

**6. Set `allowed_origins`** in `config.php` to the real domain. Requests that
change something are refused from anywhere else.

**7. Create the photo folder** outside the document root and point `photo_dir`
at it, **as an absolute path**. A photograph under the web root is downloadable
by anyone who guesses the filename, and a relative path is one typo away from
putting them there: under PHP-FPM it resolves against `api/` itself. So a
relative path is refused outright, with a line in the log naming the setting,
and no photograph is stored. Unix `/var/...`, Windows `C:\...` and a UNC
`\\server\share` are all accepted. The folder has to be writable by the user
PHP-FPM runs as, and needs to be readable by nothing else.

**8. Turn off the DEMO flags** in `application.html`, **`resume.html`**,
`payment.html` and `admin.html`. There are four, not three: `resume.html` is
easy to miss and it is the one page whose whole job is getting an applicant
back into an application, so leaving it in demo means they get a stub.

`application.html` and `resume.html` have to move together — they are two ends
of the same flow. The admin screen is genuinely independent of both, so it can
stay in demo while the form goes live, or the other way round. `payment.html`
stays on DEMO until the card endpoint exists; see the end of this file.

**Then delete the preview sign in from `admin.html` as well.** Setting the flag
to false is not the whole job. Five things in that file exist only so the
preview can be clicked through, and all five have to come out. They sit in the
`<script>` block near the top, between the `var DEMO` line and the demo
application data, each already marked with a comment saying to delete it:

    DEMO_ADMIN_EMAIL              the preview's account, admin@example.com
    DEMO_ADMIN_PASSWORD_SHA256    a SHA-256 of the preview's password
    demoSignIn                    the function that compares those two
    DEMO_MFA_CODE                 the preview's fixed code, 123456
    demoVerifyCode                the function that checks it

Take the `if (DEMO) return demoSignIn(creds);` and
`if (DEMO) return demoVerifyCode(payload);` lines in `onSignIn` and
`onVerifyCode` out at the same time. With the flag false they never run, so
leaving them does no harm today; the point is that nothing is left calling a
function that is not there if anyone ever puts the flag back. Leave
`var DEMO = false` itself in place, because the other `if (DEMO)` branches
further down are what serve the demo applications, and the data block they read
from carries its own comment saying to delete it with the flag.

The reason this is not just tidying is that `DEMO_ADMIN_PASSWORD_SHA256` is a
real hash of a real password, and that password is published in this repository
on purpose, so that anyone reviewing the preview can sign in to it. A plain
SHA-256 is fast to guess against, which is exactly why the server side uses
bcrypt, so treat the hash as being the password. Ship it and the password is
published again, this time on your own domain, to anyone who opens `/admin` and
reads the source.

With `DEMO` false those lines are dead code and cannot be used to sign in, which
the comment block above them says in as many words, so leaving them in is
disclosure rather than a way past the login. It still should not ship. The flag
is one hand-edited line on four pages, and if it is ever missed or put back on
`admin.html`, the published password signs the visitor straight in to four
invented applications full of passport numbers and card numbers, which is a
reasonable thing to mistake for a breach of real applicant data. Deleting the
hash means that mistake cannot happen twice.

`python3 site/tests/live_check.py https://your-domain` checks all four flags on
the live site afterwards, and reports whether `DEMO_ADMIN_PASSWORD_SHA256` is
still in the served `admin.html`, which is more reliable than remembering.

---

## Check it works

With the site and the API on the same host:

    # create an application
    curl -s -c /tmp/c -H 'Content-Type: application/json' \
         -H 'Origin: https://www.visajourneyusa.com' \
         -d '{"securityPrompt":"What was the name of your first pet?","securityAnswer":"Rex"}' \
         https://www.visajourneyusa.com/api/application

    # the admin sign in
    curl -s -c /tmp/a -H 'Content-Type: application/json' \
         -H 'Origin: https://www.visajourneyusa.com' \
         -d '{"email":"YOUR_ADMIN_EMAIL","password":"YOUR_PASSWORD"}' \
         https://www.visajourneyusa.com/api/admin/session

The first answers `{"applicationId":"..."}`. The second answers
`{"email":...,"name":"Admin"}` before the second factor is enrolled, and
`{"mfaRequired":true}` after. Then open `/admin` in a browser and sign in.

---

## The second factor

Build the password step first and this second. A server with no secret enrolled
answers the password step with `{ email, name }` and the admin screen signs
straight in, so everything except the card-reveal route works while this is
still being set up.

    php tools/enrol-totp.php

It prints the secret for `TOTP_SECRET`, an `otpauth://` URI to scan, the code
that is valid right now so you can check the clock, and ten recovery codes. The
recovery codes are shown once and only their hashes are stored.

**Paste the secret whole, or leave `totp_secret` empty.** Empty means "no
second factor enrolled yet" and the password step signs straight in, with the
session recorded as having presented no second factor. A secret that is *set*
but unusable is a broken setting rather than an absent one, so sign in answers
`500` with `not_configured` and the log says to re-run `tools/enrol-totp.php`.

**Pasting it with the dashes in is fine.** Authenticator apps display a secret
in groups, and people paste what they are shown. `Totp::base32Decode` strips
every character outside the base32 alphabet, so `DFJF-7O4R-...` and
`DFJF7O4R...` are the same secret and produce the same codes. An earlier
wording of this guide said a dashed paste decoded to nothing, which was wrong,
and an audit disproved it by decoding both.

What `Totp::usable()` actually refuses is a secret that cannot carry a real
HMAC key, and there are three tests, all of them failing closed:

- **Fewer than ten decoded bytes:** ten is RFC 4226's minimum for a shared
  secret, and `generateSecret()` makes twenty. This is what catches a
  placeholder of digits: none of `0`, `1`, `8` or `9` is in the base32
  alphabet, so `0` and `000000` both decode to nothing at all.
- **The base32 string being one character repeated:** checked on what was
  typed rather than on the key, because that is the shape a person types.
- **Fewer than six distinct byte values in the decoded key:** this is the one
  that matters most, and it was added after a length check on its own proved
  not to be enough: `AAAAAAAAAAAAAAAA` decodes to a full ten bytes, every one
  of them zero, so it passed the length test. An auditor computed the code for
  the current step from an all-zero key, signed in with it, and came out with a
  session carrying `second_factor = 1`, which is the flag the card routes are
  specified to check. A key anybody can guess produces codes anybody can
  compute, which is no second factor at all.

Three things in `Totp.php` and `Admin::verifyCode()` are there for a reason and
should survive any tidying:

- **One step either side of now**, so a code works for about ninety seconds.
  Phones drift. Wider than that is a longer window for a code someone watched
  being typed.
- **A step is refused once used.** `admin_state.last_totp_step` is what does it.
  Without it a code read over a shoulder works again until it expires, and the
  second factor stops being one.
- **Wrong codes count in their own lockout bucket, separate from the one that
  counts wrong passwords.** `Guard` keys them on the caller's address as
  `admin-code` and `admin-signin`, and nothing clears one from the other. One
  shared bucket was tried both ways and both were wrong. Clearing a shared
  bucket on a correct password let anyone holding the password refill the code
  budget at will — sign in, spend four guesses, sign in again. Not clearing it
  made four password typos plus one mistyped code five failures, so the only
  admin account locked itself out for fifteen minutes and then refused the
  correct code that followed. Two separate buckets answer both: a correct
  password cannot refill the code budget, and password typos cannot eat it.
  `site/README.md` under "Rate limiting and lockout" has the same thing from
  the front end's side.

**Running `enrol-totp.php` again revokes every unused recovery code.** That is
deliberate — re-enrolling means the old factor is gone — but it catches people
who run it a second time just to look at the output. The ten you wrote down
stop working. It also prints a new secret, which does nothing until you put it
in the environment or `config.php` AND reload PHP-FPM; until you do, sign in
keeps answering `{ email, name }` and it looks as though the tool did nothing.

Keep the recovery codes somewhere that is **not** the phone with the
authenticator app. There is one admin account, so losing that phone without them
locks the only login out of the site with no way back.

---

## Backups, restores and deleting an applicant's record

Nothing in this package backs anything up, and nothing deletes an application.
Both are yours to set up, and the two settled questions are below. The open ones
are at the end and need an answer from whoever owns the business, not from
whoever installs this.

**What holds applicant data:** two places, and a backup that misses either is
not a backup.

- **The database:** `applications` is the table that matters, one row per
  applicant, holding the full answer set as JSON in `answers`, which is passport
  number, date of birth, addresses, travel history, employment and family
  details. Alongside it, `application_notes` and `application_activity` hold
  what the admin wrote and did about each application. The other five tables are
  operational rather than personal: `applicant_sessions` and `admin_sessions`
  expire on their own, `admin_recovery_codes` and `admin_state` belong to the
  admin account, and `rate_events` holds IP addresses against a bucket name and
  nothing linking them to an applicant.
- **The `photo_dir` folder:** one passport photograph per applicant who uploaded
  one, named after the application reference with a `.jpg` or `.png` extension.
  It sits outside the document root and outside whatever `mysqldump` covers, so
  a database-only backup silently leaves the photographs out.

A plain `mysqldump visajourney` plus an archive of `photo_dir`, both encrypted
at rest and held somewhere the web server cannot reach, is enough. Treat the
backups as holding exactly what the database holds, because they do: an
identity-theft kit per row. A dump sitting unencrypted on the same host is the
usual way this data leaks.

**Restoring:** load the dump as `root`, not as the `visajourney` user, which has
no DDL privileges by design (step 1). Then check that `admin_state` has its row:

    mysql -u root -p visajourney -e "SELECT COUNT(*) FROM admin_state WHERE id = 1"

A `0` means the row is missing, which `schema.migrations.sql` warns about: a
dump restored without its `INSERT`s loses it, and a hand-built schema never had
it. `Admin::verifyCode` recreates it on the first correct code and logs that it
did, so it is not a lockout, but that is a backstop rather than the intended
path. Run the one `INSERT IGNORE` from `schema.migrations.sql` after a restore
and the first sign in works without relying on it.

**Deleting one applicant's record:** there is no route for this, so it is done
by hand on the server, in two parts.

    mysql -u root -p visajourney \
      -e "DELETE FROM applications WHERE reference = 'VJ7K2M4PQX'"
    rm /path/to/photo_dir/VJ7K2M4PQX.jpg   # or .png

The notes, the activity list and any applicant session go with the row:
`application_notes`, `application_activity` and `applicant_sessions` all declare
`ON DELETE CASCADE` on `applications(id)`, so one `DELETE` is enough for the
database. The photograph does not cascade, because it is a file rather than a
row, and that is the part most likely to be forgotten. Remember the backups as
well: a record deleted today is still in last night's dump, and stays there for
as long as that dump is kept.

**Two things are left undecided here, and this package cannot settle them:**
they are decisions about the business, and leaving them unanswered is itself a
decision.

- **How long any of this is kept:** there is no retention period anywhere in
  this package. An application and its photograph stay in the database until
  somebody deletes them, which today means forever. The only retention rule
  in the package is the 90-day purge of stored card numbers
  (`card_retention_days`, enforced by the API and `tools/purge-cards.php`),
  and it covers the card number only, none of the rest. Pick a period, write it
  down, and make something enforce it.
- **Who may ask for a record to be deleted, and how you know it is them:** the
  reference number is not proof, because it is printed on the applicant's screen and
  emailed to them, so it identifies an application and does not authorise
  anything. The security answer is the only thing the applicant holds that is
  secret, and it is stored as a bcrypt hash, so it can be checked but not read
  out. Decide what you will accept as identification before the first request
  arrives rather than while someone is waiting.

Whatever rules apply to this data where the business operates and where the
applicants are, this package makes no claim about them and they are not
addressed here. That is a question for whoever owns the business.

---

## What is deliberately not here

**The card routes are now here (2026-10-22).** `POST /api/application/card`,
the card-reveal route and mark-charged are built, with the key from the
`CARD_KEY` environment variable, the append-only reveal log and the retention
purge. Installing them on a server that is already running is in
`DEVELOPER-INSTRUCTIONS.md` at the package root: run `schema.migrations.sql`,
set `CARD_KEY`, enrol the second factor, then flip `DEMO` on `payment.html`.
**A supported PHP version** is still strongly advised before real card numbers
are stored (see the last section): unpatched PHP fails PCI DSS on its own.

The reveal route uses `Sessions::requireAdmin($db, true)`, as the paragraphs
below say it must.

When you write them, use `Sessions::requireAdmin($db, true)`. That checks the
session's `second_factor` column, which is set only when a TOTP code or a
recovery code was accepted.

**Do not check `mfa_passed` instead.** It means "this sign in finished", which
is also true for a password-only session on a server with no secret enrolled.
This used to be the only column, `requireAdmin`'s second argument did nothing
at all, and these instructions told you to rely on it — so the reveal route,
written exactly as documented, would have handed a full card number to a
session that never presented a second factor. An audit found it before anyone
wrote the route. The two facts are separate columns now; keep them separate.

**The contact form endpoint.** Still a `preventDefault` in `site.js`.

---

## Decisions worth keeping

**Nothing is authorised by the reference number.** It is printed on the
applicant's screen and emailed to them, so it identifies an application and does
not protect one. `GET /api/application/:id` checks the `vj_app` session cookie
set at create or resume. Dropping that check would make every application
readable by anyone who guessed ten characters.

**The applicant cookie is SameSite=Lax, the admin cookie is Strict.** The
applicant comes back from the payment provider, which is a cross-site
navigation, and a Strict cookie is not sent on it: they would arrive at the
resume screen holding a valid reference and wondering why. Nobody navigates into
`/admin` from another site, so it takes the stricter setting.

**A wrong email and a wrong password give the same 401 and the same message,**
and the bcrypt compare runs either way, so a wrong email does not come back
faster. Saying which half was wrong tells an attacker they have the email right.

**A locked-out request is refused before any comparison.** Checking the password
anyway and then refusing leaks whether it was right, which is the thing the
lockout exists to hide.

**Every response is `no-store`.** These carry applicants' answers. A cached copy
in a proxy or on a shared machine is the same leak as any other.

**The amount always comes from the server.** `config.php` holds the fee. A price
posted from a browser is a price the customer can edit.

**Errors are logged, never returned.** A stack trace can echo the request body,
and the request body here is somebody's passport number.

---

## A word about PHP 7.4

The API runs on 7.4 and will keep running on it. This section is about the
server, not the code.

**PHP 7.4 stopped receiving security patches on 28 November 2022.** Every
vulnerability found in PHP since then is unpatched on that server and will stay
unpatched: there is no update to apply. That is a different thing from being old.

Two consequences worth putting in front of whoever owns the decision.

**It is already a problem for what this system holds.** The database stores
passport numbers, dates of birth, addresses, travel history and employment
details for named individuals — a complete identity-theft kit per row. The
platform underneath it has no security maintenance.

**It is a hard blocker for the card work, not a recommendation.** The plan is to
store full card numbers so the processor can be charged by hand. That puts this
system under PCI DSS at SAQ D, the thorough one, which includes quarterly scans
by an approved vendor. PCI DSS requires system components to be protected from
known vulnerabilities by applying security patches. Software that no longer
receives patches cannot satisfy that, so an unsupported PHP is an assessment
finding on its own — the quarterly scan reports the version and fails. No amount
of correctness in the code above changes that, because the finding is about the
platform.

So the order that works:

1. **Now.** Install this on 7.4. It works, it is tested, and the applicant and
   admin halves are complete. Nothing is blocked.
2. **Before the card routes are written.** Move to a supported PHP — 8.1 or
   newer. The API needs no changes for this; that is what the compatibility
   check protects. It is a server upgrade, not a rewrite.
3. **Then** build the card routes, on the supported version.

If step 2 cannot happen, that is worth knowing early, because the honest answer
is then to not store card numbers at all and use the processor's vault or a
payment link instead. That removes the PAN from this system entirely, which
drops the obligation from SAQ D back to SAQ A and is less work than either
alternative.

The upgrade itself is usually small for code like this: no framework, no
composer, no deprecated extensions, and a test suite that tells you whether it
worked. To verify it, run the three commands from the top of this file on the
new version — the API suite both ways, and the contract check.
