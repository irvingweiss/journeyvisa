-- Changes to apply to a database that was created from an EARLIER version of
-- schema.mysql.sql.
--
-- A fresh install does not need this file: schema.mysql.sql already has
-- everything in it. Run these only if the database is already there and the
-- API was working against it before.
--
-- Each block says how to tell whether you need it. The whole file is safe to
-- run in order, and safe to run again: every statement checks first and does
-- nothing when its change is already there. (It used to stop on the
-- second_factor ALTER with "duplicate column name" the second time; that ALTER
-- now asks information_schema first.)
--
-- The checks use SET @sql / PREPARE / EXECUTE rather than a stored procedure,
-- so no DELIMITER line is needed and it runs the same in the mysql client and
-- in phpMyAdmin. MySQL 8 has no ADD COLUMN IF NOT EXISTS (MariaDB does).
--
-- Run it with:
--
--     mysql -u <admin user> -p <database> < schema.migrations.sql

-- ---------------------------------------------------------------------------
-- 2026-10-22  admin_sessions.second_factor
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SHOW COLUMNS FROM admin_sessions LIKE 'second_factor';
--
-- No rows means yes, apply this. Without the column, signing in fails with a
-- generic 500 and the only clue is the PHP error log, which names the column.
--
-- WHERE it fails depends on whether a TOTP secret is enrolled, which is why
-- the symptom looks like two different bugs:
--
--   secret enrolled     the password step SUCCEEDS and answers
--                       {"mfaRequired":true}, because Sessions::startAdminHalf
--                       does not touch this column. The CODE step is what
--                       500s: Sessions::admin() selects second_factor.
--   no secret enrolled  the password step itself 500s, because
--                       Sessions::startAdminFull inserts this column.
--
-- So a half-finished sign in that looks fine until the code is typed is this
-- migration missing, not a problem with the code or the clock.
--
-- Why it exists: mfa_passed means "the sign in finished", which is also true
-- for a password-only session on a server with no TOTP secret enrolled. The
-- card routes need "a second factor was actually presented", which is a
-- different question, and asking the first one would have handed a card
-- number to a password-only session. See the comment on admin_sessions in
-- schema.mysql.sql.

SET @vj_sql = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE admin_sessions ADD COLUMN second_factor TINYINT(1) NOT NULL DEFAULT 0 AFTER mfa_passed',
  'DO 0')
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'admin_sessions'
    AND COLUMN_NAME = 'second_factor');
PREPARE vj_stmt FROM @vj_sql;
EXECUTE vj_stmt;
DEALLOCATE PREPARE vj_stmt;

-- Existing sessions are password-only as far as anyone can now prove, and the
-- DEFAULT 0 above already says so. Signing out and back in sets it properly.
-- If you would rather not leave sessions in that state at all:
--
--     DELETE FROM admin_sessions;
--
-- which just means signing in again.

-- ---------------------------------------------------------------------------
-- 2026-10-22  admin_state must have its row
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SELECT COUNT(*) FROM admin_state WHERE id = 1;
--
-- A 0 means yes. schema.mysql.sql seeds this row, so a normal install has it;
-- a hand-built schema or a dump restored without its INSERTs may not.
--
-- Without the row, the replay guard in Admin::verifyCode updates zero rows,
-- which is also what "this code was already used" looks like. It tells the
-- two apart rather than guessing: on zero rows it counts the rows for id = 1,
-- and if there are none it INSERTs the row itself, logs
-- "admin_state had no row; created it" and lets the sign in through. So a
-- missing row self-heals on the first correct code and is NOT a lockout.
--
-- Run this anyway. The self-heal is a backstop, not the intended path: it
-- leaves a line in the error log on an otherwise clean install, and it can
-- only recover a row that the API has permission to insert. Applying it here
-- means the first sign in works without relying on that.
--
-- It is worth knowing what the self-heal is guarding against, because the
-- obvious shortcut is wrong: reporting "That code has already been used" for
-- a zero-row update would refuse every correct code forever, on a schema the
-- admin cannot see anything wrong with, and send whoever is debugging it a
-- long way in the wrong direction.

-- id is the primary key, so INSERT IGNORE adds the row if it is missing and
-- does nothing if it is already there. Deliberately not a SELECT ... WHERE NOT
-- EXISTS against the same table: that form is easy to get subtly wrong across
-- databases, and this one says what it means in one line.
INSERT IGNORE INTO admin_state (id, last_totp_step) VALUES (1, 0);

-- Postgres: INSERT IGNORE is MySQL's. Use
--   INSERT INTO admin_state (id, last_totp_step) VALUES (1, 0)
--     ON CONFLICT (id) DO NOTHING;

-- Postgres note: for the ALTER, use SMALLINT rather than TINYINT(1), and drop
-- the AFTER clause. Do NOT use BOOLEAN. On PHP 7.4 the pgsql driver returns
-- booleans as the strings 't' and 'f', and 'f' is truthy in PHP, which would
-- make both admin_sessions flags read as set when they are not. Keeping these
-- columns as integers keeps every driver agreeing.

-- ---------------------------------------------------------------------------
-- 2026-10-22  stored card numbers: card_vault, card_reveal_log
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SHOW TABLES LIKE 'card%';
--
-- If card_vault and card_reveal_log are not both listed, yes. Without them,
-- POST /api/application/card and the card-reveal route answer 500 and the
-- PHP error log names the missing table.
--
-- What they are for is set out beside the same CREATE TABLEs in
-- schema.mysql.sql, which is the copy to read. These are the same
-- statements with IF NOT EXISTS.
--
-- The applications table already has every payment column the card routes
-- use (card_brand, card_last4, card_exp_month, card_exp_year,
-- number_on_file, paid_amount, paid_currency, charged_on, charged_by,
-- processor_ref, charge_recorded_at). A database built from an older schema
-- might lack some of them, so each is added below only if it is missing.

CREATE TABLE IF NOT EXISTS card_vault (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT       NOT NULL UNIQUE,
  ciphertext     TEXT         NOT NULL,
  nonce          VARCHAR(32)  NOT NULL,
  wrapped_key    VARCHAR(255) NOT NULL,
  kms_key_id     VARCHAR(64)  NOT NULL,
  created_at     DATETIME     NOT NULL,
  purge_after    DATETIME     NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX card_vault_idx_purge (purge_after)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS card_reveal_log (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  at          DATETIME     NOT NULL,
  admin_email VARCHAR(255) NOT NULL,
  ip          VARCHAR(45)  NOT NULL,
  user_agent  VARCHAR(255) NOT NULL,
  reference   VARCHAR(16)  NOT NULL,
  outcome     VARCHAR(32)  NOT NULL,
  INDEX reveal_log_idx_account (admin_email, outcome, at),
  INDEX reveal_log_idx_ref (reference, outcome, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- The payment columns on applications, each only if missing.
SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN card_brand VARCHAR(32) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'card_brand');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN card_last4 VARCHAR(4) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'card_last4');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN card_exp_month INT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'card_exp_month');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN card_exp_year INT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'card_exp_year');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN number_on_file TINYINT(1) NOT NULL DEFAULT 0', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'number_on_file');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN paid_amount DECIMAL(10,2) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'paid_amount');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN paid_currency VARCHAR(8) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'paid_currency');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN charged_on DATE NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'charged_on');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN charged_by VARCHAR(255) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'charged_by');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN processor_ref VARCHAR(128) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'processor_ref');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE applications ADD COLUMN charge_recorded_at DATETIME NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'applications' AND COLUMN_NAME = 'charge_recorded_at');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

-- Append-only, enforced by the database. DROP IF EXISTS first so the file
-- can run twice. Needs the TRIGGER privilege (and on some hosts with binary
-- logging, SUPER or log_bin_trust_function_creators = 1). If your host
-- refuses, everything above has already been applied: skip these and rely on
-- the grants in DEVELOPER-INSTRUCTIONS.md.
DROP TRIGGER IF EXISTS card_reveal_log_no_update;
CREATE TRIGGER card_reveal_log_no_update BEFORE UPDATE ON card_reveal_log
  FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'card_reveal_log is append-only';
DROP TRIGGER IF EXISTS card_reveal_log_no_delete;
CREATE TRIGGER card_reveal_log_no_delete BEFORE DELETE ON card_reveal_log
  FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'card_reveal_log is append-only';

-- Postgres: CREATE TABLE IF NOT EXISTS works as written once the types are
-- changed as the top of schema.mysql.sql describes; replace the PREPARE
-- blocks with ALTER TABLE ... ADD COLUMN IF NOT EXISTS, and the triggers with
-- a trigger function that RAISEs EXCEPTION.

-- ---------------------------------------------------------------------------
-- 2026-10-25  card_vault.cvv_ciphertext, card_vault.cvv_wrapped_key
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SHOW COLUMNS FROM card_vault LIKE 'cvv_%';
--
-- Fewer than two rows means yes. Without them, saving a card fails with a
-- generic 500 naming the column in the PHP error log.
--
-- The security code (CVV), encrypted on its own with its own data key, so it
-- can be wiped without touching the card number. Both columns are NULL once
-- the charge has been recorded (Admin::markCharged) and in the retention
-- purge. PCI DSS does not allow it to be kept after the charge in any form.
--
-- If the trigger statements in the block above were refused by your host,
-- run this block on its own: it does not depend on them.

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE card_vault ADD COLUMN cvv_ciphertext TEXT NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'card_vault' AND COLUMN_NAME = 'cvv_ciphertext');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

SET @vj_sql = (SELECT IF(COUNT(*) = 0, 'ALTER TABLE card_vault ADD COLUMN cvv_wrapped_key VARCHAR(255) NULL', 'DO 0')
  FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'card_vault' AND COLUMN_NAME = 'cvv_wrapped_key');
PREPARE vj_stmt FROM @vj_sql; EXECUTE vj_stmt; DEALLOCATE PREPARE vj_stmt;

-- Postgres: ALTER TABLE card_vault ADD COLUMN IF NOT EXISTS cvv_ciphertext
-- TEXT NULL, and the same for cvv_wrapped_key VARCHAR(255) NULL.
