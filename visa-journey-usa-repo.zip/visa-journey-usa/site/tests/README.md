# Tests

Runs the real pages in a headless DOM and asserts the behaviour, rather than
eyeballing it. Every bug fixed during the build has a test here, so a later change
that reintroduces one gets caught.

One dependency. Install it from this folder so the pinned version is used:

    npm install

`package.json` pins jsdom to 26.x deliberately. From jsdom 27 onward,
`element.querySelector('#someId')` resolves through the document's id map rather
than the element's own subtree, so a second element with that id anywhere in the
document makes a correctly scoped lookup return `null`. The suites mount the form
more than once per document, so on 27+ they would fail on code that works. The
harness now also keeps one mount live at a time (`host.js`), which makes the suites
pass on 29 as well, but the pin stays so a fresh checkout is not at the mercy of
the next change in that area.

## Run them

From this folder. Start with the two cheapest checks: the rebuild check catches a
build script quietly losing a page, and the link check catches a link going nowhere.
Neither needs a server or Node.

    # clean-room rebuild
    python3 rebuild_check.py

    # every link in all three builds
    python3 link_check.py deploy
    python3 link_check.py src
    python3 link_check.py preview

    # the source build
    python3 -m http.server 8899 --directory ../src &
    node suite.js ../src/
    kill %1

    # the deploy build, served with clean URLs the way Netlify does
    python3 serve_clean.py ../deploy &
    node suite.js ../deploy/ http://127.0.0.1:8898/
    python3 deploy_checks.py ../deploy
    python3 crawl.py
    kill %1

    # the draft cache and the reference email, both need the source build served
    python3 -m http.server 8899 --directory ../src &
    node draft.js ../src/
    node email.js ../src/
    node dates.js ../src/
    node persona.js ../src/
    node branches.js ../src/
    node scenarios.js ../src/
    kill %1

    # the admin screen
    python3 -m http.server 8899 --directory ../src &
    node admin.js ../src/
    kill %1

    # the single-file preview, which needs no server
    node single.js ../preview/visa-journey-usa.html

## After deploying

Everything above tests the build. This one tests the server, which is a different
thing and the one that has actually gone wrong:

    python3 live_check.py https://www.visajourneyusa.com

## What each covers

- `link_check.py` resolves every `href` and `src` in a build, plus every in-page
  anchor, plus the navigation performed from inline scripts, which no crawl of
  href attributes would see. For `deploy` it works out which clean URLs Netlify
  will serve and checks against that, reads `netlify.toml` so a link that only
  works via a 301 is reported as such, and cross-checks the sitemap both ways: a
  listed URL that nothing serves, and a real page that is missing from it. For
  `preview` it checks every hash link against the router's own route list, and
  every route against the sections in the file. 576 links in the deploy build, 509
  in the source build, 60 in the preview.

- `crawl.py` requests every URL for real against `serve_clean.py`, starting at `/`
  and following links until it runs out of new ones. `link_check.py` reasons about
  paths; this one would catch a mistake in that reasoning. It also reports any page
  in the folder that nothing links to.

- `live_check.py` is the only one that runs against a deployed site. It requests
  every URL the folder should serve, compares the live build marker with
  `BUILD.txt`, checks that an unknown path answers 404 and not 200, checks the five
  security headers, checks that the old `.html` paths 301 to the clean ones, and
  follows the links on each live page. It exists because the build was correct while
  production was not: six pages were missing from the server and every page in the
  site linked to them. It is host-neutral, so it is also how you confirm a
  non-Netlify host picked up the config in `deploy/server-config/`.

- `rebuild_check.py` (96 checks) copies the package to a temp directory, deletes
  every generated file, runs all three build scripts, and asserts everything comes
  back byte-identical. It also parses the generated host configs in
  `deploy/server-config/`, since a config that does not parse takes a site down on
  reload rather than failing visibly at build time, and checks that each one sends
  `/index.html` to `/` rather than to `/index`. This one found two real bugs the day
  it was written and a third the day the host configs were added.

- `suite.js` (121 checks) the form's 22 steps and schema rules, typing and Tab and
  click behaviour, the spouse and photo steps, submit and payment handoff, surviving
  a refresh, the resume flow, the payment page, and every site page including the
  contact form.
- `deploy_checks.py` (83 checks) files present, internal links and asset paths,
  robots tags per page, sitemap contents, `netlify.toml`, and a real HTTP fetch of
  every public URL plus the 404, which must answer with a 404 status and not a 200.
- `draft.js` (17 checks) a refresh restores what was typed, and the fields that
  must never reach the browser (security answer, passport and ID numbers, the
  photograph) are absent from the stored draft.
- `email.js` (21 checks) the reference-number email is opt-in, validates the
  address, reports failures, and never puts the security answer in the payload.
- `dates.js` (28 checks) every date is a day / month / year control rather than a
  native picker, partial dates never reach the answer data, and impossible dates,
  silly years and future birth dates are all caught. Also covers the standalone year field.
- `branches.js` (24 checks) every answer that opens a follow-up page on the
  DS-160 actually opens one here: divorced, widowed, legally separated, and a
  company paying for the trip.
- `persona.js` (31 checks) walks a deliberately awkward applicant through the form:
  a dual Algerian and French national with accented and Arabic-script names, a
  previous refusal, conscript military service, an address with no state, a +213
  phone and a US contact in a territory. This is the suite that catches
  assumptions baked in by a US or western European author.
- `scenarios.js` (22 checks) three more awkward applicants: a single-name
  Indonesian worker applying from a third country with her employer paying, a
  six-year-old whose mother is doing the typing, and a stateless applicant on a
  travel document with no expiry date and no postal address.
- `admin.js` (189 checks) the admin screen: sign in, the list with its search
  and status filter, and the detail view. The detail checks are the ones worth
  keeping: that every question put to this applicant appears including the ones
  left blank, that questions the applicant never saw are left out rather than
  listed as unanswered, that the labels are the schema's own rather than a
  prettified key name, that the DS-160 country and occupation codes sit beside
  the answers, and that the security answer never reaches the page. It also
  checks the answers are read-only, since the applicant signed them.

  It also covers the card. On the admin side: that the number is masked until
  asked for, that a reveal shows it in fours in a monospace font, copies it
  without the spaces, and logs "Viewed full card number" each time, that it is
  wiped after 60 seconds and on Hide, navigation, sign out and print, that a
  number arriving on onGet is never drawn, and that a reveal answering after the
  admin has left is dropped. Then recording a charge: the processor reference
  is required, the date cannot be in the future, it asks first, the button
  disables on the press, and a paid application offers no way to charge or
  reveal again. An expired card is caught before anyone charges it, and a mount
  given onCharge still gets a working Charge button. On the card step: that it
  says in three places that nothing is charged today, that Luhn, brand and
  expiry are checked before anything is sent, that there is no CVV field, and
  that nothing reaches localStorage or sessionStorage.

  And the single admin account. The preview checks a SHA-256 of the password
  against the hash in `admin.html`, and the password itself is in no file here,
  these tests included. jsdom has no WebCrypto, so each page is given Node's,
  with one seam: a fixed test-only input is answered with the stored hash, which
  stands in for "the compare matched". Every other input is hashed for real. So
  the suite checks that a wrong email is refused even with a matching password,
  that a wrong or empty password is refused, that both refusals read the same,
  that the password is hashed even when the email is wrong, that the right
  account signs in whatever the case of the email, that the bar then shows the
  account email, that notes are written by "Admin" and no demo record names a
  second person, that there is no "last opened by" column, that a page with no
  WebCrypto says why it cannot sign in, and that the production `onSignIn`
  posts to `/api/admin/session` and shows the server's message for a 401 and a
  429 lockout. It also checks that `admin.js` itself carries no account and no
  hash, and that the preview hash is marked for removal with the DEMO flag.

  Every content assertion reads the mount container, not `document.body`. A
  page's `body.textContent` includes the text of its `<script>` tags, and the
  demo applications live in one of those, so asserting against the body passes
  even when the page renders nothing at all. That mistake was in the first
  version of this suite.

- `single.js` (26 checks) the preview file is genuinely self-contained and every
  route, the form, payment and resume all work inside it.

## Why the rebuild check exists

An edit to `build.py` silently deleted the generator for the two legal pages, and
nothing noticed for several rounds of changes, because stale copies of those pages
were sitting in `src/` and being copied through to `deploy/`. The site was correct
by accident. Anyone running `build.py` on a fresh checkout would have lost both
pages.

No test that runs against already-built output can catch that. Run this one after
any change to a build script.

## If a test fails

The name says what broke. The ones most likely to fail after a careless edit are
the input-behaviour checks in section 2 of `suite.js` and the button colour checks
in section 8. Both are guarding fixes explained in the main README under
"Two things not to undo".
