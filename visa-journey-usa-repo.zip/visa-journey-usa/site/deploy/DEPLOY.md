# Deploying

These are plain static files. There is no build step, no framework and no Node
dependency, so they go on any host that serves HTML.

## Not using Netlify?

Then `netlify.toml` in this folder does nothing, and one of the three jobs it was
doing is load-bearing. Read `server-config/README.md` and copy the file that
matches your setup. There is one for Apache, nginx, IIS, Vercel and Cloudflare
Pages.

The load-bearing one is clean URLs. Every link in the HTML points at `/about-us`,
not `/about-us.html`. If the server does not map an extensionless path to the
`.html` file on disk, every link in the site 404s. Most static hosts do this
already; Apache, nginx and IIS need one rule, which is in that folder.

The other two, security headers and 301s from the old `.html` paths, are worth
having and break nothing by their absence.

## Netlify: drag and drop

Netlify home, then Sites, then drop this whole folder onto the drop zone. Do not
zip it first and do not drop the files individually: Netlify needs the folder so
the paths line up. It goes live in about twenty seconds on a random subdomain,
which is fine for review.

## Or connect a repository

If the code ends up in Git, point Netlify at the repo and use:

    Build command:      (leave empty)
    Publish directory:  .

There is no build step. These are plain files.

## Custom domain

Site configuration, then Domain management, then add `visajourneyusa.com`. Netlify
issues the certificate itself. Set one of www or the bare domain as primary and let
Netlify redirect the other, so you are not splitting link equity across both.

Point DNS at Netlify before you switch anything, and keep the current site up until
the new one resolves.

## What is in here

- Fourteen pages plus a 404, at clean URLs. `/about-us`, not `/about-us.html`.
  Eight of them are the core site and the application: `/`, `/about-us`,
  `/contact-us`, `/application`, `/payment`, `/resume`, `/terms-and-conditions`,
  `/privacy-policy`. The other six are the search pages, and every one of them is
  linked from the nav or the footer of every page: `/b1-b2-visitor-visa`,
  `/ds-160-help`, `/visa-interview-preparation`, `/us-visa-renewal`,
  `/visiting-family-in-usa`, `/business-visitor-visa`.
- `netlify.toml` sets security headers, cache headers and redirects from the old
  `.html` paths. Netlify reads it automatically; every other host ignores it.
- `server-config/` is the same three jobs written out for Apache, nginx, IIS,
  Vercel and Cloudflare Pages. Copy one if you are not on Netlify. This folder is
  documentation, not part of the site, so it is harmless left in place, though
  there is no reason to upload it.
- `robots.txt` and `sitemap.xml` are both live and pointing at the real domain.
- `favicon.svg` and `hero.svg`.

## Upload the whole folder

Every file in here is linked from somewhere in the site, so a partial upload
produces 404s on a working build. The nav links to `/b1-b2-visitor-visa`,
`/ds-160-help` and `/visa-interview-preparation` on all fourteen pages, and the
footer links to those three plus `/us-visa-renewal`, `/visiting-family-in-usa`
and `/business-visitor-visa`. If those six files are not on the server, six links
in the chrome of every page are dead.

This has already happened once in production: the eight core pages were live and
answering correctly while all six search pages returned 404, with the build marker
still reporting the right build, because the files that were uploaded were from it.

## Checking it after you deploy

Point the checker at the deployed site and it requests every URL this folder is
meant to serve, compares the live build marker with `BUILD.txt`, and follows the
links on each live page:

    python3 tests/live_check.py https://www.visajourneyusa.com

It exits 0 only if everything answers 200 and the build marker matches. Run it
after every deploy. It needs nothing but Python 3 and can run from any machine.

## Checking which build is live

Every page carries a build marker. View source and look near the top for:

    <meta name="vj-build" content="2026-09-10 1a2b3c4d5e">

`BUILD.txt` at the site root lists the same build id and each asset's hash. If the
id on the live page does not match `BUILD.txt` in the folder you uploaded, the new
deploy has not gone out yet.

Asset URLs carry a hash of the file's contents, like `/visa-application-form.js?v=...`.
A changed file gets a new URL on every deploy, so browsers cannot keep running a
stale copy. That was the reason a release could look unchanged for up to an hour.

## The hero illustration

`hero.svg` is a flat vector in the site's own palette: 4 KB, sharp at any size, no
external dependency. It replaced a photograph that was being hotlinked from the old
server and has since 404'd.

If you swap in a real photograph later, keep the file local, keep the `width` and
`height` attributes on the tag so the layout does not jump while it loads, and use a
4:3 image, since the frame crops to that ratio.

## The admin account

`/admin` has one login, one address, set in the server environment, and it is checked by the
server against two environment variables. Set them in the host's environment
settings (Netlify: Site configuration, then Environment variables), never in a
file in this folder or in the repository:

    ADMIN_EMAIL=<the one admin address>
    ADMIN_PASSWORD_HASH='<output of api/tools/make-admin-hash.php>'

The hash is bcrypt, cost 12. Paste it exactly; in a shell or a `.env` file keep
the single quotes, or the `$` signs get expanded and nobody can sign in. The
email is compared case-insensitively; the password with bcrypt's own
constant-time compare. The plain password is not written down anywhere in this
package.

**To change the password**, make a new hash, replace the variable and redeploy:

    python3 -c "import bcrypt, getpass; print(bcrypt.hashpw(getpass.getpass('New admin password: ').encode(), bcrypt.gensalt(12)).decode())"

It prompts without echoing, so the password stays out of shell history. End all
admin sessions afterwards so the old password stops working everywhere.

**The endpoint behind it** (`POST /api/admin/session`) must also:

- Rate limit: 5 failed attempts per IP in 15 minutes, then `429` with a
  `Retry-After` header.
- Lock out: 10 consecutive failures lock the account for 15 minutes and email
  the account holder. Temporary on purpose, or anyone could lock the only admin
  out.
- Answer a wrong email and a wrong password identically (same `401`, same
  message, same time: run the bcrypt compare either way).
- Set the session cookie `Secure; HttpOnly; SameSite=Strict`, `Path=/`, no
  `Domain`, under a `__Host-` name, with a new session id at every sign in, 8
  hours maximum and 30 minutes idle. Sign out destroys it on the server.
- Require a TOTP code (authenticator app) after the password. This login can
  reveal full card numbers, so treat that as required.

Only one person should hold this login: with a single shared account, the card
reveal log can say which account and IP viewed a number, but not which person.

The full contract, with reasons, is in the main README under "The admin account"
and at the top of `admin.js`.

## Before you point the domain at it

- The application form and the payment step are already in this folder and wired
  up. Both run in demo mode: open `application.html` and `payment.html` and look for
  `var DEMO = true`. Flip it to false once the four API endpoints exist, and the
  fetch calls beside it take over.
- The payment step takes full card numbers, and the admin can reveal them. Do not
  flip `DEMO` on `payment.html` or `admin.html` until everything under "Storing full
  card numbers" in the main README is in place: encryption with a KMS key, the
  reveal log, the rate limit, scrubbed logs, and the PCI SAQ D work around them.
- `admin.html` still carries a preview-only sign in: `DEMO_ADMIN_EMAIL`,
  `DEMO_ADMIN_PASSWORD_SHA256` and `demoSignIn`, beside `var DEMO = true`. Delete
  all three when you flip `DEMO`, and set the two environment variables above.
- Wire the contact form. It currently validates and shows a success state without
  sending anything. Either add a Netlify Form (put `netlify` and `name="contact"` on
  the form tag and remove the preventDefault in `site.js`) or point it at your own
  endpoint.
- Search the folder for `EDIT:` for the three things only you can fill in: the legal
  entity name in the footer, the service fee figure, and the support hours.
- Update the date in `sitemap.xml` whenever you change the pages.
