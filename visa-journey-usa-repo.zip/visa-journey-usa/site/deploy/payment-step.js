/* =====================================================================
   Visa Journey USA — payment step (vanilla JavaScript)
   =====================================================================

   Visually this matches the existing payment page: the three-step header, the
   navy banner, the two-column layout with Payment Information on the left and
   Shopping Cart on the right, the card brand logos, and the green button.

   WHAT IS DIFFERENT, AND WHY

   1. THERE ARE THREE WAYS TO TAKE THE CARD, AND THEY ARE NOT EQUAL.

      Stripe Elements (mountCardFields) and the hosted redirect
      (`hostedRedirect: true`) keep the card number off your page, your server
      and your logs entirely. Each Elements field is an iframe served by
      Stripe. That is what keeps you on PCI SAQ A (a short self-assessment)
      and it makes it impossible to store a CVV by accident, which is
      prohibited outright. The mount points for Elements are #vj-card-number,
      #vj-card-expiry and #vj-card-cvc.

      `collectCard: true` is the third way, and it is the one payment.html
      uses today. The fee is charged later, by hand, on a processor this site
      is not connected to, so there is no token to save and the admin needs
      the actual number. In this mode the card fields are plain inputs on this
      page and the details go to your server through onSaveCard.

      That moves the whole site to PCI SAQ D: quarterly ASV scans, encryption
      with real key management, access logging, formal policies, annual
      validation. It was chosen knowingly. Do not build the server end of it
      without reading "Storing full card numbers" in README.md, and when the
      charge moves to a processor that can hold a token, switch back to one of
      the first two and delete the stored numbers.

      There is no CVV field in this mode, on purpose. A CVV is only any use
      for an authorisation made while the cardholder is present, and nothing
      is authorised here. PCI DSS forbids keeping it after authorisation, even
      encrypted, so a CVV collected now could never legitimately reach the
      later charge anyway. Do not add the field back "for the processor".

      Card data in this mode lives in this function's memory and nowhere else.
      It is never written to localStorage or sessionStorage, never logged, and
      the number is wiped from memory once the server has accepted it.

   2. THE BUTTON NO LONGER SAYS "OBTAIN YOUR VISA NOW".
      You prepare applications. A consular officer decides the outcome, and can
      refuse regardless of how good the paperwork is. Promising a visa is the
      single riskiest claim on the site.

   3. THE GOVERNMENT FEE IS NOT A GREY ASTERISK.
      It sits in the cart at the same weight as your own fee, with a total, so
      nobody reaches their card details thinking $185 is the whole cost. This
      also cuts chargebacks from customers who felt ambushed.

   4. THE VERISIGN AND "GUARANTEED SAFE CHECKOUT" BADGES ARE NOT INCLUDED.
      VeriSign's seal business passed to Symantec and then DigiCert years ago,
      so that seal is no longer issued and displaying it claims a certification
      that does not exist. The other two are decorative images with no
      certifying body behind them. The slot is still there: pass `sealHtml` to
      drop in a real seal your actual provider issues to you, served from their
      domain so a customer can click it and verify. Card brand logos are fine
      and are included.

   USAGE

     VisaJourneyPayment.mount(document.getElementById("payment"), {
       applicationId: "AB3K9QRTVX",
       serviceFee: 185,
       governmentFee: 185,
       onPay: async ({ nameOnCard, method }) => { ... },   // confirm with Stripe
       onBack: () => history.back(),
       mountCardFields: (nodes) => {
         const elements = stripe.elements();
         elements.create("cardNumber").mount(nodes.number);
         elements.create("cardExpiry").mount(nodes.expiry);
         elements.create("cardCvc").mount(nodes.cvc);
       },
     });

   Or, keeping the card details yourself (see note 1 above first):

     VisaJourneyPayment.mount(document.getElementById("payment"), {
       applicationId: "AB3K9QRTVX",
       serviceFee: 185,
       chargeLater: true,
       collectCard: true,
       onSaveCard: async ({ applicationId, card }) => { ... },
     });

   onSaveCard in collectCard mode receives

       { applicationId, method, nameOnCard,
         card: { name, number, expMonth, expYear, postal, brand, last4 } }

   number is digits only, already Luhn-checked. expMonth is 1-12, expYear is
   four digits, postal may be empty (plenty of applicants' countries have no
   postal codes). brand is "Visa", "Mastercard", "Discover" or "Amex". Reject
   the promise to show an error; set err.userMessage to choose the wording.
   ===================================================================== */

var VisaJourneyPayment = (function () {
  "use strict";

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === "class") node.className = v;
      else if (k === "text") node.textContent = v;
      else if (k === "html") node.innerHTML = v;
      else if (k.slice(0, 2) === "on") node.addEventListener(k.slice(2).toLowerCase(), v);
      else node.setAttribute(k, v === true ? "" : v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  var STYLE_ID = "vjp-styles";
  var CSS = [
    ".vjp{--navy:#17356b;--navy-line:#1b3a6b;--green:#3ea63e;--green-dark:#348a34;",
    "--ink:#1f2937;--muted:#4b5563;--line:#cbd5e1;--amber:#b45309;--amber-bg:#fffbeb;",
    "font-family:system-ui,-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:var(--ink);",
    "background:#fff;padding:1.5rem 1rem 4rem;box-sizing:border-box}",
    ".vjp *,.vjp *:before,.vjp *:after{box-sizing:inherit}",
    ".vjp-wrap{max-width:64rem;margin:0 auto}",
    ".vjp-title{text-align:center;font-size:1.5rem;font-weight:400;color:var(--ink);margin:0 0 1.5rem}",
    ".vjp-steps{display:flex;justify-content:center;gap:3rem;flex-wrap:wrap;margin-bottom:1.75rem;padding:0;list-style:none}",
    ".vjp-step{text-align:center}",
    ".vjp-dot{width:2rem;height:2rem;border-radius:999px;display:flex;align-items:center;justify-content:center;",
    "margin:0 auto .5rem;font-size:.875rem;font-weight:600;color:#fff;background:#9ca3af}",
    ".vjp-step.vjp-now .vjp-dot{background:var(--navy)}",
    ".vjp-step p{margin:0;font-size:.875rem;color:var(--muted)}",
    ".vjp-step.vjp-now p{color:var(--navy);font-weight:600}",
    ".vjp-banner{background:var(--navy);color:#fff;text-align:center;padding:1.25rem 1rem;margin-bottom:1.75rem}",
    ".vjp-banner p{margin:0;font-size:1.0625rem;font-weight:600}",
    ".vjp-banner p+p{margin-top:.375rem;font-size:.9375rem;font-weight:400;color:#c7d5ee}",
    ".vjp-cols{display:grid;grid-template-columns:1fr;gap:1.5rem}",
    "@media(min-width:820px){.vjp-cols{grid-template-columns:1.15fr .85fr}}",
    ".vjp-box{border:2px solid var(--navy-line);padding:1.5rem}",
    ".vjp-boxhead{color:var(--navy);font-size:1rem;font-weight:700;letter-spacing:.02em;margin:0 0 1.25rem;text-transform:uppercase}",
    ".vjp-radio{display:flex;gap:.5rem;align-items:center;margin-bottom:1.25rem;cursor:pointer}",
    ".vjp-radio span{font-weight:600;font-size:.9375rem}",
    ".vjp-method{font-weight:600;font-size:.9375rem;color:var(--ink);margin:0 0 1.25rem}",
    ".vjp-disclosure{font-size:.875rem;line-height:1.6;color:var(--ink);margin:1.25rem 0 0}",
    ".vjp-line{display:grid;grid-template-columns:9rem 1fr;gap:1rem;align-items:center;margin-bottom:1rem}",
    "@media(max-width:560px){.vjp-line{grid-template-columns:1fr;gap:.375rem}}",
    ".vjp-line>label{font-size:.9375rem;color:var(--ink)}",
    ".vjp-in{width:100%;border:1px solid var(--line);border-radius:2px;padding:.5rem .625rem;font-size:1rem;",
    "font-family:inherit;background:#fff;color:var(--ink);min-height:2.375rem}",
    ".vjp-in:focus{outline:none;border-color:var(--navy);box-shadow:0 0 0 2px rgba(23,53,107,.25)}",
    ".vjp-pair{display:grid;grid-template-columns:1fr 1fr;gap:1rem}",
    ".vjp-stripe{border:1px solid var(--line);border-radius:2px;padding:.625rem;background:#fff;min-height:2.375rem}",
    ".vjp-stripe.vjp-ready{padding:.5rem .625rem}",
    ".vjp-brands{display:flex;gap:.5rem;margin:.25rem 0 1rem;flex-wrap:wrap}",
    ".vjp-brands img{height:1.5rem;width:auto}",
    ".vjp-brand-fallback{display:inline-flex;align-items:center;justify-content:center;height:1.5rem;padding:0 .5rem;",
    "border:1px solid var(--line);border-radius:2px;font-size:.6875rem;font-weight:700;color:var(--muted);background:#f8fafc}",
    ".vjp-pay{display:block;width:100%;background:var(--green);color:#fff;border:0;padding:1rem;font-size:1.125rem;",
    "font-weight:700;cursor:pointer;font-family:inherit;margin-top:1.25rem}",
    ".vjp-pay:hover{background:var(--green-dark)}",
    ".vjp-pay[disabled]{opacity:.6;cursor:default}",
    ".vjp-cart{display:flex;justify-content:space-between;align-items:baseline;gap:1rem;font-size:1.25rem}",
    ".vjp-cart .vjp-amt{font-weight:600;white-space:nowrap}",
    ".vjp-cartrow{display:flex;justify-content:space-between;align-items:baseline;gap:1rem;",
    "padding:.625rem 0;border-top:1px solid var(--line);font-size:.9375rem}",
    ".vjp-cartrow:first-of-type{border-top:0}",
    ".vjp-total{display:flex;justify-content:space-between;gap:1rem;padding-top:.75rem;margin-top:.25rem;",
    "border-top:2px solid var(--navy-line);font-weight:700;font-size:1.0625rem}",
    ".vjp-seal{margin-top:1.25rem;text-align:center}",
    ".vjp-assure{margin:1.25rem 0 0;padding:0;list-style:none;border-top:1px solid var(--line);padding-top:1rem}",
    ".vjp-assure li{font-size:.8125rem;color:var(--muted);line-height:1.5;margin-bottom:.375rem}",
    ".vjp-note{font-size:.8125rem;color:var(--muted);line-height:1.55;margin:1rem 0 0}",
    ".vjp-consent{display:flex;gap:.625rem;margin:1.25rem 0 0;cursor:pointer}",
    ".vjp-consent span{font-size:.8125rem;line-height:1.55;color:var(--ink)}",
    ".vjp-err{color:#b91c1c;font-size:.875rem;margin:.75rem 0 0}",
    /* charge-later mode. The first says nothing is taken today; the second
       stops the amount beside it reading as due now. */
    ".vjp-hold{background:#f0fdfa;border:1px solid #99f6e4;border-radius:.375rem;",
    "padding:.75rem .875rem;margin:0 0 1.25rem;font-size:.8125rem;line-height:1.6;color:#115e59}",
    ".vjp-due{margin:.5rem 0 0;font-size:.75rem;line-height:1.5;color:#92400e;",
    "background:#fffbeb;border:1px solid #fde68a;border-radius:.25rem;padding:.5rem .625rem}",
    ".vjp-back{background:none;border:0;color:var(--navy);text-decoration:underline;font-size:.875rem;",
    "cursor:pointer;font-family:inherit;padding:0;margin-top:1rem}",
    ".vjp-ref{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:600}",
    /* collectCard mode: plain inputs, so they carry their own error state. */
    ".vjp-in[aria-invalid=true]{border-color:#b91c1c}",
    ".vjp-ferr{color:#b91c1c;font-size:.8125rem;margin:.375rem 0 0}",
    ".vjp-fhint{color:var(--muted);font-size:.75rem;margin:.375rem 0 0;line-height:1.5}",
    ".vjp-num{font-variant-numeric:tabular-nums;letter-spacing:.04em}",
    ".vjp-exp{display:grid;grid-template-columns:1fr 1fr;gap:1rem;max-width:16rem}",
    ".vjp-postal{max-width:10rem}",
    ".vjp-brand-fallback.vjp-on{border-color:var(--navy);color:var(--navy);background:#eef2fb}",
    ".vjp-brands img.vjp-off{opacity:.35}",
  ].join("");

  function injectStyles() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID; s.textContent = CSS;
    document.head.appendChild(s);
  }

  var BRANDS = ["Visa", "Mastercard", "Discover", "Amex"];

  /* ---------------------------------------------------- card checks ----
     Used only in collectCard mode. They catch typing mistakes before the
     number is stored, which matters more than usual here: nobody tries the
     card until weeks later, and by then the applicant has moved on. They are
     not a substitute for the processor's own checks at charge time. */

  function digitsOnly(v) { return String(v || "").replace(/\D/g, ""); }

  /* Prefixes for the four brands shown on the page. Mastercard includes the
     2221-2720 range issued since 2017, which older checks still miss. Discover
     includes the UnionPay ranges it accepts in the US. */
  function cardBrand(digits) {
    var d = digitsOnly(digits);
    var four = Number(d.slice(0, 4));
    var six = Number(d.slice(0, 6));
    if (/^4/.test(d)) return "Visa";
    if (/^3[47]/.test(d)) return "Amex";
    if (/^5[1-5]/.test(d) || (d.length >= 4 && four >= 2221 && four <= 2720)) return "Mastercard";
    if (/^(6011|65|64[4-9])/.test(d) || (d.length >= 6 && six >= 622126 && six <= 622925)) return "Discover";
    return "";
  }

  var LENGTHS = { Visa: [13, 16, 19], Mastercard: [16], Amex: [15], Discover: [16, 17, 18, 19] };

  function luhn(digits) {
    var d = digitsOnly(digits), sum = 0, dbl = false;
    for (var i = d.length - 1; i >= 0; i--) {
      var n = d.charCodeAt(i) - 48;
      if (dbl) { n *= 2; if (n > 9) n -= 9; }
      sum += n; dbl = !dbl;
    }
    return d.length > 0 && sum % 10 === 0;
  }

  /* Shown in fours as it is typed, so the applicant can check it against the
     card in groups rather than as one run of sixteen digits. */
  function groupDigits(digits) {
    return digitsOnly(digits).replace(/(\d{4})(?=\d)/g, "$1 ");
  }

  /* A card is good until the last day of its expiry month. */
  function expired(month, year, now) {
    now = now || new Date();
    var y = Number(year), m = Number(month);
    return y < now.getFullYear() || (y === now.getFullYear() && m < now.getMonth() + 1);
  }

  /* Returns { field: message } for everything wrong, empty when all is well. */
  function checkCard(c, now) {
    var errs = {};
    var num = digitsOnly(c.number);
    var brand = cardBrand(num);
    if (!String(c.nameFirst || "").trim() || !String(c.nameLast || "").trim()) {
      errs.name = "Enter the name exactly as it appears on the card.";
    }
    if (!num) errs.number = "Enter the card number.";
    else if (!brand) errs.number = "We accept Visa, Mastercard, Discover and American Express. Check the number or use one of those.";
    else if (LENGTHS[brand].indexOf(num.length) === -1 || !luhn(num)) {
      errs.number = "That card number is not valid. Check it against your card.";
    }
    if (!c.expMonth || !c.expYear) errs.expiry = "Choose the month and year printed on the card.";
    else if (expired(c.expMonth, c.expYear, now)) errs.expiry = "This card has expired. Use a card that is still valid.";
    var postal = String(c.postal || "").trim();
    if (postal && !/^[A-Za-z0-9][A-Za-z0-9 -]{1,9}$/.test(postal)) {
      errs.postal = "Check the postal code. Use letters, numbers, spaces or hyphens only.";
    }
    return errs;
  }

  function mount(container, options) {
    options = options || {};
    injectStyles();

    var serviceFee = options.serviceFee == null ? 185 : options.serviceFee;
    /* Still accepted so existing mount calls do not break, but nothing on this
       page renders it since the government fee panel was removed. */
    var governmentFee = options.governmentFee == null ? 185 : options.governmentFee;
    void governmentFee;
    /* chargeLater: the applicant authorises a card that is stored with the
       payment provider and charged later, from the admin, once the work is
       done. Nothing is taken today. The page has to say so in plain words in
       more than one place, because a card form that does not charge is not what
       anyone expects, and because storing a credential for later use has to be
       disclosed before it is stored. */
    var later = options.chargeLater === true;
    /* collectCard: see note 1 at the top of this file before turning it on. */
    var collect = options.collectCard === true;
    var state = { method: "card", busy: false, error: "", nameFirst: "", nameLast: "",
                  number: "", expMonth: "", expYear: "", postal: "", fieldErrors: {} };

    /* ------------------------------------------------ collectCard fields --
       Plain inputs, deliberately outside any form element so a stray Enter or
       a browser extension cannot submit them anywhere. Typing updates state
       without redrawing, so the cursor stays put; the page only redraws on
       the button. */
    function cardInputs(left) {
      var errs = state.fieldErrors || {};

      function errFor(key, id) {
        return errs[key] ? el("p", { class: "vjp-ferr", id: id, text: errs[key] }) : null;
      }

      var f = el("input", { class: "vjp-in", id: "vjp-name-first", "aria-label": "First name on card",
        autocomplete: "cc-given-name", "aria-invalid": errs.name ? "true" : null,
        "aria-describedby": errs.name ? "vjp-err-name" : null,
        oninput: function () { state.nameFirst = f.value; } });
      var l = el("input", { class: "vjp-in", "aria-label": "Last name on card",
        autocomplete: "cc-family-name", "aria-invalid": errs.name ? "true" : null,
        oninput: function () { state.nameLast = l.value; } });
      f.value = state.nameFirst; l.value = state.nameLast;
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-name-first", text: "Name on Card" }),
        el("div", {}, [el("div", { class: "vjp-pair" }, [f, l]), errFor("name", "vjp-err-name")]),
      ]));

      var brands = el("div", { class: "vjp-brands", "aria-hidden": "true" });
      function lightBrand(digits) {
        var b = cardBrand(digits);
        Array.prototype.forEach.call(brands.children, function (node) {
          var on = !!b && node.getAttribute("data-brand") === b;
          if (node.tagName === "IMG") node.className = b && !on ? "vjp-off" : "";
          else node.className = "vjp-brand-fallback" + (on ? " vjp-on" : "");
        });
      }

      /* type=text with inputmode, not type=number: a number input drops
         leading zeros, shows spinners, and lets a scroll wheel change the
         value. autocomplete=cc-number lets the browser or a password manager
         fill it, which is fewer typos than any check below. */
      var num = el("input", { class: "vjp-in vjp-num", id: "vjp-card-number", type: "text",
        inputmode: "numeric", autocomplete: "cc-number", spellcheck: "false",
        maxlength: "23", placeholder: "1234 1234 1234 1234",
        "aria-invalid": errs.number ? "true" : null,
        "aria-describedby": errs.number ? "vjp-err-number" : null,
        oninput: function () {
          var before = num.value.slice(0, num.selectionStart || 0);
          var keep = digitsOnly(before).length;
          var digits = digitsOnly(num.value).slice(0, 19);
          num.value = groupDigits(digits);
          state.number = digits;
          lightBrand(digits);
          /* Put the cursor back after the same number of digits, so editing
             the middle of the number does not throw it to the end. */
          var pos = 0, seen = 0;
          while (pos < num.value.length && seen < keep) {
            if (/\d/.test(num.value.charAt(pos))) seen++;
            pos++;
          }
          try { num.setSelectionRange(pos, pos); } catch (e) { /* not focused */ }
        } });
      num.value = groupDigits(state.number);
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-card-number", text: "Credit Card Number" }),
        el("div", {}, [num, errFor("number", "vjp-err-number")]),
      ]));

      BRANDS.forEach(function (b) {
        if (options.brandLogos && options.brandLogos[b]) {
          brands.appendChild(el("img", { src: options.brandLogos[b], alt: b, "data-brand": b }));
        } else {
          brands.appendChild(el("span", { class: "vjp-brand-fallback", "data-brand": b,
            text: b.toUpperCase() }));
        }
      });
      lightBrand(state.number);
      left.appendChild(el("div", { class: "vjp-line" }, [el("span", {}), brands]));

      /* Two selects rather than an MM/YY text box. Nothing to mistype, and
         nobody has to guess whether the year is two digits or four. */
      var month = el("select", { class: "vjp-in", id: "vjp-exp-month", "aria-label": "Expiry month",
        autocomplete: "cc-exp-month", "aria-invalid": errs.expiry ? "true" : null,
        "aria-describedby": errs.expiry ? "vjp-err-expiry" : null,
        onchange: function () { state.expMonth = month.value; } },
        [el("option", { value: "", text: "Month" })].concat(
          [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(function (m) {
            var mm = (m < 10 ? "0" : "") + m;
            return el("option", { value: String(m), text: mm, selected: String(m) === String(state.expMonth) });
          })));
      var thisYear = new Date().getFullYear();
      var years = [];
      for (var y = thisYear; y <= thisYear + 15; y++) years.push(y);
      var year = el("select", { class: "vjp-in", "aria-label": "Expiry year",
        autocomplete: "cc-exp-year", "aria-invalid": errs.expiry ? "true" : null,
        onchange: function () { state.expYear = year.value; } },
        [el("option", { value: "", text: "Year" })].concat(years.map(function (yy) {
          return el("option", { value: String(yy), text: String(yy), selected: String(yy) === String(state.expYear) });
        })));
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-exp-month", text: "Expiration Date" }),
        el("div", {}, [el("div", { class: "vjp-exp" }, [month, year]), errFor("expiry", "vjp-err-expiry")]),
      ]));

      /* Optional. Many applicants live where postal codes are not used, and
         a required field there gets filled with 00000, which is worse than
         nothing when the processor checks it against the bank's records. */
      var postal = el("input", { class: "vjp-in vjp-postal", id: "vjp-postal", type: "text",
        autocomplete: "postal-code", maxlength: "10",
        "aria-invalid": errs.postal ? "true" : null,
        "aria-describedby": errs.postal ? "vjp-err-postal" : "vjp-postal-hint",
        oninput: function () { state.postal = postal.value; } });
      postal.value = state.postal;
      left.appendChild(el("div", { class: "vjp-line" }, [
        el("label", { "for": "vjp-postal", text: "Billing Postal Code" }),
        el("div", {}, [postal,
          errFor("postal", "vjp-err-postal") ||
          el("p", { class: "vjp-fhint", id: "vjp-postal-hint",
            text: "The postal code your bank has for this card. Leave it blank if your address does not have one." })]),
      ]));

      /* No CVV field. See note 1 at the top of this file. */
    }

    function focusFirstError() {
      var bad = container.querySelector("[aria-invalid=true]");
      if (bad && bad.focus) bad.focus();
    }

    function render() {
      container.className = "vjp";
      container.innerHTML = "";

      /* ---- header ---- */
      var steps = el("ol", { class: "vjp-steps" });
      ["Complete the Form", "Review", "Payment"].forEach(function (label, i) {
        var now = i === 2;
        steps.appendChild(el("li", { class: "vjp-step" + (now ? " vjp-now" : "") }, [
          el("div", { class: "vjp-dot", text: String(i + 1) }),
          el("p", { text: label }),
        ]));
      });

      var banner = el("div", { class: "vjp-banner" }, [
        el("p", { text: later
          ? "Your card details are handled over a secure, encrypted connection."
          : "Your payment is processed over a secure, encrypted connection." }),
        el("p", { text: later
          ? "Your card will not be charged today. We take the fee once we have prepared and reviewed your application."
          : "Complete your preparation fee and we will review your application." }),
      ]);

      /* ---- left column: payment information ---- */
      var left = el("div", { class: "vjp-box" }, [
        el("p", { class: "vjp-boxhead", text: later ? "Card details" : "Payment Information" })]);

      /* Said once, prominently, before any card field. Someone who stops
         reading here should still have been told the two things that matter:
         nothing is taken now, and we will take it later without asking again. */
      if (later) {
        left.appendChild(el("p", { class: "vjp-hold" }, [
          el("strong", { text: "Nothing is charged today. " }),
          (collect
            ? "We keep your card details encrypted and charge the $"
            : "We store your card securely with our payment provider and charge the $") +
          serviceFee + " preparation fee once our team has prepared and reviewed " +
          "your application. We will email you when we do. You are not charged " +
          "again after that.",
        ]));
      }

      /* Card is the only method offered, so this is a heading rather than a
         radio. A radio group with one option asks the customer to make a choice
         that does not exist. ACH was removed in September 2026; if it comes
         back, restore the radio group along with it. */
      left.appendChild(el("p", { class: "vjp-method",
        text: later ? "Credit or debit card" : "Credit card payment" }));

      {
        if (collect) {
          cardInputs(left);
        } else if (options.hostedRedirect) {
          left.appendChild(el("p", { class: "vjp-note", style: "margin-top:0",
            text: later
              ? "You will be taken to our payment provider to enter your card details securely. They store the card; we never see or store your card number."
              : "You will be taken to our payment provider to enter your card details securely. We never see or store your card number." }));
        } else {
          /* Name on card is safe to collect here: it is not card data under PCI. */
          var f = el("input", { class: "vjp-in", "aria-label": "First name on card",
            oninput: function () { state.nameFirst = f.value; } });
          var l = el("input", { class: "vjp-in", "aria-label": "Last name on card",
            oninput: function () { state.nameLast = l.value; } });
          f.value = state.nameFirst; l.value = state.nameLast;
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Name on Card" }),
            el("div", { class: "vjp-pair" }, [f, l]),
          ]));

          /* Stripe Elements mount points. Each renders an iframe served by
             Stripe, so the card number never enters this page. */
          var numberNode = el("div", { class: "vjp-stripe", id: "vj-card-number" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Credit Card Number" }), numberNode,
          ]));

          var brands = el("div", { class: "vjp-brands" });
          BRANDS.forEach(function (b) {
            if (options.brandLogos && options.brandLogos[b]) {
              brands.appendChild(el("img", { src: options.brandLogos[b], alt: b }));
            } else {
              brands.appendChild(el("span", { class: "vjp-brand-fallback", text: b.toUpperCase() }));
            }
          });
          left.appendChild(el("div", { class: "vjp-line" }, [el("span", {}), brands]));

          var expiryNode = el("div", { class: "vjp-stripe", id: "vj-card-expiry" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "Expiration Date" }), expiryNode,
          ]));

          var cvcNode = el("div", { class: "vjp-stripe", id: "vj-card-cvc", style: "max-width:10rem" });
          left.appendChild(el("div", { class: "vjp-line" }, [
            el("label", { text: "CCV" }), cvcNode,
          ]));

          if (typeof options.mountCardFields === "function") {
            setTimeout(function () {
              try { options.mountCardFields({ number: numberNode, expiry: expiryNode, cvc: cvcNode }); }
              catch (err) { state.error = "We could not load the secure card fields. Please refresh and try again."; }
            }, 0);
          } else {
            [numberNode, expiryNode, cvcNode].forEach(function (n) {
              n.appendChild(el("span", { style: "color:#9ca3af;font-size:.8125rem",
                text: "Secure field, loaded by payment provider" }));
            });
          }
        }
      }

      /* Stated as a plain disclosure, not a checkbox. The wording still has to
         appear before the pay button, and it still has to say the fee is ours,
         that the government fee is separate, and that nothing is guaranteed. */
      left.appendChild(el("p", { class: "vjp-disclosure",
        text: later
          ? "The $" + serviceFee + " we will charge is a preparation service fee paid to Visa Journey USA. It is separate from the government fees you pay yourself, and it does not guarantee a visa. By continuing you authorise us to charge this card for that fee once the work is done, without asking you again."
          : "This $" + serviceFee + " is a preparation service fee paid to Visa Journey USA. It is separate from the government fees you pay yourself, and it does not guarantee a visa." }));

      var payBtn = el("button", { type: "button", class: "vjp-pay",
        text: state.busy
          ? (later ? "Saving" : "Processing")
          : (later ? "Save my card and Submit" : "Pay $" + serviceFee + " and Submit"),
        onclick: function () {
          if (state.busy) return;
          var payload = {
            method: state.method,
            nameOnCard: (state.nameFirst + " " + state.nameLast).trim(),
          };
          if (collect) {
            state.fieldErrors = checkCard(state);
            if (Object.keys(state.fieldErrors).length) {
              state.error = "Some card details need attention. Check the highlighted fields above.";
              render();
              focusFirstError();
              return;
            }
            var num = digitsOnly(state.number);
            payload.applicationId = options.applicationId || "";
            payload.card = {
              name: payload.nameOnCard, number: num,
              expMonth: Number(state.expMonth), expYear: Number(state.expYear),
              postal: state.postal.trim(), brand: cardBrand(num), last4: num.slice(-4),
            };
          }
          state.error = ""; state.busy = true; render();
          var handler = later ? (options.onSaveCard || options.onPay) : options.onPay;
          Promise.resolve(handler && handler(payload)).then(function () {
            /* Accepted by the server, so this page has no further use for the
               number. Dropping it means nothing is left in memory for a
               browser extension or a later script on the page to find. */
            state.number = ""; payload.card && (payload.card.number = "");
          }).catch(function (err) {
            state.busy = false;
            state.error = (err && err.userMessage) || (later
              ? "We could not save your card. Nothing has been charged. Please check your details and try again."
              : "We could not take the payment. No money has been taken. Please check your details and try again.");
            render();
          });
        } });
      payBtn.disabled = state.busy;
      left.appendChild(payBtn);
      if (state.error) left.appendChild(el("p", { class: "vjp-err", role: "alert", text: state.error }));
      left.appendChild(el("p", { class: "vjp-note",
        text: later
          ? "Saving your card does not submit your application to the U.S. government. You must still sign the DS-160 yourself and attend your interview in person."
          : "Paying this fee does not submit your application to the U.S. government. You must still sign the DS-160 yourself and attend your interview in person." }));

      /* ---- right column: shopping cart ---- */
      var right = el("div", {}, []);
      var cart = el("div", { class: "vjp-box" }, [
        el("div", { class: "vjp-cart" }, [
          el("span", { text: "Visa service fee" }),
          el("span", { class: "vjp-amt", text: "$" + serviceFee }),
        ]),
      ]);

      /* The amount sits beside a card form, so it has to say when it is taken.
         Without this line the figure reads as due now. */
      if (later) {
        cart.appendChild(el("p", { class: "vjp-due",
          text: "Due later. Charged once we have prepared and reviewed your application, not today." }));
      }

      /* The government fee panel and the combined total were removed at the
         client's request, September 2026. The separation of the two fees is now
         carried by the disclosure sentence above the pay button, by the notice
         bar at the top of every page, and by the site footer. If any of those
         three ever go, this panel needs to come back: nothing else on this page
         tells the customer the government fee exists. */

      if (options.sealHtml) {
        cart.appendChild(el("div", { class: "vjp-seal", html: options.sealHtml }));
      }

      /* Only claims that can be substantiated. See the note at the top of this
         file about the badges that were here before. */
      /* The middle line changed with collectCard. "Never stored on our
         servers" stopped being true the day the number started being kept,
         and a claim like that on a payment page is the one a regulator or a
         chargeback reviewer reads literally. */
      cart.appendChild(el("ul", { class: "vjp-assure" }, collect ? [
        el("li", { text: "Card details are sent over an encrypted connection and stored encrypted" }),
        el("li", { text: "Used only to charge this fee, then deleted" }),
        el("li", { text: "We never ask for or store your card security code" }),
        el("li", { text: "Refund terms are set out in our Terms and Conditions" }),
      ] : [
        el("li", { text: "Payments handled by a PCI-compliant payment provider" }),
        el("li", { text: "Card details are never stored on our servers" }),
        el("li", { text: "Refund terms are set out in our Terms and Conditions" }),
      ]));

      right.appendChild(cart);
      if (options.applicationId) {
        right.appendChild(el("p", { class: "vjp-note" }, [
          "Application ", el("span", { class: "vjp-ref", text: options.applicationId }),
        ]));
      }
      if (typeof options.onBack === "function") {
        right.appendChild(el("button", { type: "button", class: "vjp-back", text: "Back to review", onclick: options.onBack }));
      }

      container.appendChild(el("div", { class: "vjp-wrap" }, [
        el("h1", { class: "vjp-title", text: "Prepare your visa application in 3 easy steps" }),
        steps, banner,
        el("div", { class: "vjp-cols" }, [left, right]),
      ]));
    }

    render();
    return { setBusy: function (v) { state.busy = v; render(); },
             setError: function (m) { state.error = m; state.busy = false; render(); } };
  }

  /* The card checks are exposed so they can be tested on their own, and so the
     server can be compared against them. The server must repeat them: anything
     a browser checks, a browser can skip. */
  return { mount: mount, luhn: luhn, cardBrand: cardBrand, checkCard: checkCard };
})();

if (typeof module !== "undefined" && module.exports) module.exports = VisaJourneyPayment;
