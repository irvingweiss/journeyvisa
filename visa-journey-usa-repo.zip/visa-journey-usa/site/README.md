# Visa Journey USA — developer handover

Static site. No framework, no build step, no dependencies. Plain HTML, one CSS
file, and three JavaScript files. It runs on any static host.

---

**New here?** `CHANGELOG.md` beside this file lists what changed in this version and
what still has to be built on the server, the email endpoint most of all.

## What is in this package

    deploy/     Upload this. Production-ready, clean URLs, headers, sitemap.
    src/        The same site with relative links, plus the build scripts.
    preview/    Two self-contained HTML files, the site and the admin screen.
                For showing people, not for hosting.
    tests/      658 automated checks, plus a link check and a live-site check.
                Run them before and after any change.

The tests are not decoration. Several of them guard fixes that look like tidy-up
candidates to anyone who was not here, and the two listed at the bottom of this
file have already been reintroduced once each.

If you only read one other file, read `deploy/DEPLOY.md`.

---

## Deploying

Drag the `deploy` folder onto Netlify. Not the zip, not the files individually.
`netlify.toml` is read automatically, so nothing needs configuring in the dashboard.

**Upload the whole folder.** Every file in it is linked from somewhere in the site,
so a partial upload breaks links on a build that is correct. This has happened once:
the eight core pages went up and all six search pages did not, which left six dead
links in the nav and footer of every page. `CHANGELOG.md` has the detail.

After it goes out, check the server rather than trusting the build:

    python3 tests/live_check.py https://www.visajourneyusa.com

If it goes into Git instead:

    Build command:      (leave empty)
    Publish directory:  deploy

For any other host: serve `deploy/` as the document root and turn on extensionless
URL resolution, so `/about-us` serves `about-us.html`. Netlify does this by default.
On nginx it is `try_files $uri $uri.html $uri/ =404;`.

---

## Pages

    /                        homepage
    /about-us
    /contact-us              form, client-side validation only
    /application             the 21-section DS-160 form
    /payment                 preparation fee, hands off to your payment provider
    /resume                  get back into an application in progress
    /terms-and-conditions    plain-English summary, full text still to be pasted in
    /privacy-policy          same
    404.html                 Netlify serves this automatically

`/payment` and `/resume` are `noindex` and are deliberately absent from the sitemap.

---

## The three JavaScript files

**`visa-application-form.js`** is the application form. It exposes two functions:

    VisaJourneyForm.mount(element, options)
    VisaJourneyForm.mountResume(element, options)

It styles itself, holds all 21 sections and their conditional logic, and keeps
nothing in localStorage or sessionStorage. Passport and ID numbers do not survive
a page close, which is deliberate: shared and stolen devices are a real risk for
this audience. That also means an unsaved step is genuinely lost, so
`onSaveStep` has to reject when a write fails.

**`payment-step.js`** is the fee screen. `VisaJourneyPayment.mount(element, options)`.
In the mode the site uses today it collects the full card details and hands them
to `onSaveCard`. It keeps them in memory only, never in browser storage, and never
asks for the CVV.

**`site.js`** is the mobile menu and the contact form. Nothing else.

---

## What you need to build

### 1. Four endpoints for the form

Open `application.html` and `resume.html` and look for `var DEMO = true`. While
that is true, reference numbers are generated in the browser and nothing is stored.
Fine for review, wrong for real applicants: every one of them loses their answers.

Flip it to false and the `fetch` calls beside it take over. They expect:

    POST /api/application
      in:   { securityPrompt, securityAnswer }
      out:  { applicationId }
      Hash the answer with bcrypt or argon2. Never store it in plain text.
      The form drops it from memory as soon as this resolves.

    PATCH /api/application/:id
      in:   { applicationId, stepId, data }
      out:  204
      Must return non-2xx on a failed write. The form shows "Could not save"
      and keeps the answers on screen, which is the whole safety net.

    POST /api/application/submit
      in:   the full answer set
      out:  200

    GET /api/application/:id
      out:  { applicationId, data, stepIndex }  when the session is valid
            401 or 403 when it is not
      This is what makes a browser refresh survivable. The page keeps the
      reference and step in the URL, then asks for the answers back. Authorise
      it with the session you set on create or resume, never with the
      reference number alone: the reference is not a secret, it is printed on
      screen and emailed.

    POST /api/application/lookup
      in:   { applicationId }
      out:  { securityPrompt }

    POST /api/application/resume
      in:   { applicationId, answer }
      out:  { applicationId, data, stepIndex }
      This one has to return the saved answers, not just a success flag.
      `data` is the same shape onSaveStep has been receiving, and `stepIndex`
      is where they left off. The widget hands all three to the form and
      reopens it in place. Return 401 for a wrong answer, and put
      attemptsRemaining on the error body to have the count shown.

Rate limit `lookup` and `resume`. Those two are what someone would hammer to guess
a reference number. Lock an application after a handful of failed answers.

Resuming deliberately needs this round trip: nothing is kept in browser storage, so
the server is the only place the saved answers exist.

### 2. The contact form

`site.js` validates and shows a success state without sending anything. Either:

- Netlify Forms: add `netlify` and `name="contact"` to the `<form>` tag in
  `contact-us.html` and remove the `preventDefault` in `site.js`. Submissions
  appear in the Netlify dashboard. No backend at all.
- Or point it at your own endpoint. Validate again server side and rate limit it.

### 3. Payment

`payment.html` runs in `collectCard` mode: the card fields are on the page and
the details go to your server, because the fee is charged later, by hand, on a
processor this site is not connected to. While `DEMO` is true the fields work and
are checked, but nothing is sent. Before flipping it, read "Storing full card
numbers" below. All of it. That section is the price of this mode, and none of it
is optional.

Never trust an amount sent from the browser. The amount charged is whatever the
admin records in the admin screen against what the processor actually took.

---

## Before it goes live

- **Remove `noindex,nofollow`.** The current production site sends it on every page.
  These files send `index,follow`, so if the tag survives the switch it is being
  injected by a layout or a header somewhere. Nothing can rank until it is gone.
- ~~Host the hero image locally.~~ Done. The hotlinked photograph 404'd, so it is
  now `hero.svg`, a 4 KB flat vector in the site's palette with no external
  dependency. Swap in a photograph if you prefer, but keep it local and 4:3.
- **Fill in the three `EDIT:` markers.** Grep for them. They are the registered legal
  entity in the footer, the service fee figure, and the support hours.
- **Paste the real legal copy** into `terms-and-conditions.html` and
  `privacy-policy.html`. Both currently carry an honest plain-English summary and a
  marked block where the full text belongs.
- Update the date in `sitemap.xml` when the pages change.
- **Set up the admin account on the server** (`ADMIN_EMAIL`, `ADMIN_PASSWORD_HASH`,
  lockout, session cookie), change the password if it has been sent around,
  and delete the preview-only sign in from `admin.html` (`DEMO_ADMIN_EMAIL`,
  `DEMO_ADMIN_PASSWORD_SHA256`, `demoSignIn`, `DEMO_MFA_CODE`, `demoVerifyCode`)
  along with its `DEMO` flag. All of it is under "The admin account", below.
- **Enrol the second factor and build `POST /api/admin/session/verify`** before
  switching on the card-reveal route. Keep the ten recovery codes somewhere that
  is not the same phone as the authenticator app. Under "The second factor".

---

## Refreshing the page

Answers are never written to browser storage, so a refresh cannot restore them from
the browser. Instead:

- The form reports its position, and `application.html` keeps it in the URL as
  `?ref=ABC123&step=7` via `replaceState`.
- On load with a `ref`, the page asks `GET /api/application/:id` for the saved
  answers and reopens at the saved step.
- If that returns 401 or 403, the person goes to `/resume?ref=ABC123` with the
  reference already filled in, so it is one security question rather than a lost
  application.
- A `beforeunload` guard warns before a refresh throws away edits made since the
  last Continue, since only completed steps reach the server.

### Emailing the reference number

Optional, offered on the screen where the number is issued, and only sent if the
applicant types an address and presses the button. It is wired to:

    POST /api/application/email-reference
      in:   { applicationId, email, kind: "reference" }
      out:  200

**It does not send anything yet.** `DEMO = true` means the button is wired to a
callback that deliberately fails with "no email was actually sent", so nobody is
shown a confirmation for mail that never left. Flip `DEMO` and build the endpoint
and it starts working with no other change. The same applies to the resume link
behind "Save and finish later".

Two rules for whoever writes that endpoint:

- **The email contains the reference number and nothing else.** Never the security
  answer. Those two together are the whole credential, and the form explicitly tells
  applicants not to send them in one message. Sending them one ourselves would be
  worse than pointless.
- **Rate limit it.** An open send endpoint keyed on an application id is a way to
  post mail to strangers.

Delete the `onEmailReference` callback from `application.html` and the option
disappears from the screen. There is also `onRequestResumeLink`, used by the
"Save and finish later" link, which emails a link back into the application. That
one only works once the applicant has reached the step where their email address is
collected, and the form now says so rather than doing nothing.

### The draft cache

There is also a browser-side cache, so a refresh puts the answers back immediately
without waiting on the server. `application.html` and `resume.html` switch it on with
`draftCache: "session"`. Set it to `"none"` to turn it off.

It uses sessionStorage, never localStorage: it belongs to one tab and is gone when
that tab closes, so nothing is left sitting on a shared machine.

These are never written to it, whatever the setting, and the list is in
`visa-application-form.js` as `NEVER_CACHED`:

- the security answer and its confirmation
- passport number and passport book number, including inside the other-nationality rows
- national ID, US SSN, US taxpayer ID
- the photograph

Those are the fields that make a borrowed or stolen device genuinely dangerous, and
they each take seconds to retype. The form says so on screen when it restores a
draft, and offers a button to throw the draft away. The draft is deleted on submit.

Do not add passport or ID numbers to that cache to make resuming smoother. The
server round trip exists for exactly that.

Until `GET /api/application/:id` exists, the cache is the only thing restoring
answers, and only within the same tab. Close the tab and they are gone. That is
still the single biggest reason not to leave `DEMO = true` on a live site.

## Applicants who are not American or western European

A form like this quietly assumes things: that names are ASCII, that addresses have
a state, that a phone number has no country code, that everyone holds one
nationality. `tests/persona.js` walks an Algerian applicant with a complicated case
through the whole form to catch those. Five real problems came out of the first run
and are fixed:

- **Accented names.** Aïcha and Benoît were rejected with "Numbers are not accepted
  here", which is both wrong and useless. They are still rejected, because the
  DS-160 wants English characters, but the message now names accents as the cause
  and points at the machine-readable strip on the passport photo page, which holds
  the exact spelling to type. Arabic or other non-Latin script gets a third message
  pointing at the native-alphabet field. Names beginning with an apostrophe, like
  'Abd Allah, were rejected outright and now pass.
- **US territories.** Guam, the US Virgin Islands, American Samoa and the Northern
  Mariana Islands were missing from the state lists, so an applicant whose US
  contact lives in any of them could not complete the step.
- **Phone formats.** Only one of eight phone fields said to include the country
  dialling code. All of them do now, and the US contact field says to use a US
  number.
- **Dual nationality.** Someone holding Algerian and French nationality can usually
  travel on an ESTA with no interview, no MRV fee and no fee to us. The form now
  says so when a second passport is from a Visa Waiver country, and sends them to
  travel.state.gov to check. That list changes: re-check it yearly. The comment in
  the code says the same.
- **Email confirmation** was a text field, so phones offered the wrong keyboard.

## Applicants who are children

The DS-160 is explicit about this and we were not. Under 16, a parent or legal
guardian signs; at 16 or 17 the applicant signs but a parent may help. Our
certification said "I confirm that the answers above are true and correct", which a
six-year-old cannot agree to and which left the parent unsure whose name they had
just put to it.

The review step now works out the applicant's age from the date of birth and shows
the right guidance, and the certification wording changes to cover a parent or
guardian answering on the applicant's behalf. Consent text may now be a function of
the answers, which is how that switch is done.

## Date entry

Every date in the form is three controls, day and month as dropdowns and the year
as a typed four-digit box, matching what the DS-160 does. Native
`<input type="date">` is not used anywhere.

The reason is the date of birth. A browser date picker opens on the current month
and expects the applicant to scroll back forty years, and on several browsers the
year segment resists being typed into once a value is set. Applicants could not
reach their own birth year.

The composed value is still stored as a plain `yyyy-mm-dd` string under the same
key, so saving, validation, the review screen and the submit payload are unchanged.
Half-entered dates are held in the widget rather than the answer data, so a lone
month never reaches the server or counts as an answer.

Where the form asks for a year on its own, `type: "year"` gives the same typed
four-digit box rather than a number spinner whose arrows step one year at a time.
It strips non-digits as you type and rejects a partial year, a year before 1900 and
anything more than 25 years ahead. Use it for any year field added later.

## Photo handling

`/application` step 21 takes a passport-style photograph. It is read in the browser,
checked against the DS-160 rules (JPEG, square, 600 to 1200 pixels a side, under
240 KB) and held in state as a data URL.

That means it arrives in the `onSubmit` payload as `photo`, with `photoName`,
`photoBytes`, `photoWidth` and `photoHeight` beside it. Decode the base64 and write
it to file storage. Do not leave a data URL sitting in a database column.

Like every other answer, it is not written to localStorage, so closing the tab loses
it. That is deliberate.

## Two things not to undo

Both are marked with comments in the files. Both were bugs that got fixed, and both
look like tidy-up candidates to someone who was not here.

**In `site.css`:** the button rules carry a `.vj-site` prefix. Most buttons on this
site are anchors, and `.vj-site a` sets a link colour at a higher specificity than a
bare `.btn-primary`. Strip the prefix and the filled buttons go back to dark teal
text on a teal background.

**In `visa-application-form.js`:** free-text, date and number inputs write to
state through `setSmart`. It updates the value, clears any error on that field in
place, and repaints **only when the step's visible or required fields actually
change**, which it works out by comparing a fingerprint of the step before and
after. Selects, yes/no controls and checkboxes still repaint every time, because
they drive most of the branching.

That conditional repaint is the whole fix for three separate symptoms, all of
which came from destroying and rebuilding the DOM during a user gesture:

- typing lost focus after every character
- Tab did not move to the next field
- clicking from one field into another needed a second click, because the node
  being clicked into was rebuilt between mousedown and mouseup
- date fields could not be filled at all, since a date input fires `input` on
  every segment and the picker closed each time

`render()` also wraps `paint()` to restore focus and caret position for the
repaints that do still happen. Keep both.
Selects and yes/no controls must keep repainting immediately, because conditional
branches depend on them.

---

## Rebuilding

Only if you change the shared header or footer. They live in `src/build.py` rather
than being copy-pasted into eight files.

    cd src
    python3 build.py      # regenerates the eight pages
    python3 deploy.py     # rebuilds ../deploy with clean URLs and headers
    python3 bundle.py     # rebuilds the single-file preview

If you are moving this into a real templating system, `build.py` is the spec for
what the shared chrome contains.

---

## The admin screen

`/admin`, built in this version. It is not in the nav, not in the footer, not in
the sitemap, disallowed in `robots.txt` and `noindex,nofollow`. Nothing on the
public site links to it, and `deploy_checks.py` asserts that.

The detail view is drawn by walking `VJ_SCHEMA.STEPS`, the form's own schema,
rather than by listing the answer object. That matters more than it looks:

- The admin reads the exact wording the applicant answered, permanently. Change
  a question in the form and the admin screen follows with nothing to keep in sync.
- A question that was asked and left blank still shows, marked unanswered. Walking
  the answers instead would silently drop every unanswered question, which is the
  one thing a reviewer most needs to see.
- A question this applicant was never shown is left out, because `showIf` is
  evaluated against their data. An unasked question is not an unanswered one.

The DS-160 country and occupation codes are shown beside those answers, since the
admin is retyping all of this into the Department of State's own form.

It deliberately cannot edit an applicant's answers. They signed them
electronically, and an admin changing them afterwards would make that signature
meaningless. Corrections go back through the applicant, or become a note.

Everything behind it is still to build: the endpoints under `/api/admin/`,
documented at the top of `admin.js` with what each one owes back. Until then
`var DEMO = true` in `admin.html` serves four invented applications so the
screens can be reviewed. Their cards carry the card networks' published test
numbers, so the reveal can be clicked through. `preview/visa-journey-admin.html` is the same thing as
one file you can open without a server. Both only let the admin account in; see
the next section for how, and for what has to go before launch.

### The admin account

There is one admin login, and only one. There is no list of managers, no
invitations and no users table behind it. The account lives in two environment
variables on the server, and **neither value belongs in this repository**:

    ADMIN_EMAIL=<the one admin address>
    ADMIN_PASSWORD_HASH='<output of api/tools/make-admin-hash.php>'

Set them in the host's environment settings, or in `api/config.php`, which
`.gitignore` keeps out of version control. A hash committed to a repository
stays in its history after it is deleted, and history is what gets cloned.

The second is a bcrypt hash (cost 12) of the password. The password itself is in
no file in this package, and must not be: not in the code, not in a test, not in
a `.env` committed to the repository, not in a ticket. Single quotes matter
there, because the hash is full of `$` and a shell or a `.env` loader will
otherwise try to expand it. In Netlify's or any host's environment settings,
paste it as it is.

**How sign in works on the server.** `POST /api/admin/session` with
`{ email, password }`. The contract is at the top of `admin.js`, under
`onSignIn`. In short:

1. If this IP or the account is locked out (below), answer `429` with
   `{ code: "locked", message }` and a `Retry-After` header, and stop. No
   compare.
2. Trim the email and compare it with `ADMIN_EMAIL` case-insensitively.
3. Check the password with the bcrypt library's own compare against
   `ADMIN_PASSWORD_HASH`. Run it **even when the email was wrong**, so a wrong
   email takes as long as a wrong password. bcrypt's compare is constant time;
   a hand-written string comparison is not.
4. Wrong either way: one `401`, one message ("Those details were not
   recognised."), whichever half was wrong.
5. Right: start a new session and answer `{ email, name: "Admin" }`.

In Node that is a few lines with `bcrypt` or `bcryptjs`:

    const ok = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH);
    const emailOk = email.trim().toLowerCase() ===
                    process.env.ADMIN_EMAIL.trim().toLowerCase();
    if (!(ok && emailOk)) return fail(401);

Most bcrypt libraries in other languages read a `$2b$` hash as it is (Python's
`bcrypt.checkpw`, PHP's `password_verify`, Go's `bcrypt.CompareHashAndPassword`).

**Changing the password.** Generate a new hash and replace `ADMIN_PASSWORD_HASH`:

    python3 -c "import bcrypt, getpass; print(bcrypt.hashpw(getpass.getpass('New admin password: ').encode(), bcrypt.gensalt(12)).decode())"

(`pip install bcrypt` first if it is missing.) It asks for the password without
echoing it and without putting it in your shell history, which a password typed
on the command line would be. Paste the output into the environment setting,
redeploy, and every existing session should be ended so the old password stops
working everywhere at once. Change it whenever someone who knew it stops needing
it, and before launch if it has ever been sent by email or chat.

**Rate limiting and lockout.** One login guarding full card numbers is the most
attractive thing on this site to guess at. At minimum:

- Per IP: 5 failed attempts in 15 minutes, then `429` until the window passes.
- Per account: after 10 consecutive failures from anywhere, lock the account
  for 15 minutes and email the account holder. Keep the lockout temporary: a
  permanent one lets anyone lock the only admin out of the site by typing
  wrong passwords at it.
- A successful sign in resets the account counter. Log every attempt, failed or
  not, with time, IP and user agent, never the password typed.

**The session cookie.** A random session id, stored server side, in a cookie
set like this:

    Set-Cookie: __Host-vj_admin=<random id>; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=28800

- `Secure`: never sent over plain HTTP. `HttpOnly`: no script can read it, so a
  cross-site scripting bug cannot walk off with the session. `SameSite=Strict`:
  not sent on requests started by another site, which closes off cross-site
  request forgery on the admin routes. The `__Host-` prefix makes the browser
  insist on all of that, plus no `Domain`, so a subdomain cannot overwrite it.
- Issue a new id at sign in; never promote the one the browser arrived with.
- Expire it after 8 hours, and after 30 minutes idle. Sign out deletes it on the
  server (`DELETE /api/admin/session`), not just in the browser.
- Every `/api/admin/` route checks the session. A URL that is hard to guess is
  not access control.

The second factor is built on the front end now. Its server side has a section
of its own below, "The second factor".

### The second factor

Built on the front end, and the server side is the part below. The card-reveal
route must refuse any session that did not pass this, because PCI DSS requires a
second factor for every access to card data and this login can reveal card
numbers.

**Sign in is two requests, not one.**

    POST /api/admin/session          { email, password }
      -> 200 { mfaRequired: true }   and a HALF SESSION cookie, 5 minutes,
                                     marked as not yet MFA-passed
      -> 200 { email, name }         only while no second factor is enrolled
      -> 401 { message }             wrong email or wrong password, one message
      -> 429 { code: "locked" }      with Retry-After

    POST /api/admin/session/verify   { code }
      -> 200 { email, name }         a NEW session token, mfa_passed = true
      -> 401 { code, message }       wrong code
      -> 401 { code: "expired" }     the half session ran out
      -> 429 { code: "locked" }      with Retry-After

The password is not sent again on the second request, and the browser does not
keep it. The half session cookie is what says who is half way in. Issue a brand
new token on success rather than promoting the half one, so a token captured
during the first step is worth nothing after the second.

**Enrolling the secret.** One account, so this happens once, by hand, and there
is no enrolment screen to build.

    python3 -c "import secrets, base64; print(base64.b32encode(secrets.token_bytes(20)).decode().rstrip('='))"

That is the shared secret. Put it in an authenticator app by building an
`otpauth://` URI and turning it into a QR code, or by typing the secret in:

    otpauth://totp/Visa%20Journey%20USA:<the%20admin%20address>?secret=THESECRET&issuer=Visa%20Journey%20USA&algorithm=SHA1&digits=6&period=30

SHA1, six digits, thirty seconds. Those are not a recommendation, they are what
every authenticator app assumes; change them and most apps produce codes the
server will reject.

**Store the secret encrypted, in the KMS you already have for card numbers.**
Not in an environment variable, and not in plaintext in the database. Someone who
reads the secret can generate valid codes for ever, which makes it worth as much
as the password. Decrypt it only inside the verify route.

**Verifying a code.** Use a TOTP library rather than writing it: `otplib` in
Node, `pyotp` in Python, `pragmatigo/otp` or `pquerna/otp` in Go, `OTPHP` in PHP.

- Allow one step either side of now, so a 30-second code is accepted for about 90
  seconds. People's phones drift. Do not widen it further.
- **Refuse a code that has already been used,** even inside its window. Store the
  last accepted step number against the account and reject anything less than or
  equal to it. Without this, a code read over someone's shoulder or out of a
  phishing page works a second time for up to a minute and a half.
- Compare in constant time. The libraries above do.
- Count every wrong code against the same lockout as wrong passwords.

**Recovery codes.** The admin screen accepts a recovery code in the same field,
because losing the phone otherwise locks the only account out of the site with no
way back. Generate ten at enrolment, show them once, store only a hash of each
(bcrypt or argon2, the same as the password), and mark one used the moment it is
accepted. The verify route tries the TOTP code first, then the recovery codes.

**The session flag is what the reveal route checks.** Set `mfa_passed` on the
session row at the end of a successful verify, and have
`POST /api/admin/applications/:id/card/reveal` refuse any session without it.
Checking "is MFA enrolled for this account" instead would pass a session that
signed in before enrolment.

**Ordering, so this does not get built in the wrong order.** The password step
can ship on its own: answer `{ email, name }` while no secret is enrolled and the
admin screen signs straight in. Everything except the reveal route works at that
point. Enrol the secret, build the verify route, then switch the reveal route on.

**What to tell the person who holds the login.** The code is in their
authenticator app and changes every thirty seconds. The recovery codes go
somewhere that is not the same phone. If the phone is lost, a recovery code gets
them in, and the secret should then be regenerated and re-enrolled.


**One shared login means the logs cannot tell people apart.** The reveal log,
the notes, the Activity list and "charged by" all record "Admin", because that
is all the server knows. If two people share the password, nobody can later say
which of them viewed a card number. So only one person should hold this login.
If a second person ever needs access, that is the moment to give each person
their own account, not to share this one.

**The preview's sign in is not this.** A static file has no server to check a
bcrypt hash, so `admin.html` (while `DEMO` is true) and
`preview/visa-journey-admin.html` compare a SHA-256 of the typed password with a
hash written into the page, using the browser's WebCrypto. That keeps a casual
visitor out of a preview and nothing more: anyone with the file can read the
hash, and a plain SHA-256 is fast to guess against, which is why the server uses
bcrypt. **Delete `DEMO_ADMIN_EMAIL`, `DEMO_ADMIN_PASSWORD_SHA256` and
`demoSignIn` from `admin.html` together with the DEMO flag before go-live.**
To change the preview's password meanwhile, replace the hex with:

    python3 -c "import hashlib, getpass; print(hashlib.sha256(getpass.getpass('Preview password: ').encode()).hexdigest())"

WebCrypto only runs in a secure context, so the preview signs in when opened as
a file, over https or on localhost, and says so if opened over plain http.

---

## Taking the fee after the work is done

The card step does not charge. The applicant enters a card at the end of the form
and is told plainly that nothing is taken today. Once the application has been
prepared and reviewed, the admin opens it in `/admin`, presses **Show full
number**, charges the $185 on the other processor, and records it with **Mark as
charged** (amount, date, and the processor's reference). Recording it marks the
application paid and deletes the stored number.

The card is kept by this site, not by a payment provider, because the processor
that takes the fee is not connected to the site and cannot hold a token for it.
That was a deliberate choice, made knowing what it costs, and the cost is the
next section. When the fee moves to a processor that can hold a saved card,
switch back (see "Going back to a saved card" at the end) and delete every stored
number.

To charge at the card step instead, set `chargeLater: false` in `payment.html`.

### Storing full card numbers

Keeping full card numbers (PANs) puts the whole site in PCI DSS scope at the
heaviest level: **SAQ D**. That is not a form to fill in once. It is the full
PCI DSS requirement set, an annual assessment, quarterly scans, and evidence for
each of them. The application database already holds passport and national ID
numbers, which is one more reason to keep the card data in its own corner and
make that corner small. Everything below is required, not advice.

**Never store the CVV.** Not encrypted, not for an hour, not "until the charge".
PCI DSS forbids keeping it after authorisation with no exception, and nothing here
authorises anything, so there is no window in which holding it is allowed. The
card step does not ask for it. Do not add the field back for the other processor.
That processor will run the charge as a keyed card-not-present payment without
it, which can mean a slightly higher decline rate. That is the trade, and it is
the legal one.

**Encrypt the number at rest, in its own table.** Not in the applications table,
not in the answers JSON, not in a column next to the passport number.

    card_vault
      application_id    references the application, unique
      ciphertext        AES-256-GCM of the digits
      nonce             12 random bytes, new for every encryption
      wrapped_key       the data key, encrypted by the KMS
      kms_key_id        which master key wrapped it
      created_at
      purge_after       see "Purge" below

- Envelope encryption. For each card, ask the KMS (AWS KMS, Google Cloud KMS,
  Azure Key Vault) for a fresh data key, encrypt the number with it using
  AES-256-GCM, store the wrapped copy of the data key beside the ciphertext, and
  drop the plaintext key from memory. The master key never leaves the KMS.
- Pass the application reference as GCM's additional authenticated data. A
  ciphertext copied onto another application's row then fails to decrypt rather
  than revealing the wrong card.
- **The key is never in the codebase**, the repository, an environment file, a
  container image or a CI variable. The app gets permission to call the KMS, and
  only the reveal route's service role gets permission to call decrypt.
- Rotate the master key yearly. The KMS keeps old versions for decrypting.
- Brand, last four and expiry are stored in the clear on the application, so the
  admin can show "Visa •••• 4242, expires 09/28" without decrypting anything.
- Database backups hold the ciphertext too. Keep their retention no longer than
  the purge period, or a purged number lives on in last month's backup.

**Decrypt in exactly one place: the reveal endpoint.** Nothing else in the
codebase calls decrypt. Not a report, not an export, not a support script. The
route checks the admin session, and that the session was signed in with a
second factor (see "The second factor"). PCI requires multi-factor
authentication for access to card data, and a stolen admin password is the
likeliest way in. If accounts are ever added, seeing card numbers becomes a
permission of its own rather than something every account can do.

**Rate limit reveals.** Something like 20 an hour and 3 per application in ten
minutes, answered with a 429 (the admin says "Too many card views in a short
time"). Alert the account holder when the limit is hit. Nobody
charging fees by hand needs a hundred card numbers in an afternoon, and someone
copying them out does.

**Log every reveal, in an append-only log.** One row per call, allowed or not:

    card_reveal_log
      at                server time
      admin_email       always the one account today; see below
      ip, user_agent
      reference         the application
      outcome           allowed | no_permission | rate_limited | not_on_file

- Write the row **before** returning the number. If the write fails, refuse the
  reveal. A reveal with no record is the one thing this log exists to prevent.
- Append-only means the app's database role can insert and nothing else: no
  update, no delete. Ship the rows to a store the app cannot rewrite as well.
  PCI wants a year of logs kept, the last three months to hand.
- Never put the number in the log, not even the last four. The reference is
  enough to find the card.
- The admin's Activity list shows "Viewed full card number" when a reveal
  succeeds. That is for the benefit of whoever is signed in. This log is the
  record.
- With one shared login, the log records which account and which IP, not which
  person. That is why only one person should hold the login ("The admin
  account", above). The IP and user agent are the only way to tell sessions
  apart, so keep them.

**Never let a PAN reach application logs or error trackers.** This is how numbers
leak from sites that encrypted their database properly.

- Turn off request body logging for `POST /api/application/card` and response body
  logging for the reveal route. Check what your framework does on a 500 as well:
  many log the request body by default.
- Scrub card numbers in the error tracker before events leave the server
  (Sentry's `beforeSend`, or the equivalent). As a tripwire, scan logs for 13 to 19
  digit runs that pass the Luhn check and alert on any match.
- Card data goes in POST bodies only, never in a URL, which ends up in access logs,
  browser history and the Referer header. The code here already does this.
- Keep session replay, heatmaps and analytics scripts off `/payment` and `/admin`.
  Each of them records what is typed or shown.
- Send `Cache-Control: no-store` on the reveal response.

**TLS only.** TLS 1.2 or later, HSTS (already in `netlify.toml`), no plain HTTP
anywhere a card number travels. That includes between the load balancer and the
app server, which is the hop people forget.

**Purge the number** in the same transaction that marks the application charged.
Purge it as well when the application is withdrawn or deleted, and on a fixed
retention period whichever comes first. 90 days after the card was saved is a
reasonable default, set in `purge_after` and enforced by a daily job. Once purged,
send `numberOnFile: false` on the card in `onGet`, and the admin shows "The full
number has been deleted from our server" in place of the button. If a charge is
still owed after a purge, ask the applicant for the card again.

**Run quarterly ASV scans** (external vulnerability scans by a PCI-approved
scanning vendor) and keep the passing reports. SAQ D also means quarterly
internal scans, a yearly penetration test, and written policies for all of the
above. Get a QSA or the acquiring bank to confirm the scope before launch.

**The payment page itself is in scope.** Since the card fields are on the site's
own page, PCI DSS 4.0 requires an inventory of every script that page loads, a
reason for each, and a way to notice if one changes (6.4.3 and 11.6.1). Today
the page loads `site.js` and `payment-step.js` and nothing else. Keep it that way:
no tag manager, chat widget or third-party script on `/payment`.

**The Copy button** puts the number on the admin's clipboard, where it stays
until something else is copied. PCI allows this for people with a documented
business need to see the number, so write that need down for the person who
holds the admin login.

### The contracts

Each one in the same form `admin.js` uses for the others. All of them check a
session server side.

    onSaveCard    (payment-step.js, collectCard mode)
                  POST /api/application/card
      in:   { applicationId,
              card: { name, number, expMonth, expYear, postal, brand, last4 } }
      out:  204
      number is digits only and has already passed Luhn, length and brand checks
      in the browser. Repeat all three: anything a browser checks, a browser can
      skip. expMonth is 1-12, expYear four digits, postal may be empty (many
      applicants' countries have no postal codes). Authorise against the
      applicant's session, not the reference alone. Encrypt into card_vault,
      store brand, last4, expMonth and expYear on the application, and return.
      Saving a second card for the same application replaces the first.

    onRevealCard  (admin.js)
                  POST /api/admin/applications/:id/card/reveal
      in:   { reference }
      out:  { number, name, expMonth, expYear, postal }
      The only route that decrypts. Admin session, signed in with MFA, rate
      limit, log row first, Cache-Control: no-store. On failure a non-2xx with
      { code, message }: 429 or code "rate_limited" for the limit, "not_on_file"
      once purged. Any other code shows your message as written.

    onMarkCharged (admin.js)
                  POST /api/admin/applications/:id/mark-charged
      in:   { reference, amount, currency, chargedOn, processorReference }
      out:  { status: "paid", amount, chargedOn, processorReference }
      Records a charge made on the other processor. It does not take money.
      chargedOn is yyyy-mm-dd and not in the future. Store all of it with the
      time it was recorded, purge card_vault for the application in the same
      transaction, and refuse an application that is already paid, rather than
      relying on the admin hiding the button.

    onGet         (admin.js, existing, one addition)
      payment.card: { brand, last4, expMonth, expYear, numberOnFile }
      Never the full number. onGet runs on every page view, so a number in it
      would be seen without a reveal and without a log row.

    onCharge      (admin.js, unchanged, not wired today)
                  POST /api/admin/applications/:id/charge
      in:   { reference }
      out:  { status, chargedAt, amount, receiptUrl }
      For a card saved as a token with a processor this site can call. The admin
      draws a Charge button only when it is supplied. Three rules: the amount
      comes from your server, it is idempotent keyed on the application, and it
      refuses an application that is already paid.

### What else is stored, and what must never be

Stored against the application: brand, last four, expiry month and year, whether
a full number is on file, and once charged, the amount, date, processor
reference and when it was recorded. In `card_vault`, until purged: the
encrypted number, name on card and billing postal code.

Never stored anywhere: the CVV. Never stored in the browser: any of it. The card
step keeps the details in memory only, and the card field names are on the form's
`NEVER_CACHED` list in case anyone ever routes them through a form step.

### The two things that go wrong on this timeline

An application submitted in August with an interview in November leaves a card
sitting for months, so both of these are ordinary rather than edge cases.

**The card expires before anyone charges it.** The admin works this out from the
stored expiry and warns before anyone charges it, rather than letting the admin
find out through a decline. There is a demo application in this state.

**The bank declines a charge it cannot verify.** A keyed charge with no CVV and the
cardholder absent is the kind a bank outside the US is most likely to question,
and most of these applicants are outside the US. When it happens, ask the
applicant to pay through a payment link from the other processor, then record
that charge here. India is stricter still: RBI rules restrict what a merchant may
keep at all, so check that before launching there.

### Going back to a saved card

When the fee moves to a processor the site can call, return to the setup that
keeps card numbers off the site entirely and drops it back to the short
self-assessment (SAQ A):

1. In `payment.html`, remove `collectCard` and set `hostedRedirect: true`. Point
   `onSaveCard` at `POST /api/application/setup-intent`, which returns a Checkout
   Session URL in **setup** mode. On the webhook, store the customer id, the
   payment method id, brand, last4, expMonth and expYear.
2. In `admin.html`, pass `onCharge` and drop `onRevealCard`. The admin goes back to
   a Charge button and the "held by the payment provider" line by itself.
3. Purge `card_vault`, drop the table, and keep the reveal log for its retention
   period.
