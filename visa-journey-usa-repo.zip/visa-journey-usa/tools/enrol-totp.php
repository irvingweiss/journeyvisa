<?php
/* Enrol the second factor and print the recovery codes.
 *
 *   php tools/enrol-totp.php
 *
 * Run once. It prints a secret for the environment, a URI to scan, and ten
 * recovery codes, then writes the hashed recovery codes to the database.
 */
if (PHP_SAPI !== 'cli') { exit("Run this from the command line.\n"); }

require __DIR__ . '/../api/lib/Http.php';
require __DIR__ . '/../api/lib/Db.php';
require __DIR__ . '/../api/lib/Totp.php';

$cfg = require __DIR__ . '/../api/config.php';
$db = Db::pdo($cfg);

$secret = Totp::generateSecret();
$account = $cfg['admin_email'] ?: 'admin@visajourneyusa.com';
$uri = Totp::uri($secret, $account, 'Visa Journey USA');

echo "\n1. Put this in the server environment (never in the repository):\n\n";
echo "   TOTP_SECRET=$secret\n";
echo "\n2. Add it to your authenticator app. Either scan a QR code made from\n";
echo "   this URI, or type the secret in by hand:\n\n";
echo "   $uri\n";
echo "\n3. Check it works before you rely on it. The code right now is: "
   . Totp::at($secret, intdiv(time(), 30)) . "\n";

$codes = [];
$st = $db->prepare('INSERT INTO admin_recovery_codes (code_hash, used_at) VALUES (?, NULL)');
for ($i = 0; $i < 10; $i++) {
    $code = strtolower(bin2hex(random_bytes(5)));
    $codes[] = $code;
    $st->execute([password_hash($code, PASSWORD_BCRYPT)]);
}

echo "\n4. Recovery codes. Each works once, in the same box as the six digits.\n";
echo "   Shown now and never again; only their hashes are stored.\n";
echo "   Keep them somewhere that is NOT the phone with the authenticator app:\n";
echo "   there is one admin account, so losing the phone without these locks\n";
echo "   the only login out of the site.\n\n";
foreach ($codes as $c) { echo "   $c\n"; }
echo "\n";
