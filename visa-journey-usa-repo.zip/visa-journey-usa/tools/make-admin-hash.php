<?php
/* Generate the bcrypt hash for ADMIN_PASSWORD_HASH.
 *
 *   php tools/make-admin-hash.php
 *
 * It asks for the password without echoing it, so the password does not end up
 * in your shell history, which it would if it were an argument.
 */
if (PHP_SAPI !== 'cli') { exit("Run this from the command line.\n"); }

echo "New admin password: ";
system('stty -echo 2>/dev/null');
$pw = trim((string) fgets(STDIN));
system('stty echo 2>/dev/null');
echo "\n";

if (strlen($pw) < 12) {
    exit("Use at least 12 characters. This login can read every applicant's passport number.\n");
}
echo "\nADMIN_PASSWORD_HASH='" . password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]) . "'\n\n";
echo "Paste that into the environment or config.php, single quotes included:\n";
echo "the hash is full of \$ and a shell or .env loader will otherwise eat it.\n";
