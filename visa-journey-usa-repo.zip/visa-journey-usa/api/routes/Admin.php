<?php
/* The admin half of the API: sign in, the list, one application, status and
 * notes.
 *
 * Shapes are fixed by admin.js; the contract is at the top of that file. The
 * card routes are deliberately not here, and the end of this file says why.
 */

class Admin
{
    private PDO $db;
    private array $cfg;

    public function __construct(PDO $db, array $cfg)
    {
        $this->db = $db;
        $this->cfg = $cfg;
    }

    /* ------------------------------------------ POST /api/admin/session */

    public function signIn(): void
    {
        $ip = Http::ip();
        $limit  = (int) $this->cfg['admin_fail_limit'];
        $window = (int) $this->cfg['admin_fail_window'];
        $lock   = (int) $this->cfg['admin_lockout'];

        /* Locked out: answer before comparing anything. Running the compare
           anyway and then refusing tells an attacker whether the password was
           right, which is exactly what the lockout is for. */
        $left = Guard::lockedFor($this->db, 'admin-signin', $ip, $limit, $window, $lock);
        if ($left > 0) {
            header('Retry-After: ' . $left);
            Http::fail(429, 'locked',
                'Too many attempts. Try again in ' . ceil($left / 60) . ' minutes.');
        }

        $in = Http::body();
        $email = strtolower(trim((string) ($in['email'] ?? '')));
        $password = (string) ($in['password'] ?? '');

        $expectedEmail = strtolower(trim((string) $this->cfg['admin_email']));
        $hash = (string) $this->cfg['admin_password_hash'];

        if ($expectedEmail === '' || $hash === '') {
            Http::fail(500, 'not_configured',
                'The admin account is not set up on the server yet.');
        }

        /* The compare runs even when the email is wrong, so a wrong email
           takes as long as a wrong password. password_verify is constant
           time; == is not. */
        $passwordOk = password_verify($password, $hash);
        $emailOk = hash_equals($expectedEmail, $email);

        if (!$passwordOk || !$emailOk) {
            Guard::record($this->db, 'admin-signin', $ip, false);
            /* One status, one message, whichever half was wrong. */
            Http::fail(401, 'bad_credentials', 'Those details were not recognised.');
        }

        Guard::clear($this->db, 'admin-signin', $ip);

        /* No secret enrolled yet: sign straight in, so the password step can
           ship before the second factor is built. The card-reveal route
           refuses these sessions because it checks mfa_passed, not whether a
           secret happens to exist. */
        if (trim((string) $this->cfg['totp_secret']) === '') {
            Sessions::startAdminFull($this->db, $this->cfg, $expectedEmail);
            Http::json(['email' => $expectedEmail, 'name' => 'Admin']);
        }

        Sessions::startAdminHalf($this->db, $this->cfg, $expectedEmail);
        Http::json(['mfaRequired' => true]);
    }

    /* ----------------------------------- POST /api/admin/session/verify */

    public function verifyCode(): void
    {
        $ip = Http::ip();
        $limit  = (int) $this->cfg['admin_fail_limit'];
        $window = (int) $this->cfg['admin_fail_window'];
        $lock   = (int) $this->cfg['admin_lockout'];

        /* Wrong codes count against the same lockout as wrong passwords.
           Separate counters would let someone spend their password budget,
           then start again on six digits. */
        $left = Guard::lockedFor($this->db, 'admin-signin', $ip, $limit, $window, $lock);
        if ($left > 0) {
            header('Retry-After: ' . $left);
            Http::fail(429, 'locked',
                'Too many attempts. Try again in ' . ceil($left / 60) . ' minutes.');
        }

        $session = Sessions::admin($this->db);
        if (!$session) {
            Http::fail(401, 'expired', 'That took too long. Enter your password again.');
        }
        if ($session['mfa_passed']) {
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        $code = preg_replace('/\s+/', '', (string) (Http::body()['code'] ?? ''));
        $secret = trim((string) $this->cfg['totp_secret']);

        $step = Totp::verify($secret, $code);
        if ($step !== null) {
            /* Refuse a step already accepted. Without this a code watched
               over a shoulder works again until it expires, and the second
               factor stops being one. */
            $st = $this->db->prepare('SELECT last_totp_step FROM admin_state WHERE id = 1');
            $st->execute();
            $last = (int) ($st->fetchColumn() ?: 0);
            if ($step <= $last) {
                Guard::record($this->db, 'admin-signin', $ip, false);
                Http::fail(401, 'reused',
                    'That code has already been used. Wait for the next one.');
            }
            $this->db->prepare('UPDATE admin_state SET last_totp_step = ? WHERE id = 1')
                     ->execute([$step]);
            Guard::clear($this->db, 'admin-signin', $ip);
            Sessions::startAdminFull($this->db, $this->cfg, $session['email']);
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        /* A recovery code goes in the same box. Each is single use, and only
           its hash is stored. */
        if ($this->useRecoveryCode($code)) {
            Guard::clear($this->db, 'admin-signin', $ip);
            Sessions::startAdminFull($this->db, $this->cfg, $session['email']);
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        Guard::record($this->db, 'admin-signin', $ip, false);
        Http::fail(401, 'bad_code',
            'That code was not right. Check the app and try the current one.');
    }

    private function useRecoveryCode(string $code): bool
    {
        if (strlen($code) < 8) {
            return false;
        }
        $st = $this->db->prepare(
            'SELECT id, code_hash FROM admin_recovery_codes WHERE used_at IS NULL'
        );
        $st->execute();
        foreach ($st->fetchAll() as $row) {
            if (password_verify(strtolower($code), $row['code_hash'])) {
                $this->db->prepare('UPDATE admin_recovery_codes SET used_at = ? WHERE id = ?')
                         ->execute([Db::now(), $row['id']]);
                return true;
            }
        }
        return false;
    }

    /* ---------------------------------------- DELETE /api/admin/session */

    public function signOut(): void
    {
        Sessions::endAdmin($this->db, $this->cfg);
        Http::noContent();
    }

    /* ------------------------------------- GET /api/admin/applications */

    public function listApplications(): void
    {
        Sessions::requireAdmin($this->db);

        $query  = trim((string) ($_GET['query'] ?? ''));
        $status = trim((string) ($_GET['status'] ?? ''));

        $sql = 'SELECT reference, applicant_name, status, step_index, created_at, updated_at
                  FROM applications WHERE 1 = 1';
        $args = [];

        if ($query !== '') {
            /* Reference or surname. Managers look people up by name far more
               often than by reference. */
            $sql .= ' AND (UPPER(reference) LIKE ? OR UPPER(applicant_name) LIKE ?)';
            $like = '%' . strtoupper($query) . '%';
            $args[] = $like;
            $args[] = $like;
        }
        if ($status !== '') {
            $sql .= ' AND status = ?';
            $args[] = $status;
        }
        $sql .= ' ORDER BY updated_at DESC LIMIT 200';

        $st = $this->db->prepare($sql);
        $st->execute($args);

        $out = [];
        foreach ($st->fetchAll() as $row) {
            $out[] = [
                'reference'     => $row['reference'],
                'applicantName' => $row['applicant_name'],
                'status'        => $row['status'],
                'stepIndex'     => (int) $row['step_index'],
                'createdAt'     => Db::iso($row['created_at']),
                'updatedAt'     => Db::iso($row['updated_at']),
                'lastOpenedBy'  => $this->lastOpenedBy($row['reference']),
            ];
        }
        Http::json(['applications' => $out]);
    }

    /* --------------------------------- GET /api/admin/applications/:ref */

    public function getApplication(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        /* It is a hash on this side and has no business on this response. The
           admin screen drops it defensively too, but by then it has crossed
           the wire. */
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        $this->recordOpen((int) $row['id'], $session['email']);

        Http::json([
            'reference'     => $row['reference'],
            'applicantName' => $row['applicant_name'],
            'status'        => $row['status'],
            'stepIndex'     => (int) $row['step_index'],
            'createdAt'     => Db::iso($row['created_at']),
            'updatedAt'     => Db::iso($row['updated_at']),
            'submittedAt'   => Db::iso($row['submitted_at']),
            'data'          => $answers,
            'photoUrl'      => $this->photoUrl($row['reference']),
            'payment'       => $this->payment($row),
            'notes'         => $this->notes((int) $row['id']),
            'activity'      => $this->activityList((int) $row['id']),
        ]);
    }

    /* ------------------------- PATCH /api/admin/applications/:ref/status */

    public function setStatus(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        $status = trim((string) (Http::body()['status'] ?? ''));
        $allowed = ['New', 'In review', 'Waiting on client', 'Ready to file', 'Filed'];
        if (!in_array($status, $allowed, true)) {
            Http::fail(400, 'bad_status', 'That is not a status this system uses.');
        }

        $st = $this->db->prepare('UPDATE applications SET status = ?, updated_at = ? WHERE id = ?');
        $st->execute([$status, Db::now(), $row['id']]);
        $this->activity((int) $row['id'], $session['email'], 'Changed status to ' . $status);
        Http::noContent();
    }

    /* -------------------------- POST /api/admin/applications/:ref/notes */

    public function addNote(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        $body = trim((string) (Http::body()['body'] ?? ''));
        if ($body === '') {
            Http::fail(400, 'empty', 'Write something first.');
        }
        if (mb_strlen($body) > 5000) {
            $body = mb_substr($body, 0, 5000);
        }

        $at = Db::now();
        $st = $this->db->prepare(
            'INSERT INTO application_notes (application_id, author, body, at) VALUES (?, ?, ?, ?)'
        );
        $st->execute([$row['id'], 'Admin', $body, $at]);
        $this->db->prepare('UPDATE applications SET updated_at = ? WHERE id = ?')
                 ->execute([$at, $row['id']]);

        Http::json(['author' => 'Admin', 'at' => Db::iso($at), 'body' => $body]);
    }

    /* -------------------------- GET /api/admin/applications/:ref/photo */

    public function photo(string $reference): void
    {
        Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);
        foreach (['jpg', 'png'] as $ext) {
            $path = rtrim($this->cfg['photo_dir'], '/') . '/' . $row['reference'] . '.' . $ext;
            if (is_file($path)) {
                header('Content-Type: ' . ($ext === 'png' ? 'image/png' : 'image/jpeg'));
                header('Cache-Control: no-store, private');
                header('Content-Length: ' . filesize($path));
                readfile($path);
                exit;
            }
        }
        Http::fail(404, 'no_photo', 'No photograph on file.');
    }

    /* ----------------------------------------------------------- helpers */

    private function byReference(string $reference): array
    {
        $st = $this->db->prepare('SELECT * FROM applications WHERE reference = ?');
        $st->execute([strtoupper(trim($reference))]);
        $row = $st->fetch();
        if (!$row) {
            Http::fail(404, 'not_found', 'No application with that reference.');
        }
        return $row;
    }

    private function payment(array $row): array
    {
        $card = null;
        if ($row['card_last4']) {
            $card = [
                'brand'        => $row['card_brand'],
                'last4'        => $row['card_last4'],
                'expMonth'     => $row['card_exp_month'] !== null ? (int) $row['card_exp_month'] : null,
                'expYear'      => $row['card_exp_year'] !== null ? (int) $row['card_exp_year'] : null,
                'numberOnFile' => (bool) $row['number_on_file'],
            ];
        }
        $status = $row['charged_on'] ? 'paid' : ($card ? 'authorised' : 'none');
        return [
            'status'             => $status,
            /* The amount comes from the server. A price posted from a browser
               is a price the customer can edit. */
            'amount'             => $row['paid_amount'] !== null
                                      ? (float) $row['paid_amount']
                                      : (float) $this->cfg['service_fee'],
            'currency'           => $row['paid_currency'] ?: $this->cfg['currency'],
            'chargedOn'          => $row['charged_on'],
            'chargedAt'          => Db::iso($row['charge_recorded_at']),
            'chargedBy'          => $row['charged_by'],
            'processorReference' => $row['processor_ref'],
            'card'               => $card,
        ];
    }

    private function notes(int $id): array
    {
        $st = $this->db->prepare(
            'SELECT author, body, at FROM application_notes
              WHERE application_id = ? ORDER BY at ASC'
        );
        $st->execute([$id]);
        return array_map(static fn($r) => [
            'author' => $r['author'],
            'at'     => Db::iso($r['at']),
            'body'   => $r['body'],
        ], $st->fetchAll());
    }

    private function activityList(int $id): array
    {
        $st = $this->db->prepare(
            'SELECT author, action, at FROM application_activity
              WHERE application_id = ? ORDER BY at DESC LIMIT 50'
        );
        $st->execute([$id]);
        return array_map(static fn($r) => [
            'author' => $r['author'],
            'at'     => Db::iso($r['at']),
            'action' => $r['action'],
        ], $st->fetchAll());
    }

    private function activity(int $id, string $author, string $action): void
    {
        $st = $this->db->prepare(
            'INSERT INTO application_activity (application_id, author, action, at)
             VALUES (?, ?, ?, ?)'
        );
        $st->execute([$id, $author, $action, Db::now()]);
    }

    /**
     * Record that the application was opened.
     *
     * Deduplicated inside half an hour, because the detail view reloads every
     * time the status changes or a note is added, and an activity list that
     * is forty identical lines is one nobody reads.
     */
    private function recordOpen(int $id, string $who): void
    {
        $st = $this->db->prepare(
            'SELECT at FROM application_activity
              WHERE application_id = ? AND action = ? ORDER BY at DESC LIMIT 1'
        );
        $st->execute([$id, 'Opened the application']);
        $last = $st->fetchColumn();
        if ($last && (time() - strtotime($last . ' UTC')) < 1800) {
            return;
        }
        $this->activity($id, 'Admin', 'Opened the application');
    }

    private function lastOpenedBy(string $reference): ?string
    {
        $st = $this->db->prepare(
            'SELECT a.author FROM application_activity a
               JOIN applications p ON p.id = a.application_id
              WHERE p.reference = ? ORDER BY a.at DESC LIMIT 1'
        );
        $st->execute([$reference]);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    }

    private function photoUrl(string $reference): ?string
    {
        foreach (['jpg', 'png'] as $ext) {
            if (is_file(rtrim($this->cfg['photo_dir'], '/') . '/' . $reference . '.' . $ext)) {
                return '/api/admin/applications/' . rawurlencode($reference) . '/photo';
            }
        }
        return null;
    }
}

/* ---------------------------------------------------------------------------
 * The card routes are not in this file, and that is deliberate.
 *
 * /card/reveal and /mark-charged come after three things exist: the key
 * management for the stored number, the second factor actually enrolled, and
 * the append-only reveal log. README.md sets all three out under "Storing full
 * card numbers" and "The second factor". Until then the admin screen simply
 * does not draw the buttons, because it only draws what it has callbacks for,
 * so there is nothing half-built on screen.
 *
 * Sessions::requireAdmin($db, true) is the check those routes use when they
 * are written: it insists the session passed a second factor, rather than
 * asking whether a secret is enrolled, which a session created before
 * enrolment would pass.
 * ------------------------------------------------------------------------ */
