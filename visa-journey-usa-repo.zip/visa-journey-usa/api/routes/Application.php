<?php
/* The applicant's half of the API: create, save a step, submit, come back.
 *
 * These are what application.html and resume.html call once DEMO is false.
 * Shapes are fixed by the front end; README.md records them under "What you
 * need to build".
 */

class Application
{
    private PDO $db;
    private array $cfg;

    public function __construct(PDO $db, array $cfg)
    {
        $this->db = $db;
        $this->cfg = $cfg;
    }

    /* ---------------------------------------------- POST /api/application */

    public function create(): void
    {
        $in = Http::body();
        $prompt = trim((string) ($in['securityPrompt'] ?? ''));
        $answer = (string) ($in['securityAnswer'] ?? '');

        if ($prompt === '' || trim($answer) === '') {
            Http::fail(400, 'incomplete', 'Choose a question and give an answer.');
        }

        /* Normalised the same way the form normalises it before checking, so
           "Smith " and "smith" are the same answer months later. */
        $hash = password_hash(self::normalise($answer), PASSWORD_BCRYPT);

        /* A collision is vanishingly unlikely, but a duplicate key would
           otherwise surface to an applicant as a failure at step one. */
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $reference = Http::reference();
            try {
                $st = $this->db->prepare(
                    'INSERT INTO applications (reference, security_prompt, security_hash,
                                               answers, step_index, status, created_at, updated_at)
                     VALUES (?, ?, ?, ?, 0, ?, ?, ?)'
                );
                $st->execute([$reference, $prompt, $hash, '{}', 'New', Db::now(), Db::now()]);
                $id = (int) $this->db->lastInsertId();
                Sessions::startApplicant($this->db, $this->cfg, $id);
                Http::json(['applicationId' => $reference]);
            } catch (PDOException $e) {
                if ($attempt === 4) {
                    throw $e;
                }
            }
        }
    }

    /* ------------------------------------------ PATCH /api/application/:id */

    public function saveStep(string $reference): void
    {
        $row = $this->mine($reference);
        $in = Http::body();
        $data = $in['data'] ?? null;
        if (!is_array($data)) {
            Http::fail(400, 'no_data', 'Nothing to save.');
        }

        /* The step arrives as a patch of the whole answer set. Merge rather
           than replace: a later step must not wipe an earlier one if the
           front end ever sends a partial payload. */
        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        $answers = array_merge($answers, $data);

        /* Never store the security answer with the answers. It is a hash in
           its own column; a copy in here would be plaintext. */
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        $stepIndex = isset($in['stepIndex']) ? (int) $in['stepIndex'] : (int) $row['step_index'];

        $st = $this->db->prepare(
            'UPDATE applications
                SET answers = ?, step_index = ?, applicant_name = ?, email = ?, updated_at = ?
              WHERE id = ?'
        );
        $st->execute([
            json_encode($answers, JSON_UNESCAPED_UNICODE),
            max($stepIndex, (int) $row['step_index']),
            self::nameFrom($answers),
            self::emailFrom($answers),
            Db::now(),
            $row['id'],
        ]);

        /* 204 and nothing else. The form treats any non-2xx as "could not
           save" and keeps the answers on screen, which is the safety net. */
        Http::noContent();
    }

    /* -------------------------------------------- GET /api/application/:id */

    public function get(string $reference): void
    {
        $row = $this->mine($reference);
        $answers = json_decode($row['answers'] ?: '{}', true);
        Http::json([
            'applicationId' => $row['reference'],
            'data'          => is_array($answers) ? $answers : [],
            'stepIndex'     => (int) $row['step_index'],
        ]);
    }

    /* --------------------------------------- POST /api/application/submit */

    public function submit(): void
    {
        $in = Http::body();
        $reference = (string) ($in['applicationId'] ?? '');
        $row = $this->mine($reference);

        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        foreach ($in as $k => $v) {
            if ($k !== 'applicationId') {
                $answers[$k] = $v;
            }
        }
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        /* The photograph arrives as a data URL. Decode it to a file: base64 in
           a database column is three times the size and shows up in every
           dump, backup and query log that touches the row. */
        if (!empty($answers['photo']) && str_starts_with((string) $answers['photo'], 'data:')) {
            $saved = $this->savePhoto($row['reference'], (string) $answers['photo']);
            unset($answers['photo']);
            if ($saved) {
                $answers['photoStored'] = true;
            }
        }

        $st = $this->db->prepare(
            'UPDATE applications
                SET answers = ?, status = ?, applicant_name = ?, email = ?,
                    submitted_at = ?, updated_at = ?
              WHERE id = ?'
        );
        $st->execute([
            json_encode($answers, JSON_UNESCAPED_UNICODE),
            'New',
            self::nameFrom($answers),
            self::emailFrom($answers),
            Db::now(),
            Db::now(),
            $row['id'],
        ]);

        $this->activity((int) $row['id'], 'Applicant', 'Application submitted');
        Http::json(['applicationId' => $row['reference']]);
    }

    /* --------------------------------------- POST /api/application/lookup */

    public function lookup(): void
    {
        $ip = Http::ip();
        if (Guard::countRecent($this->db, 'lookup', $ip, (int) $this->cfg['lookup_rate_window'], false)
            >= (int) $this->cfg['lookup_rate_limit']) {
            Http::fail(429, 'rate_limited', 'Too many attempts. Try again later.');
        }
        Guard::record($this->db, 'lookup', $ip, true);

        $in = Http::body();
        $reference = strtoupper(trim((string) ($in['applicationId'] ?? '')));
        $row = $this->byReference($reference);

        /* A wrong reference and a locked application answer the same way, so
           this cannot be used to find out which references exist. */
        if (!$row || $row['locked_at'] !== null) {
            Http::fail(404, 'not_found', 'We could not find that reference number.');
        }
        Http::json(['securityPrompt' => $row['security_prompt']]);
    }

    /* --------------------------------------- POST /api/application/resume */

    public function resume(): void
    {
        $ip = Http::ip();
        $in = Http::body();
        $reference = strtoupper(trim((string) ($in['applicationId'] ?? '')));
        $answer = (string) ($in['answer'] ?? '');
        $row = $this->byReference($reference);

        if (!$row || $row['locked_at'] !== null) {
            Guard::record($this->db, 'resume', $ip, false);
            Http::fail(401, 'wrong', 'That answer did not match.');
        }

        $limit = (int) $this->cfg['resume_fail_limit'];
        $failures = (int) $row['failed_answers'];

        if (!password_verify(self::normalise($answer), $row['security_hash'])) {
            $failures++;
            $lock = $failures >= $limit ? Db::now() : null;
            $st = $this->db->prepare(
                'UPDATE applications SET failed_answers = ?, locked_at = ? WHERE id = ?'
            );
            $st->execute([$failures, $lock, $row['id']]);
            Guard::record($this->db, 'resume', $ip, false);

            if ($lock) {
                Http::fail(401, 'locked',
                    'For your security this application is locked. Email ' .
                    $this->cfg['support_email'] . ' and we will help you back in.',
                    ['attemptsRemaining' => 0]);
            }
            Http::fail(401, 'wrong', 'That answer did not match.',
                ['attemptsRemaining' => max(0, $limit - $failures)]);
        }

        /* Right answer: clear the count and hand the browser a session, which
           is what every later read is authorised by. */
        $this->db->prepare('UPDATE applications SET failed_answers = 0 WHERE id = ?')
                 ->execute([$row['id']]);
        Sessions::startApplicant($this->db, $this->cfg, (int) $row['id']);

        $answers = json_decode($row['answers'] ?: '{}', true);
        Http::json([
            'applicationId' => $row['reference'],
            'data'          => is_array($answers) ? $answers : [],
            'stepIndex'     => (int) $row['step_index'],
        ]);
    }

    /* ------------------------------- POST /api/application/email-reference */

    public function emailReference(): void
    {
        $ip = Http::ip();
        if (Guard::countRecent($this->db, 'email-ref', $ip, 3600, false) >= 5) {
            Http::fail(429, 'rate_limited', 'Too many emails requested. Try again later.');
        }
        Guard::record($this->db, 'email-ref', $ip, true);

        $in = Http::body();
        $row = $this->mine((string) ($in['applicationId'] ?? ''));
        $to = trim((string) ($in['email'] ?? ''));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            Http::fail(400, 'bad_email', 'That does not look like a complete email address.');
        }

        /* The reference and nothing else. Never the security question and
           never the answer: both in one mailbox is the whole credential. */
        $subject = 'Your Visa Journey USA reference number';
        $body = "Your reference number is {$row['reference']}.\r\n\r\n"
              . "Keep it somewhere safe. You will also be asked your security question "
              . "when you come back, and we will never ask you for that answer by email "
              . "or on the phone.\r\n\r\n"
              . "Come back to your application: https://www.visajourneyusa.com/resume\r\n";
        $headers = 'From: ' . $this->cfg['support_email'] . "\r\n"
                 . 'Reply-To: ' . $this->cfg['support_email'] . "\r\n"
                 . 'Content-Type: text/plain; charset=utf-8';

        if (!@mail($to, $subject, $body, $headers)) {
            Http::fail(502, 'send_failed', 'We could not send that email. Please write the number down.');
        }
        Http::json(['sent' => true]);
    }

    /* ----------------------------------------------------------- helpers */

    private function byReference(string $reference): ?array
    {
        $st = $this->db->prepare('SELECT * FROM applications WHERE reference = ?');
        $st->execute([$reference]);
        $row = $st->fetch();
        return $row ?: null;
    }

    /**
     * The application this browser is allowed to touch.
     *
     * Authorised by the session cookie set at create or resume, never by the
     * reference in the URL. Answering 401 rather than 403 is what makes
     * application.html send the person to /resume with the reference
     * prefilled, so a lost session is one question rather than a dead end.
     */
    private function mine(string $reference): array
    {
        $row = $this->byReference(strtoupper(trim($reference)));
        $sessionId = Sessions::applicantId($this->db);
        if (!$row || $sessionId === null || $sessionId !== (int) $row['id']) {
            Http::fail(401, 'no_session', 'Sign back in to your application.');
        }
        return $row;
    }

    private function savePhoto(string $reference, string $dataUrl): bool
    {
        if (!preg_match('#^data:image/(jpeg|jpg|png);base64,#i', $dataUrl, $m)) {
            return false;
        }
        $bytes = base64_decode(substr($dataUrl, strpos($dataUrl, ',') + 1), true);
        if ($bytes === false || strlen($bytes) > 2 * 1024 * 1024) {
            return false;
        }
        $dir = rtrim($this->cfg['photo_dir'], '/');
        if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
            return false;
        }
        $ext = strtolower($m[1]) === 'png' ? 'png' : 'jpg';
        return (bool) @file_put_contents($dir . '/' . $reference . '.' . $ext, $bytes);
    }

    private function activity(int $applicationId, string $author, string $action): void
    {
        $st = $this->db->prepare(
            'INSERT INTO application_activity (application_id, author, action, at)
             VALUES (?, ?, ?, ?)'
        );
        $st->execute([$applicationId, $author, $action, Db::now()]);
    }

    /** Same normalisation the form uses, so the answer matches months later. */
    public static function normalise(string $v): string
    {
        return preg_replace('/\s+/u', ' ', trim(mb_strtolower($v)));
    }

    private static function nameFrom(array $a): ?string
    {
        $given = trim((string) ($a['givenNames'] ?? ''));
        $sur = trim((string) ($a['surnames'] ?? ''));
        $name = trim($given . ' ' . $sur);
        return $name === '' ? null : mb_substr($name, 0, 120);
    }

    private static function emailFrom(array $a): ?string
    {
        $email = trim((string) ($a['email'] ?? ''));
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : null;
    }
}
