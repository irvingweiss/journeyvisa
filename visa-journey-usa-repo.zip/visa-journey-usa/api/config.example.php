<?php
/* Visa Journey USA — API configuration.
 *
 * Copy to config.php and fill in. config.php holds credentials, so it must not
 * be in version control and must not be reachable over the web. The .htaccess
 * shipped beside it blocks it, but the safer arrangement is to keep this whole
 * api/ folder outside the document root and point one rewrite at index.php.
 *
 * Anything that can come from the environment should. On a host with a secrets
 * manager, read these from it rather than from this file.
 */

return [

    /* ---------------------------------------------------------- database */

    /* MySQL 8. For Postgres change this one line to
       'pgsql:host=localhost;dbname=visajourney' and nothing else: every query
       in this API is portable. */
    'dsn'      => getenv('DB_DSN') ?: 'mysql:host=localhost;dbname=visajourney;charset=utf8mb4',
    'db_user'  => getenv('DB_USER') ?: 'visajourney',
    'db_pass'  => getenv('DB_PASS') ?: '',

    /* ------------------------------------------------------ admin account */

    /* One account. Not a row in a users table. Generate the hash with
       tools/make-admin-hash.php and paste the output, single quotes included:
       it is full of $ and a .env loader will otherwise expand it. */
    'admin_email'         => getenv('ADMIN_EMAIL') ?: '',
    'admin_password_hash' => getenv('ADMIN_PASSWORD_HASH') ?: '',

    /* Base32 TOTP secret from tools/enrol-totp.php. Leave empty and the
       password step signs straight in, which is fine while you are building,
       and is why the card-reveal route checks the session's mfa_passed flag
       rather than checking whether a secret exists. */
    'totp_secret' => getenv('TOTP_SECRET') ?: '',

    /* ------------------------------------------------------------ limits */

    'admin_fail_limit'   => 5,     // failed sign ins before lockout
    'admin_fail_window'  => 900,   // seconds the failures are counted over
    'admin_lockout'      => 900,   // seconds locked out for

    'resume_fail_limit'  => 5,     // wrong security answers before an application locks
    'lookup_rate_limit'  => 20,    // lookups per IP per window
    'lookup_rate_window' => 600,

    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,

    /* ------------------------------------------------------------- other */

    /* Where decoded photographs are written. Outside the document root, or
       they are downloadable by anyone who guesses the filename. */
    'photo_dir' => getenv('PHOTO_DIR') ?: __DIR__ . '/../../private/photos',

    /* Shown on the admin screen and used when recording a charge. The browser
       never sends an amount. */
    'service_fee' => 185,
    'currency'    => 'USD',

    'support_email' => 'support@visajourneyusa.com',

    /* Only requests from these origins may change anything. Add the bare
       domain too if the site answers on both. */
    'allowed_origins' => [
        'https://www.visajourneyusa.com',
        'https://visajourneyusa.com',
    ],

    /* false only while developing over plain http on localhost. Leaving it
       false in production sends session cookies over http. */
    'secure_cookies' => true,
];
