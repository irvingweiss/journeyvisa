<?php
/* Visa Journey USA — API front controller.
 *
 * Every /api/ request lands here. Plain PHP 8.1+, PDO, no framework and no
 * composer, so it drops onto an ordinary host with nothing to install.
 *
 * Routing: send /api/* here. The .htaccess beside this file does it on Apache;
 * INSTALL.md has the nginx and IIS equivalents.
 */

declare(strict_types=1);

/* Never print a stack trace to a caller: these requests carry applicants'
 * answers, and a trace can echo the parameters back. Log it, answer generically. */
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

require __DIR__ . '/lib/Http.php';
require __DIR__ . '/lib/Db.php';
require __DIR__ . '/lib/Guard.php';
require __DIR__ . '/lib/Totp.php';
require __DIR__ . '/lib/Sessions.php';
require __DIR__ . '/routes/Application.php';
require __DIR__ . '/routes/Admin.php';

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    Http::fail(500, 'no_config', 'The API is not configured yet.');
}
$cfg = require $configFile;

/* A request that changes something has to come from this site. See
 * Http::sameOrigin for why this plus SameSite cookies is enough. */
if (!Http::sameOrigin($cfg['allowed_origins'])) {
    Http::fail(403, 'bad_origin', 'Request refused.');
}

try {
    $db = Db::pdo($cfg);
} catch (Throwable $e) {
    error_log('[vj] database: ' . $e->getMessage());
    Http::fail(503, 'no_database', 'The service is temporarily unavailable.');
}

Guard::sweep($db);

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = '/' . trim($path, '/');

/* Tolerate the API being mounted at /api or at the document root. */
if (str_starts_with($path, '/api/')) {
    $path = substr($path, 4);
} elseif ($path === '/api') {
    $path = '/';
}

$applications = new Application($db, $cfg);
$admin = new Admin($db, $cfg);

/* A tiny router. $m[1] is the reference where one appears in the path. */
$routes = [
    ['POST',   '#^/application$#',                              fn($m) => $applications->create()],
    ['POST',   '#^/application/submit$#',                       fn($m) => $applications->submit()],
    ['POST',   '#^/application/lookup$#',                       fn($m) => $applications->lookup()],
    ['POST',   '#^/application/resume$#',                       fn($m) => $applications->resume()],
    ['POST',   '#^/application/email-reference$#',              fn($m) => $applications->emailReference()],
    ['PATCH',  '#^/application/([A-Za-z0-9]+)$#',               fn($m) => $applications->saveStep($m[1])],
    ['GET',    '#^/application/([A-Za-z0-9]+)$#',               fn($m) => $applications->get($m[1])],

    ['POST',   '#^/admin/session$#',                            fn($m) => $admin->signIn()],
    ['POST',   '#^/admin/session/verify$#',                     fn($m) => $admin->verifyCode()],
    ['DELETE', '#^/admin/session$#',                            fn($m) => $admin->signOut()],
    ['GET',    '#^/admin/applications$#',                       fn($m) => $admin->listApplications()],
    ['GET',    '#^/admin/applications/([A-Za-z0-9]+)$#',        fn($m) => $admin->getApplication($m[1])],
    ['PATCH',  '#^/admin/applications/([A-Za-z0-9]+)/status$#', fn($m) => $admin->setStatus($m[1])],
    ['POST',   '#^/admin/applications/([A-Za-z0-9]+)/notes$#',  fn($m) => $admin->addNote($m[1])],
    ['GET',    '#^/admin/applications/([A-Za-z0-9]+)/photo$#',  fn($m) => $admin->photo($m[1])],
];

try {
    $pathMatched = false;
    foreach ($routes as [$verb, $pattern, $handler]) {
        if (preg_match($pattern, $path, $m)) {
            $pathMatched = true;
            if ($verb === $method) {
                $handler($m);
                exit;
            }
        }
    }
    /* A path that exists under another verb is a 405, not a 404: it is a
       different mistake and says so. */
    if ($pathMatched) {
        Http::fail(405, 'bad_method', 'That is not how this endpoint is called.');
    }
    Http::fail(404, 'no_route', 'No such endpoint.');
} catch (Throwable $e) {
    /* The message goes to the server log, never to the caller. */
    error_log('[vj] ' . $method . ' ' . $path . ': ' . $e->getMessage());
    Http::fail(500, 'server_error', 'Something went wrong at our end.');
}
