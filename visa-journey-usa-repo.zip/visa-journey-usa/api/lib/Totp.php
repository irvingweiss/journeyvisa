<?php
/* TOTP, RFC 6238, in about sixty lines and with no dependency.
 *
 * SHA1, six digits, thirty seconds. Those are not preferences: they are what
 * every authenticator app assumes when it scans a QR code, and changing them
 * produces codes this will reject.
 */

class Totp
{
    public const PERIOD = 30;
    public const DIGITS = 6;

    /** RFC 4648 base32, which is how authenticator apps take a secret. */
    public static function base32Decode(string $secret): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $secret));
        $bits = '';
        for ($i = 0, $n = strlen($secret); $i < $n; $i++) {
            $pos = strpos($alphabet, $secret[$i]);
            if ($pos === false) {
                continue;
            }
            $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 8) as $byte) {
            if (strlen($byte) === 8) {
                $out .= chr(bindec($byte));
            }
        }
        return $out;
    }

    /** The code for one 30-second step. */
    public static function at(string $secret, int $step): string
    {
        $key = self::base32Decode($secret);
        /* The counter is a 64-bit big-endian integer. */
        $counter = pack('J', $step);
        $hash = hash_hmac('sha1', $counter, $key, true);
        $offset = ord($hash[19]) & 0x0f;
        $value = ((ord($hash[$offset]) & 0x7f) << 24)
               | ((ord($hash[$offset + 1]) & 0xff) << 16)
               | ((ord($hash[$offset + 2]) & 0xff) << 8)
               | (ord($hash[$offset + 3]) & 0xff);
        $code = $value % (10 ** self::DIGITS);
        return str_pad((string) $code, self::DIGITS, '0', STR_PAD_LEFT);
    }

    /**
     * Check a code and return the step it matched, or null.
     *
     * One step either side of now, so a code is good for about ninety seconds.
     * People's phones drift. Widening it further widens the window an attacker
     * has with a code they watched being typed.
     *
     * The caller must refuse a step it has already accepted. Without that, a
     * code read over a shoulder or captured on a phishing page works a second
     * time until it expires, and the second factor stops being one.
     */
    public static function verify(string $secret, string $code, int $drift = 1, ?int $now = null): ?int
    {
        $code = preg_replace('/\D/', '', $code);
        if (strlen($code) !== self::DIGITS) {
            return null;
        }
        $current = intdiv($now ?? time(), self::PERIOD);
        for ($i = -$drift; $i <= $drift; $i++) {
            /* hash_equals, not ==. A length-safe constant-time compare keeps
               the answer from leaking how much of the code was right. */
            if (hash_equals(self::at($secret, $current + $i), $code)) {
                return $current + $i;
            }
        }
        return null;
    }

    /** A new secret, for tools/enrol-totp.php. */
    public static function generateSecret(int $bytes = 20): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $raw = random_bytes($bytes);
        $bits = '';
        for ($i = 0; $i < strlen($raw); $i++) {
            $bits .= str_pad(decbin(ord($raw[$i])), 8, '0', STR_PAD_LEFT);
        }
        $out = '';
        foreach (str_split($bits, 5) as $chunk) {
            if (strlen($chunk) === 5) {
                $out .= $alphabet[bindec($chunk)];
            }
        }
        return $out;
    }

    /** The URI an authenticator app scans. */
    public static function uri(string $secret, string $account, string $issuer): string
    {
        return 'otpauth://totp/' . rawurlencode($issuer) . ':' . rawurlencode($account)
             . '?secret=' . $secret
             . '&issuer=' . rawurlencode($issuer)
             . '&algorithm=SHA1&digits=' . self::DIGITS . '&period=' . self::PERIOD;
    }
}
