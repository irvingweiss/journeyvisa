<?php
/* Request and response plumbing. Everything this API answers is JSON, and
 * everything it answers is no-store: these responses carry applicants' answers
 * and must not sit in a proxy or a browser cache. */

class Http
{
    /** The decoded JSON body, or [] when there is none. */
    public static function body(): array
    {
        $raw = file_get_contents('php://input');
        if ($raw === '' || $raw === false) {
            return [];
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : [];
    }

    public static function json($payload, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        /* Applicant answers and card summaries travel on these responses. A
           cached copy on a shared machine or in a proxy is the same leak as a
           cached copy anywhere else. */
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        header('X-Content-Type-Options: nosniff');
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    public static function noContent(): void
    {
        http_response_code(204);
        header('Cache-Control: no-store');
        exit;
    }

    /** The shape the front end reads: err.code and err.userMessage. */
    public static function fail(int $status, string $code, string $message, array $extra = []): void
    {
        self::json(array_merge(['code' => $code, 'message' => $message], $extra), $status);
    }

    public static function ip(): string
    {
        /* Behind a load balancer or Cloudflare the real address is in a
           header. Trust it ONLY if your edge sets it and strips any copy the
           client sent; otherwise an attacker picks their own rate-limit
           bucket. If you are not behind one, delete this block. */
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR'] as $h) {
            if (!empty($_SERVER[$h])) {
                $first = trim(explode(',', $_SERVER[$h])[0]);
                if (filter_var($first, FILTER_VALIDATE_IP)) {
                    return $first;
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }

    /**
     * Cross-site request forgery, cheaply.
     *
     * The session cookies are SameSite, which already stops a form on another
     * site posting as the signed-in person. This is the second lock: a request
     * that changes something must come from an origin we know. A browser will
     * not let another site send Content-Type: application/json cross-origin
     * without a preflight, and the preflight is not answered here, so between
     * the two there is no path in.
     */
    public static function sameOrigin(array $allowed): bool
    {
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        if ($method === 'GET' || $method === 'HEAD') {
            return true;
        }
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === '') {
            /* Same-origin requests from older browsers may omit Origin. Fall
               back to Referer, and if neither is there, refuse: every caller
               of this API is a page on the site. */
            $referer = $_SERVER['HTTP_REFERER'] ?? '';
            if ($referer === '') {
                return false;
            }
            $parts = parse_url($referer);
            if (!$parts || empty($parts['scheme']) || empty($parts['host'])) {
                return false;
            }
            $origin = $parts['scheme'] . '://' . $parts['host'] .
                      (isset($parts['port']) ? ':' . $parts['port'] : '');
        }
        return in_array($origin, $allowed, true);
    }

    public static function cookie(string $name, string $value, int $maxAge, array $cfg, string $sameSite = 'Strict'): void
    {
        setcookie($name, $value, [
            'expires'  => $maxAge > 0 ? time() + $maxAge : 1,
            'path'     => '/',
            'secure'   => (bool) ($cfg['secure_cookies'] ?? true),
            'httponly' => true,
            'samesite' => $sameSite,
        ]);
    }

    /** A URL-safe random token. 32 bytes, so guessing is not a strategy. */
    public static function token(): string
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    /**
     * A reference number.
     *
     * Same alphabet the form uses: no O/0 and no I/1, because applicants read
     * these over the phone and write them down. Ten characters of it is about
     * 50 bits, which is not guessable, but the reference is still not treated
     * as a secret anywhere in this API: it is printed on screen and emailed.
     */
    public static function reference(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $out = '';
        for ($i = 0; $i < 10; $i++) {
            $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }
        return $out;
    }
}
