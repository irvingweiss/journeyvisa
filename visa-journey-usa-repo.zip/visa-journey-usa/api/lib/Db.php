<?php
/* One PDO connection, in exceptions mode, with emulated prepares off so the
 * driver sends real parameters and an injected string can never become SQL.
 * Every query in this file set is parameterised; none builds SQL by
 * concatenation. */

class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(array $cfg): PDO
    {
        if (self::$pdo === null) {
            self::$pdo = new PDO($cfg['dsn'], $cfg['db_user'], $cfg['db_pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
            if (str_starts_with($cfg['dsn'], 'sqlite:')) {
                self::$pdo->exec('PRAGMA foreign_keys = ON');
            }
        }
        return self::$pdo;
    }

    /** UTC everywhere. Applicants and staff are in different time zones and
     *  the front end formats for display. */
    public static function now(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    public static function inFuture(int $seconds): string
    {
        return gmdate('Y-m-d H:i:s', time() + $seconds);
    }

    /** ISO 8601 for the browser, which is what the admin screen formats. */
    public static function iso(?string $sqlTime): ?string
    {
        if (!$sqlTime) {
            return null;
        }
        $ts = strtotime($sqlTime . ' UTC');
        return $ts ? gmdate('Y-m-d\TH:i:s\Z', $ts) : null;
    }
}
