# Visa Journey USA — the API

Plain PHP 8.1 or later and PDO. No framework, no composer, nothing to install.
It drops onto an ordinary host beside the static site.

Written against MySQL 8. For Postgres change one line in `config.php` (the DSN)
and use the Postgres notes at the top of `schema.mysql.sql`: every query here is
portable, so nothing else moves.

**This was tested end to end before it was sent.** The real admin screen, with
`DEMO` off, signed in through both steps, listed applications out of the
database, opened one, and saved a status change back. If something does not work
after you install it, the install is the place to look first.

---

## What is here

    api/
      index.php            every /api/ request lands here
      config.example.php   copy to config.php and fill in
      .htaccess            Apache rewrite plus a block on config.php
      lib/Http.php         JSON in and out, no-store, origin check, tokens
      lib/Db.php           the PDO connection, UTC helpers
      lib/Guard.php        rate limiting and lockout
      lib/Totp.php         TOTP, RFC 6238, no dependency
      lib/Sessions.php     applicant and admin sessions
      routes/Application.php   the applicant endpoints
      routes/Admin.php         the admin endpoints
    tools/
      make-admin-hash.php  generates ADMIN_PASSWORD_HASH
      enrol-totp.php       generates the TOTP secret and recovery codes
    schema.mysql.sql       the database

---

## Install

**1. Create the database** and load `schema.mysql.sql`.

    mysql -u root -p -e "CREATE DATABASE visajourney CHARACTER SET utf8mb4"
    mysql -u root -p visajourney < schema.mysql.sql

**2. Put `api/` where PHP can reach it.** Either inside the document root, or
better outside it with one rewrite pointing at `index.php`. Credentials live in
`config.php`, and a folder outside the web root cannot be served by accident.

**3. Copy `config.example.php` to `config.php`** and fill in the database
details. Every setting can come from the environment instead, which is the
better place for the credentials.

**4. Generate the admin password hash:**

    php tools/make-admin-hash.php

It asks for the password without echoing it, so it does not land in your shell
history. Paste the output into the environment or `config.php`, keeping the
single quotes: the hash is full of `$` and a shell or `.env` loader will eat it
otherwise.

**5. Route `/api/` to `index.php`.**

Apache: the `.htaccess` in `api/` already does it. Confirm `AllowOverride` is on,
or move those directives into the vhost.

nginx:

    location /api/ {
        try_files $uri /api/index.php$is_args$args;
    }
    location = /api/index.php {
        include fastcgi_params;
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root/api/index.php;
    }

IIS, in `web.config` inside `api\`:

    <rule name="API" stopProcessing="true">
      <match url=".*" />
      <conditions><add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" /></conditions>
      <action type="Rewrite" url="index.php" />
    </rule>

**6. Set `allowed_origins`** in `config.php` to the real domain. Requests that
change something are refused from anywhere else.

**7. Create the photo folder** outside the document root and point `photo_dir`
at it. A photograph under the web root is downloadable by anyone who guesses the
filename.

**8. Turn off the DEMO flags** in `application.html`, `payment.html` and
`admin.html`. They are independent, so the form can go live while the admin
screen stays in demo, or the other way round.

---

## Check it works

With the site and the API on the same host:

    # create an application
    curl -s -c /tmp/c -H 'Content-Type: application/json' \
         -H 'Origin: https://www.visajourneyusa.com' \
         -d '{"securityPrompt":"What was the name of your first pet?","securityAnswer":"Rex"}' \
         https://www.visajourneyusa.com/api/application

    # the admin sign in
    curl -s -c /tmp/a -H 'Content-Type: application/json' \
         -H 'Origin: https://www.visajourneyusa.com' \
         -d '{"email":"YOUR_ADMIN_EMAIL","password":"YOUR_PASSWORD"}' \
         https://www.visajourneyusa.com/api/admin/session

The first answers `{"applicationId":"..."}`. The second answers
`{"email":...,"name":"Admin"}` before the second factor is enrolled, and
`{"mfaRequired":true}` after. Then open `/admin` in a browser and sign in.

---

## The second factor

Build the password step first and this second. A server with no secret enrolled
answers the password step with `{ email, name }` and the admin screen signs
straight in, so everything except the card-reveal route works while this is
still being set up.

    php tools/enrol-totp.php

It prints the secret for `TOTP_SECRET`, an `otpauth://` URI to scan, the code
that is valid right now so you can check the clock, and ten recovery codes. The
recovery codes are shown once and only their hashes are stored.

Three things in `Totp.php` and `Admin::verifyCode()` are there for a reason and
should survive any tidying:

- **One step either side of now**, so a code works for about ninety seconds.
  Phones drift. Wider than that is a longer window for a code someone watched
  being typed.
- **A step is refused once used.** `admin_state.last_totp_step` is what does it.
  Without it a code read over a shoulder works again until it expires, and the
  second factor stops being one.
- **Wrong codes count against the same lockout as wrong passwords.** Separate
  counters would let someone spend the password budget and start again on six
  digits.

Keep the recovery codes somewhere that is **not** the phone with the
authenticator app. There is one admin account, so losing that phone without them
locks the only login out of the site with no way back.

---

## What is deliberately not here

**The card routes.** `/card/reveal` and `/mark-charged` are not in
`routes/Admin.php`. They need three things first: key management for the stored
number, the second factor actually enrolled, and the append-only reveal log.
site/README.md sets all three out under "Storing full card
numbers". Until they exist the admin screen simply does not draw those buttons,
because it only draws what it has callbacks for, so there is nothing half-built
on screen.

When you write them, use `Sessions::requireAdmin($db, true)`. It insists the
session passed a second factor, rather than asking whether a secret is enrolled,
which a session created before enrolment would pass.

**The contact form endpoint.** Still a `preventDefault` in `site.js`.

---

## Decisions worth keeping

**Nothing is authorised by the reference number.** It is printed on the
applicant's screen and emailed to them, so it identifies an application and does
not protect one. `GET /api/application/:id` checks the `vj_app` session cookie
set at create or resume. Dropping that check would make every application
readable by anyone who guessed ten characters.

**The applicant cookie is SameSite=Lax, the admin cookie is Strict.** The
applicant comes back from the payment provider, which is a cross-site
navigation, and a Strict cookie is not sent on it: they would arrive at the
resume screen holding a valid reference and wondering why. Nobody navigates into
`/admin` from another site, so it takes the stricter setting.

**A wrong email and a wrong password give the same 401 and the same message,**
and the bcrypt compare runs either way, so a wrong email does not come back
faster. Saying which half was wrong tells an attacker they have the email right.

**A locked-out request is refused before any comparison.** Checking the password
anyway and then refusing leaks whether it was right, which is the thing the
lockout exists to hide.

**Every response is `no-store`.** These carry applicants' answers. A cached copy
in a proxy or on a shared machine is the same leak as any other.

**The amount always comes from the server.** `config.php` holds the fee. A price
posted from a browser is a price the customer can edit.

**Errors are logged, never returned.** A stack trace can echo the request body,
and the request body here is somebody's passport number.
