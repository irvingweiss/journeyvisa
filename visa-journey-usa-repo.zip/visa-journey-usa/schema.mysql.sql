-- Visa Journey USA — schema (MySQL 8).
--
-- For Postgres: swap BIGINT AUTO_INCREMENT for BIGSERIAL, DATETIME for
-- TIMESTAMPTZ, and drop the ENGINE/CHARSET clauses. Every query in the API is
-- portable, so nothing else changes.

CREATE TABLE applications (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  reference       VARCHAR(16)  NOT NULL UNIQUE,
  security_prompt VARCHAR(255) NOT NULL,
  -- bcrypt of the normalised answer. Never the answer itself.
  security_hash   VARCHAR(255) NOT NULL,
  failed_answers  INT          NOT NULL DEFAULT 0,
  locked_at       DATETIME     NULL,
  answers         LONGTEXT     NOT NULL,          -- JSON, as onSaveStep sends it
  step_index      INT          NOT NULL DEFAULT 0,
  status          VARCHAR(32)  NOT NULL DEFAULT 'New',
  applicant_name  VARCHAR(120) NULL,
  email           VARCHAR(255) NULL,
  created_at      DATETIME     NOT NULL,
  updated_at      DATETIME     NOT NULL,
  submitted_at    DATETIME     NULL,
  -- payment, all non-sensitive. The number itself never lives here.
  card_brand      VARCHAR(32)  NULL,
  card_last4      VARCHAR(4)   NULL,
  card_exp_month  INT          NULL,
  card_exp_year   INT          NULL,
  number_on_file  TINYINT(1)   NOT NULL DEFAULT 0,
  paid_amount     DECIMAL(10,2) NULL,
  paid_currency   VARCHAR(8)   NULL,
  charged_on      DATE         NULL,
  charged_by      VARCHAR(255) NULL,
  processor_ref   VARCHAR(128) NULL,
  charge_recorded_at DATETIME  NULL,
  INDEX idx_updated (updated_at),
  INDEX idx_status (status),
  INDEX idx_name (applicant_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE application_notes (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT NOT NULL,
  author         VARCHAR(255) NOT NULL,
  body           TEXT NOT NULL,
  at             DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX idx_app (application_id, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE application_activity (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT NOT NULL,
  author         VARCHAR(255) NOT NULL,
  action         VARCHAR(255) NOT NULL,
  at             DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX idx_app (application_id, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- An applicant may read one application. Set at create and at resume, never
-- derived from the reference number, which is printed and emailed.
CREATE TABLE applicant_sessions (
  token          VARCHAR(64) PRIMARY KEY,
  application_id BIGINT NOT NULL,
  created_at     DATETIME NOT NULL,
  expires_at     DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX idx_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- mfa_passed is the flag the card-reveal route checks. A half session (the
-- password accepted, the code not yet) has it at 0 and can do nothing else.
CREATE TABLE admin_sessions (
  token      VARCHAR(64) PRIMARY KEY,
  email      VARCHAR(255) NOT NULL,
  mfa_passed TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL,
  INDEX idx_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row, id 1. last_totp_step stops a code being used twice inside its
-- window, which is what keeps a watched code from working a second time.
CREATE TABLE admin_state (
  id             INT PRIMARY KEY,
  last_totp_step BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO admin_state (id, last_totp_step) VALUES (1, 0);

-- Ten at enrolment, hashed, single use. There is one account, so without
-- these a lost phone locks the only login out of the site.
CREATE TABLE admin_recovery_codes (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  code_hash VARCHAR(255) NOT NULL,
  used_at   DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Rate limiting and lockout.
CREATE TABLE rate_events (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  bucket    VARCHAR(32) NOT NULL,
  ip        VARCHAR(45) NOT NULL,
  succeeded TINYINT(1) NOT NULL DEFAULT 0,
  at        DATETIME NOT NULL,
  INDEX idx_bucket (bucket, ip, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
