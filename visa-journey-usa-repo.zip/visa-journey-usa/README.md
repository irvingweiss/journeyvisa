# Visa Journey USA

The website, the B1/B2 application form, the manager admin screen and the API
behind them.

No framework and no build step on the front end: the site is plain HTML, CSS and
vanilla JavaScript. The API is plain PHP 8.1 and PDO with no composer. Nothing
here needs installing to run.

## Where things are

    site/            the website
      deploy/        what goes on the server. Upload this folder, nothing else
      src/           the sources and the three build scripts
      preview/       single-file versions for showing people, not for hosting
      tests/         the automated checks
      README.md      the full handover: how everything works and why
      CHANGELOG.md   what changed, newest first

    api/             the PHP API. Plain PHP 8.1 and PDO
    tools/           generate the admin password hash and enrol the second factor
    schema.mysql.sql the database
    INSTALL.md       installing the API, step by step

Start with `INSTALL.md` to get it running, and `site/README.md` for how the
pieces fit together.

## Running it

Nothing to build. To work on the site:

    cd site/src
    python3 build.py && python3 deploy.py && python3 bundle.py

`build.py` generates the pages from shared chrome, `deploy.py` produces
`site/deploy/` with clean URLs and cache-busting, and `bundle.py` folds
everything into the single-file previews. Edit the sources in `site/src/`, never
the generated output in `site/deploy/`: the next build overwrites it.

To run the checks:

    cd site/tests
    npm install          # jsdom, pinned to 26.x on purpose
    python3 rebuild_check.py
    python3 link_check.py deploy
    node admin.js ../src/

`site/tests/README.md` lists the rest and says what each one covers. They all
pass as committed.

## Secrets

**Nothing in this repository is a credential, and it should stay that way.**

The admin email, the admin password hash and the TOTP secret live in the
server's environment or in `api/config.php`, which `.gitignore` keeps out of
version control. `api/config.example.php` shows the shape with no values in it.
Generate the password hash with `tools/make-admin-hash.php` and the second
factor with `tools/enrol-totp.php`.

A secret committed by accident is not fixed by deleting it in a later commit. It
stays in the history, and the history is what gets cloned. If one does get in,
rotate the value rather than only removing the line.

Two things that look like secrets and are not:

- `DEMO_ADMIN_PASSWORD_SHA256` in `admin.html` is the password for the **offline
  preview**, published deliberately: it is `visa-preview-2026`. It keeps a
  casual visitor out of a preview file and nothing more. It is a plain SHA-256,
  which is fast to attack, which is exactly why the server uses bcrypt instead.
  **Never make it the same as the real admin password.** It is deleted before
  go-live along with the rest of the preview sign in.
- The applications in the preview and in `admin.html`'s demo data are invented.
  The names, reference numbers and passport numbers are made up.

## State of play

Working and tested: the site, the 22-step application form, the resume flow, the
admin screen, and the API behind all of them. The applicant and admin halves
were driven end to end against a real database before this was committed.

Still to build, in this order:

1. Key management for a stored card number, then `POST /api/application/card`,
   then `payment.html` can come off its DEMO flag.
2. The append-only reveal log, then the card-reveal route.
3. Recording a charge, purging the stored number in the same transaction.

`site/README.md` sets all three out under "Storing full card numbers". The admin
screen draws those buttons only when it has callbacks for them, so until they
exist nothing on screen is half-built.

The contact form is also still unwired: it validates and shows a success state
without sending anything. The place to hook it up is marked in `site/src/site.js`.
