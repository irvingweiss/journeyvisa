# Visa Journey USA

The website, the B1/B2 application form, the manager admin screen and the API
behind them.

No framework and no build step on the front end: the site is plain HTML, CSS and
vanilla JavaScript. The API is plain PHP 7.4 and PDO with no composer. Nothing
here needs installing to run.

PHP 7.4 is what the server runs today. The API also runs unchanged on PHP 8.x,
and a check in `tests/` fails if anything PHP 8-only gets in. Read "A word about
PHP 7.4" at the end of `INSTALL.md` before go-live.

## Where things are

    site/            the website
      deploy/        the site as it goes on the server. Upload all of it
                     (the API in api/ goes on the server too: see INSTALL.md)
      src/           the sources and the three build scripts
      preview/       single-file versions for showing people, not for hosting
      tests/         the automated checks
      README.md      the full handover: how everything works and why
      CHANGELOG.md   what changed, newest first

    api/             the PHP API. Plain PHP 7.4 and PDO
    tools/           generate the admin password hash and enrol the second factor
    tests/           the API checks: 7.4 compatibility, the API end to end,
                     and the pages against the router
    schema.mysql.sql       the database
    schema.migrations.sql  changes for a database built from an older version
    INSTALL.md       installing the API, step by step

Start with `INSTALL.md` to get it running, and `site/README.md` for how the
pieces fit together.

## Running it

Nothing to build. To work on the site:

    cd site/src
    python3 build.py && python3 deploy.py && python3 bundle.py

`build.py` generates the pages from shared chrome, `deploy.py` produces
`site/deploy/` with clean URLs and cache-busting, and `bundle.py` folds
everything into the single-file previews. Edit the sources in `site/src/`, never
the generated output in `site/deploy/`: the next build overwrites it.

To run the checks, the site:

    cd site/tests
    npm install          # jsdom (pinned to 26.x on purpose) and playwright
    npx playwright install chromium   # browser.js needs a real browser

    # neither of these needs a server or Node
    python3 rebuild_check.py
    python3 link_check.py deploy

    # the jsdom suites fetch the pages over HTTP, so they need one serving
    # ../src on port 8899. Without it every suite fails on the first fetch.
    python3 -m http.server 8899 --directory ../src &
    node suite.js ../src/
    node admin.js ../src/
    kill %1

    # page_errors needs no server. Run it against BOTH directories: ../deploy/
    # is what actually ships, and it is a separate build.
    node page_errors.js ../src/
    node page_errors.js ../deploy/

    # these two request real URLs from the built folder, served the way a host
    # serves it (clean URLs, no .html). serve_clean.py is that host.
    python3 serve_clean.py ../deploy &
    python3 deploy_checks.py ../deploy
    python3 crawl.py
    kill %1

    node browser.js ../deploy/     # a real browser, the real API, DEMO off
                                   # it starts its own server, so nothing above
                                   # needs to still be running

If you forget one of those servers, the suite that needs it says so and exits
2 with the command, rather than failing a handful of assertions that look like
a broken build. `site/tests/README.md` lists the rest of the suites and what
each one covers.

and the API, from the package root. The `cd ../..` matters: the block above
left you in `site/tests`, and every command here is relative to the root, so
without it they all fail with "Could not open input file".

    cd ../..

    php tests/api_test.php                 # 319 checks, end to end, no MySQL
    VJ_STRINGIFY=1 php tests/api_test.php  # again, with PDO returning strings
    python3 tests/api_contract.py          # the pages call routes that exist
    cd tests && npm install && node php74_check.js ../api ../tools
    node php74_check.js --self-test        # check the checker

`tests/README.md` says what each covers, and what none of them cover.

`site/tests/README.md` lists the rest and says what each one covers. They all
pass as committed.

## Secrets

**Nothing in this repository is a credential, and it should stay that way.**

The admin email, the admin password hash and the TOTP secret live in the
server's environment or in `api/config.php`, which `.gitignore` keeps out of
version control. `api/config.example.php` shows the shape with no values in it.
Generate the password hash with `tools/make-admin-hash.php` and the second
factor with `tools/enrol-totp.php`.

A secret committed by accident is not fixed by deleting it in a later commit. It
stays in the history, and the history is what gets cloned. If one does get in,
rotate the value rather than only removing the line.

Two things that look like secrets and are not:

- `DEMO_ADMIN_PASSWORD_SHA256` in `admin.html` is the password for the **offline
  preview**, published deliberately: it is `visa-preview-2026`. It keeps a
  casual visitor out of a preview file and nothing more. It is a plain SHA-256,
  which is fast to attack, which is exactly why the server uses bcrypt instead.
  **Never make it the same as the real admin password.** It is deleted before
  go-live along with the rest of the preview sign in.
- The applications in the preview and in `admin.html`'s demo data are invented.
  The names, reference numbers and passport numbers are made up.

## State of play

Working and tested: the site, the 22-step application form, the resume flow, the
admin screen, and the API behind all of them. The applicant and admin halves
were driven end to end against a database before this was committed — SQLite,
not MySQL, because no MySQL server was available where this was built. The
logic and the portability are proven; the MySQL driver and the MySQL-specific
DDL are not. `INSTALL.md` step 1 says what to confirm by hand.

An audit before handover found and fixed: the card-reveal guard the install
instructions describe did not actually require a second factor; the admin
lockout could be bypassed, and the manager locked out, with a forwarded header;
a correct password reset the budget for guessing the six-digit code; an
application could be locked permanently by anyone holding its reference number;
the photograph was trusted by its declared type rather than its bytes; and the
"Save and exit" button posted to a route that did not exist. Each one now has a
check that fails if it comes back.

Still to build, in this order:

1. **Move the server off PHP 7.4 to a supported version.** Not a code change —
   the API already runs on both. This is first because storing card numbers puts
   the system under PCI DSS at SAQ D, and unpatched software fails that on its
   own. "A word about PHP 7.4" at the end of `INSTALL.md` has the detail.
2. Key management for a stored card number, then `POST /api/application/card`,
   then `payment.html` can come off its DEMO flag.
3. The append-only reveal log, then the card-reveal route.
4. Recording a charge, purging the stored number in the same transaction.

`site/README.md` sets the last three out under "Storing full card numbers";
the PHP upgrade is at the end of `INSTALL.md`. The admin screen draws those
buttons only when it has callbacks for them, so until they exist nothing on
screen is half-built.

The contact form is also still unwired: it validates and shows a success state
without sending anything. The place to hook it up is marked in `site/src/site.js`.
