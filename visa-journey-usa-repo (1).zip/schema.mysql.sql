-- Visa Journey USA — schema (MySQL 8).
--
-- For Postgres, six changes to this file. Every QUERY in the API is portable,
-- so no PHP changes, but the DDL below is MySQL's:
--   1. BIGINT AUTO_INCREMENT PRIMARY KEY  ->  BIGSERIAL PRIMARY KEY
--   2. DATETIME                           ->  TIMESTAMPTZ
--   3. LONGTEXT                           ->  TEXT
--   4. TINYINT(1)                         ->  SMALLINT (see the warning below)
--   5. Drop every ENGINE= and DEFAULT CHARSET= clause
--   6. Move each inline INDEX clause out of its CREATE TABLE and into a
--      separate CREATE INDEX statement; Postgres does not accept them inline
--
-- Every index name in this file is UNIQUE across the file, and it has to stay
-- that way. MySQL index names are per-table, so idx_app on two tables is
-- legal here; in Postgres and SQLite they share one namespace per schema, and
-- the second CREATE INDEX of a duplicated pair fails with "relation already
-- exists". That stops the port part-way through, with some tables indexed and
-- some not and no obvious reason why.
--
-- Four names carry a table prefix (notes_idx_app, activity_idx_app,
-- applicant_sessions_idx_expiry, admin_sessions_idx_expiry) because those
-- four were the collisions an audit found: idx_app appeared on both
-- application_notes and application_activity, and idx_expiry on both session
-- tables. The rest (idx_updated, idx_status, idx_name, idx_bucket) are bare
-- because each appears once, which is all uniqueness requires. Do not "tidy"
-- the prefixes away, and if you add an index, check its name is not already
-- in this file rather than only that it is unused in its own table.
--
-- Changes 1 to 5 are what tests/api_test.php translates to reach SQLite,
-- which is the shortest way to see them in action. It does NOT exercise 6:
-- the translator drops the inline INDEX lines rather than converting them, so
-- the test database carries no indexes at all. Index DDL is therefore the one
-- part of this file no suite here runs; check it against a real server.
--
-- Keep the TINYINT(1) columns as SMALLINT. Do NOT make them BOOLEAN, however
-- natural that looks: on PHP 7.4 the pgsql driver returns booleans as the
-- strings 't' and 'f', and 'f' is a non-empty string, so it is TRUE in PHP.
-- Both admin_sessions flags would then read as set when they are not, which
-- means a half session passing as complete and a password-only session
-- passing the card-reveal guard. Db::flag defends against it, but integers
-- are the fix. The columns are mfa_passed, second_factor, number_on_file and
-- rate_events.succeeded.

CREATE TABLE applications (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  reference       VARCHAR(16)  NOT NULL UNIQUE,
  security_prompt VARCHAR(255) NOT NULL,
  -- bcrypt of the normalised answer. Never the answer itself.
  security_hash   VARCHAR(255) NOT NULL,
  failed_answers  INT          NOT NULL DEFAULT 0,
  locked_at       DATETIME     NULL,
  answers         LONGTEXT     NOT NULL,          -- JSON, as onSaveStep sends it
  step_index      INT          NOT NULL DEFAULT 0,
  status          VARCHAR(32)  NOT NULL DEFAULT 'New',
  applicant_name  VARCHAR(120) NULL,
  email           VARCHAR(255) NULL,
  created_at      DATETIME     NOT NULL,
  updated_at      DATETIME     NOT NULL,
  submitted_at    DATETIME     NULL,
  -- payment, all non-sensitive. The number itself never lives here.
  card_brand      VARCHAR(32)  NULL,
  card_last4      VARCHAR(4)   NULL,
  card_exp_month  INT          NULL,
  card_exp_year   INT          NULL,
  number_on_file  TINYINT(1)   NOT NULL DEFAULT 0,
  paid_amount     DECIMAL(10,2) NULL,
  paid_currency   VARCHAR(8)   NULL,
  charged_on      DATE         NULL,
  charged_by      VARCHAR(255) NULL,
  processor_ref   VARCHAR(128) NULL,
  charge_recorded_at DATETIME  NULL,
  INDEX idx_updated (updated_at),
  INDEX idx_status (status),
  INDEX idx_name (applicant_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE application_notes (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT NOT NULL,
  author         VARCHAR(255) NOT NULL,
  body           TEXT NOT NULL,
  at             DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX notes_idx_app (application_id, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE application_activity (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  application_id BIGINT NOT NULL,
  author         VARCHAR(255) NOT NULL,
  action         VARCHAR(255) NOT NULL,
  at             DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX activity_idx_app (application_id, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- An applicant may read one application. Set at create and at resume, never
-- derived from the reference number, which is printed and emailed.
CREATE TABLE applicant_sessions (
  token          VARCHAR(64) PRIMARY KEY,
  application_id BIGINT NOT NULL,
  created_at     DATETIME NOT NULL,
  expires_at     DATETIME NOT NULL,
  FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
  INDEX applicant_sessions_idx_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Two flags, and they are not the same question.
--
-- mfa_passed means "this sign in finished". A half session (the password
-- accepted, the code not yet given) has it at 0 and can reach nothing but
-- /admin/session/verify.
--
-- second_factor means "a second factor was actually presented". It is 1 only
-- when a TOTP code or a recovery code was accepted. When no secret is enrolled
-- the password alone finishes the sign in, so that session has mfa_passed = 1
-- and second_factor = 0.
--
-- The card routes must check second_factor, which is what
-- Sessions::requireAdmin($db, true) does. Checking mfa_passed instead would
-- accept a password-only session, because for that session it is also 1. These
-- were one column until an audit found that the card-reveal guard, written as
-- documented, would have let a password-only session read a card number.
CREATE TABLE admin_sessions (
  token        VARCHAR(64) PRIMARY KEY,
  email        VARCHAR(255) NOT NULL,
  mfa_passed   TINYINT(1) NOT NULL DEFAULT 0,
  second_factor TINYINT(1) NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL,
  expires_at   DATETIME NOT NULL,
  INDEX admin_sessions_idx_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- One row, id 1. last_totp_step stops a code being used twice inside its
-- window, which is what keeps a watched code from working a second time.
CREATE TABLE admin_state (
  id             INT PRIMARY KEY,
  last_totp_step BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO admin_state (id, last_totp_step) VALUES (1, 0);

-- Ten at enrolment, hashed, single use. There is one account, so without
-- these a lost phone locks the only login out of the site.
CREATE TABLE admin_recovery_codes (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  code_hash VARCHAR(255) NOT NULL,
  used_at   DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Rate limiting and lockout.
CREATE TABLE rate_events (
  id        BIGINT AUTO_INCREMENT PRIMARY KEY,
  bucket    VARCHAR(32) NOT NULL,
  ip        VARCHAR(45) NOT NULL,
  succeeded TINYINT(1) NOT NULL DEFAULT 0,
  at        DATETIME NOT NULL,
  INDEX idx_bucket (bucket, ip, at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
