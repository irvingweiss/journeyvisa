# The API checks

Three checks, covering different things. Run all of them.

The site has its own separate suite in `site/tests/` — 783 checks over the
pages, the form and the admin screen, counting each suite once. Several of
those take a build directory as their argument and are meant to be run against
both `src/` and `deploy/`, so a full run reports more than 783.
`site/tests/README.md` has the per-suite figures. These three are about the PHP
and about the seam between the PHP and the pages.

    php tests/api_test.php                 # the API, end to end, 319 checks
    VJ_STRINGIFY=1 php tests/api_test.php  # again, with PDO returning strings
    python3 tests/api_contract.py          # the pages call routes that exist
    cd tests && npm install && node php74_check.js ../api ../tools
    node php74_check.js --self-test        # check the checker

All five commands exit non-zero on failure, so they can gate a deploy.

## The server runs PHP 7.4

That is the constraint most of this exists to protect. PHP 7.4 has no
`str_starts_with`, no `match`, no `?->`, no promoted constructor parameters and
no union types. Code using any of them parses fine on a developer's PHP 8
laptop and fatals on the server, usually as a blank 500 with "syntax error" in
a log nobody is watching.

## 1. The API, end to end

    php tests/api_test.php

Starts the real API on a throwaway SQLite database and drives every endpoint
over HTTP, the way the browser does. No MySQL server, no composer, no
framework. It boots the real `index.php`, so it needs the same extensions the
API does: `pdo_sqlite`, `mbstring`, `json` and `filter`.

It covers the invariants that matter, not the happy path:

- A stranger holding the reference number can neither read nor write the
  application. The reference is printed and emailed, so it identifies an
  application and must not authorise one.
- A wrong email and a wrong password give the same status and the same message.
- A locked-out request is refused without the password being checked.
- A half session — password accepted, code not yet given — reaches nothing but
  `/admin/session/verify`.
- A password-only session, which is what you get when no TOTP secret is
  enrolled, is recorded as having presented **no** second factor. The card
  routes turn on that distinction and would otherwise hand a card number to
  one.
- A TOTP code is refused the second time it is used.
- A forwarded header cannot be used to pick a rate-limit bucket.
- A correct password does not reset the counter that limits code guesses.
- An application's lock expires rather than being permanent.
- A photograph is checked by its bytes, not by the type it claims.
- A `config.php` written before today's settings existed still works.
- The security answer is never stored in the clear and never returned.
- Every response is `no-store`.
- A path that exists under another verb is 405, not 404. With three
  exceptions, which are a consequence of the router and not a bug: the
  catch-all `GET /application/:ref` matches `/application/submit`, `/lookup`
  and `/resume`, so those answer 401 under GET rather than 405, because they
  are read as a reference nobody holds a session for.
- **Every route in `index.php` was actually exercised.** A new route therefore
  arrives with a test, or arrives failing. Two routes had no test at all until
  this check was added.

Two things it does deliberately:

**It runs the server with the PHP 8 functions disabled.** `php -S -d
disable_functions=str_starts_with,...` makes calling one a fatal error, so the
suite runs as though on 7.4 even though it is almost certainly running on
something newer. That turns "we read the source" into "we ran it without
them". The list is in `api_test.php`; add to it, do not trim it.

**`VJ_STRINGIFY=1` makes PDO return every column as a string.** That is what
PHP 7.4 does for SQLite and Postgres, and for MySQL whenever emulated prepares
are on. Without it, testing on a modern PHP only ever exercises native
integers, and a `=== 1` against a column that arrives as `'1'` in production
would sail through. **The suite is meant to pass both ways, so run it twice.**

The SQLite schema is translated from `schema.mysql.sql` at run time rather than
kept as a second copy, so a column added to the real schema and forgotten here
cannot pass.

## 2. The contract between the pages and the API

    python3 tests/api_contract.py

Reads the router table out of `api/index.php` and every live `fetch()` and
`post()` out of the built pages, and fails if a page calls something the API
does not serve, or serves under a different verb.

This is the gap the other two suites leave. The site tests run with the DEMO
flags on, so every network call is stubbed and a wrong URL is never sent. The
API test drives the API directly, so it only ever calls routes the API already
has. A page posting to a path the router does not implement passes both.

That is not hypothetical. `application.html`'s "Save and exit" button posted to
`/api/application/resume-link` while the API implemented
`/api/application/email-reference`. The answers saved, the email never sent,
and the applicant was told so. Nothing in either suite could see it.

Routes that are deliberately not built yet are listed in `NOT_BUILT_YET` with
the reason, and the check insists each one is behind a DEMO flag. Any other
missing path is a failure.

## 3. The PHP 7.4 compatibility check

    cd tests && npm install
    node php74_check.js ../api ../tools
    node php74_check.js --self-test

Parses every file against a PHP 7.4 grammar, then walks the tree for the things
that grammar wrongly accepts (promoted parameters, attributes, `readonly`,
union and intersection types, `mixed`, `never`, `false`, `static`,
`$object::class`), and for functions, classes and constants added after 7.4 —
including ones named as a string (`call_user_func('str_contains', ...)`) rather
than called directly.

`--self-test` runs it against `fixtures/php8_only.php`, which holds every
construct it is supposed to catch, and `fixtures/php74_clean.php`, which holds
the 7.4 code most easily mistaken for PHP 8 — arrow functions, typed
properties, `??=`, array spread, `list()` destructuring. A checker that has
quietly stopped detecting anything reports a clean run, which looks exactly
like success; this is what tells the two apart. It asserts three things: that
every kind of finding it is meant to produce is still produced, `syntax` among
them, so the 7.4 grammar pass cannot silently break or start parsing at the
wrong version; that the bad fixture still produces at least a fixed number of
findings, because deleting one rule from a kind that has other examples left
every kind present and the self-test stayed green three times running; and that
the clean fixture produces none. **If you add a rule, add a line to the bad
fixture and raise `EXPECTED_FINDINGS` in `php74_check.js` to match.** Never
lower that number to turn a red run green.

**The real run and `--self-test` go through the same `scanSource()`.** They used
to be two copies of the same twenty lines, each building its own parser, so the
self-test never exercised the configuration the real scan used — an audit set
the real grammar pass to 8.3, planted a trailing comma in a parameter list in
`api/` (a fatal on 7.4), and `--self-test` went on printing its reassuring
message while the real run saw nothing. One code path means the self-test
covers the real run.

**A run that found no PHP files exits 2 rather than passing.** Without that, a
path typo or an extension the file walker does not recognise prints "No PHP
8-only syntax" and exits 0, so the gate passes by scanning zero bytes.

### What it does not do

An audit found it weaker than its clean output suggested, so to be plain about
it. A clean run means: no PHP 8 syntax, and no newer function or class from a
hand-maintained list, spelled in a way a static reader can see. It does not
mean the code is correct on 7.4. In particular it does not know about:

- **New parameters on existing functions.** `hash(..., ['seed' => 1])` takes an
  options array only from 8.1, and this cannot see that.
- **Semantics.** The PHP 8 string-to-number comparison change, PDO returning
  strings rather than integers, warnings that became TypeErrors, locale
  handling. Those are what `api_test.php` and `VJ_STRINGIFY=1` are for.
- **Array unpacking with string keys** (8.1), which is syntactically identical
  to the 7.4 spread.
- **Anything reached through a variable** more indirectly than a plain string
  literal.
- **The other direction.** The requirement is 7.4 *and newer*, and nothing here
  catches a construct removed in 8.0.

It is a syntax and name checker. Keep it, and do not let it be the only thing
anyone relies on.

## What none of these cover

**MySQL specifically.** SQLite proves the logic and the portability; it does
not prove the MySQL driver. Run the curl checks at the end of `INSTALL.md`
against the real server once after installing, and sign in to `/admin` in a
browser.

**The card routes**, which are deliberately not built. See "What is
deliberately not here" in `INSTALL.md`.
