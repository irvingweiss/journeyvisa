-- Changes to apply to a database that was created from an EARLIER version of
-- schema.mysql.sql.
--
-- A fresh install does not need this file: schema.mysql.sql already has
-- everything in it. Run these only if the database is already there and the
-- API was working against it before.
--
-- Each block says how to tell whether you need it. They are safe to run in
-- order. Running the file twice stops on the ALTER with "duplicate column
-- name", which is the ALTER telling you it is already applied; the INSERT
-- below is idempotent and does nothing the second time.

-- ---------------------------------------------------------------------------
-- 2026-10-22  admin_sessions.second_factor
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SHOW COLUMNS FROM admin_sessions LIKE 'second_factor';
--
-- No rows means yes, apply this. Without the column, signing in fails with a
-- generic 500 and the only clue is the PHP error log, which names the column.
--
-- WHERE it fails depends on whether a TOTP secret is enrolled, which is why
-- the symptom looks like two different bugs:
--
--   secret enrolled     the password step SUCCEEDS and answers
--                       {"mfaRequired":true}, because Sessions::startAdminHalf
--                       does not touch this column. The CODE step is what
--                       500s: Sessions::admin() selects second_factor.
--   no secret enrolled  the password step itself 500s, because
--                       Sessions::startAdminFull inserts this column.
--
-- So a half-finished sign in that looks fine until the code is typed is this
-- migration missing, not a problem with the code or the clock.
--
-- Why it exists: mfa_passed means "the sign in finished", which is also true
-- for a password-only session on a server with no TOTP secret enrolled. The
-- card routes need "a second factor was actually presented", which is a
-- different question, and asking the first one would have handed a card
-- number to a password-only session. See the comment on admin_sessions in
-- schema.mysql.sql.

ALTER TABLE admin_sessions
  ADD COLUMN second_factor TINYINT(1) NOT NULL DEFAULT 0 AFTER mfa_passed;

-- Existing sessions are password-only as far as anyone can now prove, and the
-- DEFAULT 0 above already says so. Signing out and back in sets it properly.
-- If you would rather not leave sessions in that state at all:
--
--     DELETE FROM admin_sessions;
--
-- which just means signing in again.

-- ---------------------------------------------------------------------------
-- 2026-10-22  admin_state must have its row
-- ---------------------------------------------------------------------------
--
-- Do you need it? Run:
--
--     SELECT COUNT(*) FROM admin_state WHERE id = 1;
--
-- A 0 means yes. schema.mysql.sql seeds this row, so a normal install has it;
-- a hand-built schema or a dump restored without its INSERTs may not.
--
-- Without the row, the replay guard in Admin::verifyCode updates zero rows,
-- which is also what "this code was already used" looks like. It tells the
-- two apart rather than guessing: on zero rows it counts the rows for id = 1,
-- and if there are none it INSERTs the row itself, logs
-- "admin_state had no row; created it" and lets the sign in through. So a
-- missing row self-heals on the first correct code and is NOT a lockout.
--
-- Run this anyway. The self-heal is a backstop, not the intended path: it
-- leaves a line in the error log on an otherwise clean install, and it can
-- only recover a row that the API has permission to insert. Applying it here
-- means the first sign in works without relying on that.
--
-- It is worth knowing what the self-heal is guarding against, because the
-- obvious shortcut is wrong: reporting "That code has already been used" for
-- a zero-row update would refuse every correct code forever, on a schema the
-- admin cannot see anything wrong with, and send whoever is debugging it a
-- long way in the wrong direction.

-- id is the primary key, so INSERT IGNORE adds the row if it is missing and
-- does nothing if it is already there. Deliberately not a SELECT ... WHERE NOT
-- EXISTS against the same table: that form is easy to get subtly wrong across
-- databases, and this one says what it means in one line.
INSERT IGNORE INTO admin_state (id, last_totp_step) VALUES (1, 0);

-- Postgres: INSERT IGNORE is MySQL's. Use
--   INSERT INTO admin_state (id, last_totp_step) VALUES (1, 0)
--     ON CONFLICT (id) DO NOTHING;

-- Postgres note: for the ALTER, use SMALLINT rather than TINYINT(1), and drop
-- the AFTER clause. Do NOT use BOOLEAN. On PHP 7.4 the pgsql driver returns
-- booleans as the strings 't' and 'f', and 'f' is truthy in PHP, which would
-- make both admin_sessions flags read as set when they are not. Keeping these
-- columns as integers keeps every driver agreeing.
