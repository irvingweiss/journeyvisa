<?php
/* The configuration, with a default for every tunable.
 *
 * Why this exists. config.php is written once, by hand, at install time, and
 * then it sits there. Every setting used to be read straight out of it with no
 * fallback, so adding a setting silently broke every install that already had
 * a config.php -- and the breakage was not a clear error, it was a zero.
 *
 * That is not hypothetical. Three rate-limit settings were added to
 * Application::resume(), read as (int) $cfg['resume_rate_window'] with no
 * default. On an install whose config.php predated them, (int) null is 0, so
 * the window was zero seconds, the limit was zero attempts, and `0 >= 0` is
 * true: every single resume attempt answered 429 before the security answer
 * was ever checked. Applicants could not get back into their applications at
 * all, and the only trace was an undefined-index notice in a log. The same
 * missing key turned the per-application lockout into a no-op, because
 * locked_at plus a zero window is always in the past.
 *
 * So: defaults live here, config.php overrides them, and a setting added in
 * future degrades to something sensible instead of to zero. A limit of zero is
 * never what anybody means.
 */

class Config
{
    /** The value used when config.php does not name a setting. */
    const DEFAULTS = [
        /* Credentials and connection have no safe default. They are listed so
           the shape is complete, and checked below. */
        'dsn'                 => '',
        'db_user'             => '',
        'db_pass'             => '',
        'admin_email'         => '',
        'admin_password_hash' => '',
        'totp_secret'         => '',

        'admin_fail_limit'   => 5,
        'admin_fail_window'  => 900,
        'admin_lockout'      => 900,

        'resume_fail_limit'  => 5,
        'resume_lockout'     => 1800,
        'resume_rate_limit'  => 10,
        'resume_rate_window' => 600,

        'lookup_rate_limit'  => 20,
        'lookup_rate_window' => 600,

        'admin_session_hours'     => 12,
        'applicant_session_hours' => 72,

        'photo_dir'     => '',
        'service_fee'   => 185,
        'currency'      => 'USD',
        'support_email' => '',

        'allowed_origins' => [],
        'secure_cookies'  => true,

        /* Empty means no forwarded header is believed. See Http::ip. */
        'trusted_proxy_header' => '',
        /* How many proxies of your own sit in front of this API. Only read
           when trusted_proxy_header is X-Forwarded-For, where it decides how
           far from the right-hand end the caller's address is. See Http::ip. */
        'trusted_proxy_hops' => 1,

        /* Tests only. Makes PDO return every column as a string, the way
           PHP 7.4's drivers do, so the suite can prove the code does not
           depend on native integers. Leave it alone in a real install. */
        'stringify_fetches' => false,
    ];

    /* What each setting has to be, checked in load().
     *
     * Why a table rather than a cast at each point of use. Every setting here
     * is written by hand into a PHP file, so a typo produces a value of the
     * wrong TYPE, not just the wrong number -- and PHP's casts turn those
     * into plausible-looking nonsense rather than errors. An audit found five
     * of these, all from the same root cause:
     *
     *   (int) [5]            is 1, so a fail limit of [5] locks the only
     *                        manager out on the first typo.
     *   (string) ['/photos'] is "Array", so mkdir makes a RELATIVE directory
     *                        called Array and passport photographs are
     *                        written inside the web root, with the applicant
     *                        told the upload worked.
     *   (string) ['X-F-F']   is "Array", so the rate-limit bucket is keyed on
     *                        a header named "Array" that any caller can set:
     *                        unlimited password guessing, plus the ability to
     *                        lock out the real manager by naming their
     *                        address.
     *   [8080, 443]          as allowed_origins passes is_array, then fails
     *                        every strict in_array, so every write answers
     *                        403 and nothing says why.
     *   (bool) ''            is false, silently dropping Secure from the
     *                        cookie that authorises reading passport numbers.
     *                        (An earlier version of this comment gave '0' as
     *                        the example. '0' means false, so false is the
     *                        right answer for it; the empty string is the one
     *                        that silently means the opposite of the default.)
     *
     * None of those logged anything. Checking the type once, here, where the
     * log line can name the setting, is the fix for all of them.
     *
     *   int     a whole number of at least 1 (a limit or window of 0 is an
     *           outage: `0 >= 0` refuses every request before checking it)
     *   number  a positive amount, fractional allowed (money)
     *   string  a string; may be empty, since most of these are optional
     *   bool    true or false, with 1/0 and "true"/"false" accepted
     *   string- list of non-empty strings
     *   list    (see string-list)
     */
    const TYPES = [
        'dsn'                 => 'string',
        'db_user'             => 'string',
        'db_pass'             => 'string',
        'admin_email'         => 'string',
        'admin_password_hash' => 'string',
        'totp_secret'         => 'string',

        'admin_fail_limit'   => 'int',
        'admin_fail_window'  => 'int',
        'admin_lockout'      => 'int',

        'resume_fail_limit'  => 'int',
        'resume_lockout'     => 'int',
        'resume_rate_limit'  => 'int',
        'resume_rate_window' => 'int',

        'lookup_rate_limit'  => 'int',
        'lookup_rate_window' => 'int',

        'admin_session_hours'     => 'int',
        'applicant_session_hours' => 'int',

        'photo_dir'     => 'string',
        'service_fee'   => 'number',
        'currency'      => 'string',
        'support_email' => 'string',

        'allowed_origins' => 'string-list',
        'secure_cookies'  => 'bool',

        'trusted_proxy_header' => 'string',
        'trusted_proxy_hops'   => 'int',

        'stringify_fetches' => 'bool',
    ];

    /**
     * Read config.php and fill in anything it does not name.
     *
     * A key present but null takes the default too: a config written by a
     * generator that emits null for "not set" should behave as not set, not
     * as zero.
     */
    public static function load(string $file): array
    {
        $given = require $file;
        if (!is_array($given)) {
            return self::DEFAULTS;
        }
        $cfg = self::DEFAULTS;
        $unknown = [];
        foreach ($given as $key => $value) {
            if ($value !== null) {
                $cfg[$key] = $value;
            }
            if (!array_key_exists($key, self::DEFAULTS)) {
                $unknown[] = $key;
            }
        }
        /* A setting whose NAME is mistyped is the other half of the same
           problem the type checking below solves, and it is quieter: the value
           is simply never read, so the limit stays at its default and the
           person who set it has no way to tell. One log line turns that into
           a five-second fix. Unknown keys are kept rather than dropped, in
           case a future version reads them. */
        if ($unknown) {
            error_log('[vj] config.php sets settings this API does not use, so they'
                . ' have no effect -- check the spelling: ' . implode(', ', $unknown));
        }

        /* Check the type of every setting, and fall back to the default when
           it is wrong. See TYPES above for why this is a table rather than a
           cast at each point of use, and what each of the five audit findings
           it closes actually did. A mistyped setting should not take the site
           down, so this logs and carries on -- but it logs by NAME, which is
           the part that was missing. */
        foreach (self::TYPES as $key => $type) {
            $value = $cfg[$key];
            $ok = true;
            switch ($type) {
                case 'int':
                    /* is_numeric first: (int) of an array is 1, which sails
                       through a `< 1` test and leaves the array in place for
                       every later cast to turn into 1 as well.
                       
                       trim() before is_numeric, because PHP 8.0 accepts a
                       trailing space in a numeric string and 7.4 does not.
                       Without it, '3600 ' is honoured on a developer's PHP 8
                       and silently reverts to the default on the 7.4 the
                       server runs -- a setting that works in testing and not
                       in production, which is the worst shape a bug can
                       have. */
                    $ok = (is_int($value)
                            || (is_string($value) && is_numeric(trim($value))))
                        && (int) trim((string) $value) >= 1;
                    if ($ok) {
                        $value = trim((string) $value);
                    }
                    if ($ok) {
                        $cfg[$key] = (int) $value;
                    }
                    break;
                case 'number':
                    /* is_finite as well: '1e400' is numeric and casts to INF,
                       which passes `> 0`, and json_encode then fails on the
                       whole response so the caller gets an empty 200. */
                    $ok = (is_int($value) || is_float($value)
                            || (is_string($value) && is_numeric(trim($value))))
                        && (float) $value > 0 && is_finite((float) $value);
                    if ($ok) {
                        $cfg[$key] = (float) $value;
                    }
                    break;
                case 'string':
                    $ok = is_string($value);
                    break;
                case 'bool':
                    /* Forgiving about spelling, strict about meaning. 1/0 and
                       "true"/"false" are what people actually write; anything
                       else takes the default, because guessing wrong on
                       secure_cookies drops Secure from an admin cookie. */
                    if (is_bool($value)) {
                        break;
                    }
                    $spelling = is_string($value) ? strtolower(trim($value)) : $value;
                    $yes = [1, '1', 'true', 'yes', 'on'];
                    $no  = [0, '0', 'false', 'no', 'off'];
                    if (in_array($spelling, $yes, true)) {
                        $cfg[$key] = true;
                    } elseif (in_array($spelling, $no, true)) {
                        $cfg[$key] = false;
                    } else {
                        $ok = false;
                    }
                    break;
                case 'string-list':
                    $ok = is_array($value);
                    if ($ok) {
                        $clean = [];
                        foreach ($value as $item) {
                            /* Every comparison against this list is a strict
                               in_array, so a port number written without
                               quotes matches nothing and every write answers
                               403 with no explanation anywhere. */
                            if (!is_string($item) || trim($item) === '') {
                                $ok = false;
                                break;
                            }
                            /* Normalise rather than only reject. An Origin
                               header is scheme://host[:port] with no trailing
                               slash, so ' https://x' and 'https://x/' match
                               nothing under a strict comparison -- and those
                               are what a hand-typed list actually contains.
                               An audit booted both and got 403 bad_origin on
                               every write with nothing in the log, which is
                               exactly the failure this type table exists to
                               stop. */
                            $clean[] = rtrim(trim($item), '/');
                        }
                        if ($ok) {
                            $value = $clean;
                            $cfg[$key] = $clean;
                        }
                    }
                    break;
            }
            if (!$ok) {
                error_log('[vj] config.php has ' . $key . ' = '
                    . var_export($value, true) . ', which is not a valid '
                    . $type . '; using the default of '
                    . var_export(self::DEFAULTS[$key], true));
                $cfg[$key] = self::DEFAULTS[$key];
            }
        }

        /* The one setting whose SHAPE matters as much as its type.
         *
         * admin_password_hash is a string either way, so the type table above
         * cannot tell a bcrypt hash from the password itself -- and pasting
         * the password is the obvious mistake at step 4, where the whole task
         * is "run this command and paste what it prints". The result was
         * silent and total: password_verify() against a non-hash always
         * returns false, signIn's `$hash === ''` test passes so it does not
         * report not_configured, and the only manager account answers 401 to
         * the correct password for ever with nothing in the log. An audit
         * pasted the plaintext password and confirmed there was no way to
         * tell from the outside.
         *
         * This logs rather than refuses, because a wrong hash stops one
         * feature and the applicant form must keep working -- the same
         * reasoning as Config::missing(). */
        if ($cfg['admin_password_hash'] !== ''
            && password_get_info($cfg['admin_password_hash'])['algo'] === null) {
            error_log('[vj] admin_password_hash in config.php is not a password hash,'
                . ' so no password can ever match it and admin sign in will always'
                . ' be refused. Did you paste the password instead of the hash?'
                . ' Re-run tools/make-admin-hash.php. See step 4 of INSTALL.md.');
        }

        return $cfg;
    }

    /**
     * Settings without which NO request can work, so the API refuses to start.
     *
     * Deliberately short. The admin credentials and photo_dir are NOT here,
     * even though nothing involving them works without them, because they
     * stop one feature rather than all of them -- and because this check
     * briefly included them and broke the install guide's own order: the
     * guide has you fill in the database details at step 3, test with curl,
     * and generate the admin hash at step 4. With the credentials in this
     * list, that curl answered 500 and the applicant endpoints were dead
     * until an unrelated step was done. Each feature reports its own missing
     * setting by name instead: Admin::signIn answers 'not_configured', and
     * Application::savePhoto names photo_dir.
     */
    public static function missing(array $cfg): array
    {
        $missing = [];
        foreach (['dsn'] as $key) {
            if (!is_string($cfg[$key] ?? null) || trim((string) $cfg[$key]) === '') {
                $missing[] = $key;
            }
        }
        /* is_array, not empty(). A config whose allowed_origins is a bare
           string rather than a list passes empty() and then fails inside
           Http::sameOrigin(array $allowed) as an uncaught TypeError, outside
           the try block, so the caller gets a zero-byte 500 and the log says
           only "Uncaught TypeError" with nothing pointing at the config. An
           audit found it, which is the behaviour this function exists to
           replace. */
        if (!is_array($cfg['allowed_origins'] ?? null) || $cfg['allowed_origins'] === []) {
            $missing[] = 'allowed_origins';
        }
        return $missing;
    }

    /**
     * Where passport photographs go, or '' if it is not usable.
     *
     * One place, called by both the write (Application::savePhoto) and the
     * read (Admin::photo), because they drifted apart: the write grew a guard
     * and a cast and the read kept a bare rtrim(). With photo_dir unset that
     * made the write refuse and the read probe the filesystem ROOT for
     * /<REF>.jpg; with photo_dir an array it made the write store the file
     * and the read fail to find it -- as a 500 on PHP 8 and a path of
     * "/<REF>.jpg" on the 7.4 this actually ships on, so the behaviour
     * differed between the version the developer tests on and the version in
     * production.
     *
     * Absolute only. A relative path is resolved against the web server's
     * working directory, which under PHP-FPM is api/ itself, so a typo puts
     * passport photographs inside the document root where they can be
     * fetched without signing in.
     */
    public static function photoDir(array $cfg): string
    {
        $raw = $cfg['photo_dir'] ?? '';
        if (!is_string($raw) || trim($raw) === '') {
            return '';
        }
        $raw = rtrim(trim($raw), '/\\');
        if ($raw === '') {
            return '';
        }
        /* Unix absolute, or a Windows drive or UNC path, since this ships an
           IIS configuration too. */
        $absolute = $raw[0] === '/'
            || preg_match('#^[A-Za-z]:[\\\\/]#', $raw) === 1
            || strncmp($raw, '\\\\', 2) === 0;
        if (!$absolute) {
            error_log('[vj] config.php has photo_dir = ' . var_export($cfg['photo_dir'], true)
                . ', which is not an absolute path. Photographs will not be stored.'
                . ' See step 7 of INSTALL.md.');
            return '';
        }
        return $raw;
    }
}
