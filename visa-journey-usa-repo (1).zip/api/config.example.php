<?php
/* Visa Journey USA — API configuration.
 *
 * Copy to config.php and fill in. config.php holds credentials, so it must not
 * be in version control and must not be reachable over the web. The .htaccess
 * shipped beside it blocks it, but the safer arrangement is to keep this whole
 * api/ folder outside the document root and point one rewrite at index.php.
 *
 * Anything that can come from the environment should. On a host with a secrets
 * manager, read these from it rather than from this file.
 *
 * Every setting here has a default in Config::DEFAULTS, so leaving one out is
 * safe. Every setting also has a TYPE, in Config::TYPES, which is checked as
 * the file loads: a value of the wrong type falls back to that setting's
 * default and the PHP error log gets a line naming the setting. It is not cast
 * into something plausible. That is deliberate, because this file is written by
 * hand and PHP's casts hide the typo rather than reporting it -- (int) [5] is
 * 1, so a fail limit written as [5] would lock the only manager out on the
 * first mistyped password. Every limit, window and session length must be a
 * whole number of at least 1; a 0 is treated as a mistake too, since `0 >= 0`
 * refuses every request before checking it.
 */

return [

    /* ---------------------------------------------------------- database */

    /* MySQL 8. For Postgres change this one line to
       'pgsql:host=localhost;dbname=visajourney' and nothing else: every query
       in this API is portable. */
    'dsn'      => getenv('DB_DSN') ?: 'mysql:host=localhost;dbname=visajourney;charset=utf8mb4',
    'db_user'  => getenv('DB_USER') ?: 'visajourney',
    'db_pass'  => getenv('DB_PASS') ?: '',

    /* ------------------------------------------------------ admin account */

    /* One account. Not a row in a users table. Generate the hash with
       tools/make-admin-hash.php and paste the output, single quotes included:
       it is full of $ and a .env loader will otherwise expand it. */
    'admin_email'         => getenv('ADMIN_EMAIL') ?: '',
    'admin_password_hash' => getenv('ADMIN_PASSWORD_HASH') ?: '',

    /* Base32 TOTP secret from tools/enrol-totp.php. Leave empty and the
       password step signs straight in, which is fine while you are building.

       That session is recorded with second_factor = 0, because none was
       presented. The card routes must check THAT, via
       Sessions::requireAdmin($db, true) -- not mfa_passed, which is also 1
       for a password-only session and would hand a card number to one. An
       audit found exactly that mistake written into this file.

       Empty or whole, nothing in between. A secret that is SET but not
       usable is a configuration error, not an absent second factor: sign in
       answers 500 'not_configured' and the log says to re-run the tool.
       Totp::usable() sets out what counts, and the short version is: do not
       put a placeholder here.

       '000000' and '0' decode to a ZERO-length key, because no digit is in
       the base32 alphabet, and the codes from an empty key are what anybody
       can compute. 'AAAAAAAAAAAAAAAA' is worse, because it looks like a real
       secret and decodes to ten bytes of 0x00. Both used to sign in and mark
       the session as having passed a second factor.

       Pasting a secret WITH the dashes an authenticator app shows is fine:
       every character outside the alphabet is stripped, so 'DFJF-7O4R-...'
       and 'DFJF7O4R...' are the same secret. An earlier version of this
       comment said otherwise and was wrong. */
    'totp_secret' => getenv('TOTP_SECRET') ?: '',

    /* ------------------------------------------------------------ limits */

    'admin_fail_limit'   => 5,     // failed sign ins before lockout
    'admin_fail_window'  => 900,   // seconds the failures are counted over
    'admin_lockout'      => 900,   // seconds locked out for

    'resume_fail_limit'  => 5,     // wrong security answers before an application locks
    'resume_lockout'     => 1800,  // seconds it stays locked, then it clears itself
    'resume_rate_limit'  => 10,    // resume attempts per IP per window
    'resume_rate_window' => 600,
    'lookup_rate_limit'  => 20,    // lookups per IP per window
    'lookup_rate_window' => 600,

    'admin_session_hours'     => 12,
    'applicant_session_hours' => 72,

    /* ------------------------------------------------------------- other */

    /* Where decoded photographs are written. Outside the document root, or
       they are downloadable by anyone who guesses the filename.

       ABSOLUTE ONLY: Unix /var/..., Windows C:\... or a UNC \\server\share.
       A relative path is refused, with a line in the log, and no photograph is
       stored -- because under PHP-FPM a relative path resolves against api/
       itself, so the photographs would land inside the document root, which is
       the one place they must not be. Config::photoDir() decides this once for
       both the write and the read sides. __DIR__ below keeps it absolute. */
    'photo_dir' => getenv('PHOTO_DIR') ?: __DIR__ . '/../../private/photos',

    /* Shown on the admin screen and used when recording a charge. The browser
       never sends an amount. */
    'service_fee' => 185,
    'currency'    => 'USD',

    'support_email' => 'support@visajourneyusa.com',

    /* Only requests from these origins may change anything. Add the bare
       domain too if the site answers on both. */
    'allowed_origins' => [
        'https://www.visajourneyusa.com',
        'https://visajourneyusa.com',
    ],

    /* false only while developing over plain http on localhost. Leaving it
       false in production sends session cookies over http. */
    'secure_cookies' => true,

    /* Which forwarded header gives the caller's real address, if any.
       LEAVE THIS EMPTY unless an edge you control sets the header on every
       request AND strips any copy the client sent.

       Every rate limit and the admin lockout are keyed on the address, so
       whoever controls this value controls the lockout. A client can put
       anything in X-Forwarded-For. Empty means the address the connection came
       from is used, which is the safe answer and right for an ordinary host.

       Behind Cloudflare:            'CF-Connecting-IP'
       Behind your own nginx or ALB:  'X-Forwarded-For'

       Exactly one of four names, and nothing else:

           X-Forwarded-For   CF-Connecting-IP   X-Real-IP   True-Client-IP

       Any other value -- including two names written into one string, which an
       earlier wording of INSTALL.md invited -- is refused with a line in the
       log and the connection address is used instead. The whitelist exists
       because Http::ip has to know whether a header is APPENDED to (believe
       the right-hand end) or SET outright (believe the left) before it can
       read it, and it cannot know that about a name it has never seen.

       Http::ip knows that X-Forwarded-For is appended to and counts in from
       the rightmost entry; CF-Connecting-IP and the other two are set outright
       by the edge, so there is only ever one value. A :port suffix is stripped
       first, for both IPv4 and a bracketed IPv6 address, because IIS with ARR
       and Azure App Service append ip:port rather than a bare address. */
    'trusted_proxy_header' => '',

    /* How many proxies OF YOUR OWN append to X-Forwarded-For. Read only when
       trusted_proxy_header is X-Forwarded-For; the other three headers are set
       outright, so there is nothing to count. Http::ip counts in from the
       RIGHT-hand end by this many entries.

           1  a single nginx, or a single AWS ALB. The default.
           2  Cloudflare in front of your own nginx.
           1  a proxy that REPLACES the header with the peer address
              (proxy_set_header X-Forwarded-For $remote_addr): one value reads
              the same from either end.

       Both mistakes are quiet and they fail in opposite directions. Too low
       and the value read is your inner proxy's own address, the same for every
       visitor, so all of them share one rate-limit bucket: one person's five
       bad passwords lock the only manager out for everybody. Too high and the
       value read is one the caller supplied, which hands them the bucket --
       unlimited password guessing, and the ability to lock your manager out by
       sending their address. */
    'trusted_proxy_hops' => 1,
];
