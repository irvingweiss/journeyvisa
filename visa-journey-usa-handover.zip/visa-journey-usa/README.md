# Visa Journey USA — developer handover

Static site. No framework, no build step, no dependencies. Plain HTML, one CSS
file, and three JavaScript files. It runs on any static host.

---

## What is in this package

    deploy/     Upload this. Production-ready, clean URLs, headers, sitemap.
    src/        The same site with relative links, plus the build scripts.
    preview/    One self-contained HTML file. For showing people, not for hosting.

If you only read one other file, read `deploy/DEPLOY.md`.

---

## Deploying

Drag the `deploy` folder onto Netlify. Not the zip, not the files individually.
`netlify.toml` is read automatically, so nothing needs configuring in the dashboard.

If it goes into Git instead:

    Build command:      (leave empty)
    Publish directory:  deploy

For any other host: serve `deploy/` as the document root and turn on extensionless
URL resolution, so `/about-us` serves `about-us.html`. Netlify does this by default.
On nginx it is `try_files $uri $uri.html $uri/ =404;`.

---

## Pages

    /                        homepage
    /about-us
    /contact-us              form, client-side validation only
    /application             the 21-section DS-160 form
    /payment                 preparation fee, hands off to your payment provider
    /resume                  get back into an application in progress
    /terms-and-conditions    plain-English summary, full text still to be pasted in
    /privacy-policy          same
    404.html                 Netlify serves this automatically

`/payment` and `/resume` are `noindex` and are deliberately absent from the sitemap.

---

## The three JavaScript files

**`visa-application-form.js`** is the application form. It exposes two functions:

    VisaJourneyForm.mount(element, options)
    VisaJourneyForm.mountResume(element, options)

It styles itself, holds all 21 sections and their conditional logic, and keeps
nothing in localStorage or sessionStorage. Passport and ID numbers do not survive
a page close, which is deliberate: shared and stolen devices are a real risk for
this audience. That also means an unsaved step is genuinely lost, so
`onSaveStep` has to reject when a write fails.

**`payment-step.js`** is the fee screen. `VisaJourneyPayment.mount(element, options)`.

**`site.js`** is the mobile menu and the contact form. Nothing else.

---

## What you need to build

### 1. Four endpoints for the form

Open `application.html` and `resume.html` and look for `var DEMO = true`. While
that is true, reference numbers are generated in the browser and nothing is stored.
Fine for review, wrong for real applicants: every one of them loses their answers.

Flip it to false and the `fetch` calls beside it take over. They expect:

    POST /api/application
      in:   { securityPrompt, securityAnswer }
      out:  { applicationId }
      Hash the answer with bcrypt or argon2. Never store it in plain text.
      The form drops it from memory as soon as this resolves.

    PATCH /api/application/:id
      in:   { applicationId, stepId, data }
      out:  204
      Must return non-2xx on a failed write. The form shows "Could not save"
      and keeps the answers on screen, which is the whole safety net.

    POST /api/application/submit
      in:   the full answer set
      out:  200

    POST /api/application/lookup     { applicationId } -> { securityPrompt }
    POST /api/application/resume     { applicationId, answer } -> 200 or 401

Rate limit `lookup` and `resume`. Those two are what someone would hammer to guess
a reference number. Lock an application after a handful of failed answers.

### 2. The contact form

`site.js` validates and shows a success state without sending anything. Either:

- Netlify Forms: add `netlify` and `name="contact"` to the `<form>` tag in
  `contact-us.html` and remove the `preventDefault` in `site.js`. Submissions
  appear in the Netlify dashboard. No backend at all.
- Or point it at your own endpoint. Validate again server side and rate limit it.

### 3. Payment

`payment.html` currently runs in hosted-redirect mode, so no card fields are on the
page. `onPay` shows a preview message instead of charging anything.

Create the payment intent or checkout session server side and redirect from `onPay`.
Never trust an amount sent from the browser. To use Stripe Elements inline instead
of a redirect, drop `hostedRedirect` and pass `mountCardFields`; the commented
example is in `payment.html`.

---

## Before it goes live

- **Remove `noindex,nofollow`.** The current production site sends it on every page.
  These files send `index,follow`, so if the tag survives the switch it is being
  injected by a layout or a header somewhere. Nothing can rank until it is gone.
- **Host the hero image locally.** `index.html` still loads it from
  `www.visajourneyusa.com/assets/...`, which breaks the moment the old server goes.
- **Fill in the three `EDIT:` markers.** Grep for them. They are the registered legal
  entity in the footer, the service fee figure, and the support hours.
- **Paste the real legal copy** into `terms-and-conditions.html` and
  `privacy-policy.html`. Both currently carry an honest plain-English summary and a
  marked block where the full text belongs.
- Update the date in `sitemap.xml` when the pages change.

---

## Two things not to undo

Both are marked with comments in the files. Both were bugs that got fixed, and both
look like tidy-up candidates to someone who was not here.

**In `site.css`:** the button rules carry a `.vj-site` prefix. Most buttons on this
site are anchors, and `.vj-site a` sets a link colour at a higher specificity than a
bare `.btn-primary`. Strip the prefix and the filled buttons go back to dark teal
text on a teal background.

**In `visa-application-form.js`:** free-text inputs write to state through
`setQuiet`, which updates the value without repainting, and only repaint on
`change`. A repaint mid-word destroys the input being typed into and drops the
caret, which made the first step impossible to complete. `render()` also wraps
`paint()` to restore focus and caret after the repaints that do still happen.
Selects and yes/no controls must keep repainting immediately, because conditional
branches depend on them.

---

## Rebuilding

Only if you change the shared header or footer. They live in `src/build.py` rather
than being copy-pasted into eight files.

    cd src
    python3 build.py      # regenerates the eight pages
    python3 deploy.py     # rebuilds ../deploy with clean URLs and headers
    python3 bundle.py     # rebuilds the single-file preview

If you are moving this into a real templating system, `build.py` is the spec for
what the shared chrome contains.
