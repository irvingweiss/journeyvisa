# Deploying to Netlify

## Drag and drop

Netlify home, then Sites, then drop this whole folder onto the drop zone. Do not
zip it first and do not drop the files individually: Netlify needs the folder so
the paths line up. It goes live in about twenty seconds on a random subdomain,
which is fine for review.

## Or connect a repository

If the code ends up in Git, point Netlify at the repo and use:

    Build command:      (leave empty)
    Publish directory:  .

There is no build step. These are plain files.

## Custom domain

Site configuration, then Domain management, then add `visajourneyusa.com`. Netlify
issues the certificate itself. Set one of www or the bare domain as primary and let
Netlify redirect the other, so you are not splitting link equity across both.

Point DNS at Netlify before you switch anything, and keep the current site up until
the new one resolves.

## What is in here

- Six pages plus a 404, at clean URLs. `/about-us`, not `/about-us.html`.
- `netlify.toml` sets security headers, cache headers and redirects from the old
  `.html` paths. Netlify reads it automatically.
- `robots.txt` and `sitemap.xml` are both live and pointing at the real domain.
- `favicon.svg`.

## Before you point the domain at it

- The application form and the payment step are already in this folder and wired
  up. Both run in demo mode: open `application.html` and `payment.html` and look for
  `var DEMO = true`. Flip it to false once the four API endpoints exist, and the
  fetch calls beside it take over.
- Wire the contact form. It currently validates and shows a success state without
  sending anything. Either add a Netlify Form (put `netlify` and `name="contact"` on
  the form tag and remove the preventDefault in `site.js`) or point it at your own
  endpoint.
- Search the folder for `EDIT:` for the three things only you can fill in: the legal
  entity name in the footer, the service fee figure, and the support hours.
- Update the date in `sitemap.xml` whenever you change the pages.
