# If you are not deploying to Netlify

`netlify.toml` in the folder above is read by Netlify and ignored by everything
else. It does three jobs, and this folder has each of them written out for the
other common hosts. Copy the one that matches your setup. Nothing here is picked
up on its own.

    apache.htaccess         rename to .htaccess in the site root
    nginx.conf              merge into the server block, then nginx -t and reload
    iis-web.config          rename to web.config in the site root
    vercel.json             put in the project root
    cloudflare-_headers     rename to _headers in the site root
    cloudflare-_redirects   rename to _redirects in the site root

## The three jobs

**1. Clean URLs, and this one is not optional.** Every link in the HTML points at
`/about-us`, not `/about-us.html`. If the server does not map an extensionless
path to the `.html` file on disk, every link in the site 404s. Netlify, Cloudflare
Pages, Vercel, GitHub Pages and S3 with CloudFront do this already. Apache, nginx
and IIS need the rule in this folder.

If your host cannot do it at all, say so and the build can be regenerated with
`.html` on every link instead. It is a one-line change to `deploy.py`, not a
rewrite. Do not hand-edit the HTML to add `.html`: there are over five hundred
internal links across fourteen pages and the build would overwrite your edits on
the next run.

**2. Security headers.** Five of them. Nothing breaks without them; a security
review will ask.

**3. 301s from the old `.html` paths.** So `/about-us.html` does not sit alongside
`/about-us` as a second indexable copy of the same page. Worth having, not urgent.

## The custom 404

`404.html` is in the folder above. Netlify and Cloudflare Pages use it without
being told. Apache, nginx and IIS need the directive, which is in each config here.
It must answer with a real 404 status, not a 200 with the error page's body, or
search engines will index every typo as a real page.

## Check it afterwards

    python3 tests/live_check.py https://www.visajourneyusa.com

That requests every URL this folder should serve, reports the status codes,
compares the live build marker with `BUILD.txt`, checks the security headers and
the `.html` redirects, and follows the links on each live page. It exits 0 only
when everything is right. It needs nothing but Python 3.
