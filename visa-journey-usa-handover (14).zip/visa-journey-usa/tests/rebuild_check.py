#!/usr/bin/env python3
"""Clean-room rebuild check.

Copies the package to a temp directory, deletes every generated file, runs the
three build scripts, and asserts that everything comes back.

This exists because it caught a real bug: an edit to build.py silently removed the
generator for the two legal pages, and nothing noticed, because stale copies of
those pages were still sitting in src/ and getting copied through to deploy/. The
site was correct only by accident. A developer running build.py on a fresh
checkout would have lost both pages.

Any test that runs against already-built output cannot catch that class of bug.
This one can.

    python3 rebuild_check.py [path-to-package-root]
"""

import os, shutil, subprocess, sys, tempfile

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1
                       else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

PAGES = [
    'index.html', 'about-us.html', 'contact-us.html', 'application.html',
    'payment.html', 'resume.html', 'terms-and-conditions.html', 'privacy-policy.html',
    'b1-b2-visitor-visa.html', 'ds-160-help.html', 'visa-interview-preparation.html',
    'us-visa-renewal.html', 'visiting-family-in-usa.html', 'business-visitor-visa.html',
]
DEPLOY_EXTRA = ['404.html', 'site.css', 'site.js', 'visa-application-form.js',
                'payment-step.js', 'hero.svg', 'favicon.svg', 'robots.txt',
                'sitemap.xml', 'netlify.toml', 'DEPLOY.md']

# The host configs for anyone not on Netlify. Clean URLs are load-bearing, so a
# build that quietly stopped producing these would leave a non-Netlify deploy with
# no instructions for the one rule the whole site depends on.
SERVER_CONFIG = ['README.md', 'apache.htaccess', 'nginx.conf', 'iis-web.config',
                 'vercel.json', 'cloudflare-_headers', 'cloudflare-_redirects']

passed = failed = 0
def ok(name, cond, detail=''):
    global passed, failed
    if cond:
        passed += 1
        print('  PASS  ' + name)
    else:
        failed += 1
        print('  FAIL  ' + name + (' -> ' + str(detail) if detail else ''))

tmp = tempfile.mkdtemp(prefix='vj-rebuild-')
work = os.path.join(tmp, 'pkg')
shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('node_modules', '__pycache__'))

# Delete everything the build is supposed to produce. If a generator has gone
# missing, the file simply will not come back.
for name in os.listdir(os.path.join(work, 'src')):
    if name.endswith('.html'):
        os.remove(os.path.join(work, 'src', name))
shutil.rmtree(os.path.join(work, 'deploy'), ignore_errors=True)
shutil.rmtree(os.path.join(work, 'preview'), ignore_errors=True)

print('\nCLEAN REBUILD')
src = os.path.join(work, 'src')
for script in ('build.py', 'deploy.py', 'bundle.py'):
    r = subprocess.run([sys.executable, script], cwd=src, capture_output=True, text=True)
    ok(script + ' runs without error', r.returncode == 0, (r.stderr or '').strip().splitlines()[-1:] or '')

print('\nSOURCE PAGES REGENERATED')
for page in PAGES:
    ok(page, os.path.exists(os.path.join(src, page)))

print('\nDEPLOY FOLDER REGENERATED')
dep = os.path.join(work, 'deploy')
for name in PAGES + DEPLOY_EXTRA:
    ok(name, os.path.exists(os.path.join(dep, name)))

print('\nSERVER CONFIGS REGENERATED')
cfg = os.path.join(dep, 'server-config')
for name in SERVER_CONFIG:
    ok('server-config/' + name, os.path.exists(os.path.join(cfg, name)))

# A config that does not parse is worse than no config: it takes the site down on
# reload rather than failing visibly at build time.
import json as _json, xml.etree.ElementTree as _ET
try:
    d = _json.load(open(os.path.join(cfg, 'vercel.json')))
    ok('vercel.json is valid JSON with cleanUrls on', d.get('cleanUrls') is True)
except Exception as e:
    ok('vercel.json is valid JSON with cleanUrls on', False, e)
try:
    r = _ET.parse(os.path.join(cfg, 'iis-web.config')).getroot()
    names = [x.get('name') for x in r.findall('.//rule')]
    ok('iis-web.config is valid XML', r.tag == 'configuration')
    ok('iis sends index.html to the root before stripping .html',
       names[:1] == ['index.html to root'], names)
except Exception as e:
    ok('iis-web.config is valid XML', False, e)

# /index.html must land on / and not on /index, or the homepage ends up at two
# URLs, which is the exact thing the redirect rules exist to prevent.
ht = open(os.path.join(cfg, 'apache.htaccess')).read()
ok('apache handles index.html before the general strip',
   ht.index('index\\.html') < ht.index('(.+?)\\.html'))
ng = open(os.path.join(cfg, 'nginx.conf')).read()
ok('nginx sends /index.html to the root',
   'location = /index.html' in ng and 'return 301 /;' in ng)
ok('nginx maps extensionless paths to .html', 'try_files $uri $uri.html' in ng)
ok('nginx keeps the error page out of the redirect rule',
   'location = /404.html' in ng)
rd = open(os.path.join(cfg, 'cloudflare-_redirects')).read()
ok('cloudflare _redirects covers every page',
   all(('/%s.html' % p) in rd for p in
       ['about-us', 'b1-b2-visitor-visa', 'us-visa-renewal', 'business-visitor-visa']))

print('\nPREVIEW REGENERATED')
prev = os.path.join(work, 'preview', 'visa-journey-usa.html')
ok('single file written', os.path.exists(prev))
if os.path.exists(prev):
    body = open(prev).read()
    ok('preview is a full build', len(body) > 200000, len(body))
    for route in ['route-home', 'route-about', 'route-contact', 'route-application',
                  'route-payment', 'route-resume', 'route-terms', 'route-privacy',
                  'route-b1b2', 'route-ds160', 'route-interview', 'route-renewal',
                  'route-family', 'route-business']:
        ok('preview contains ' + route, 'id="%s"' % route in body)

print('\nREBUILD MATCHES WHAT WAS SHIPPED')
for page in PAGES:
    a = os.path.join(src, page)
    b = os.path.join(ROOT, 'src', page)
    if os.path.exists(b):
        ok(page + ' identical to the shipped copy', open(a).read() == open(b).read())

shutil.rmtree(tmp, ignore_errors=True)

print('\n' + '=' * 60)
print('  %d passed, %d failed' % (passed, failed))
print('=' * 60)
sys.exit(1 if failed else 0)
