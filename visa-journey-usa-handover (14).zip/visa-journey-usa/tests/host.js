/* A fresh container for one mount of the form.

   The form gives its fields fixed ids, the way a real page needs. Mount it
   twice into the same document and those ids exist twice. That is fine in a
   browser, where host.querySelector('#stayLength') searches the host's own
   subtree. From jsdom 27 it is not: the lookup resolves through the document's
   id map and comes back null even though the element is sitting in the host.
   Tests then fail on code that works.

   So the harness keeps one mount live at a time, which is what a real page
   does anyway. Each call detaches the previous host before returning a new one.
   Any test that needs two mounts side by side should build its own container
   rather than use this. */

module.exports = function newHost(d) {
  var old = d.querySelectorAll("[data-test-host]");
  for (var i = 0; i < old.length; i++) old[i].remove();

  /* application.html and resume.html mount the form themselves on load. A test
     that mounts its own copy is replacing that one, not adding a second, so the
     page's mount point is emptied rather than left behind to duplicate every id.
     The element stays in the document so anything checking the page structure
     still finds it. */
  var page = d.getElementById("visa-application");
  if (page) page.textContent = "";

  var host = d.createElement("div");
  host.setAttribute("data-test-host", "");
  d.body.appendChild(host);
  return host;
};
