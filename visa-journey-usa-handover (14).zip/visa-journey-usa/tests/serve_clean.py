"""Serves the deploy folder the way Netlify does: /about-us -> about-us.html,
404.html for anything missing. Lets us test the real artefact, not an approximation.

A missing path answers with a real 404 status and the custom 404 body, so a
crawler can tell a broken link from a working one. Netlify behaves the same way:
the custom error page is served under the error status, not under 200."""
import http.server, os, sys
ROOT = sys.argv[1]


class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)

    def resolve(self, path):
        """(file to serve, status). Status is 404 when nothing matched."""
        p = path.split('?')[0].split('#')[0]
        if p.endswith('/') and p != '/':
            p = p[:-1]
        if p == '/':
            p = '/index.html'
        full = os.path.join(ROOT, p.lstrip('/'))
        if os.path.isfile(full):
            return full, 200
        if os.path.isfile(full + '.html'):
            return full + '.html', 200
        if os.path.isdir(full) and os.path.isfile(os.path.join(full, 'index.html')):
            return os.path.join(full, 'index.html'), 200
        return os.path.join(ROOT, '404.html'), 404

    def translate_path(self, path):
        return self.resolve(path)[0]

    def send_head(self):
        full, status = self.resolve(self.path)
        try:
            body = open(full, 'rb').read()
        except OSError:
            self.send_error(404)
            return None
        self.send_response(status)
        self.send_header('Content-Type', self.guess_type(full))
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        import io
        return io.BytesIO(body)

    def log_message(self, *a): pass


http.server.HTTPServer(('127.0.0.1', 8898), H).serve_forever()
