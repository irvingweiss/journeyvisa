#!/usr/bin/env python3
"""
live_check.py — point this at the deployed site and it tells you what is missing.

    python3 tests/live_check.py https://www.visajourneyusa.com

It does three things:

1. Requests every URL this build is meant to serve and reports the status code.
   A 404 here means that file did not reach the server, not that the build is
   wrong — the same URL will be fine locally.
2. Reads the build marker off the live homepage and compares it with BUILD.txt
   in the folder, so you can see at a glance whether the deploy actually went out.
3. Follows the nav and footer links on each live page, so a link pointing at a
   page that was never uploaded shows up as a broken link rather than as a
   surprise for a visitor.

Exit code is 0 only if every URL answers 200 and the build marker matches.

No dependencies. Runs on any machine with Python 3.
"""

import os
import re
import sys
import html as htmllib
import urllib.request
import urllib.error
from urllib.parse import urljoin, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(os.path.dirname(HERE), "deploy")

ATTR = re.compile(r'(?:href|src)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)
MARKER = re.compile(r'<meta\s+name="vj-build"\s+content="([^"]*)"', re.I)


def expected_urls():
    """Every path this build should answer, worked out from the folder itself."""
    urls = []
    for name in sorted(os.listdir(DEPLOY)):
        if not os.path.isfile(os.path.join(DEPLOY, name)):
            continue
        if name in ("netlify.toml", "DEPLOY.md", "BUILD.txt"):
            continue
        if name == "index.html":
            urls.append("/")
        elif name == "404.html":
            continue
        elif name.endswith(".html"):
            urls.append("/" + name[:-5])
        else:
            urls.append("/" + name)
    return urls


def local_build():
    path = os.path.join(DEPLOY, "BUILD.txt")
    if not os.path.exists(path):
        return None
    m = re.search(r"build\s+(\S+)", open(path, encoding="utf-8").read())
    return m.group(1) if m else None


SECURITY_HEADERS = [
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
    "Strict-Transport-Security",
]


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "vj-live-check"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            ctype = r.headers.get("Content-Type", "")
            body = r.read().decode("utf-8", "replace") if "html" in ctype else ""
            return r.status, body, dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, "", dict(e.headers or {})
    except Exception as e:
        return 0, str(e), {}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """So a 301 is reported as a 301 rather than silently followed."""
    def redirect_request(self, *a, **k):
        return None


def head_only(url):
    """Status and Location without following the redirect."""
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(url, headers={"User-Agent": "vj-live-check"})
    try:
        with opener.open(req, timeout=20) as r:
            return r.status, r.headers.get("Location")
    except urllib.error.HTTPError as e:
        return e.code, (e.headers or {}).get("Location")
    except Exception:
        return 0, None


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    base = sys.argv[1].rstrip("/")

    print("== live check: %s ==\n" % base)

    missing = []
    bodies = {}
    home_headers = {}

    print("  URLs this build should serve")
    for path in expected_urls():
        status, body, headers = get(base + path)
        flag = "ok " if status == 200 else "MISSING"
        print("    %-7s %-5s %s" % (flag, status or "---", path))
        if status != 200:
            missing.append((path, status))
        else:
            if path == "/":
                home_headers = headers
            if body:
                bodies[path] = body

    # ---------------------------------------------------------- build marker

    print("\n  Build marker")
    want = local_build()
    home = bodies.get("/", "")
    m = MARKER.search(home)
    live = m.group(1).split()[-1] if m else None
    stale = False
    if want is None:
        print("    no BUILD.txt in deploy/ to compare against")
    elif live is None:
        print("    live homepage carries no vj-build marker — it is not this build")
        stale = True
    elif live == want:
        print("    matches: %s" % live)
    else:
        print("    MISMATCH — live is %s, this folder is %s" % (live, want))
        print("    The deploy has not gone out, or only part of it has.")
        stale = True

    # ---------------------------------------------------- the custom 404 page

    print("\n  Error page")
    status, body, _ = get(base + "/no-such-page-" + "x" * 8)
    bad404 = False
    if status == 404:
        print("    unknown path answers 404")
    elif status == 200:
        print("    WRONG — an unknown path answers 200. Search engines will index")
        print("    every typo as a real page, and a broken link looks like a good one.")
        bad404 = True
    else:
        print("    unknown path answers %s, expected 404" % (status or "no response"))
        bad404 = True

    # ------------------------------------------------------ security headers

    print("\n  Security headers on the homepage")
    missing_headers = []
    if not home_headers:
        print("    could not read them, homepage did not answer")
    else:
        lower = {k.lower(): v for k, v in home_headers.items()}
        for h in SECURITY_HEADERS:
            if h.lower() in lower:
                print("    ok      %s" % h)
            else:
                print("    absent  %s" % h)
                missing_headers.append(h)
        if missing_headers:
            print("    These come from netlify.toml, which only Netlify reads. On any")
            print("    other host use the matching file in deploy/server-config/.")

    # -------------------------------------------- redirects from .html paths

    print("\n  Redirects from the old .html paths")
    bad_redirects = []
    samples = ["/index.html", "/about-us.html", "/b1-b2-visitor-visa.html"]
    for path in samples:
        status, loc = head_only(base + path)
        want = "/" if path == "/index.html" else path[:-5]
        if status == 301 and loc and urlparse(loc).path == want:
            print("    ok      %-28s 301 -> %s" % (path, want))
        elif status == 301:
            print("    WRONG   %-28s 301 -> %s, expected %s"
                  % (path, urlparse(loc or "").path or "?", want))
            bad_redirects.append(path)
        elif status == 200:
            print("    absent  %-28s serves 200, so the page sits at two URLs"
                  % path)
            bad_redirects.append(path)
        else:
            print("    absent  %-28s answers %s" % (path, status or "no response"))
            bad_redirects.append(path)

    # -------------------------------------------------------- link following

    print("\n  Links on the live pages")
    broken = {}
    for path, body in bodies.items():
        for mm in ATTR.finditer(body):
            raw = mm.group(1) if mm.group(1) is not None else mm.group(2)
            link = htmllib.unescape(raw).strip()
            if not link or link.startswith(("mailto:", "tel:", "data:",
                                            "javascript:", "#")):
                continue
            target = urljoin(base + path, link)
            if urlparse(target).netloc != urlparse(base).netloc:
                continue
            tp = urlparse(target).path or "/"
            status, _, _ = get(target)
            if status != 200:
                broken.setdefault((tp, status), set()).add(path)

    if not broken:
        print("    every internal link answers 200")
    else:
        for (tp, status), where in sorted(broken.items()):
            print("    BROKEN %-5s %-34s linked from %s"
                  % (status, tp, ", ".join(sorted(where))))

    # ------------------------------------------------------------- verdict

    print("\n" + "=" * 62)
    if missing:
        print("  BREAKS THE SITE: %d URL(s) are not on the server." % len(missing))
        print("  Upload the whole deploy/ folder, not a subset of it. Every file")
        print("  in that folder is linked from somewhere in the site.")
    if broken:
        print("  BREAKS THE SITE: %d link target(s) are dead for visitors."
              % len(broken))
    if stale:
        print("  The live build marker does not match this folder, so what is")
        print("  deployed is not what is in deploy/.")
    if bad404:
        print("  The error page is not answering 404.")
    if missing_headers:
        print("  %d security header(s) absent. Nothing breaks; a review will ask."
              % len(missing_headers))
    if bad_redirects:
        print("  %d .html path(s) are not redirecting. Each one is a second URL"
              % len(bad_redirects))
        print("  serving the same page, which splits it in search results.")
    if not (missing or stale or broken or bad404 or missing_headers or bad_redirects):
        print("  OK — the live site matches this build and every link works.")
    print("=" * 62)

    serious = missing or stale or broken or bad404 or missing_headers or bad_redirects
    return 1 if serious else 0


if __name__ == "__main__":
    sys.exit(main())
