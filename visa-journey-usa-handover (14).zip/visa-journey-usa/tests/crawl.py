#!/usr/bin/env python3
"""
crawl.py — a real crawler over the deploy folder, served the way Netlify serves it.

link_check.py reasons about paths. This one actually requests every URL and
records the status code, following links out from `/` until it runs out of new
ones, so a mistake in the clean-URL mapping shows up as a 404 rather than
passing a path check.

    python3 tests/serve_clean.py ../deploy &
    python3 tests/crawl.py

Exits non-zero if any internal URL answers anything other than 200, or if a
page in the folder was never reachable from the homepage.
"""

import os
import re
import sys
import html as htmllib
import urllib.request
import urllib.error
from urllib.parse import urljoin, urlparse

BASE = "http://127.0.0.1:8898"
HERE = os.path.dirname(os.path.abspath(__file__))
DEPLOY = os.path.join(os.path.dirname(HERE), "deploy")

ATTR = re.compile(r'(?:href|src)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)

# Reached with a reference number rather than from a link; crawled explicitly.
SEEDS = ["/", "/payment", "/resume", "/404"]


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "vj-crawl"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read().decode("utf-8", "replace"), \
                r.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        return e.code, "", ""
    except Exception as e:
        return 0, str(e), ""


def main():
    seen = {}
    queue = list(SEEDS)
    found_on = {}
    broken = []

    while queue:
        path = queue.pop(0)
        if path in seen:
            continue
        url = BASE + path
        status, body, ctype = get(url)
        seen[path] = status

        if status != 200:
            broken.append((path, status, found_on.get(path, "(seed)")))
            continue

        if "html" not in ctype:
            continue

        for m in ATTR.finditer(body):
            raw = m.group(1) if m.group(1) is not None else m.group(2)
            link = htmllib.unescape(raw).strip()
            if not link or link.startswith(("http://", "https://", "mailto:",
                                            "tel:", "data:", "javascript:", "#")):
                continue
            target = urljoin(url, link)
            if urlparse(target).netloc != urlparse(BASE).netloc:
                continue
            p = urlparse(target).path or "/"
            if p not in seen and p not in queue:
                found_on[p] = path
                queue.append(p)

    pages = sorted(f[:-5] for f in os.listdir(DEPLOY) if f.endswith(".html"))
    reachable = set()
    for p in seen:
        reachable.add("index" if p == "/" else p.lstrip("/").rstrip("/") or "index")

    orphans = [p for p in pages if p not in reachable]

    print("== crawl ==")
    print("   %d URLs requested from %s" % (len(seen), BASE))
    print("   %d answered 200" % sum(1 for s in seen.values() if s == 200))

    bad = False
    if broken:
        bad = True
        print("\n   %d BROKEN:" % len(broken))
        for path, status, where in broken:
            print("     %-40s %-5s linked from %s" % (path, status, where))

    if orphans:
        bad = True
        print("\n   %d page(s) in the folder that nothing links to:" % len(orphans))
        for p in orphans:
            print("     %s" % p)

    if not bad:
        print("   OK — every page reachable, every URL 200")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
