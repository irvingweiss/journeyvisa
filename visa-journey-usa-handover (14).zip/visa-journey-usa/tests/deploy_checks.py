import os, re, sys, urllib.request, urllib.error, tomllib
ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'deploy')
BASE = 'http://127.0.0.1:8898'
p = f = 0
def ok(name, cond, detail=''):
    global p, f
    if cond: p += 1; print('  PASS  ' + name)
    else: f += 1; print('  FAIL  ' + name + (' -> ' + str(detail) if detail else ''))

pages = sorted(x for x in os.listdir(ROOT) if x.endswith('.html'))
print('\nDEPLOY BUILD — files')
for want in ['index.html','about-us.html','contact-us.html','application.html','payment.html',
             'resume.html','terms-and-conditions.html','privacy-policy.html','404.html',
             'b1-b2-visitor-visa.html','ds-160-help.html','visa-interview-preparation.html',
             'us-visa-renewal.html','visiting-family-in-usa.html','business-visitor-visa.html',
             'site.css','site.js','visa-application-form.js','payment-step.js','hero.svg',
             'robots.txt','sitemap.xml','netlify.toml','favicon.svg']:
    ok('%s present' % want, os.path.exists(os.path.join(ROOT, want)))

print('\nDEPLOY BUILD — links and metadata')
clean = {'/','/about-us','/contact-us','/application','/payment','/resume',
         '/terms-and-conditions','/privacy-policy','/b1-b2-visitor-visa','/ds-160-help',
         '/visa-interview-preparation','/us-visa-renewal','/visiting-family-in-usa',
         '/business-visitor-visa'}
assets = {'/site.css','/site.js','/hero.svg','/favicon.svg',
          '/visa-application-form.js','/payment-step.js'}
bad = []
for page in pages:
    s = open(os.path.join(ROOT, page)).read()
    for href in re.findall(r'href="(/[^"#]*)', s):
        h = href.split('?')[0]
        if h not in clean and h not in assets: bad.append(page + ' -> ' + href)
    for src in re.findall(r'src="(/[^"]*)"', s):
        if src.split('?')[0] not in assets: bad.append(page + ' -> ' + src)
ok('every internal link and asset path is known', not bad, bad[:3])
ok('no relative .html left in markup or scripts',
   not re.findall(r'"[a-z-]+\.html', ' '.join(open(os.path.join(ROOT, x)).read() for x in pages)))
ok('no remote asset host referenced',
   not any('visajourneyusa.com/assets' in open(os.path.join(ROOT, x)).read() for x in pages))

for page in pages:
    s = open(os.path.join(ROOT, page)).read()
    robots = re.search(r'name="robots" content="([^"]+)"', s)
    expected = 'noindex,follow' if page in ('payment.html','resume.html','404.html') else 'index,follow'
    ok('%s robots is %s' % (page, expected), robots and robots.group(1) == expected,
       robots.group(1) if robots else 'missing')

sm = open(os.path.join(ROOT, 'sitemap.xml')).read()
ok('sitemap has 12 public urls', sm.count('<loc>') == 12, sm.count('<loc>'))
ok('sitemap excludes /payment and /resume', '/payment<' not in sm and '/resume<' not in sm)
ok('robots.txt points at the sitemap', 'sitemap.xml' in open(os.path.join(ROOT,'robots.txt')).read().lower())
t = tomllib.load(open(os.path.join(ROOT,'netlify.toml'),'rb'))
ok('netlify.toml parses', True)
ok('netlify.toml has security headers', any('X-Frame-Options' in str(h) for h in t['headers']))
ok('netlify.toml redirects every old .html path', len(t['redirects']) == 14, len(t['redirects']))

print('\nDEPLOY BUILD — cache busting')
import hashlib
def _h(p): return hashlib.sha1(open(os.path.join(ROOT, p), 'rb').read()).hexdigest()[:10]
unversioned, stale = [], []
for page in pages:
    s = open(os.path.join(ROOT, page)).read()
    for asset in ['site.css', 'site.js', 'visa-application-form.js', 'payment-step.js', 'hero.svg']:
        for ref in re.findall(r'(?:src|href)="/%s(\?v=[0-9a-f]+)?"' % re.escape(asset), s):
            if not ref: unversioned.append(page + ' -> ' + asset)
            elif ref[3:] != _h(asset): stale.append(page + ' -> ' + asset)
ok('every asset reference carries a version', not unversioned, unversioned[:3])
ok('every version matches the file actually shipped', not stale, stale[:3])
stamps = set()
for page in pages:
    m = re.search(r'<meta name="vj-build" content="[^ ]+ ([0-9a-f]+)">', open(os.path.join(ROOT, page)).read())
    stamps.add(m.group(1) if m else None)
ok('every page carries a build marker', None not in stamps, stamps)
ok('all pages carry the same build id', len(stamps) == 1, stamps)
bt = open(os.path.join(ROOT, 'BUILD.txt')).read() if os.path.exists(os.path.join(ROOT, 'BUILD.txt')) else ''
ok('BUILD.txt matches the pages', bool(stamps) and list(stamps)[0] in bt)

print('\nDEPLOY BUILD — served responses')
for path in sorted(clean) + sorted(assets):
    try:
        r = urllib.request.urlopen(BASE + path, timeout=5)
        ok('GET %s -> %d' % (path, r.status), r.status == 200 and len(r.read()) > 100)
    except Exception as e:
        ok('GET %s' % path, False, e)
# An unknown path must answer with the custom page AND a 404 status. Serving it
# under 200 would let search engines index every typo as a real page, and would
# hide a broken link from any crawler.
try:
    urllib.request.urlopen(BASE + '/no-such-page', timeout=5)
    ok('unknown path answers 404, not 200', False, 'got 200')
except urllib.error.HTTPError as e:
    body = e.read().decode()
    ok('unknown path answers 404, not 200', e.code == 404, 'got %d' % e.code)
    ok('unknown path serves the custom 404 page', 'That page is not here' in body)
except Exception as e:
    ok('unknown path answers 404, not 200', False, e)

print('\n' + '='*60)
print('  %d passed, %d failed' % (p, f))
print('='*60)
sys.exit(1 if f else 0)
