#!/usr/bin/env python3
"""
link_check.py — every link in a build, resolved.

Run against any build:

    python3 tests/link_check.py deploy      # clean URLs, as Netlify serves them
    python3 tests/link_check.py src         # relative .html links, opened from disk
    python3 tests/link_check.py preview     # hash routes in the single file

For `deploy` it reads netlify.toml, works out which clean URLs Netlify will
actually serve (a file at ./about-us.html is served at /about-us), and then
checks every href, src and in-page anchor against that set. For `src` it
resolves each link as a path on disk. For `preview` it checks every hash link
against the router's own ROUTES list and the ids in the file.

It also reads navigation out of inline <script> blocks, which is where the
pages hand the form its paymentUrl and where /resume redirects happen. Those
are links a crawl of href attributes alone would never see.

Exits non-zero if anything is unreachable, and prints every bad link.
"""

import os
import re
import sys
import html as htmllib

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

ATTR = re.compile(
    r'(?:href|src)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)
ID = re.compile(r'\sid\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)
NAME_ANCHOR = re.compile(r'<a\s[^>]*name\s*=\s*(?:"([^"]*)"|\'([^\']*)\')', re.I)

SKIP_SCHEMES = ("http://", "https://", "mailto:", "tel:", "data:",
                "javascript:", "#")


def values(pattern, text):
    for m in pattern.finditer(text):
        yield htmllib.unescape(m.group(1) if m.group(1) is not None else m.group(2))


def pages(folder):
    return sorted(f for f in os.listdir(folder) if f.endswith(".html"))


def anchors_in(text):
    """Every fragment target a page offers."""
    found = set(values(ID, text))
    found |= set(values(NAME_ANCHOR, text))
    return found


# --------------------------------------------------------------- deploy ----

def netlify_redirects(folder):
    toml = os.path.join(folder, "netlify.toml")
    if not os.path.exists(toml):
        return {}
    text = open(toml, encoding="utf-8").read()
    out = {}
    for block in text.split("[[redirects]]")[1:]:
        f = re.search(r'from\s*=\s*"([^"]+)"', block)
        t = re.search(r'to\s*=\s*"([^"]+)"', block)
        if f and t:
            out[f.group(1)] = t.group(1)
    return out


def served_deploy(folder):
    """
    The set of URL paths Netlify will serve from this folder, and the file
    behind each one. Netlify's Pretty URLs serve foo.html at /foo (and keep
    /foo.html working, which our redirects turn into a 301 to /foo).
    """
    served = {}
    for name in sorted(os.listdir(folder)):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        if name == "index.html":
            served["/"] = name
            served["/index.html"] = name
        elif name.endswith(".html"):
            stem = name[:-5]
            served["/" + stem] = name
            served["/" + stem + "/"] = name
            served["/" + name] = name
        else:
            served["/" + name] = name
    return served


def check_deploy(folder):
    served = served_deploy(folder)
    redirects = netlify_redirects(folder)
    anchors = {}
    for name in pages(folder):
        anchors[name] = anchors_in(open(os.path.join(folder, name),
                                        encoding="utf-8").read())

    problems = []
    checked = 0

    for name in pages(folder):
        text = open(os.path.join(folder, name), encoding="utf-8").read()
        for raw in values(ATTR, text):
            link = raw.strip()
            if not link:
                problems.append((name, raw, "empty href/src"))
                continue
            if link.startswith(("http://", "https://", "mailto:", "tel:",
                                "data:", "javascript:")):
                continue

            checked += 1

            if link.startswith("#"):
                frag = link[1:]
                if frag and frag not in anchors[name]:
                    problems.append((name, link, "no such anchor on this page"))
                continue

            path, _, frag = link.partition("#")
            path = path.split("?")[0]

            if not path.startswith("/"):
                # relative link in the deploy build: under clean URLs a
                # relative "about-us.html" from /b1-b2-visitor-visa resolves
                # to /about-us.html, which 301s — but any relative link
                # without .html, or from a trailing-slash URL, breaks.
                problems.append(
                    (name, link,
                     "relative link in the clean-URL build — must start with /"))
                continue

            target = served.get(path)
            if target is None:
                if path in redirects:
                    dest = redirects[path]
                    if dest in served:
                        continue
                    problems.append((name, link,
                                     "redirects to %s, which is not served" % dest))
                    continue
                problems.append((name, link, "404 — nothing serves %s" % path))
                continue

            if frag and target.endswith(".html"):
                if frag not in anchors.get(target, set()):
                    problems.append((name, link,
                                     "page exists, but #%s is not on it" % frag))

    return checked, problems, served, redirects


# ------------------------------------------------------------------ src ----

def check_src(folder):
    anchors = {}
    for name in pages(folder):
        anchors[name] = anchors_in(open(os.path.join(folder, name),
                                        encoding="utf-8").read())

    problems = []
    checked = 0

    for name in pages(folder):
        text = open(os.path.join(folder, name), encoding="utf-8").read()
        for raw in values(ATTR, text):
            link = raw.strip()
            if not link:
                problems.append((name, raw, "empty href/src"))
                continue
            if link.startswith(("http://", "https://", "mailto:", "tel:",
                                "data:", "javascript:")):
                continue

            checked += 1

            if link.startswith("#"):
                frag = link[1:]
                if frag and frag not in anchors[name]:
                    problems.append((name, link, "no such anchor on this page"))
                continue

            path, _, frag = link.partition("#")
            path = path.split("?")[0]

            if path.startswith("/"):
                problems.append(
                    (name, link,
                     "absolute link in the relative build — breaks on file://"))
                continue

            target = os.path.join(folder, path)
            if not os.path.exists(target):
                problems.append((name, link, "404 — no file %s" % path))
                continue

            if frag and path.endswith(".html"):
                if frag not in anchors.get(os.path.basename(path), set()):
                    problems.append((name, link,
                                     "file exists, but #%s is not in it" % frag))

    return checked, problems


# ------------------------------------------------------------- js links ----

JS_URL = re.compile(
    r'(?:location\.(?:href|replace|assign)\s*(?:=|\()\s*'
    r'|(?:paymentUrl|resumeUrl|applicationUrl|homeUrl)\s*:\s*)'
    r'["\']([^"\']+)["\']')

SCRIPT = re.compile(r"<script\b[^>]*>(.*?)</script>", re.I | re.S)


def js_sources(folder):
    """
    Every piece of script in the build, whether it sits in a .js file or in an
    inline block. The inline blocks are the ones that matter most here: that is
    where each page passes the form its paymentUrl and where /resume sends
    people after a successful lookup.
    """
    for name in sorted(os.listdir(folder)):
        path = os.path.join(folder, name)
        if not os.path.isfile(path):
            continue
        if name.endswith(".js"):
            yield name, open(path, encoding="utf-8").read()
        elif name.endswith(".html"):
            text = open(path, encoding="utf-8").read()
            for block in SCRIPT.findall(text):
                if block.strip():
                    yield name + " (inline script)", block


def check_js(folder, served):
    """Navigation the scripts perform, which no HTML crawl would see."""
    problems = []
    checked = 0
    for where, text in js_sources(folder):
        for m in JS_URL.finditer(text):
            url = m.group(1)
            if url.startswith(("http://", "https://", "mailto:")):
                continue
            checked += 1
            path = url.split("?")[0].split("#")[0]
            if not path:
                continue
            if served is None:
                if not os.path.exists(os.path.join(folder, path)):
                    problems.append((where, url, "no file %s" % path))
            else:
                if not path.startswith("/"):
                    problems.append((where, url,
                                     "relative navigation in the clean-URL build"))
                elif path not in served:
                    problems.append((where, url, "404 — nothing serves %s" % path))
    return checked, problems


# ------------------------------------------------------------- sitemap ----

# Deliberately not in the sitemap. /payment and /resume are reached with a
# reference number and have nothing for a search engine to index; /404 is the
# error page itself.
UNLISTED = {"/payment", "/resume", "/404"}


def check_sitemap(folder, served):
    path = os.path.join(folder, "sitemap.xml")
    if not os.path.exists(path):
        return 0, []
    text = open(path, encoding="utf-8").read()
    problems = []
    locs = re.findall(r"<loc>([^<]+)</loc>", text)
    for loc in locs:
        url = re.sub(r"^https?://[^/]+", "", loc) or "/"
        if url not in served:
            problems.append(("sitemap.xml", loc, "404 — nothing serves %s" % url))
    # the reverse: a real page missing from the sitemap
    listed = {re.sub(r"^https?://[^/]+", "", l) or "/" for l in locs}
    for url, target in sorted(served.items()):
        if not target.endswith(".html"):
            continue
        if url.endswith("/") and url != "/":
            continue
        if url.endswith(".html"):
            continue
        if url in UNLISTED:
            continue
        if url not in listed:
            problems.append(("sitemap.xml", url, "real page missing from sitemap"))
    return len(locs), problems


# ----------------------------------------------------------- preview ----

def check_preview(folder):
    """
    The single file routes on the hash. A link is good if it names a route the
    router knows, or a route plus an in-page anchor that exists.
    """
    path = os.path.join(folder, "visa-journey-usa.html")
    if not os.path.exists(path):
        candidates = [f for f in os.listdir(folder) if f.endswith(".html")]
        if not candidates:
            return 0, [("preview", "", "no html file in preview/")]
        path = os.path.join(folder, candidates[0])

    text = open(path, encoding="utf-8").read()

    m = re.search(r"var ROUTES\s*=\s*\[(.*?)\]", text, re.S)
    if not m:
        return 0, [(os.path.basename(path), "", "router ROUTES list not found")]
    routes = set(re.findall(r'"([^"]+)"', m.group(1)))

    ids = anchors_in(text)
    problems = []
    checked = 0

    for raw in values(ATTR, text):
        link = raw.strip()
        if not link or link.startswith(("http://", "https://", "mailto:",
                                        "tel:", "data:", "javascript:")):
            continue
        checked += 1

        if not link.startswith("#"):
            problems.append((os.path.basename(path), link,
                             "the single file has no sibling files to link to"))
            continue

        frag = link[1:].split("?")[0]
        if not frag:
            continue
        if frag in routes:
            continue
        # a route plus an anchor, e.g. #home-faq
        hit = [r for r in routes if frag.startswith(r + "-")]
        if hit and frag in ids:
            continue
        if hit:
            problems.append((os.path.basename(path), link,
                             "route %s exists, but no element has id=%s"
                             % (hit[0], frag)))
            continue
        if frag in ids:
            continue
        problems.append((os.path.basename(path), link,
                         "not a route and not an id — goes nowhere"))

    # the reverse: a route with no section to show
    for r in sorted(routes):
        if ("route-" + r) not in ids:
            problems.append((os.path.basename(path), "#" + r,
                             "router knows this route but no #route-%s section exists" % r))

    return checked, problems


# ------------------------------------------------------------------ run ----

def main():
    which = sys.argv[1] if len(sys.argv) > 1 else "deploy"
    folder = os.path.join(ROOT, which)
    if not os.path.isdir(folder):
        print("no such build: %s" % folder)
        return 2

    print("== %s ==" % which)
    all_problems = []

    if which == "deploy":
        checked, problems, served, redirects = check_deploy(folder)
        all_problems += problems
        print("   %d internal links in %d pages" % (checked, len(pages(folder))))
        print("   %d URLs served, %d redirects" % (len(served), len(redirects)))

        jc, jp = check_js(folder, served)
        all_problems += jp
        print("   %d script-driven navigations" % jc)

        sc, sp = check_sitemap(folder, served)
        all_problems += sp
        print("   %d sitemap URLs" % sc)
    elif which == "preview":
        checked, problems = check_preview(folder)
        all_problems += problems
        print("   %d links in the single file" % checked)
    else:
        checked, problems = check_src(folder)
        all_problems += problems
        print("   %d internal links in %d pages" % (checked, len(pages(folder))))
        jc, jp = check_js(folder, None)
        all_problems += jp
        print("   %d script-driven navigations" % jc)

    if not all_problems:
        print("   OK — every link resolves")
        return 0

    print("\n   %d BROKEN:" % len(all_problems))
    for where, link, why in all_problems:
        print("     %-32s %-44s %s" % (where, link, why))
    return 1


if __name__ == "__main__":
    sys.exit(main())
