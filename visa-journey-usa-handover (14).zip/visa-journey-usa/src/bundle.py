#!/usr/bin/env python3
"""Fold the six built pages into a single self-contained HTML file.

Why: a multi-file site needs a server or a folder to work. One file with the CSS,
the JS and every page inlined opens anywhere, including straight out of a download,
and clicking around it works. That is what you present from.

Run after build.py.
"""

import re, os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = HERE
OUT = os.path.join(HERE, "..", "preview", "visa-journey-usa.html")

# The output folder may not exist on a fresh checkout, and writing into a missing
# directory should not fail a build.
_outdir = os.path.dirname(OUT)
if _outdir:
    os.makedirs(_outdir, exist_ok=True)
ROUTES = [
    ("index.html", "home"),
    ("about-us.html", "about"),
    ("contact-us.html", "contact"),
    ("application.html", "application"),
    ("terms-and-conditions.html", "terms"),
    ("privacy-policy.html", "privacy"),
    ("payment.html", "payment"),
    ("resume.html", "resume"),
    ("b1-b2-visitor-visa.html", "b1b2"),
    ("ds-160-help.html", "ds160"),
    ("visa-interview-preparation.html", "interview"),
    ("us-visa-renewal.html", "renewal"),
    ("visiting-family-in-usa.html", "family"),
    ("business-visitor-visa.html", "business"),
]

HOME_ANCHORS = ["what-we-do", "how-it-works", "faq"]


def main_of(path):
    s = open(os.path.join(SRC, path)).read()
    m = re.search(r'<main id="main">(.*?)</main>', s, re.S)
    return m.group(1)


def inline_hero(html):
    return html.replace('src="hero.svg"', 'src="' + HERO_DATA_URI + '"')


def rewrite_links(html):
    # in-page anchors on the homepage first, so they are not eaten by the page rule
    for a in HOME_ANCHORS:
        html = html.replace('href="index.html#%s"' % a, 'href="#home-%s"' % a)
        html = html.replace('href="#%s"' % a, 'href="#home-%s"' % a)
    for page, route in ROUTES:
        html = html.replace('href="%s"' % page, 'href="#%s"' % route)
    return html


def rewrite_home_ids(html):
    for a in HOME_ANCHORS:
        html = html.replace('id="%s"' % a, 'id="home-%s"' % a)
    return html


css = open(os.path.join(SRC, "site.css")).read()

# The hero illustration goes in as a data URI so the single file stays a single
# file. Base64 rather than inline SVG markup, which would let the illustration's
# internal ids collide with anything else on the page.
import base64
HERO_DATA_URI = "data:image/svg+xml;base64," + base64.b64encode(
    open(os.path.join(SRC, "hero.svg"), "rb").read()).decode("ascii")
site_js = open(os.path.join(SRC, "site.js")).read()

bodies = {}
for page, route in ROUTES:
    body = main_of(page)
    if route == "home":
        body = rewrite_home_ids(body)
    bodies[route] = inline_hero(rewrite_links(body))

# The three widget routes get plain containers here. Their <script src> tags make
# no sense in a single file, so the modules are inlined once at the end instead
# and mounted lazily when the route is first opened.

bodies["application"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Your application</h1>
      <p class="lede">Short sections, saved as you go. You get a reference number on the first screen, and that is how you come back to it later.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="visa-application"></div></div>
  </section>
"""

bodies["payment"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Payment</h1>
      <p class="lede">Your preparation fee. The government fee is separate and is paid directly to the government when you book your interview.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="payment"></div></div>
  </section>
"""

bodies["resume"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Return to your application</h1>
      <p class="lede">Enter your reference number and answer your security question to pick up where you left off.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="resume"></div></div>
  </section>
"""

MARK = """<svg class="mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
  <rect x="1" y="1" width="30" height="30" rx="9" fill="#0f766e"/>
  <circle cx="16" cy="16" r="8.5" fill="none" stroke="#ffffff" stroke-width="1.4" stroke-dasharray="2.2 2.2"/>
  <path d="M11.5 16.6l3 3 6-6.6" fill="none" stroke="#ffffff" stroke-width="1.9"
        stroke-linecap="round" stroke-linejoin="round"/>
</svg>"""

NAV = [("#home", "Home"), ("#b1b2", "B1/B2 visa"), ("#ds160", "DS-160 help"),
       ("#interview", "Interview prep"), ("#about", "About"), ("#contact", "Contact")]

nav_links = "".join('<a href="%s" data-nav="%s">%s</a>' % (h, h[1:], t) for h, t in NAV)
mobile_links = "".join('<a href="%s" data-nav="%s">%s</a>' % (h, h[1:], t) for h, t in NAV)

routes_html = "\n".join(
    '<section class="route" id="route-%s"%s>%s</section>' % (r, "" if r == "home" else " hidden", bodies[r])
    for _, r in ROUTES
)

EXTRA_CSS = """
/* ------------------------------------------------- single-file extras */

.route[hidden] { display: none; }

"""

ROUTER_JS = """
/* ------------------------------------------------------------------ router
   Six pages in one file. Hash decides which is visible. Anchors inside the
   homepage still work: #home-faq shows the homepage, then scrolls. */

(function () {
  var ROUTES = ["home", "about", "contact", "application", "payment", "resume", "terms",
                "privacy", "b1b2", "ds160", "interview", "renewal", "family", "business"];

  function resolve() {
    /* The form appends ?ref=... to whatever paymentUrl it is given, so strip a
       query string before matching. */
    var hash = (location.hash || "").replace(/^#/, "").split("?")[0];
    var route = "home", anchor = null;
    for (var i = 0; i < ROUTES.length; i++) {
      var r = ROUTES[i];
      if (hash === r) { route = r; break; }
      if (hash.indexOf(r + "-") === 0) { route = r; anchor = hash; break; }
    }
    return { route: route, anchor: anchor };
  }

  function show() {
    var target = resolve();

    ROUTES.forEach(function (r) {
      var el = document.getElementById("route-" + r);
      if (el) el.hidden = (r !== target.route);
    });

    document.querySelectorAll("[data-nav]").forEach(function (a) {
      if (a.getAttribute("data-nav") === target.route) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });

    var nav = document.getElementById("mobile-nav");
    var toggle = document.getElementById("menu-toggle");
    if (nav) nav.classList.remove("is-open");
    if (toggle) toggle.setAttribute("aria-expanded", "false");

    if (typeof window.__mountRoute === "function") window.__mountRoute(target.route);

    if (target.anchor) {
      var el = document.getElementById(target.anchor);
      if (el) { el.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    }
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  window.addEventListener("hashchange", show);
  show();
})();
"""

FORM_JS = open(os.path.join(SRC, "visa-application-form.js")).read()
PAYMENT_JS = open(os.path.join(SRC, "payment-step.js")).read()

WIDGET_JS = r"""
/* ----------------------------------------------------------- widgets
   The real application form and payment step, mounted the first time
   their route is opened. Everything here runs in demo mode: nothing is
   saved anywhere and no payment is taken. */

(function () {
  var mounted = {};
  var lastRef = "";

  function ref() {
    return "DEMO" + Math.random().toString(36).slice(2, 8).toUpperCase();
  }

  function previewNotSent() {
    var e = new Error("preview: no email sent");
    e.userMessage = "This is a preview, so no email was actually sent.";
    return e;
  }

  window.__mountRoute = function (route) {
    if (mounted[route]) return;

    if (route === "application" && window.VisaJourneyForm) {
      var app = VisaJourneyForm.mount(document.getElementById("visa-application"), {
        draftCache: "session",
        onCreateApplication: function () { return Promise.resolve({ applicationId: ref() }); },
        onSaveStep: function () { return Promise.resolve(); },
        /* The preview sends no mail, so it says so rather than showing a
           confirmation for an email that never left. */
        onRequestResumeLink: function () { return Promise.reject(previewNotSent()); },
        onEmailReference: function () { return Promise.reject(previewNotSent()); },
        paymentUrl: "#payment",
        onSubmit: function () {
          lastRef = app.getApplicationId ? app.getApplicationId() : "";
          return Promise.resolve();
        }
      });
      mounted.application = true;
    }

    if (route === "payment" && window.VisaJourneyPayment) {
      var pay = document.getElementById("payment");
      VisaJourneyPayment.mount(pay, {
        applicationId: lastRef,
        serviceFee: 185,
        governmentFee: 185,
        hostedRedirect: true,
        onBack: function () { window.location.hash = "#application"; },
        onPay: function () {
          pay.innerHTML =
            '<div class="app-fallback" style="text-align:center">' +
            "<h2>This is a preview</h2>" +
            '<p class="p" style="margin-left:auto;margin-right:auto">No payment was taken and no card ' +
            "details were collected.</p>" +
            '<p style="margin-top:1.5rem"><a class="btn btn-quiet" href="#home">Back to the homepage</a></p>' +
            "</div>";
          window.scrollTo({ top: 0, behavior: "smooth" });
          return Promise.resolve();
        }
      });
      mounted.payment = true;
    }

    if (route === "resume" && window.VisaJourneyForm) {
      VisaJourneyForm.mountResume(document.getElementById("resume"), {
        onLookup: function () { return Promise.resolve({ securityPrompt: "What was the name of your first pet?" }); },
        /* Returns the saved answers, which is what makes resuming actually
           resume. The widget reopens the form in place with them. */
        onResume: function (payload) {
          return Promise.resolve({
            applicationId: payload.applicationId,
            stepIndex: 2,
            data: {
              surnames: "OKAFOR", givenNames: "ADA", sex: "Female",
              maritalStatus: "Married", nationality: "NIGERIA"
            }
          });
        },
        paymentUrl: "#payment",
        onSaveStep: function () { return Promise.resolve(); },
        onSubmit: function () { return Promise.resolve(); }
      });
      mounted.resume = true;
    }
  };
})();
"""

html = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Visa Journey USA | B1/B2 visitor visa preparation and review</title>
<meta name="description" content="A private preparation and review service for U.S. B1/B2 visitor visa applications. Guided questions through the whole B1/B2 form, and a real review before you file.">
<meta name="robots" content="index,follow">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet">

<style>
__CSS__
</style>
</head>

<body class="vj-site">

<div class="notice-bar">
  <div class="wrap">
    <p><strong>Visa Journey USA is a private preparation service.</strong> We are not affiliated with, endorsed by, or connected to the U.S. Department of State or any government agency. You can apply directly at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a> and pay only the government fee. Our fee is separate, and is charged for preparing and reviewing your application. We do not influence, expedite, or guarantee any visa decision.</p>
  </div>
</div>

<header class="site-header">
  <div class="header-in wrap">
    <a class="brand" href="#home">__MARK__<span class="brand-name">Visa Journey <em>USA</em></span></a>
    <nav class="nav" aria-label="Main">
      __NAV__
      <a class="btn btn-primary btn-sm" href="#application">Start your application</a>
    </nav>
    <button class="menu-btn" type="button" id="menu-toggle" aria-expanded="false" aria-controls="mobile-nav">
      <span class="menu-bars" aria-hidden="true"></span>
      <span class="sr-only">Menu</span>
    </button>
  </div>
  <nav class="mobile-nav" id="mobile-nav" aria-label="Main, mobile">
    __MOBILE__
    <a href="#terms">Terms and conditions</a>
    <a href="#privacy">Privacy policy</a>
    <a class="btn btn-primary" href="#application">Start your application</a>
  </nav>
</header>

<main id="main">
__ROUTES__
</main>

<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="brand brand-light" href="#home">__MARK__<span class="brand-name">Visa Journey <em>USA</em></span></a>
        <p class="footer-blurb">A private preparation and review service for U.S. B1/B2 visitor visa applications.</p>
      </div>

      <div>
        <h2>Visa help</h2>
        <ul>
          <li><a href="#b1b2">B1/B2 visitor visa</a></li>
          <li><a href="#ds160">DS-160 help</a></li>
          <li><a href="#interview">Interview preparation</a></li>
          <li><a href="#renewal">Visa renewal</a></li>
          <li><a href="#family">Visiting family in the USA</a></li>
          <li><a href="#business">Business visitor visa</a></li>
        </ul>
      </div>

      <div>
        <h2>Service</h2>
        <ul>
          <li><a href="#application">Start your application</a></li>
          <li><a href="#home-how-it-works">How it works</a></li>
          <li><a href="#home-faq">Common questions</a></li>
          <li><a href="#resume">Return to an application</a></li>
        </ul>
      </div>

      <div>
        <h2>Company</h2>
        <ul>
          <li><a href="#about">About us</a></li>
          <li><a href="#contact">Contact us</a></li>
          <li><a href="#terms">Terms and conditions</a></li>
          <li><a href="#privacy">Privacy policy</a></li>
        </ul>
      </div>

      <div>
        <h2>Get in touch</h2>
        <!-- EDIT: add the registered legal entity name and state of registration
             on the line below, plus a phone number if you have one. -->
        <address>
          Visa Journey USA<br>
          1175 West Broadway, Suite 33<br>
          Hewlett, NY 11557<br>
          <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a>
        </address>
      </div>
    </div>

    <div class="footer-legal">
      <p>Visa Journey USA is a private preparation and review service. We are not a law firm, we do not provide legal advice, and we are not affiliated with, endorsed by, or connected to the U.S. Department of State, U.S. Citizenship and Immigration Services, or any other government agency.</p>
      <p>You can complete and submit a visa application yourself at no cost beyond the government fee at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a>. Our fee is charged for preparation and review and is separate from any government fee. We do not influence, expedite, or guarantee the outcome of any visa application.</p>
      <p class="copyright">&copy; 2026 Visa Journey USA. All rights reserved.</p>
    </div>
  </div>
</footer>

<script>
__FORMJS__
</script>

<script>
__PAYMENTJS__
</script>

<script>
__SITEJS__
__WIDGETJS__
__ROUTERJS__
</script>

</body>
</html>
"""

html = (html
        .replace("__CSS__", css + EXTRA_CSS)
        .replace("__MARK__", MARK)
        .replace("__NAV__", nav_links)
        .replace("__MOBILE__", mobile_links)
        .replace("__ROUTES__", routes_html)
        .replace("__FORMJS__", FORM_JS)
        .replace("__PAYMENTJS__", PAYMENT_JS)
        .replace("__SITEJS__", site_js)
        .replace("__WIDGETJS__", WIDGET_JS)
        .replace("__ROUTERJS__", ROUTER_JS))

open(OUT, "w").write(html)
print("wrote", OUT, len(html), "bytes")
