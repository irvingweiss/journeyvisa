<?php
/* The admin half of the API: sign in, the list, one application, status,
 * notes, and the two card routes (reveal the stored number, record a charge).
 *
 * Shapes are fixed by admin.js; the contract is at the top of that file. The
 * end of this file says how the card routes are guarded.
 */

class Admin
{
    private PDO $db;
    private array $cfg;

    public function __construct(PDO $db, array $cfg)
    {
        $this->db = $db;
        $this->cfg = $cfg;
    }

    /* ------------------------------------------ POST /api/admin/session */

    public function signIn(): void
    {
        $ip = Http::ip();
        $limit  = (int) $this->cfg['admin_fail_limit'];
        $window = (int) $this->cfg['admin_fail_window'];
        $lock   = (int) $this->cfg['admin_lockout'];

        /* Locked out: answer before comparing anything. Running the compare
           anyway and then refusing tells an attacker whether the password was
           right, which is exactly what the lockout is for. */
        $left = Guard::lockedFor($this->db, 'admin-signin', $ip, $limit, $window, $lock);
        if ($left > 0) {
            header('Retry-After: ' . $left);
            Http::fail(429, 'locked',
                'Too many attempts. Try again in ' . ceil($left / 60) . ' minutes.');
        }

        $in = Http::body();
        $email = strtolower(trim((string) ($in['email'] ?? '')));
        $password = (string) ($in['password'] ?? '');

        $expectedEmail = strtolower(trim((string) $this->cfg['admin_email']));
        $hash = (string) $this->cfg['admin_password_hash'];

        if ($expectedEmail === '' || $hash === '') {
            Http::fail(500, 'not_configured',
                'The admin account is not set up on the server yet.');
        }

        /* The compare runs even when the email is wrong, so a wrong email
           takes as long as a wrong password. password_verify is constant
           time; == is not. */
        $passwordOk = password_verify($password, $hash);
        $emailOk = hash_equals($expectedEmail, $email);

        if (!$passwordOk || !$emailOk) {
            Guard::record($this->db, 'admin-signin', $ip, false);
            /* One status, one message, whichever half was wrong. */
            Http::fail(401, 'bad_credentials', 'Those details were not recognised.');
        }

        /* The password was right, so the wrong-password count goes.
           
           This is safe only because wrong CODES are counted in their own
           bucket, 'admin-code', which nothing here touches. The two were one
           bucket, and that was wrong in both directions. Clearing a shared
           bucket on a correct password let anyone holding the password refill
           the code budget at will -- sign in, spend four guesses, sign in
           again. Then NOT clearing it meant four password typos plus one
           mistyped code was five failures, so the only admin account locked
           itself out for fifteen minutes and refused the correct code that
           followed. Two audits, one each way. Separate buckets answer both:
           a correct password cannot refill the code budget, and password
           typos cannot eat it. */
        Guard::clear($this->db, 'admin-signin', $ip);

        /* No secret enrolled yet: sign straight in, so the password step can
           ship before the second factor is built. The session records
           second_factor = 0, because none was presented, and a card route
           calling requireAdmin($db, true) therefore refuses it. Passing false
           here is the whole point: see schema.mysql.sql on admin_sessions. */
        $secret = (string) $this->cfg['totp_secret'];
        if (trim($secret) === '') {
            Sessions::startAdminFull($this->db, $this->cfg, $expectedEmail, false);
            Http::json(['email' => $expectedEmail, 'name' => 'Admin']);
        }

        /* A secret that is set but cannot be used is a broken setting, not an
           absent one, so it fails closed and says so. Signing straight in
           would silently disable the second factor on a server whose config
           says it is enabled; issuing a half session would hand out a session
           no code can ever complete. Testing the string for emptiness here
           did the first of those: a placeholder like '000000' decodes to a
           zero-length key, so the codes became publicly computable. */
        if (!Totp::usable($secret)) {
            error_log('[vj] totp_secret in config.php is not a usable base32 secret.'
                . ' Re-run tools/enrol-totp.php. See "The second factor" in INSTALL.md.');
            Http::fail(500, 'not_configured',
                'The second factor is not set up correctly on the server.');
        }

        Sessions::startAdminHalf($this->db, $this->cfg, $expectedEmail);
        Http::json(['mfaRequired' => true]);
    }

    /* ----------------------------------- POST /api/admin/session/verify */

    public function verifyCode(): void
    {
        $ip = Http::ip();
        $limit  = (int) $this->cfg['admin_fail_limit'];
        $window = (int) $this->cfg['admin_fail_window'];
        $lock   = (int) $this->cfg['admin_lockout'];

        /* Wrong codes have their own counter, and it is keyed on the address
           rather than on the half session, so signing in again does not reset
           it. That is what stops someone holding the password from refilling
           the budget four guesses at a time. It is separate from the password
           counter so that mistyping the password a few times cannot lock the
           account out on the code step. */
        $left = Guard::lockedFor($this->db, 'admin-code', $ip, $limit, $window, $lock);
        if ($left > 0) {
            header('Retry-After: ' . $left);
            Http::fail(429, 'locked',
                'Too many attempts. Try again in ' . ceil($left / 60) . ' minutes.');
        }

        $session = Sessions::admin($this->db);
        if (!$session) {
            Http::fail(401, 'expired', 'That took too long. Enter your password again.');
        }
        if (Db::flag($session['mfa_passed'] ?? 0)) {
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        $code = preg_replace('/\s+/', '', (string) (Http::body()['code'] ?? ''));
        $secret = trim((string) $this->cfg['totp_secret']);

        $step = Totp::verify($secret, $code);
        if ($step !== null) {
            /* Refuse a step already accepted. Without this a code watched
               over a shoulder works again until it expires, and the second
               factor stops being one.

               One statement, not a SELECT then an UPDATE. The condition is in
               the WHERE clause so the database decides, and two requests
               arriving with the same code cannot both read the old value and
               both be allowed through. rowCount tells us which one won. */
            /* `last_totp_step IS NULL OR last_totp_step < ?`, and the values
               bound as integers. Both halves of that matter.
               
               The NULL test is there because a NULL column compares false to
               everything, which looks exactly like "already used": every
               correct code refused for ever. The shipped schema is NOT NULL,
               but the fallback below exists for hand-built schemas, and one of
               those is as likely to make the column nullable as to leave the
               row out.
               
               It is NOT written as COALESCE(last_totp_step, 0) < ?, which was
               the obvious way and was wrong. PDO binds a PHP int as a STRING
               by default. SQLite applies the column's INTEGER affinity to a
               bound string when the column is compared directly, so the
               comparison is numeric and correct -- but wrapping the column in
               a function discards that affinity, so it compared integer
               against text, and in SQLite every integer sorts before every
               string. The condition was therefore ALWAYS true and a used code
               was accepted a second time: the replay guard, defeated by the
               line meant to harden it. MySQL coerces numerically and would
               never have shown it. An audit caught it, the SQLite harness is
               why, and the explicit PARAM_INT binding below means neither
               driver has to be clever. */
            $st = $this->db->prepare(
                'UPDATE admin_state SET last_totp_step = ?
                  WHERE id = 1 AND (last_totp_step IS NULL OR last_totp_step < ?)'
            );
            $st->bindValue(1, $step, PDO::PARAM_INT);
            $st->bindValue(2, $step, PDO::PARAM_INT);
            $st->execute();
            if ($st->rowCount() !== 1) {
                /* Zero rows means either the step was already used, or there
                   is no admin_state row at all. Those are completely
                   different problems and the second one is not the admin's
                   fault, so find out which before blaming the code. A
                   hand-built schema or a dump restored without its INSERTs
                   has no row, and reporting "already used" for every correct
                   code sends whoever is debugging it a long way in the wrong
                   direction. */
                $exists = (int) $this->db->query(
                    'SELECT COUNT(*) FROM admin_state WHERE id = 1'
                )->fetchColumn();
                if ($exists === 0) {
                    $this->db->prepare(
                        'INSERT INTO admin_state (id, last_totp_step) VALUES (1, ?)'
                    )->execute([$step]);
                    error_log('[vj] admin_state had no row; created it. '
                        . 'Load schema.mysql.sql or see schema.migrations.sql.');
                } else {
                    Guard::record($this->db, 'admin-code', $ip, false);
                    Http::fail(401, 'reused',
                        'That code has already been used. Wait for the next one.');
                }
            }
            Guard::clear($this->db, 'admin-code', $ip);
            Sessions::startAdminFull($this->db, $this->cfg, $session['email'], true);
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        /* A recovery code goes in the same box. Each is single use, and only
           its hash is stored. */
        if ($this->useRecoveryCode($code)) {
            /* The code bucket, not the password one: this is the code step
               succeeding. Clearing the password bucket from here would do
               nothing useful and would leave the code failures standing. */
            Guard::clear($this->db, 'admin-code', $ip);
            /* A recovery code is a second factor: it is something held apart
               from the password, single use, and issued at enrolment. */
            Sessions::startAdminFull($this->db, $this->cfg, $session['email'], true);
            Http::json(['email' => $session['email'], 'name' => 'Admin']);
        }

        Guard::record($this->db, 'admin-code', $ip, false);
        Http::fail(401, 'bad_code',
            'That code was not right. Check the app and try the current one.');
    }

    private function useRecoveryCode(string $code): bool
    {
        if (strlen($code) < 8) {
            return false;
        }
        $st = $this->db->prepare(
            'SELECT id, code_hash FROM admin_recovery_codes WHERE used_at IS NULL'
        );
        $st->execute();
        foreach ($st->fetchAll() as $row) {
            if (password_verify(strtolower($code), $row['code_hash'])) {
                $this->db->prepare('UPDATE admin_recovery_codes SET used_at = ? WHERE id = ?')
                         ->execute([Db::now(), $row['id']]);
                return true;
            }
        }
        return false;
    }

    /* ------------------------------------------- GET /api/admin/session */

    /**
     * Who is signed in, if anyone. For the admin screen to pick up a session
     * it already has rather than asking for the password again.
     *
     * Without this the page was unusable in a way nothing noticed: it set its
     * signed-in state only inside the sign in handlers, so reloading, opening
     * /admin in a second tab, or following a link to a particular application
     * all landed on the sign in screen -- while the 12-hour session cookie
     * sat there, valid. And because a TOTP step is single use, a manager who
     * reloaded twice inside thirty seconds could not even sign in again: they
     * had to wait for the next code. Managers read every answer on an
     * application and come back to it repeatedly, so that is the main path
     * through this screen.
     *
     * It authorises nothing on its own. requireAdmin does the work, exactly as
     * for every other admin route, and a session without a second factor is
     * reported as such so the page can decide what to offer.
     */
    public function currentSession(): void
    {
        $session = Sessions::requireAdmin($this->db);
        Http::json([
            'email'        => $session['email'],
            'name'         => 'Admin',
            'secondFactor' => Db::flag($session['second_factor'] ?? 0),
        ]);
    }

    public function signOut(): void
    {
        Sessions::endAdmin($this->db, $this->cfg);
        Http::noContent();
    }

    /* ------------------------------------- GET /api/admin/applications */

    public function listApplications(): void
    {
        Sessions::requireAdmin($this->db);

        $query  = trim((string) ($_GET['query'] ?? ''));
        $status = trim((string) ($_GET['status'] ?? ''));

        $sql = 'SELECT reference, applicant_name, status, step_index, created_at, updated_at
                  FROM applications WHERE 1 = 1';
        $args = [];

        if ($query !== '') {
            /* Reference or surname. Managers look people up by name far more
               often than by reference. */
            $sql .= ' AND (UPPER(reference) LIKE ? OR UPPER(applicant_name) LIKE ?)';
            $like = '%' . strtoupper($query) . '%';
            $args[] = $like;
            $args[] = $like;
        }
        if ($status !== '') {
            $sql .= ' AND status = ?';
            $args[] = $status;
        }
        $sql .= ' ORDER BY updated_at DESC LIMIT 200';

        $st = $this->db->prepare($sql);
        $st->execute($args);

        $out = [];
        foreach ($st->fetchAll() as $row) {
            $out[] = [
                'reference'     => $row['reference'],
                'applicantName' => $row['applicant_name'],
                'status'        => $row['status'],
                'stepIndex'     => (int) $row['step_index'],
                'createdAt'     => Db::iso($row['created_at']),
                'updatedAt'     => Db::iso($row['updated_at']),
                'lastOpenedBy'  => $this->lastOpenedBy($row['reference']),
            ];
        }
        Http::json(['applications' => $out]);
    }

    /* --------------------------------- GET /api/admin/applications/:ref */

    public function getApplication(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        /* Before reading, so a number past its retention period is gone and
           the screen says so, rather than offering a button that 404s. */
        CardVault::purgeExpired($this->db);
        $row = $this->byReference($reference);

        $answers = json_decode($row['answers'] ?: '{}', true);
        $answers = is_array($answers) ? $answers : [];
        /* It is a hash on this side and has no business on this response. The
           admin screen drops it defensively too, but by then it has crossed
           the wire. */
        unset($answers['securityAnswer'], $answers['securityAnswerConfirm']);

        $this->recordOpen((int) $row['id'], $session['email']);

        Http::json([
            'reference'     => $row['reference'],
            'applicantName' => $row['applicant_name'],
            'status'        => $row['status'],
            'stepIndex'     => (int) $row['step_index'],
            'createdAt'     => Db::iso($row['created_at']),
            'updatedAt'     => Db::iso($row['updated_at']),
            'submittedAt'   => Db::iso($row['submitted_at']),
            'data'          => $answers,
            'photoUrl'      => $this->photoUrl($row['reference']),
            'payment'       => $this->payment($row),
            'notes'         => $this->notes((int) $row['id']),
            'activity'      => $this->activityList((int) $row['id']),
        ]);
    }

    /* ------------------------- PATCH /api/admin/applications/:ref/status */

    public function setStatus(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        $status = trim((string) (Http::body()['status'] ?? ''));
        $allowed = ['New', 'In review', 'Waiting on client', 'Ready to file', 'Filed'];
        if (!in_array($status, $allowed, true)) {
            Http::fail(400, 'bad_status', 'That is not a status this system uses.');
        }

        $st = $this->db->prepare('UPDATE applications SET status = ?, updated_at = ? WHERE id = ?');
        $st->execute([$status, Db::now(), $row['id']]);
        $this->activity((int) $row['id'], $session['email'], 'Changed status to ' . $status);
        Http::noContent();
    }

    /* -------------------------- POST /api/admin/applications/:ref/notes */

    public function addNote(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        $body = trim((string) (Http::body()['body'] ?? ''));
        if ($body === '') {
            Http::fail(400, 'empty', 'Write something first.');
        }
        if (mb_strlen($body) > 5000) {
            $body = mb_substr($body, 0, 5000);
        }

        $at = Db::now();
        $st = $this->db->prepare(
            'INSERT INTO application_notes (application_id, author, body, at) VALUES (?, ?, ?, ?)'
        );
        $st->execute([$row['id'], 'Admin', $body, $at]);
        $this->db->prepare('UPDATE applications SET updated_at = ? WHERE id = ?')
                 ->execute([$at, $row['id']]);

        Http::json(['author' => 'Admin', 'at' => Db::iso($at), 'body' => $body]);
    }

    /* -------------------------- GET /api/admin/applications/:ref/photo */

    public function photo(string $reference): void
    {
        Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);
        /* Config::photoDir, shared with the write side. A bare rtrim() here
           was a TypeError on PHP 8 and a silent NULL on the 7.4 this ships
           on, where it made the path "/<REF>.jpg" and probed the filesystem
           root -- so a misconfigured photo_dir behaved differently on the
           developer's machine and on the server. */
        $dir = Config::photoDir($this->cfg);
        if ($dir === '') {
            Http::fail(404, 'no_photo', 'No photograph on file.');
        }
        foreach (['jpg', 'png'] as $ext) {
            $path = $dir . '/' . $row['reference'] . '.' . $ext;
            if (is_file($path)) {
                header('Content-Type: ' . ($ext === 'png' ? 'image/png' : 'image/jpeg'));
                header('Cache-Control: no-store, private');
                header('Content-Length: ' . filesize($path));
                readfile($path);
                exit;
            }
        }
        Http::fail(404, 'no_photo', 'No photograph on file.');
    }

    /* ------------------- POST /api/admin/applications/:ref/card/reveal */

    /**
     * The full card number, once. THE ONLY ROUTE THAT DECRYPTS.
     *
     * in:  { reference }    (the reference is taken from the URL)
     * out: { number, name, expMonth, expYear, postal }
     *
     * In this order, and the order is the point:
     *
     *   1. A session signed in with a second factor. Sessions::requireAdmin
     *      with true, which checks second_factor rather than mfa_passed: a
     *      password-only session (no TOTP enrolled) is refused with 403
     *      second_factor_required. PCI DSS 8.4.2 requires MFA for access to
     *      card data.
     *   2. The rate limit, counted from the reveal log itself: 20 an hour for
     *      the account and 3 per application in ten minutes by default.
     *   3. Decrypt, in memory only.
     *   4. Write the reveal log row. If that write fails, refuse: a reveal
     *      with no record is the one thing the log exists to prevent.
     *   5. Return the number, no-store.
     *
     * Every call writes a log row, allowed or not, except when the log
     * itself cannot be written. The row never carries the number, not even
     * the last four.
     *
     * Keep this response body out of every log: web server, proxy, APM,
     * error tracker.
     */
    public function revealCard(string $reference): void
    {
        $reference = strtoupper(trim($reference));
        $session = Sessions::admin($this->db);
        $who = $session ? (string) $session['email'] : '';

        $allowed = $session
            && Db::flag($session['mfa_passed'] ?? 0)
            && Db::flag($session['second_factor'] ?? 0);
        if (!$allowed) {
            /* Logged before refusing, so an attempt with a stolen
               password-only session is on the record too. Best effort: a
               refusal does not depend on the log. */
            $this->revealLog($who, $reference, 'no_permission', false);
            /* The documented guard does the refusing, with its own codes:
               401 not_signed_in, 401 mfa_required, 403
               second_factor_required. */
            Sessions::requireAdmin($this->db, true);
            Http::fail(403, 'second_factor_required',
                'This needs a second factor. Enrol one and sign in again.');
        }
        /* And once more through the guard itself, so this route can never
           drift from what every other card route is told to use. */
        $session = Sessions::requireAdmin($this->db, true);
        $who = (string) $session['email'];

        $st = $this->db->prepare('SELECT * FROM applications WHERE reference = ?');
        $st->execute([$reference]);
        $row = $st->fetch();
        $st->closeCursor();
        if (!$row) {
            $this->revealLog($who, $reference, 'not_found', false);
            Http::fail(404, 'not_found', 'No application with that reference.');
        }

        /* The limit is read from the log, which is the record of what was
           actually shown. Only allowed reveals count towards it, so being
           refused does not stretch the wait. */
        $hourLimit = (int) $this->cfg['card_reveal_hour_limit'];
        $appLimit = (int) $this->cfg['card_reveal_app_limit'];
        $appWindow = (int) $this->cfg['card_reveal_app_window'];
        $byAccount = (int) $this->scalar(
            'SELECT COUNT(*) FROM card_reveal_log
              WHERE admin_email = ? AND outcome = ? AND at >= ?',
            [$who, 'allowed', gmdate('Y-m-d H:i:s', time() - 3600)]
        );
        $byApp = (int) $this->scalar(
            'SELECT COUNT(*) FROM card_reveal_log
              WHERE reference = ? AND outcome = ? AND at >= ?',
            [$reference, 'allowed', gmdate('Y-m-d H:i:s', time() - $appWindow)]
        );
        if ($byAccount >= $hourLimit || $byApp >= $appLimit) {
            $this->revealLog($who, $reference, 'rate_limited', false);
            $this->alertRateLimit($who, $reference);
            header('Retry-After: ' . ($byApp >= $appLimit ? $appWindow : 3600));
            Http::fail(429, 'rate_limited', 'Too many card views in a short time. Try again later.');
        }

        CardVault::purgeExpired($this->db);
        $st = $this->db->prepare('SELECT * FROM card_vault WHERE application_id = ?');
        $st->execute([$row['id']]);
        $vault = $st->fetch();
        $st->closeCursor();
        if (!$vault) {
            $this->revealLog($who, $reference, 'not_on_file', false);
            Http::fail(404, 'not_on_file', 'The full number has been deleted from our server.');
        }

        if (!CardVault::configured($this->cfg)) {
            $this->revealLog($who, $reference, 'key_missing', false);
            error_log('[vj] card reveal refused: card_key is not set or is not a base64'
                . ' encoding of 32 bytes. Set the CARD_KEY environment variable.');
            Http::fail(503, 'card_key_missing',
                'The card key is not set up on the server, so the number cannot be shown.');
        }

        $card = CardVault::open($this->cfg, $reference, $vault);
        if ($card === null) {
            $this->revealLog($who, $reference, 'decrypt_failed', false);
            error_log('[vj] card reveal for ' . $reference . ': the stored number could not be'
                . ' decrypted (wrong or rotated-out key "' . $vault['kms_key_id']
                . '", or the row was altered). Nothing was shown.');
            Http::fail(500, 'decrypt_failed',
                'The stored number could not be read. Ask the applicant for the card again.');
        }

        /* The log row FIRST. If it cannot be written, the number is not
           returned. */
        if (!$this->revealLog($who, $reference, 'allowed', true)) {
            $card = null;
            error_log('[vj] card reveal for ' . $reference . ' refused: the reveal log could'
                . ' not be written. Check card_reveal_log exists and the database user can'
                . ' INSERT into it.');
            Http::fail(503, 'log_unavailable',
                'The card number cannot be shown because the access log could not be written.');
        }

        /* For whoever is signed in. The reveal log above is the record. */
        $this->activity((int) $row['id'], 'Admin', 'Viewed full card number');

        header('Expires: 0');
        Http::json([
            'number'   => $card['number'],
            'name'     => $card['name'],
            'expMonth' => $row['card_exp_month'] !== null ? (int) $row['card_exp_month'] : null,
            'expYear'  => $row['card_exp_year'] !== null ? (int) $row['card_exp_year'] : null,
            'postal'   => $card['postal'],
        ]);
    }

    /* ---------------------- POST /api/admin/applications/:ref/mark-charged */

    /**
     * Record a charge taken on the other processor. It takes no money.
     *
     * in:  { reference, amount, currency, chargedOn, processorReference }
     * out: { status: "paid", amount, chargedOn, processorReference }
     *
     * Marks the application paid and destroys the stored number in the same
     * transaction, so there is no moment when an application is paid and its
     * card number is still on the server. Refuses an application that is
     * already paid, rather than relying on the admin screen hiding the
     * button.
     */
    public function markCharged(string $reference): void
    {
        $session = Sessions::requireAdmin($this->db);
        $row = $this->byReference($reference);

        if (!empty($row['charged_on'])) {
            Http::fail(409, 'already_paid', 'This application is already marked as paid.');
        }

        $in = Http::body();
        $amount = $in['amount'] ?? null;
        if (!is_numeric($amount) || (float) $amount <= 0 || (float) $amount > 100000
            || !is_finite((float) $amount)) {
            Http::fail(400, 'bad_amount', 'Enter the amount that was charged.');
        }
        $amount = round((float) $amount, 2);

        $currency = strtoupper(trim((string) ($in['currency'] ?? '')));
        if ($currency === '') {
            $currency = strtoupper((string) $this->cfg['currency']);
        }
        if (!preg_match('/^[A-Z]{3}$/', $currency)) {
            Http::fail(400, 'bad_currency', 'Use a three-letter currency code, like USD.');
        }

        $chargedOn = trim((string) ($in['chargedOn'] ?? ''));
        $parts = explode('-', $chargedOn);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $chargedOn)
            || !checkdate((int) $parts[1], (int) $parts[2], (int) $parts[0])) {
            Http::fail(400, 'bad_date', 'Enter the date of the charge.');
        }
        /* Not in the future. A day of slack for an admin in a timezone ahead
           of UTC, where it is already tomorrow. */
        if ($chargedOn > gmdate('Y-m-d', time() + 86400)) {
            Http::fail(400, 'future_date', 'The charge date cannot be in the future.');
        }

        $processorRef = trim((string) ($in['processorReference'] ?? ''));
        if ($processorRef === '') {
            Http::fail(400, 'no_reference', 'Enter the reference the processor gave for this charge.');
        }
        if (mb_strlen($processorRef) > 128) {
            $processorRef = mb_substr($processorRef, 0, 128);
        }
        /* A processor reference that is a card number would put the number
           back on the application in the clear. */
        if (preg_match('/\d{12,19}/', preg_replace('/[\s-]/', '', $processorRef))) {
            Http::fail(400, 'bad_reference',
                'That reference looks like a card number. Use the processor\'s transaction ID.');
        }

        $now = Db::now();
        $this->db->beginTransaction();
        try {
            $st = $this->db->prepare(
                'UPDATE applications
                    SET paid_amount = ?, paid_currency = ?, charged_on = ?, charged_by = ?,
                        processor_ref = ?, charge_recorded_at = ?, number_on_file = 0,
                        updated_at = ?
                  WHERE id = ? AND charged_on IS NULL'
            );
            $st->execute([$amount, $currency, $chargedOn, $session['email'],
                          $processorRef, $now, $now, $row['id']]);
            if ($st->rowCount() !== 1) {
                /* Another request recorded it first. */
                $this->db->rollBack();
                Http::fail(409, 'already_paid', 'This application is already marked as paid.');
            }
            $this->db->prepare('DELETE FROM card_vault WHERE application_id = ?')
                     ->execute([$row['id']]);
            $this->activity((int) $row['id'], 'Admin',
                'Recorded a charge of ' . number_format($amount, 2, '.', '') . ' ' . $currency
                . ' and deleted the stored card number');
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        Http::json([
            'status'             => 'paid',
            'amount'             => $amount,
            'chargedOn'          => $chargedOn,
            'chargedAt'          => Db::iso($now),
            'processorReference' => $processorRef,
        ]);
    }

    /**
     * One row in the append-only reveal log. Returns whether it was written.
     *
     * The log is append-only: this is the only statement in the codebase
     * that touches card_reveal_log apart from the counts above, and it only
     * INSERTs. The database enforces it as well (triggers in
     * schema.mysql.sql, and the grants in DEVELOPER-INSTRUCTIONS.md).
     *
     * $mustWrite is true only for the allowed row, where a failure has to be
     * reported so the reveal is refused. For refusals it is best effort.
     */
    private function revealLog(string $who, string $reference, string $outcome,
                               bool $mustWrite): bool
    {
        try {
            $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
            $st = $this->db->prepare(
                'INSERT INTO card_reveal_log (at, admin_email, ip, user_agent, reference, outcome)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $st->execute([
                Db::now(),
                mb_substr($who, 0, 255),
                mb_substr(Http::ip(), 0, 45),
                mb_substr($ua, 0, 255),
                substr(preg_replace('/[^A-Z0-9]/', '', $reference), 0, 16),
                $outcome,
            ]);
            return $st->rowCount() === 1;
        } catch (Throwable $e) {
            error_log('[vj] card_reveal_log write failed: ' . $e->getMessage());
            return false;
        }
    }

    /** Tell the account holder the reveal limit was hit. At most once an hour,
     *  and never fatal: the 429 is the protection, this is the alarm. */
    private function alertRateLimit(string $who, string $reference): void
    {
        error_log('[vj] ALERT: card reveal rate limit hit by ' . $who . ' from ' . Http::ip()
            . ' on ' . $reference . '. If this was not you, change the admin password.');
        try {
            if (Guard::countRecent($this->db, 'reveal-alert', 'all', 3600, false) > 0) {
                return;
            }
            Guard::record($this->db, 'reveal-alert', 'all', true);
            $to = trim((string) $this->cfg['admin_email']);
            $from = trim((string) $this->cfg['support_email']);
            if (filter_var($to, FILTER_VALIDATE_EMAIL) && filter_var($from, FILTER_VALIDATE_EMAIL)) {
                @mail($to, 'Visa Journey USA: card view limit reached',
                    "The limit on viewing full card numbers in /admin was reached at "
                    . gmdate('Y-m-d H:i') . " UTC from IP " . Http::ip() . ".\r\n\r\n"
                    . "If that was not you, change the admin password and re-enrol the"
                    . " second factor now.\r\n",
                    'From: ' . $from . "\r\nContent-Type: text/plain; charset=utf-8");
            }
        } catch (Throwable $e) {
            error_log('[vj] could not send the reveal-limit alert: ' . $e->getMessage());
        }
    }

    private function scalar(string $sql, array $args)
    {
        $st = $this->db->prepare($sql);
        $st->execute($args);
        $v = $st->fetchColumn();
        $st->closeCursor();
        return $v;
    }

    /* ----------------------------------------------------------- helpers */

    private function byReference(string $reference): array
    {
        $st = $this->db->prepare('SELECT * FROM applications WHERE reference = ?');
        $st->execute([strtoupper(trim($reference))]);
        $row = $st->fetch();
        if (!$row) {
            Http::fail(404, 'not_found', 'No application with that reference.');
        }
        return $row;
    }

    private function payment(array $row): array
    {
        $card = null;
        if ($row['card_last4']) {
            $card = [
                'brand'        => $row['card_brand'],
                'last4'        => $row['card_last4'],
                'expMonth'     => $row['card_exp_month'] !== null ? (int) $row['card_exp_month'] : null,
                'expYear'      => $row['card_exp_year'] !== null ? (int) $row['card_exp_year'] : null,
                'numberOnFile' => Db::flag($row['number_on_file'] ?? 0),
            ];
        }
        $status = $row['charged_on'] ? 'paid' : ($card ? 'authorised' : 'none');
        return [
            'status'             => $status,
            /* The amount comes from the server. A price posted from a browser
               is a price the customer can edit. */
            'amount'             => $row['paid_amount'] !== null
                                      ? (float) $row['paid_amount']
                                      : (float) $this->cfg['service_fee'],
            'currency'           => $row['paid_currency'] ?: $this->cfg['currency'],
            'chargedOn'          => $row['charged_on'],
            'chargedAt'          => Db::iso($row['charge_recorded_at']),
            'chargedBy'          => $row['charged_by'],
            'processorReference' => $row['processor_ref'],
            'card'               => $card,
        ];
    }

    private function notes(int $id): array
    {
        $st = $this->db->prepare(
            'SELECT author, body, at FROM application_notes
              WHERE application_id = ? ORDER BY at ASC'
        );
        $st->execute([$id]);
        return array_map(static fn($r) => [
            'author' => $r['author'],
            'at'     => Db::iso($r['at']),
            'body'   => $r['body'],
        ], $st->fetchAll());
    }

    private function activityList(int $id): array
    {
        $st = $this->db->prepare(
            'SELECT author, action, at FROM application_activity
              WHERE application_id = ? ORDER BY at DESC LIMIT 50'
        );
        $st->execute([$id]);
        return array_map(static fn($r) => [
            'author' => $r['author'],
            'at'     => Db::iso($r['at']),
            'action' => $r['action'],
        ], $st->fetchAll());
    }

    private function activity(int $id, string $author, string $action): void
    {
        $st = $this->db->prepare(
            'INSERT INTO application_activity (application_id, author, action, at)
             VALUES (?, ?, ?, ?)'
        );
        $st->execute([$id, $author, $action, Db::now()]);
    }

    /**
     * Record that the application was opened.
     *
     * Deduplicated inside half an hour, because the detail view reloads every
     * time the status changes or a note is added, and an activity list that
     * is forty identical lines is one nobody reads.
     */
    private function recordOpen(int $id, string $who): void
    {
        $st = $this->db->prepare(
            'SELECT at FROM application_activity
              WHERE application_id = ? AND action = ? ORDER BY at DESC LIMIT 1'
        );
        $st->execute([$id, 'Opened the application']);
        $last = $st->fetchColumn();
        if ($last && (time() - strtotime($last . ' UTC')) < 1800) {
            return;
        }
        $this->activity($id, 'Admin', 'Opened the application');
    }

    private function lastOpenedBy(string $reference): ?string
    {
        $st = $this->db->prepare(
            'SELECT a.author FROM application_activity a
               JOIN applications p ON p.id = a.application_id
              WHERE p.reference = ? ORDER BY a.at DESC LIMIT 1'
        );
        $st->execute([$reference]);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    }

    private function photoUrl(string $reference): ?string
    {
        $dir = Config::photoDir($this->cfg);
        if ($dir === '') {
            return null;
        }
        foreach (['jpg', 'png'] as $ext) {
            if (is_file($dir . '/' . $reference . '.' . $ext)) {
                return '/api/admin/applications/' . rawurlencode($reference) . '/photo';
            }
        }
        return null;
    }
}

/* ---------------------------------------------------------------------------
 * The card routes: revealCard and markCharged, above.
 *
 * They were left out until three things existed: key management for the
 * stored number (lib/CardVault.php, key from the CARD_KEY environment
 * variable), the second factor (tools/enrol-totp.php), and the append-only
 * reveal log (card_reveal_log). All three are now in this package.
 *
 * Sessions::requireAdmin($db, true) is the check revealCard uses: it insists
 * the session passed a second factor, rather than asking whether a secret is
 * enrolled, which a session created before enrolment would pass.
 *
 * To go to the later version that shows the last four only, remove
 * onRevealCard from admin.html (the screen then draws no reveal button) and
 * delete the reveal route from index.php. DEVELOPER-INSTRUCTIONS.md has the
 * steps.
 * ------------------------------------------------------------------------ */
