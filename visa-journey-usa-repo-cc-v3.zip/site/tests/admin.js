/* The manager admin screen: sign in, the list, and the detail view that is
   drawn by walking VJ_SCHEMA rather than the answer object.

   The detail-view checks are the ones that matter. A reviewer reading an
   application needs to see every question that was put to this applicant,
   including the ones they left blank, and must never see the security answer.
   Both are easy to break with a well-meaning "skip the empties" change.

       node admin.js ../src/            (with a server on 8899 serving ../src) */

const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const newHost = require('./host');

const DIR = process.argv[2] || '../src/';
const BASE = process.argv[3] || 'http://localhost:8899/';
require('./server_check')(BASE, 'admin.js', DIR);

let pass = 0, fail = 0;
const failures = [];

function ok(name, cond, detail) {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else {
    fail++; failures.push(name + (detail ? ' -> ' + detail : ''));
    console.log('  FAIL  ' + name + (detail ? ' -> ' + detail : ''));
  }
}
function group(t) { console.log('\n' + t); }

const wait = ms => new Promise(r => setTimeout(r, ms));

/* ------------------------------------------------------------ sign in --
   There is one admin account. The preview checks the password by comparing
   a SHA-256 of what was typed with the hex in admin.html. The password itself
   is not in this repository, and must not be: these tests never type it.

   jsdom has no crypto.subtle, so each page gets Node's real WebCrypto, with
   one seam. When the input is STUB_PASSWORD, digest() answers with the
   stored hash, which is "the hash compare matched" without knowing what
   matches it. Every other input is hashed for real, so a wrong password is
   checked exactly the way the browser checks it. */
const ADMIN_EMAIL = 'admin@example.com';
const STUB_PASSWORD = 'stub-input-the-test-digest-treats-as-matching';
const STORED_SHA256 = (() => {
  const m = /DEMO_ADMIN_PASSWORD_SHA256\s*=\s*"([0-9a-f]{64})"/.exec(
    fs.readFileSync(DIR + 'admin.html', 'utf8'));
  return m ? m[1] : null;
})();
const digests = [];

function installCrypto(window, opts) {
  opts = opts || {};
  const util = require('util');
  const { webcrypto } = require('crypto');
  window.TextEncoder = util.TextEncoder;
  if (opts.noSubtle) {
    Object.defineProperty(window, 'crypto', { value: {}, configurable: true });
    return;
  }
  const subtle = {
    digest(algo, data) {
      digests.push(algo);
      const text = new util.TextDecoder().decode(data);
      if (text === STUB_PASSWORD && STORED_SHA256) {
        return Promise.resolve(Uint8Array.from(Buffer.from(STORED_SHA256, 'hex')).buffer);
      }
      return webcrypto.subtle.digest(algo, data);
    },
  };
  Object.defineProperty(window, 'crypto', {
    value: { subtle, getRandomValues: a => webcrypto.getRandomValues(a) },
    configurable: true,
  });
}

/* body.textContent includes the contents of every <script> on the page, and the
   demo applications live in one of those. Asserting against it would pass even
   if the page rendered nothing at all. Everything below reads the mount
   container instead, which holds only what was actually drawn. */
const shown = d => d.getElementById('vj-admin').textContent;
const drawn = d => d.getElementById('vj-admin').innerHTML;

function open(file, opts) {
  return new Promise(resolve => {
    const errs = [];
    const vc = new VirtualConsole();
    vc.on('jsdomError', e => {
      const m = e.message || String(e);
      if (!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);
    });
    const dom = new JSDOM(fs.readFileSync(DIR + file, 'utf8'), {
      runScripts: 'dangerously', resources: 'usable',
      url: BASE + file, virtualConsole: vc, pretendToBeVisual: true,
      beforeParse: win => installCrypto(win, opts),
    });
    setTimeout(() => resolve({ dom, errs, d: dom.window.document, w: dom.window }), 2600);
  });
}

const DEMO_MFA_CODE = '123456';

function submitSignIn(d, w) {
  d.querySelector('.vja-signin')
    .dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
}

/* Sign in is two steps now. This completes both, so every test that just
   needs to be past the door stays one line. Tests that care about the steps
   themselves drive them directly. */
async function signIn(d, w, email, password, code) {
  d.getElementById('vja-email').value = email === undefined ? ADMIN_EMAIL : email;
  d.getElementById('vja-pass').value = password === undefined ? STUB_PASSWORD : password;
  submitSignIn(d, w);
  await wait(220);
  const codeBox = d.getElementById('vja-code-input');
  if (!codeBox) return;            /* refused at the password step */
  codeBox.value = code === undefined ? DEMO_MFA_CODE : code;
  submitSignIn(d, w);
  await wait(220);
}

async function openRef(d, w, ref) {
  w.location.hash = '#/a/' + ref;
  w.dispatchEvent(new w.Event('hashchange'));
  await wait(260);
}

(async () => {

  /* ==================================================== 1. the page loads */
  group('1. THE PAGE LOADS');
  {
    const { d, w, errs } = await open('admin.html');
    ok('admin.html loads with no script errors', errs.length === 0, errs[0]);
    ok('VisaJourneyAdmin is exposed', typeof w.VisaJourneyAdmin === 'object');
    ok('it has the form schema to draw from', typeof w.VJ_SCHEMA === 'object');
    ok('the developer fallback stays hidden', d.getElementById('admin-fallback').hidden);
    ok('no public nav on the admin page', !d.querySelector('.site-header'));
    ok('no public footer on the admin page', !d.querySelector('.site-footer'));
    ok('no disclaimer bar on the admin page', !d.querySelector('.notice-bar'));

    const robots = d.querySelector('meta[name=robots]');
    ok('the page is noindex,nofollow', !!robots && /noindex/.test(robots.content) &&
       /nofollow/.test(robots.content), robots && robots.content);
  }

  /* ========================================================= 2. sign in */
  group('2. SIGN IN');
  {
    const { d, w } = await open('admin.html');
    ok('sign in is the first thing shown', !!d.querySelector('.vja-signin'));
    ok('no application list before signing in', !d.querySelector('.vja-table'));
    ok('it says this is not the applicant login',
       /applicant/i.test(d.querySelector('.vja-signin').textContent) &&
       /reference numbers do not work here/i.test(d.querySelector('.vja-signin').textContent));
    ok('the password field is a password field',
       d.getElementById('vja-pass').type === 'password');

    await signIn(d, w);
    ok('signing in reaches the list', !!d.querySelector('.vja-table'));
    ok('the bar names the account that is signed in',
       d.querySelector('.vja-who').textContent === 'Signed in as ' + ADMIN_EMAIL,
       d.querySelector('.vja-who').textContent);

    const out = [...d.querySelectorAll('.vja-bar button')].find(b => /Sign out/.test(b.textContent));
    ok('there is a sign out', !!out);
    out.click();
    await wait(160);
    ok('signing out returns to sign in', !!d.querySelector('.vja-signin'));
    ok('and the list is gone', !d.querySelector('.vja-table'));
  }

  /* =================================================== 2b. one account */
  group('2b. ONE ADMIN ACCOUNT');
  {
    ok('the preview hash is in admin.html, 64 hex characters', !!STORED_SHA256);
    const html = fs.readFileSync(DIR + 'admin.html', 'utf8');
    const js = fs.readFileSync(DIR + 'admin.js', 'utf8');
    ok('it is marked preview-only and to be removed with the DEMO flag',
       /PREVIEW-ONLY SIGN IN/.test(html) && /TOGETHER WITH THE DEMO FLAG/.test(html) &&
       /bcrypt/.test(html));
    ok('admin.js itself holds no account and no hash',
       js.indexOf(ADMIN_EMAIL) === -1 && (!STORED_SHA256 || js.indexOf(STORED_SHA256) === -1));
    ok('the sign in no longer accepts anything', !/accepts anything/.test(html));

    const err = d => d.querySelector('.vja-signin .vja-err');
    const refused = d => !!d.querySelector('.vja-signin') && !d.querySelector('.vja-table') &&
      !err(d).hidden && /not recognised/.test(err(d).textContent);

    {
      const { d, w } = await open('admin.html');
      ok('the heading says admin, not manager',
         /Admin sign in/.test(d.querySelector('.vja-signin h2').textContent));

      digests.length = 0;
      await signIn(d, w, 'someone.else@example.com');
      ok('a wrong email is refused, even with a matching password', refused(d), err(d).textContent);
      ok('the password is still hashed for a wrong email, so it is not answered faster',
         digests.length === 1 && digests[0] === 'SHA-256', digests.join(','));
      ok('the password box is emptied after a refusal', d.getElementById('vja-pass').value === '');

      await signIn(d, w, ADMIN_EMAIL, 'not-the-password');
      ok('the right email with a wrong password is refused', refused(d), err(d).textContent);

      await signIn(d, w, ADMIN_EMAIL, '');
      ok('an empty password is refused', refused(d));

      await signIn(d, w, 'admin@example.co', STUB_PASSWORD);
      ok('a near-miss email is refused', refused(d));

      const m1 = err(d).textContent;
      await signIn(d, w, ADMIN_EMAIL, 'another-wrong-one');
      ok('both kinds of refusal read the same, so neither half is confirmed',
         err(d).textContent === m1, err(d).textContent + ' / ' + m1);

      await signIn(d, w, '  Admin@Example.COM ');
      ok('the right credentials sign in, with the email in any case',
         !!d.querySelector('.vja-table'));
      ok('the bar shows the account email, lower case',
         d.querySelector('.vja-who').textContent === 'Signed in as ' + ADMIN_EMAIL,
         d.querySelector('.vja-who').textContent);

      await openRef(d, w, 'VJ7K2M4PQX');
      const box = d.getElementById('vja-note');
      box.value = 'Checked by the one account.';
      box.closest('form').dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
      await wait(200);
      ok('a new note is written by "Admin"',
         /Admin · [^]*Checked by the one account\./.test(shown(d)));
      ok('no demo note or activity names a second person',
         !/Dana Pruitt|Marcus Webb|Demo manager/.test(html));
    }

    {
      const { d, w } = await open('admin.html', { noSubtle: true });
      await signIn(d, w);
      ok('with no WebCrypto (plain http) it refuses and says why',
         !d.querySelector('.vja-table') && /https/.test(err(d).textContent), err(d).textContent);
    }

    {
      /* The production path, against a stand-in server. */
      const { d, w } = await open('admin.html');
      const calls = [];
      w.fetch = (url, init) => {
        calls.push({ url, init });
        const body = JSON.parse(init.body);
        const good = body.email === ADMIN_EMAIL;
        const status = calls.length > 2 ? 429 : good ? 200 : 401;
        const json = status === 200 ? { email: ADMIN_EMAIL, name: 'Admin' }
          : status === 429 ? { code: 'locked', message: 'Too many attempts. Try again in 15 minutes.' }
          : { code: 'invalid', message: 'Those details were not recognised.' };
        return Promise.resolve({ ok: status === 200, status, json: () => Promise.resolve(json) });
      };
      const host = d.createElement('div');
      d.body.appendChild(host);
      const src = fs.readFileSync(DIR + 'admin.html', 'utf8');
      const m = /onSignIn: function \(creds\) \{[\s\S]*?\n      \},/.exec(src);
      ok('admin.html has an onSignIn to exercise', !!m);
      const onSignIn = m ? w.eval('(function(){var DEMO=false;return {' + m[0] + '}.onSignIn;})()') : null;
      const api = w.VisaJourneyAdmin.mount(host, {
        onSignIn, onList: () => Promise.resolve({ applications: [] }),
      });
      d.getElementById('vj-admin').remove();
      const sub = () => host.querySelector('.vja-signin')
        .dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
      host.querySelector('#vja-email').value = 'wrong@example.com';
      host.querySelector('#vja-pass').value = 'x';
      sub(); await wait(120);
      ok('production: a 401 shows the server message', /not recognised/.test(host.textContent));
      ok('production: it posts to /api/admin/session, password in the body only',
         calls[0] && calls[0].url === '/api/admin/session' && calls[0].init.method === 'POST' &&
         !/x$/.test(calls[0].url));
      host.querySelector('#vja-email').value = ADMIN_EMAIL;
      host.querySelector('#vja-pass').value = 'y';
      sub(); await wait(120);
      ok('production: success shows the account from the server in the bar',
         api.signedInAs() === ADMIN_EMAIL &&
         host.querySelector('.vja-who').textContent === 'Signed in as ' + ADMIN_EMAIL);
      [...host.querySelectorAll('.vja-bar button')].find(b => /Sign out/.test(b.textContent)).click();
      await wait(120);
      host.querySelector('#vja-email').value = ADMIN_EMAIL;
      host.querySelector('#vja-pass').value = 'z';
      sub(); await wait(120);
      ok('production: a lockout shows the server message', /Try again in 15 minutes/.test(host.textContent));
      host.remove();
    }
  }

  /* ============================================================ 3. list */
  group('3. THE LIST');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);

    const rows = () => [...d.querySelectorAll('.vja-table tbody tr')];
    ok('every demo application is listed', rows().length === 4, rows().length);

    const heads = [...d.querySelectorAll('.vja-table th')].map(h => h.textContent);
    ok('the columns a reviewer needs are there',
       ['Reference', 'Applicant', 'Status', 'Step', 'Updated']
         .every(h => heads.indexOf(h) !== -1), heads.join(','));
    /* One shared login, so "last opened by" would always say the same thing. */
    ok('no "last opened by" column with only one account',
       heads.indexOf('Last opened by') === -1, heads.join(','));

    ok('newest activity first',
       rows()[0].children[0].textContent === 'VJ2P5X9ZTD',
       rows().map(r => r.children[0].textContent).join(','));

    ok('each row links to its application',
       rows().every(r => /^#\/a\//.test(r.querySelector('a').getAttribute('href'))));

    /* Managers look people up by name far more often than by reference. */
    const search = d.getElementById('vja-search');
    search.value = 'raman';
    search.dispatchEvent(new w.Event('input'));
    await wait(320);
    ok('search by surname works', rows().length === 1 &&
       rows()[0].children[0].textContent === 'VJ4H8N6WKC', rows().length);

    search.value = 'VJ9D3';
    search.dispatchEvent(new w.Event('input'));
    await wait(320);
    ok('search by reference works', rows().length === 1 &&
       rows()[0].children[0].textContent === 'VJ9D3T7LRB', rows().length);

    search.value = 'nobody here';
    search.dispatchEvent(new w.Event('input'));
    await wait(320);
    ok('a search with no hits says so', !d.querySelector('.vja-table') &&
       /No applications match/.test(d.querySelector('.vja-empty').textContent));

    search.value = '';
    search.dispatchEvent(new w.Event('input'));
    await wait(320);
    const status = d.getElementById('vja-status');
    status.value = 'Ready to file';
    status.dispatchEvent(new w.Event('change'));
    await wait(260);
    const readyRefs = () => rows().map(r => r.children[0].textContent).sort().join(',');
    ok('filtering by status works',
       rows().length === 2 && readyRefs() === 'VJ2P5X9ZTD,VJ4H8N6WKC', readyRefs());
  }

  /* ========================================================== 4. detail */
  group('4. THE DETAIL VIEW');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');

    const steps = [...d.querySelectorAll('.vja-step')];
    ok('the answers are grouped by the form\'s own steps', steps.length >= 18, steps.length);

    const titles = steps.map(s => s.querySelector('h3').childNodes[0].textContent);
    ok('step headings match the schema labels',
       titles[0] === 'Getting back in' && titles.indexOf('Passport') !== -1 &&
       titles.indexOf('Your trip') !== -1, titles.slice(0, 4).join(' | '));
    ok('the review step is not shown as a step', titles.indexOf('Review') === -1);

    const qas = [...d.querySelectorAll('.vja-qa')];
    ok('a real number of questions is rendered', qas.length > 100, qas.length);

    const text = shown(d);

    /* The labels have to be the schema's, not a prettified key name, or the
       manager reads different wording from the applicant. */
    ok('questions use the applicant\'s own wording',
       /Country or region of birth/.test(text), 'label missing');

    ok('an answer the applicant gave is shown', /ORAN/.test(text));
    ok('a long free-text answer is shown in full', /214\(b\)/.test(text));
    ok('dates are written out, not left as yyyy-mm-dd',
       /17 April 1988/.test(text) && !/\d{4}-\d{2}-\d{2}/.test(text),
       (text.match(/\d{4}-\d{2}-\d{2}/) || [''])[0]);

    /* The whole reason for the admin page: transcribing into the DS-160. */
    ok('the DS-160 country code sits beside the country', /DS-160: ALGR/.test(text));
    ok('the DS-160 occupation code is shown too',
       [...d.querySelectorAll('.vja-code')].some(c => c.textContent === 'DS-160: B'));

    /* A question asked and left blank is the single most important thing a
       reviewer must still see. */
    ok('a question left blank still appears, marked unanswered',
       /Not answered/.test(text));
    ok('blanks are visually distinct', d.querySelectorAll('.vja-a-none').length > 0);

    /* ...while a question this applicant was never asked is left out, because
       it is not an unanswered question. */
    ok('questions the applicant never saw are left out',
       !/Deceased spouse/i.test(text), 'a hidden branch leaked in');

    ok('repeat entries are listed', /HADDAD/.test(text));
    ok('a yes/no answer reads as Yes or No', />Yes</.test(drawn(d)));
    ok('the not-applicable flag is honoured rather than shown blank',
       /Does not apply|does not apply/.test(text));

    /* Credentials. */
    ok('the security answer never appears', !/securityAnswer/i.test(drawn(d)));
    ok('the security question itself is fine to show',
       /security question/i.test(text) || /first pet|mother/i.test(text) ||
       titles.indexOf('Getting back in') !== -1);

    ok('the reference is on the page', /VJ7K2M4PQX/.test(text));
    ok('it says whether the application was submitted', /submitted/i.test(text));
    ok('there is a way back to the list',
       !!d.querySelector('.vja-back a[href="#/"]'));
  }

  /* ================================================ 5. status and notes */
  group('5. STATUS, NOTES AND ACTIVITY');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');

    const sel = d.getElementById('vja-setstatus');
    ok('the status can be changed from the detail view', !!sel);
    ok('the status list is short enough to be used',
       sel.options.length <= 6, sel.options.length);
    ok('it opens on the application\'s current status', sel.value === 'In review');

    sel.value = 'Ready to file';
    sel.dispatchEvent(new w.Event('change'));
    await wait(200);
    ok('changing it reports that it saved',
       /Saved/.test(d.querySelector('.vja-note-msg').textContent));

    /* The notes are what make the second and third review worth anything. */
    const notes = () => [...d.querySelectorAll('.vja-card .vja-notes')][0]
      .querySelectorAll('li').length;
    ok('existing notes are shown', notes() === 2, notes());
    ok('notes carry who wrote them and when',
       /Admin · /.test(shown(d)) && /Oct 2026/.test(shown(d)));

    const box = d.getElementById('vja-note');
    const before = notes();
    box.value = 'Spoke to her again, nothing outstanding.';
    box.form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await wait(220);
    ok('a new note is added', notes() === before + 1, notes());
    ok('the box clears after adding', box.value === '');

    box.value = '   ';
    box.form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await wait(200);
    ok('an empty note is refused', notes() === before + 1, notes());

    ok('the activity log is shown', /Opened the application/.test(shown(d)));
  }

  /* ========================================= 6. what it must not do */
  group('6. WHAT IT MUST NOT DO');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');

    /* The applicant signed these answers. A manager editing them afterwards
       would make that signature meaningless, so the detail view is read-only
       apart from the status, the note box and the search. */
    /* The payment panel's "Mark as charged" form records a charge, not an
       answer, so it is the one other place an input is allowed. */
    const inputs = [...d.querySelectorAll('input, textarea, select')]
      .filter(n => n.id !== 'vja-note' && n.id !== 'vja-setstatus' &&
                   n.id !== 'vja-search' && n.id !== 'vja-status' &&
                   !n.closest('.vja-mark'));
    ok('the answers are not editable', inputs.length === 0,
       inputs.map(n => n.id || n.tagName).join(','));

    await openRef(d, w, 'NOPE000000');
    ok('an unknown reference shows an error, not a blank page',
       /Could not open/.test(shown(d)));
    ok('and still offers a way back', !!d.querySelector('.vja-back a'));
  }

  /* ======================================================== 7. the print view */
  group('7. THE PRINT VIEW');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');

    const btn = [...d.querySelectorAll('button')].find(b => /^Print$/.test(b.textContent));
    ok('there is a print button', !!btn);

    const css = [...d.querySelectorAll('style')].map(s => s.textContent).join('');
    ok('a print stylesheet exists', /@media print/.test(css));
    ok('the chrome is hidden when printing',
       /@media print\{[^}]*\.vja-bar[^}]*display:none/.test(css.replace(/\s+/g, '')) ||
       /vja-bar,\.vja-actions,\.vja-side/.test(css));
    ok('the sidebar is marked so it does not print',
       !!d.querySelector('.vja-side.vja-noprint'));
    ok('the note box does not print', !!d.querySelector('form.vja-noprint'));
  }

  /* ================================================ 8. an incomplete one */
  group('8. AN APPLICATION STILL IN PROGRESS');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    await openRef(d, w, 'VJ9D3T7LRB');

    const text = shown(d);
    ok('an unsubmitted application still opens', /VJ9D3T7LRB/.test(text));
    ok('it says it has not been submitted', /not yet submitted/i.test(text));
    ok('the answers given so far are shown', /MEDELLIN/.test(text));
    ok('an unsigned application says so plainly',
       /not signed, certification not confirmed/.test(text));
    ok('no photograph on file is stated plainly, not left blank',
       /None on file/.test(text));
  }

  /* ===================================================== 9. the preview file */
  group('9. THE STANDALONE PREVIEW');
  {
    const path = DIR + '../preview/visa-journey-admin.html';
    if (!fs.existsSync(path)) {
      ok('the admin preview file exists', false, path);
    } else {
      const body = fs.readFileSync(path, 'utf8');
      ok('the admin preview file exists', true);
      ok('it is genuinely self-contained',
         !/src="admin\.js"|src="visa-application-form\.js"|href="site\.css"/.test(body));
      ok('it says the applications in it are invented',
         /invented/.test(body) && /nothing is saved/.test(body));
      ok('it carries the whole form schema', /VJ_SCHEMA/.test(body));
      ok('its notice says to sign in with the admin account',
         /Sign in with the admin account/.test(body) && !/Sign in with anything/.test(body));

      const vc = new VirtualConsole();
      const errs = [];
      vc.on('jsdomError', e => {
        const m = e.message || String(e);
        if (!/Not implemented|fonts\.googleapis|Could not load/.test(m)) errs.push(m);
      });
      const dom = new JSDOM(body, {
        runScripts: 'dangerously', virtualConsole: vc, pretendToBeVisual: true,
        url: 'file:///preview/visa-journey-admin.html',
        beforeParse: win => installCrypto(win),
      });
      await wait(2200);
      const d2 = dom.window.document, w2 = dom.window;
      ok('it runs with no server and no errors', errs.length === 0, errs[0]);
      ok('sign in renders in the single file', !!d2.querySelector('.vja-signin'));
      await signIn(d2, w2);
      ok('the list works in the single file', !!d2.querySelector('.vja-table'));
      await openRef(d2, w2, 'VJ7K2M4PQX');
      ok('the detail view works in the single file',
         d2.querySelectorAll('.vja-step').length >= 18,
         d2.querySelectorAll('.vja-step').length);
    }
  }


  /* ================================================== 10. taking the fee */
  group('10. TAKING THE FEE');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);

    /* A card authorised at the end of the form, not yet charged. The fee is
       taken on another processor and recorded here. */
    await openRef(d, w, 'VJ7K2M4PQX');
    const btn = re => [...d.querySelectorAll('button')].find(b => re.test(b.textContent));

    ok('the card is masked, with only the last four showing',
       /Visa •••• •••• •••• 4242/.test(shown(d)), d.querySelector('.vja-cardline') && d.querySelector('.vja-cardline').textContent);
    ok('the expiry is shown, since it decides whether a charge will work',
       /expires 09\/28/.test(shown(d)));
    ok('the full card number is nowhere on the page until asked for',
       !/\b\d{13,19}\b/.test(drawn(d).replace(/\?v=[a-f0-9]+/g, '')) && !/4242 4242/.test(drawn(d)));
    ok('it no longer claims the number is not stored here',
       !/do not store the number/.test(shown(d)));
    ok('it says the number is stored encrypted and every view is logged',
       /stored encrypted/.test(shown(d)) && /Every view is logged/.test(shown(d)));
    ok('there is no direct charge button when onCharge is not supplied', !btn(/^Charg(e|ing)/));
    ok('there is a Mark as charged button', !!btn(/^Mark as charged$/));

    btn(/^Mark as charged$/).click();
    const form = d.querySelector('.vja-mark');
    ok('it opens a form for amount, date and the processor reference',
       !form.hidden && !!d.getElementById('vja-mark-amount') &&
       !!d.getElementById('vja-mark-date') && !!d.getElementById('vja-mark-ref'));
    ok('the amount starts at the fee', d.getElementById('vja-mark-amount').value === '185');

    let asked = 0;
    w.confirm = () => { asked++; return true; };
    form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await wait(80);
    ok('it will not record a charge without the processor reference',
       asked === 0 && /reference the processor gave/.test(shown(d)));

    d.getElementById('vja-mark-ref').value = 'TXN-777';
    d.getElementById('vja-mark-date').value = '2999-01-01';
    form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await wait(80);
    ok('or with a date in the future', asked === 0 && /cannot be in the future/.test(shown(d)));

    d.getElementById('vja-mark-date').value = '2026-10-19';
    w.confirm = () => { asked++; return false; };
    form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    await wait(80);
    ok('recording asks for confirmation first', asked === 1);
    ok('declining the confirmation records nothing', !/Charged \$185/.test(shown(d)));

    w.confirm = () => true;
    const go = form.querySelector('button[type=submit]');
    form.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));
    ok('the button disables the moment it is pressed, before any response', go.disabled);
    await wait(400);
    ok('a recorded application says it was charged', /Charged \$185/.test(shown(d)));
    ok('with the processor reference', /TXN-777/.test(shown(d)));
    ok('the record is in the activity log', /Marked as charged \$185 \(TXN-777\)/.test(shown(d)));
    ok('the buttons are gone once it is paid', !btn(/^Mark as charged$/) && !btn(/Show full number/));
    ok('and it says the number has been deleted', /has been deleted from our server/.test(shown(d)));
  }

  /* ========================================== 11. the three failure cases */
  group('11. WHEN THERE IS NOTHING TO CHARGE');
  {
    const { d, w } = await open('admin.html');
    await signIn(d, w);
    const any = re => [...d.querySelectorAll('button')].some(b => re.test(b.textContent));

    /* Already paid. */
    await openRef(d, w, 'VJ4H8N6WKC');
    ok('an already-paid application shows what was taken and when',
       /Charged \$185/.test(shown(d)) && /Oct 2026/.test(shown(d)));
    ok('it names who took it', / by Admin/.test(shown(d)));
    ok('it shows the processor reference', /TXN-20261018-0417/.test(shown(d)));
    ok('it offers the receipt', !!d.querySelector('.vja-card a[href*="receipt"]'));
    ok('it offers no way to charge again', !any(/^Charge|^Mark as charged/));
    ok('and no way to reveal a number that has been purged', !any(/Show full number/));

    /* Never got as far as the card step. */
    await openRef(d, w, 'VJ9D3T7LRB');
    ok('no card on file is stated plainly', /No card on file/.test(shown(d)));
    ok('and no charge or reveal is offered', !any(/^Charge|^Mark as charged|Show full number/));

    /* Authorised in August, interview in November, card expired in between.
       This is the ordinary case on this timeline, not an edge case. */
    await openRef(d, w, 'VJ2P5X9ZTD');
    ok('an expired card is caught before anyone charges it',
       /expired while the application was open/.test(shown(d)));
    ok('it says what to do about it', /Ask the applicant for a new card/.test(shown(d)));
    ok('the button is still there, since only the applicant can fix it', any(/^Mark as charged$/));
  }

  /* ============================================ 12. the card step itself */
  group('12. THE CARD STEP DOES NOT CHARGE');
  {
    const body = fs.readFileSync(DIR + 'payment.html', 'utf8');
    ok('the payment page is in save-the-card mode', /chargeLater:\s*true/.test(body));
    ok('it calls a card-saving handler, not a pay handler', /onSaveCard/.test(body));
    ok('it collects the card on the page, because the charge is on another processor',
       /collectCard:\s*true/.test(body) && /\/api\/application\/card/.test(body));
    ok('the developer note forbids storing the CVV',
       /CVV must not be stored/.test(body) && /no CVV field/.test(body));

    const { d, w } = await open('payment.html');
    const box = d.getElementById('payment');
    const text = box.textContent;
    ok('the page says nothing is charged today', /Nothing is charged today/i.test(text));
    ok('it says when the money is actually taken',
       /once our team has prepared and reviewed/i.test(text));
    ok('it says the applicant will not be asked again',
       /without asking you again/i.test(text));
    ok('the button does not say pay', !/Pay \$185/.test(text));
    ok('the button says what it does', /Save my card and Submit/.test(text));
    ok('the amount beside it is marked as due later', /Due later/.test(text));
    ok('the fee disclosures survived the rewrite',
       /separate from the government fees/i.test(text) &&
       /does not guarantee a visa/i.test(text));
    ok('it no longer claims card details are never stored',
       !/never stored on our servers/i.test(text) && /stored encrypted/i.test(text));
    ok('there is no CVV field anywhere',
       ![...box.querySelectorAll('input,select')].some(n =>
         /cv[cv]|ccv|security code/i.test((n.id || '') + (n.getAttribute('aria-label') || '') +
                                         (n.getAttribute('autocomplete') || ''))) &&
       !/\bCCV\b|\bCVV\b|\bCVC\b/.test([...box.querySelectorAll('label')].map(l => l.textContent).join(' ')));
    ok('the card number field is a text field the browser can autofill',
       d.getElementById('vjp-card-number').getAttribute('autocomplete') === 'cc-number' &&
       d.getElementById('vjp-card-number').type === 'text');
    ok('there is a billing postal code field', !!d.getElementById('vjp-postal'));
  }

  /* ========================================= 13. card checks on the step */
  group('13. THE CARD STEP CHECKS THE CARD');
  {
    const { d, w, errs } = await open('payment.html');
    ok('the card step loads with no script errors', errs.length === 0, errs[0]);
    const P = w.VisaJourneyPayment;
    ok('Luhn accepts the standard test numbers',
       ['4242424242424242', '5555555555554444', '378282246310005', '6011111111111117',
        '2223003122003222'].every(P.luhn));
    ok('Luhn rejects a one-digit typo', !P.luhn('4242424242424241'));
    ok('brands are detected, including the 2-series Mastercard range',
       P.cardBrand('4242') === 'Visa' && P.cardBrand('5555') === 'Mastercard' &&
       P.cardBrand('2223003122003222') === 'Mastercard' && P.cardBrand('3782') === 'Amex' &&
       P.cardBrand('6011') === 'Discover' && P.cardBrand('9999') === '');

    /* Mount a fresh one with a spy, so nothing navigates away. */
    const host = d.createElement('div');
    d.body.appendChild(host);
    const seen = [];
    P.mount(host, { applicationId: 'VJTEST0001', serviceFee: 185, chargeLater: true,
      collectCard: true, onSaveCard: p => { seen.push(JSON.parse(JSON.stringify(p))); return Promise.resolve(); } });
    const q = s => host.querySelector(s);
    const type = (node, v) => { node.value = v; node.dispatchEvent(new w.Event('input', { bubbles: true })); };
    const pick = (node, v) => { node.value = v; node.dispatchEvent(new w.Event('change', { bubbles: true })); };
    const save = () => [...host.querySelectorAll('button')].find(b => /Save my card/.test(b.textContent)).click();

    save();
    await wait(40);
    ok('an empty form is refused, with each problem named',
       seen.length === 0 && /Enter the name/.test(host.textContent) &&
       /Enter the card number/.test(host.textContent) && /Choose the month and year/.test(host.textContent));

    type(q('#vjp-name-first'), 'Amina'); type(host.querySelector('[aria-label="Last name on card"]'), 'Benali');
    type(q('#vjp-card-number'), '4242424242424241');
    ok('the number is grouped in fours as it is typed', q('#vjp-card-number').value === '4242 4242 4242 4241',
       q('#vjp-card-number').value);
    ok('the brand lights up as it is typed', /VISA/.test((host.querySelector('.vjp-on') || {}).textContent || ''));
    pick(q('#vjp-exp-month'), '9'); pick(host.querySelector('[aria-label="Expiry year"]'), '2028');
    save();
    await wait(40);
    ok('a number that fails the Luhn check is rejected', seen.length === 0 &&
       /That card number is not valid/.test(host.textContent));
    ok('and the field is marked invalid', q('#vjp-card-number').getAttribute('aria-invalid') === 'true');

    type(q('#vjp-card-number'), '6200000000000005');
    save();
    await wait(40);
    ok('a brand the page does not accept is refused in plain words',
       seen.length === 0 && /We accept Visa, Mastercard, Discover and American Express/.test(host.textContent));

    type(q('#vjp-card-number'), '4242424242424242');
    const y = new Date().getFullYear();
    pick(q('#vjp-exp-month'), '1'); pick(host.querySelector('[aria-label="Expiry year"]'), String(y));
    if (new Date().getMonth() > 0) {
      save();
      await wait(40);
      ok('an expired card is refused', seen.length === 0 && /This card has expired/.test(host.textContent));
    }

    pick(q('#vjp-exp-month'), '9'); pick(host.querySelector('[aria-label="Expiry year"]'), '2028');
    type(q('#vjp-postal'), '31000');
    const before = JSON.stringify(Object.assign({}, w.localStorage)) + JSON.stringify(Object.assign({}, w.sessionStorage));
    save();
    await wait(60);
    ok('a valid card goes to onSaveCard', seen.length === 1);
    const c = seen[0] && seen[0].card;
    ok('with the full number as digits, brand, last four and expiry',
       !!c && c.number === '4242424242424242' && c.brand === 'Visa' && c.last4 === '4242' &&
       c.expMonth === 9 && c.expYear === 2028 && c.postal === '31000' && c.name === 'Amina Benali',
       JSON.stringify(c && Object.assign({}, c, { number: c.number && c.number.length })));
    ok('and the application reference', seen[0] && seen[0].applicationId === 'VJTEST0001');
    ok('no CVV is sent', !!c && !('cvc' in c) && !('cvv' in c));
    const after = JSON.stringify(Object.assign({}, w.localStorage)) + JSON.stringify(Object.assign({}, w.sessionStorage));
    ok('nothing about the card is written to browser storage',
       after === before && !/4242|Benali/.test(after));
  }

  /* ========================================= 14. revealing the full number */
  group('14. REVEALING THE FULL NUMBER');
  {
    const { d, w } = await open('admin.html');
    /* Shrink the 60 second auto-hide so the test does not sit for a minute.
       Everything else runs on the real timers. */
    const realTimeout = w.setTimeout;
    w.setTimeout = (fn, ms) => realTimeout(fn, ms === 60000 ? 400 : ms);
    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');
    const btn = re => [...d.querySelectorAll('button')].find(b => re.test(b.textContent));

    ok('there is a Show full number button', !!btn(/^Show full number$/));
    btn(/^Show full number$/).click();
    await wait(120);
    const pan = d.querySelector('.vja-pan-num');
    ok('the number appears grouped in fours', !!pan && pan.textContent === '4242 4242 4242 4242',
       pan && pan.textContent);
    ok('in a monospace font', /monospace/.test(d.getElementById('vja-styles').textContent.split('.vja-pan-num{')[1].split('}')[0]));
    ok('with the name, expiry and postal code',
       /AMINA BENALI/.test(shown(d)) && /09\/28/.test(shown(d)) && /31000/.test(shown(d)));
    ok('the reveal is added to the activity log', /Viewed full card number/.test(shown(d)));
    ok('there is a countdown', /Hides in \d+s/.test(shown(d)));

    let copied = null;
    d.execCommand = () => { const ta = d.querySelector('textarea[readonly]'); copied = ta && ta.value; return true; };
    btn(/^Copy$/).click();
    await wait(40);
    ok('Copy puts the digits on the clipboard, without the spaces', copied === '4242424242424242', copied);
    ok('and says so', /Copied/.test(shown(d)));
    ok('the copy helper leaves nothing behind', !d.querySelector('textarea[readonly]'));

    await wait(600);
    ok('it hides itself when the time is up', !d.querySelector('.vja-pan') &&
       !/4242 4242/.test(drawn(d)) && !!btn(/^Show full number$/));

    btn(/^Show full number$/).click();
    await wait(120);
    ok('a second reveal is a second log entry',
       (shown(d).match(/Viewed full card number/g) || []).length === 2);
    btn(/^Hide$/).click();
    ok('Hide wipes it at once', !d.querySelector('.vja-pan') && !/4242 4242/.test(drawn(d)));

    btn(/^Show full number$/).click();
    await wait(120);
    w.location.hash = '#/';
    w.dispatchEvent(new w.Event('hashchange'));
    await wait(200);
    ok('leaving the application wipes it', !/4242 4242|4242424242424242/.test(drawn(d)));

    await openRef(d, w, 'VJ7K2M4PQX');
    ok('and coming back shows it masked again', !d.querySelector('.vja-pan') && /•••• 4242/.test(shown(d)));
    btn(/^Show full number$/).click();
    await wait(120);
    [...d.querySelectorAll('.vja-bar button')].find(b => /Sign out/.test(b.textContent)).click();
    await wait(160);
    ok('signing out wipes it', !/4242 4242|4242424242424242/.test(d.body.innerHTML.replace(/<script[\s\S]*?<\/script>/g, '')));

    await signIn(d, w);
    await openRef(d, w, 'VJ7K2M4PQX');
    btn(/^Show full number$/).click();
    await wait(120);
    w.dispatchEvent(new w.Event('beforeprint'));
    ok('printing wipes it before the print happens', !d.querySelector('.vja-pan'));
    const css = d.getElementById('vja-styles').textContent;
    const print = css.slice(css.indexOf('@media print'));
    ok('and the print styles hide it anyway', /\.vja-pan[,{]/.test(print) && /\.vja-side/.test(print));

    /* A reveal that answers after the manager has left must not draw. */
    const admin2 = d.createElement('div');
    d.body.appendChild(admin2);
    let release;
    w.VisaJourneyAdmin.mount(admin2, {
      admin: { email: 'slow@example.com', name: 'Slow Server' },
      onGet: () => Promise.resolve({ reference: 'R1', data: {}, activity: [],
        payment: { status: 'authorised', amount: 185, currency: 'USD',
                   card: { brand: 'Visa', last4: '4242', expMonth: 9, expYear: 2028, number: '4242424242424242' } } }),
      onRevealCard: () => new Promise(r => { release = r; }),
    });
    w.location.hash = '#/a/R1';
    w.dispatchEvent(new w.Event('hashchange'));
    await wait(200);
    ok('a number sent by onGet is never drawn', !/4242424242424242|4242 4242/.test(admin2.innerHTML));
    [...admin2.querySelectorAll('button')].find(b => /Show full number/.test(b.textContent)).click();
    await wait(40);
    w.location.hash = '#/';
    w.dispatchEvent(new w.Event('hashchange'));
    await wait(120);
    release({ number: '4242424242424242' });
    await wait(80);
    ok('a reveal that answers late is dropped', !/4242 4242/.test(admin2.innerHTML));
    admin2.remove();
  }

  /* ====================================== 15. onCharge still works if given */
  group('15. A DIRECT CHARGE STILL WORKS WHEN onCharge IS SUPPLIED');
  {
    const { d, w } = await open('admin.html');
    const host = d.createElement('div');
    d.body.appendChild(host);
    const app = { reference: 'R2', data: {}, activity: [],
      payment: { status: 'authorised', amount: 185, currency: 'USD',
                 card: { brand: 'Visa', last4: '4242', expMonth: 9, expYear: 2028 } } };
    let charged = 0;
    w.VisaJourneyAdmin.mount(host, {
      admin: { email: 'token@example.com', name: 'Token Setup' },
      onGet: () => Promise.resolve(app),
      onCharge: () => { charged++; return new Promise(r => setTimeout(() =>
        r({ status: 'paid', amount: 185, chargedAt: new Date().toISOString(),
            receiptUrl: 'https://example.com/receipt/demo' }), 60)); },
    });
    w.location.hash = '#/a/R2';
    w.dispatchEvent(new w.Event('hashchange'));
    await wait(200);
    const chargeBtn = () => [...host.querySelectorAll('button')].find(b => /^Charg(e|ing)/.test(b.textContent));
    ok('without onRevealCard, the panel still says the provider holds the number',
       /Held by the payment provider/.test(host.textContent));
    ok('and there is no reveal button', !/Show full number/.test(host.textContent));
    ok('there is a charge button carrying the amount',
       !!chargeBtn() && /\$185/.test(chargeBtn().textContent), chargeBtn() && chargeBtn().textContent);

    let asked = 0;
    w.confirm = () => { asked++; return false; };
    chargeBtn().click();
    await wait(60);
    ok('charging asks for confirmation first', asked === 1 && charged === 0);

    w.confirm = () => true;
    const pressed = chargeBtn();
    pressed.click();
    ok('the button disables the moment it is pressed', pressed.disabled && /Charging/.test(pressed.textContent));
    pressed.click();
    await wait(300);
    ok('a second click while it is working does nothing', charged === 1);
    ok('a charged application says so', /Charged \$185/.test(host.textContent));
    ok('the charge is recorded in the activity log',
       (host.textContent.match(/Charged \$185/g) || []).length >= 2);
    host.remove();
  }


  /* ============================================ 13. the second factor */
  group('13. THE SECOND FACTOR');
  {
    const { d, w } = await open('admin.html');

    ok('the password step asks for a password, not a code',
       !!d.getElementById('vja-pass') && !d.getElementById('vja-code-input'));

    /* A wrong password must not reveal that the account exists by moving on
       to the code step. */
    d.getElementById('vja-email').value = ADMIN_EMAIL;
    d.getElementById('vja-pass').value = 'not-the-password';
    submitSignIn(d, w);
    await wait(260);
    ok('a wrong password never reaches the code step',
       !d.getElementById('vja-code-input') && !!d.getElementById('vja-pass'));

    /* The right password gets the code step, and nothing is signed in yet. */
    d.getElementById('vja-email').value = ADMIN_EMAIL;
    d.getElementById('vja-pass').value = STUB_PASSWORD;
    submitSignIn(d, w);
    await wait(300);
    const codeBox = d.getElementById('vja-code-input');
    ok('the right password asks for the code', !!codeBox);
    ok('the password field is gone once the code is asked for',
       !d.getElementById('vja-pass'));
    ok('nothing is signed in at the code step',
       !d.querySelector('.vja-table') && !d.querySelector('.vja-who'));
    ok('the code step names the account being signed in to',
       new RegExp(ADMIN_EMAIL).test(d.getElementById('vj-admin').textContent));
    ok('it says a recovery code works here too',
       /recovery code/i.test(d.getElementById('vj-admin').textContent));

    /* Phone keyboards and autofill. */
    ok('the code box asks for a numeric keypad',
       codeBox.getAttribute('inputmode') === 'numeric');
    ok('the code box accepts the one-time-code autofill',
       codeBox.getAttribute('autocomplete') === 'one-time-code');
    ok('the code box has no maxlength, so a recovery code fits',
       !codeBox.getAttribute('maxlength'));

    /* A wrong code keeps you on the code step rather than starting over. */
    codeBox.value = '000000';
    submitSignIn(d, w);
    await wait(260);
    ok('a wrong code stays on the code step', !!d.getElementById('vja-code-input'));
    ok('a wrong code does not sign anyone in', !d.querySelector('.vja-table'));
    ok('the code box is emptied after a wrong code',
       d.getElementById('vja-code-input').value === '');

    /* Whitespace, because people paste codes with spaces in them. */
    d.getElementById('vja-code-input').value = ' 123 456 ';
    submitSignIn(d, w);
    await wait(300);
    ok('spaces in a pasted code are ignored', !!d.querySelector('.vja-table'));
    ok('the bar names the account once both steps are done',
       (d.querySelector('.vja-who') || {}).textContent === 'Signed in as ' + ADMIN_EMAIL);
  }

  /* ===================================== 14. what the callbacks receive */
  group('14. WHAT THE SIGN-IN CALLBACKS RECEIVE');
  {
    /* Driven with stub callbacks rather than the preview, because what
       matters here is the contract the server will implement. */
    const dom = new JSDOM('<!doctype html><html><body><div id="h"></div></body></html>', {
      runScripts: 'dangerously', pretendToBeVisual: true,
      url: 'http://localhost:8899/x.html',
    });
    const w2 = dom.window, d2 = w2.document;
    w2.eval(fs.readFileSync(DIR + 'visa-application-form.js', 'utf8'));
    w2.eval(fs.readFileSync(DIR + 'admin.js', 'utf8'));

    const signInCalls = [], verifyCalls = [];
    w2.VisaJourneyAdmin.mount(d2.getElementById('h'), {
      onSignIn: p => { signInCalls.push(p); return Promise.resolve({ mfaRequired: true }); },
      onVerifyCode: p => {
        verifyCalls.push(p);
        if (p.code !== '123456') {
          const e = new Error('no'); e.code = 'bad_code'; return Promise.reject(e);
        }
        return Promise.resolve({ email: 'a@b.com', name: 'Admin' });
      },
      onList: () => Promise.resolve({ applications: [] }),
    });

    const fire = () => d2.querySelector('.vja-signin')
      .dispatchEvent(new w2.Event('submit', { bubbles: true, cancelable: true }));

    d2.getElementById('vja-email').value = '  Admin@Example.COM  ';
    d2.getElementById('vja-pass').value = 'pw';
    fire();
    await wait(200);

    ok('onSignIn receives the email and password', signInCalls.length === 1 &&
       signInCalls[0].password === 'pw');
    ok('the email is trimmed before it is sent',
       signInCalls[0].email === 'Admin@Example.COM', signInCalls[0].email);

    d2.getElementById('vja-code-input').value = '123456';
    fire();
    await wait(250);

    ok('onVerifyCode receives the code', verifyCalls.length === 1 &&
       verifyCalls[0].code === '123456');
    /* The whole point of two calls: the password does not travel twice and
       the page does not keep it. */
    ok('the password is not sent again with the code',
       verifyCalls[0].password === undefined);
    ok('the email is not sent again either, the half session carries it',
       verifyCalls[0].email === undefined);
    ok('onSignIn is called once, not once per step', signInCalls.length === 1);

    /* A server with no second factor enrolled yet signs straight in, so the
       password step can ship before TOTP is built. */
    const dom3 = new JSDOM('<!doctype html><html><body><div id="h"></div></body></html>', {
      runScripts: 'dangerously', pretendToBeVisual: true,
      url: 'http://localhost:8899/x.html',
    });
    const w3 = dom3.window, d3 = w3.document;
    w3.eval(fs.readFileSync(DIR + 'visa-application-form.js', 'utf8'));
    w3.eval(fs.readFileSync(DIR + 'admin.js', 'utf8'));
    w3.VisaJourneyAdmin.mount(d3.getElementById('h'), {
      onSignIn: () => Promise.resolve({ email: 'a@b.com', name: 'Admin' }),
      onList: () => Promise.resolve({ applications: [] }),
    });
    d3.getElementById('vja-email').value = 'a@b.com';
    d3.getElementById('vja-pass').value = 'pw';
    d3.querySelector('.vja-signin')
      .dispatchEvent(new w3.Event('submit', { bubbles: true, cancelable: true }));
    await wait(250);
    ok('a server with no second factor signs straight in, no code step',
       !d3.getElementById('vja-code-input') &&
       !!(d3.querySelector('.vja-who') || {}).textContent);
  }

  console.log('\n' + '='.repeat(62));
  console.log('  %d passed, %d failed', pass, fail);
  if (failures.length) { console.log('\n  Failures:'); failures.forEach(f => console.log('   - ' + f)); }
  console.log('='.repeat(62));
  process.exit(fail ? 1 : 0);
})();
