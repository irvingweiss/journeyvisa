#!/usr/bin/env python3
"""Fold the six built pages into a single self-contained HTML file.

Why: a multi-file site needs a server or a folder to work. One file with the CSS,
the JS and every page inlined opens anywhere, including straight out of a download,
and clicking around it works. That is what you present from.

Run after build.py.
"""

import re, os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = HERE
OUT = os.path.join(HERE, "..", "preview", "visa-journey-usa.html")

# The output folder may not exist on a fresh checkout, and writing into a missing
# directory should not fail a build.
_outdir = os.path.dirname(OUT)
if _outdir:
    os.makedirs(_outdir, exist_ok=True)
ROUTES = [
    ("index.html", "home"),
    ("about-us.html", "about"),
    ("contact-us.html", "contact"),
    ("application.html", "application"),
    ("terms-and-conditions.html", "terms"),
    ("privacy-policy.html", "privacy"),
    ("payment.html", "payment"),
    ("resume.html", "resume"),
    ("b1-b2-visitor-visa.html", "b1b2"),
    ("ds-160-help.html", "ds160"),
    ("visa-interview-preparation.html", "interview"),
    ("us-visa-renewal.html", "renewal"),
    ("visiting-family-in-usa.html", "family"),
    ("business-visitor-visa.html", "business"),
]

HOME_ANCHORS = ["what-we-do", "how-it-works", "faq"]


def main_of(path):
    s = open(os.path.join(SRC, path)).read()
    m = re.search(r'<main id="main">(.*?)</main>', s, re.S)
    return m.group(1)


def inline_hero(html):
    return html.replace('src="hero.svg"', 'src="' + HERO_DATA_URI + '"')


def rewrite_links(html):
    # in-page anchors on the homepage first, so they are not eaten by the page rule
    for a in HOME_ANCHORS:
        html = html.replace('href="index.html#%s"' % a, 'href="#home-%s"' % a)
        html = html.replace('href="#%s"' % a, 'href="#home-%s"' % a)
    for page, route in ROUTES:
        html = html.replace('href="%s"' % page, 'href="#%s"' % route)
    return html


def rewrite_home_ids(html):
    for a in HOME_ANCHORS:
        html = html.replace('id="%s"' % a, 'id="home-%s"' % a)
    return html


css = open(os.path.join(SRC, "site.css")).read()

# The hero illustration goes in as a data URI so the single file stays a single
# file. Base64 rather than inline SVG markup, which would let the illustration's
# internal ids collide with anything else on the page.
import base64
HERO_DATA_URI = "data:image/svg+xml;base64," + base64.b64encode(
    open(os.path.join(SRC, "hero.svg"), "rb").read()).decode("ascii")
site_js = open(os.path.join(SRC, "site.js")).read()

bodies = {}
for page, route in ROUTES:
    body = main_of(page)
    if route == "home":
        body = rewrite_home_ids(body)
    bodies[route] = inline_hero(rewrite_links(body))

# The three widget routes get plain containers here. Their <script src> tags make
# no sense in a single file, so the modules are inlined once at the end instead
# and mounted lazily when the route is first opened.

bodies["application"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Your application</h1>
      <p class="lede">Short sections, saved as you go. You get a reference number on the first screen, and that is how you come back to it later.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="visa-application"></div></div>
  </section>
"""

bodies["payment"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Payment</h1>
      <p class="lede">Your preparation fee. The government fee is separate and is paid directly to the government when you book your interview.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="payment"></div></div>
  </section>
"""

bodies["resume"] = """
  <section class="app-head">
    <div class="wrap">
      <h1>Return to your application</h1>
      <p class="lede">Enter your reference number and answer your security question to pick up where you left off.</p>
    </div>
  </section>
  <section class="widget-band">
    <div class="wrap"><div id="resume"></div></div>
  </section>
"""

MARK = """<svg class="mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
  <rect x="1" y="1" width="30" height="30" rx="9" fill="#0f766e"/>
  <circle cx="16" cy="16" r="8.5" fill="none" stroke="#ffffff" stroke-width="1.4" stroke-dasharray="2.2 2.2"/>
  <path d="M11.5 16.6l3 3 6-6.6" fill="none" stroke="#ffffff" stroke-width="1.9"
        stroke-linecap="round" stroke-linejoin="round"/>
</svg>"""

NAV = [("#home", "Home"), ("#b1b2", "B1/B2 visa"), ("#ds160", "DS-160 help"),
       ("#interview", "Interview prep"), ("#about", "About"), ("#contact", "Contact")]

nav_links = "".join('<a href="%s" data-nav="%s">%s</a>' % (h, h[1:], t) for h, t in NAV)
mobile_links = "".join('<a href="%s" data-nav="%s">%s</a>' % (h, h[1:], t) for h, t in NAV)

routes_html = "\n".join(
    '<section class="route" id="route-%s"%s>%s</section>' % (r, "" if r == "home" else " hidden", bodies[r])
    for _, r in ROUTES
)

EXTRA_CSS = """
/* ------------------------------------------------- single-file extras */

.route[hidden] { display: none; }

"""

ROUTER_JS = """
/* ------------------------------------------------------------------ router
   Six pages in one file. Hash decides which is visible. Anchors inside the
   homepage still work: #home-faq shows the homepage, then scrolls. */

(function () {
  var ROUTES = ["home", "about", "contact", "application", "payment", "resume", "terms",
                "privacy", "b1b2", "ds160", "interview", "renewal", "family", "business"];

  function resolve() {
    /* The form appends ?ref=... to whatever paymentUrl it is given, so strip a
       query string before matching. */
    var hash = (location.hash || "").replace(/^#/, "").split("?")[0];
    var route = "home", anchor = null;
    for (var i = 0; i < ROUTES.length; i++) {
      var r = ROUTES[i];
      if (hash === r) { route = r; break; }
      if (hash.indexOf(r + "-") === 0) { route = r; anchor = hash; break; }
    }
    return { route: route, anchor: anchor };
  }

  function show() {
    var target = resolve();

    ROUTES.forEach(function (r) {
      var el = document.getElementById("route-" + r);
      if (el) el.hidden = (r !== target.route);
    });

    document.querySelectorAll("[data-nav]").forEach(function (a) {
      if (a.getAttribute("data-nav") === target.route) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });

    var nav = document.getElementById("mobile-nav");
    var toggle = document.getElementById("menu-toggle");
    if (nav) nav.classList.remove("is-open");
    if (toggle) toggle.setAttribute("aria-expanded", "false");

    if (typeof window.__mountRoute === "function") window.__mountRoute(target.route);

    if (target.anchor) {
      var el = document.getElementById(target.anchor);
      if (el) { el.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
    }
    window.scrollTo({ top: 0, behavior: "auto" });
  }

  window.addEventListener("hashchange", show);
  show();
})();
"""

FORM_JS = open(os.path.join(SRC, "visa-application-form.js")).read()
PAYMENT_JS = open(os.path.join(SRC, "payment-step.js")).read()

WIDGET_JS = r"""
/* ----------------------------------------------------------- widgets
   The real application form and payment step, mounted the first time
   their route is opened. Everything here runs in demo mode: nothing is
   saved anywhere and no payment is taken. */

(function () {
  var mounted = {};
  var lastRef = "";

  function ref() {
    return "DEMO" + Math.random().toString(36).slice(2, 8).toUpperCase();
  }

  function previewNotSent() {
    var e = new Error("preview: no email sent");
    e.userMessage = "This is a preview, so no email was actually sent.";
    return e;
  }

  window.__mountRoute = function (route) {
    if (mounted[route]) return;

    if (route === "application" && window.VisaJourneyForm) {
      var app = VisaJourneyForm.mount(document.getElementById("visa-application"), {
        draftCache: "session",
        onCreateApplication: function () { return Promise.resolve({ applicationId: ref() }); },
        onSaveStep: function () { return Promise.resolve(); },
        /* The preview sends no mail, so it says so rather than showing a
           confirmation for an email that never left. */
        onRequestResumeLink: function () { return Promise.reject(previewNotSent()); },
        onEmailReference: function () { return Promise.reject(previewNotSent()); },
        paymentUrl: "#payment",
        onSubmit: function () {
          lastRef = app.getApplicationId ? app.getApplicationId() : "";
          return Promise.resolve();
        }
      });
      mounted.application = true;
    }

    if (route === "payment" && window.VisaJourneyPayment) {
      var pay = document.getElementById("payment");
      /* Same mode as payment.html: the card is saved for a later charge,
         and the fields are on the page. Nothing leaves the browser here. */
      VisaJourneyPayment.mount(pay, {
        applicationId: lastRef,
        serviceFee: 185,
        governmentFee: 185,
        chargeLater: true,
        collectCard: true,
        onBack: function () { window.location.hash = "#application"; },
        /* The preview hands a TEST card to the admin preview
           (visa-journey-admin.html, published beside this file), so the
           whole journey can be tried before there is a server: save a card
           here, then sign in to the admin preview, reveal it, and record the
           charge. Only the card networks' published test numbers are
           accepted, so a real card typed in here is refused rather than
           written to the browser. The real payment.html never stores card
           details in the browser; it posts them to POST /api/application/card. */
        onSaveCard: function (payload) {
          var c = (payload && payload.card) || {};
          var TEST_NUMBERS = ["4242424242424242", "4000056655665556", "4111111111111111",
                              "5555555555554444", "2223003122003222", "5105105105105100",
                              "378282246310005", "371449635398431",
                              "6011111111111117", "6011000990139424"];
          if (TEST_NUMBERS.indexOf(String(c.number || "")) === -1) {
            var e = new Error("not a test card");
            e.userMessage = "This preview only takes test card numbers, such as 4242 4242 4242 4242. " +
              "Do not type a real card into the preview.";
            return Promise.reject(e);
          }
          var reference = lastRef || "VJPREVIEW1";
          try {
            window.localStorage.setItem("vj-preview-card", JSON.stringify({
              reference: reference, name: c.name, number: c.number,
              expMonth: c.expMonth, expYear: c.expYear, postal: c.postal || "",
              brand: c.brand, last4: c.last4, savedAt: new Date().toISOString()
            }));
          } catch (err) { /* private browsing: the admin preview just won't see it */ }
          pay.innerHTML =
            '<div class="app-fallback" style="text-align:center">' +
            "<h2>Test card saved (preview)</h2>" +
            '<p class="p" style="margin-left:auto;margin-right:auto">Nothing was charged and nothing left this browser. ' +
            "On the live site this is the moment the card is encrypted and stored on the server.</p>" +
            '<p class="p" style="margin-left:auto;margin-right:auto">Next, open the admin preview and find application <strong>' +
            reference + "</strong>. The card shows masked until you press Show full number.</p>" +
            '<p style="margin-top:1.5rem"><a class="btn btn-primary" href="visa-journey-admin.html">Open the admin preview</a> ' +
            '<a class="btn btn-quiet" href="#home">Back to the homepage</a></p>' +
            "</div>";
          window.scrollTo({ top: 0, behavior: "smooth" });
          return Promise.resolve();
        }
      });
      mounted.payment = true;
    }

    if (route === "resume" && window.VisaJourneyForm) {
      VisaJourneyForm.mountResume(document.getElementById("resume"), {
        onLookup: function () { return Promise.resolve({ securityPrompt: "What was the name of your first pet?" }); },
        /* Returns the saved answers, which is what makes resuming actually
           resume. The widget reopens the form in place with them. */
        onResume: function (payload) {
          return Promise.resolve({
            applicationId: payload.applicationId,
            stepIndex: 2,
            data: {
              surnames: "OKAFOR", givenNames: "ADA", sex: "Female",
              maritalStatus: "Married", nationality: "NIGERIA"
            }
          });
        },
        paymentUrl: "#payment",
        onSaveStep: function () { return Promise.resolve(); },
        onSubmit: function () { return Promise.resolve(); }
      });
      mounted.resume = true;
    }
  };
})();
"""

html = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Visa Journey USA | B1/B2 visitor visa preparation and review</title>
<meta name="description" content="A private preparation and review service for U.S. B1/B2 visitor visa applications. Guided questions through the whole B1/B2 form, and a real review before you file.">
<meta name="robots" content="index,follow">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&display=swap" rel="stylesheet">

<style>
__CSS__
</style>
</head>

<body class="vj-site">

<div class="notice-bar">
  <div class="wrap">
    <p><strong>Visa Journey USA is a private preparation service.</strong> We are not affiliated with, endorsed by, or connected to the U.S. Department of State or any government agency. You can apply directly at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a> and pay only the government fee. Our fee is separate, and is charged for preparing and reviewing your application. We do not influence, expedite, or guarantee any visa decision.</p>
  </div>
</div>

<header class="site-header">
  <div class="header-in wrap">
    <a class="brand" href="#home">__MARK__<span class="brand-name">Visa Journey <em>USA</em></span></a>
    <nav class="nav" aria-label="Main">
      __NAV__
      <a class="btn btn-primary btn-sm" href="#application">Start your application</a>
    </nav>
    <button class="menu-btn" type="button" id="menu-toggle" aria-expanded="false" aria-controls="mobile-nav">
      <span class="menu-bars" aria-hidden="true"></span>
      <span class="sr-only">Menu</span>
    </button>
  </div>
  <nav class="mobile-nav" id="mobile-nav" aria-label="Main, mobile">
    __MOBILE__
    <a href="#terms">Terms and conditions</a>
    <a href="#privacy">Privacy policy</a>
    <a class="btn btn-primary" href="#application">Start your application</a>
  </nav>
</header>

<main id="main">
__ROUTES__
</main>

<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <a class="brand brand-light" href="#home">__MARK__<span class="brand-name">Visa Journey <em>USA</em></span></a>
        <p class="footer-blurb">A private preparation and review service for U.S. B1/B2 visitor visa applications.</p>
      </div>

      <div>
        <h2>Visa help</h2>
        <ul>
          <li><a href="#b1b2">B1/B2 visitor visa</a></li>
          <li><a href="#ds160">DS-160 help</a></li>
          <li><a href="#interview">Interview preparation</a></li>
          <li><a href="#renewal">Visa renewal</a></li>
          <li><a href="#family">Visiting family in the USA</a></li>
          <li><a href="#business">Business visitor visa</a></li>
        </ul>
      </div>

      <div>
        <h2>Service</h2>
        <ul>
          <li><a href="#application">Start your application</a></li>
          <li><a href="#home-how-it-works">How it works</a></li>
          <li><a href="#home-faq">Common questions</a></li>
          <li><a href="#resume">Return to an application</a></li>
        </ul>
      </div>

      <div>
        <h2>Company</h2>
        <ul>
          <li><a href="#about">About us</a></li>
          <li><a href="#contact">Contact us</a></li>
          <li><a href="#terms">Terms and conditions</a></li>
          <li><a href="#privacy">Privacy policy</a></li>
        </ul>
      </div>

      <div>
        <h2>Get in touch</h2>
        <!-- EDIT: add the registered legal entity name and state of registration
             on the line below, plus a phone number if you have one. -->
        <address>
          Visa Journey USA<br>
          1175 West Broadway, Suite 33<br>
          Hewlett, NY 11557<br>
          <a href="mailto:support@visajourneyusa.com">support@visajourneyusa.com</a>
        </address>
      </div>
    </div>

    <div class="footer-legal">
      <p>Visa Journey USA is a private preparation and review service. We are not a law firm, we do not provide legal advice, and we are not affiliated with, endorsed by, or connected to the U.S. Department of State, U.S. Citizenship and Immigration Services, or any other government agency.</p>
      <p>You can complete and submit a visa application yourself at no cost beyond the government fee at <a href="https://travel.state.gov" rel="noopener">travel.state.gov</a>. Our fee is charged for preparation and review and is separate from any government fee. We do not influence, expedite, or guarantee the outcome of any visa application.</p>
      <p class="copyright">&copy; 2026 Visa Journey USA. All rights reserved.</p>
    </div>
  </div>
</footer>

<script>
__FORMJS__
</script>

<script>
__PAYMENTJS__
</script>

<script>
__SITEJS__
__WIDGETJS__
__ROUTERJS__
</script>

</body>
</html>
"""

html = (html
        .replace("__CSS__", css + EXTRA_CSS)
        .replace("__MARK__", MARK)
        .replace("__NAV__", nav_links)
        .replace("__MOBILE__", mobile_links)
        .replace("__ROUTES__", routes_html)
        .replace("__FORMJS__", FORM_JS)
        .replace("__PAYMENTJS__", PAYMENT_JS)
        .replace("__SITEJS__", site_js)
        .replace("__WIDGETJS__", WIDGET_JS)
        .replace("__ROUTERJS__", ROUTER_JS))

open(OUT, "w").write(html)
print("wrote", OUT, len(html), "bytes")


# ---------------------------------------------------------------- admin preview
#
# The admin screen as one self-contained file, separate from the public preview
# above on purpose: it is not part of the site and should not be reachable by
# clicking around it. Open it directly to review the admin screens before
# there is a server.

ADMIN_OUT = os.path.join(HERE, "..", "preview", "visa-journey-admin.html")

admin_src = open(os.path.join(SRC, "admin.html")).read()
admin_js = open(os.path.join(SRC, "admin.js")).read()


def inline_safe(js):
    """A literal </script> anywhere in a file, even inside a comment or a string,
    ends the tag when that file is inlined, and the rest of the page becomes
    text. It cost one silent blank preview to learn. The escape is invisible to
    the parser and leaves the code identical."""
    return js.replace("</script", "<\\/script")

admin_html = admin_src.replace(
    '<link rel="stylesheet" href="site.css">',
    "<style>\n" + css + "\n</style>")
admin_html = admin_html.replace(
    '<script src="visa-application-form.js"></script>',
    "<script>\n" + inline_safe(FORM_JS) + "\n</script>")
admin_html = admin_html.replace(
    '<script src="admin.js"></script>',
    "<script>\n" + inline_safe(admin_js) + "\n</script>")

# Say what it is on the way in. Someone opening this file months from now should
# not have to guess whether the applications in it are real.
admin_html = admin_html.replace(
    "<title>Admin | Visa Journey USA</title>",
    "<title>Admin preview | Visa Journey USA</title>")
admin_html = admin_html.replace(
    '<div id="vj-admin"></div>',
    '<div style="background:#fffbeb;border-bottom:1px solid #fde68a;padding:.625rem 1.25rem;'
    'font:400 13px/1.5 -apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,sans-serif;color:#92400e">'
    '<strong>Preview.</strong> Sign in with the admin account. The demo applications are invented and '
    'nothing is saved. A test card saved on the payment step of the site preview shows up here as one more application. Reference numbers, names and passport numbers here are made up, and the '
    'card numbers are the card networks\' public test numbers.'
    "</div>\n  <div id=\"vj-admin\"></div>")

# The test card saved in the public preview, if there is one, becomes a fifth
# application here, so the payment -> reveal -> mark-charged journey can be
# tried end to end before there is a server. Preview only: the real admin.html
# never reads card data from the browser.
PREVIEW_CARD_JS = """
    var DEMO_REVEAL_LOG = [];

    /* PREVIEW ONLY (bundle.py). A test card saved in visa-journey-usa.html. */
    var PREVIEW_REF = null;
    (function () {
      var saved = null;
      try { saved = JSON.parse(window.localStorage.getItem("vj-preview-card") || "null"); }
      catch (e) { saved = null; }
      if (!saved || !saved.number || !saved.reference) return;
      PREVIEW_REF = String(saved.reference).toUpperCase();
      var parts = String(saved.name || "TEST APPLICANT").toUpperCase().split(" ");
      var now = new Date().toISOString();
      DEMO_APPS[PREVIEW_REF] = {
        reference: PREVIEW_REF, applicantName: String(saved.name || "Test applicant"),
        status: "New", stepIndex: 21,
        createdAt: saved.savedAt || now, updatedAt: saved.savedAt || now, submittedAt: saved.savedAt || now,
        payment: {
          status: "authorised", amount: 185, currency: "USD",
          card: { brand: saved.brand, last4: saved.last4, expMonth: Number(saved.expMonth),
                  expYear: Number(saved.expYear), numberOnFile: true }
        },
        notes: [],
        activity: [{ author: "Applicant", at: saved.savedAt || now, action: "Saved a card for the fee" }],
        data: { surnames: parts.slice(-1)[0], givenNames: parts.slice(0, -1).join(" "), certify: true }
      };
      DEMO_CARDS[PREVIEW_REF] = {
        number: saved.number, name: String(saved.name || "").toUpperCase(),
        expMonth: Number(saved.expMonth), expYear: Number(saved.expYear), postal: saved.postal || ""
      };
    })();
"""
if admin_html.count("    var DEMO_REVEAL_LOG = [];\n") != 1:
    raise SystemExit("admin preview: DEMO_REVEAL_LOG anchor not found")
admin_html = admin_html.replace("    var DEMO_REVEAL_LOG = [];\n", PREVIEW_CARD_JS, 1)
if admin_html.count("delete DEMO_CARDS[payload.reference];") != 1:
    raise SystemExit("admin preview: onMarkCharged anchor not found")
admin_html = admin_html.replace(
    "delete DEMO_CARDS[payload.reference];",
    "delete DEMO_CARDS[payload.reference];\n"
    "          if (payload.reference === PREVIEW_REF) {\n"
    "            try { window.localStorage.removeItem(\"vj-preview-card\"); } catch (e) {}\n"
    "          }", 1)

if any(tag in admin_html for tag in ('href="site.css"', 'src="admin.js"',
                                     'src="visa-application-form.js"')):
    raise SystemExit("admin preview still references an external file")

# Exactly three script blocks and one style block, so a stray closing tag inside
# an inlined file shows up here rather than as a blank page.
if admin_html.count("</script>") != 3:
    raise SystemExit("admin preview has %d closing script tags, expected 3"
                     % admin_html.count("</script>"))

open(ADMIN_OUT, "w").write(admin_html)
print("wrote", ADMIN_OUT, len(admin_html), "bytes")
