#!/usr/bin/env python3
"""Turn the built pages into a Netlify deploy folder.

Differences from the local folder:
  - links point at clean URLs (/about-us, not about-us.html), which is what
    Netlify serves and what the canonical tags already claim
  - favicon, robots.txt, sitemap.xml, 404 page
  - netlify.toml with security and cache headers

Run after build.py.
"""

import os, re, shutil, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = HERE
OUT = os.path.join(HERE, "..", "deploy")

if os.path.isdir(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)

SITE = "https://www.visajourneyusa.com"

CLEAN = {
    "index.html": "/",
    "about-us.html": "/about-us",
    "contact-us.html": "/contact-us",
    "application.html": "/application",
    "terms-and-conditions.html": "/terms-and-conditions",
    "privacy-policy.html": "/privacy-policy",
    "payment.html": "/payment",
    "resume.html": "/resume",
    "b1-b2-visitor-visa.html": "/b1-b2-visitor-visa",
    "ds-160-help.html": "/ds-160-help",
    "visa-interview-preparation.html": "/visa-interview-preparation",
    "us-visa-renewal.html": "/us-visa-renewal",
    "visiting-family-in-usa.html": "/visiting-family-in-usa",
    "business-visitor-visa.html": "/business-visitor-visa",
}

HEAD_EXTRA = """<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/favicon.svg">
"""

pages = [f for f in sorted(os.listdir(SRC)) if f.endswith(".html")]

for f in pages:
    s = open(os.path.join(SRC, f)).read()

    # clean URLs
    for page, url in CLEAN.items():
        s = s.replace('href="%s"' % page, 'href="%s"' % url)
        s = s.replace('href="%s#' % page, 'href="%s#' % url)

    # absolute asset paths, so a page at /about-us still finds them
    s = s.replace('href="site.css"', 'href="/site.css"')
    s = s.replace('src="hero.svg"', 'src="/hero.svg"')
    s = s.replace('src="site.js"', 'src="/site.js"')
    s = s.replace('src="visa-application-form.js"', 'src="/visa-application-form.js"')
    s = s.replace('src="payment-step.js"', 'src="/payment-step.js"')

    # navigation written in JS rather than as an href
    s = s.replace('window.location.href = "payment.html?ref="', 'window.location.href = "/payment?ref="')
    s = s.replace('window.location.href = "application.html"', 'window.location.href = "/application"')
    s = s.replace('window.location.replace("resume.html?ref="', 'window.location.replace("/resume?ref="')
    s = s.replace('paymentUrl: "payment.html"', 'paymentUrl: "/payment"')

    # favicon + og:url
    s = s.replace('<link rel="stylesheet" href="/site.css">',
                  HEAD_EXTRA + '<link rel="stylesheet" href="/site.css">')
    canonical = re.search(r'<link rel="canonical" href="([^"]+)">', s)
    if canonical:
        s = s.replace('<meta property="og:type" content="website">',
                      '<meta property="og:type" content="website">\n'
                      '<meta property="og:url" content="%s">' % canonical.group(1))

    open(os.path.join(OUT, f), "w").write(s)

for asset in ("site.css", "site.js", "visa-application-form.js", "payment-step.js", "hero.svg"):
    src = os.path.join(SRC, asset)
    if os.path.exists(src):
        shutil.copy(src, OUT)
    else:
        print("WARNING: missing", asset)

# Some toolchains stamp provenance metadata into SVGs in place, which triples the
# file size and means two copies of the same asset stop matching. Strip any
# <metadata> block on the way out so what ships is the illustration and nothing else.
_hero = os.path.join(OUT, "hero.svg")
if os.path.exists(_hero):
    _svg = open(_hero, encoding="utf-8").read()
    _clean = re.sub(r"<metadata>.*?</metadata>", "", _svg, flags=re.S)
    _clean = re.sub(r'\s+xmlns:c2pa="[^"]*"', "", _clean)
    if _clean != _svg:
        open(_hero, "w", encoding="utf-8").write(_clean)
        print("stripped embedded metadata from hero.svg (%d -> %d bytes)" % (len(_svg), len(_clean)))

# ------------------------------------------------------- cache busting
# The CSS and JS are cached for an hour, at the same URL on every deploy. So a
# redeploy refreshed the HTML but left browsers running the previous
# visa-application-form.js for up to an hour, and nearly every form change lives
# in that file. Someone checking a new release saw the new page shell running the
# old form, and reasonably concluded nothing had changed.
#
# Each asset reference now carries a short hash of the file's contents. A changed
# file gets a new URL, so the browser has no stale copy to reach for. An unchanged
# file keeps its URL and stays cached, which is the whole point of caching it.
import hashlib, datetime

def _short_hash(path):
    return hashlib.sha1(open(path, "rb").read()).hexdigest()[:10]

VERSIONED = ["site.css", "site.js", "visa-application-form.js", "payment-step.js", "hero.svg"]
_hashes = {a: _short_hash(os.path.join(OUT, a)) for a in VERSIONED
           if os.path.exists(os.path.join(OUT, a))}

# One id for the whole release, so anyone can tell at a glance which one is live.
BUILD_ID = hashlib.sha1("".join(sorted(_hashes.values())).encode()).hexdigest()[:10]
BUILD_DATE = datetime.date.today().isoformat()

for page in [x for x in os.listdir(OUT) if x.endswith(".html")]:
    path = os.path.join(OUT, page)
    s = open(path, encoding="utf-8").read()
    for asset, h in _hashes.items():
        s = s.replace('href="/%s"' % asset, 'href="/%s?v=%s"' % (asset, h))
        s = s.replace('src="/%s"' % asset, 'src="/%s?v=%s"' % (asset, h))
    marker = '<meta name="vj-build" content="%s %s">' % (BUILD_DATE, BUILD_ID)
    if 'name="vj-build"' not in s:
        s = s.replace('<meta charset="utf-8">', '<meta charset="utf-8">\n' + marker, 1)
    open(path, "w", encoding="utf-8").write(s)

open(os.path.join(OUT, "BUILD.txt"), "w").write(
    "build %s\ndate  %s\n\n" % (BUILD_ID, BUILD_DATE) +
    "\n".join("%-28s %s" % (a, h) for a, h in sorted(_hashes.items())) + "\n")
print("versioned assets, build", BUILD_ID)


# ------------------------------------------------------------------ favicon
open(os.path.join(OUT, "favicon.svg"), "w").write(
"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <rect width="32" height="32" rx="7" fill="#0f766e"/>
  <circle cx="16" cy="16" r="8.5" fill="none" stroke="#ffffff" stroke-width="1.4" stroke-dasharray="2.2 2.2"/>
  <path d="M11.5 16.6l3 3 6-6.6" fill="none" stroke="#ffffff" stroke-width="2.2"
        stroke-linecap="round" stroke-linejoin="round"/>
</svg>
""")

# ---------------------------------------------------------------- robots.txt
open(os.path.join(OUT, "robots.txt"), "w").write(
"""User-agent: *
Allow: /

Sitemap: %s/sitemap.xml
""" % SITE)

# --------------------------------------------------------------- sitemap.xml
# /payment and /resume are deliberately absent: both are noindex, and neither
# is a page anyone should land on from search.
urls = [("/", "1.0"), ("/application", "0.9"),
        ("/b1-b2-visitor-visa", "0.8"), ("/ds-160-help", "0.8"),
        ("/visa-interview-preparation", "0.8"), ("/us-visa-renewal", "0.7"),
        ("/visiting-family-in-usa", "0.7"), ("/business-visitor-visa", "0.7"),
        ("/about-us", "0.6"), ("/contact-us", "0.6"),
        ("/terms-and-conditions", "0.3"), ("/privacy-policy", "0.3")]
entries = "\n".join(
    "  <url>\n    <loc>%s%s</loc>\n    <lastmod>2026-09-07</lastmod>\n"
    "    <priority>%s</priority>\n  </url>" % (SITE, u, p) for u, p in urls)
open(os.path.join(OUT, "sitemap.xml"), "w").write(
'<?xml version="1.0" encoding="UTF-8"?>\n'
'<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n%s\n</urlset>\n' % entries)

# ------------------------------------------------------------------- 404
notfound = open(os.path.join(OUT, "index.html")).read()
body = re.search(r'<main id="main">(.*?)</main>', notfound, re.S).group(1)
nf_body = """
  <section class="section" style="padding-top:5rem;padding-bottom:6rem">
    <div class="wrap narrow" style="text-align:center">
      <h1>That page is not here</h1>
      <p class="lede" style="margin-left:auto;margin-right:auto">The link may be out of date, or the address may have a typo in it. Everything on the site is reachable from the pages below.</p>
      <div class="btn-row" style="justify-content:center">
        <a class="btn btn-primary" href="/">Go to the homepage</a>
        <a class="btn btn-quiet" href="/contact-us">Contact us</a>
      </div>
      <p style="margin-top:2.5rem;font-size:.9375rem;color:#64748b">
        If you were part-way through an application, go to
        <a href="/application">the application page</a> and use your reference number.
      </p>
    </div>
  </section>
"""
nf = notfound.replace(body, nf_body)
nf = re.sub(r"<title>.*?</title>", "<title>Page not found | Visa Journey USA</title>", nf, flags=re.S)
nf = re.sub(r'<meta name="robots"[^>]*>', '<meta name="robots" content="noindex,follow">', nf)
nf = re.sub(r'<link rel="canonical"[^>]*>\n?', "", nf)
nf = re.sub(r'<script type="application/ld\+json">.*?</script>', "", nf, flags=re.S)
open(os.path.join(OUT, "404.html"), "w").write(nf)

# ---------------------------------------------------------------- netlify.toml
open(os.path.join(OUT, "netlify.toml"), "w").write(
"""# Netlify configuration for Visa Journey USA
#
# Drag-and-drop deploys read this file from the folder root, so nothing here
# needs to be set in the dashboard.

[build]
  publish = "."

# ---------------------------------------------------------------- headers

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "SAMEORIGIN"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
    Permissions-Policy = "camera=(), microphone=(), geolocation=(), interest-cohort=()"
    Strict-Transport-Security = "max-age=31536000; includeSubDomains"

# The HTML is small and changes when you redeploy, so let it revalidate.
[[headers]]
  for = "/*.html"
  [headers.values]
    Cache-Control = "public, max-age=0, must-revalidate"

# CSS and JS are safe to cache hard only once you add a hash to the filename.
# Until then, an hour keeps repeat visits fast without stranding an old build.
[[headers]]
  for = "/site.css"
  [headers.values]
    Cache-Control = "public, max-age=3600"

[[headers]]
  for = "/site.js"
  [headers.values]
    Cache-Control = "public, max-age=3600"

[[headers]]
  for = "/visa-application-form.js"
  [headers.values]
    Cache-Control = "public, max-age=3600"

# --------------------------------------------------------------- redirects

# Old paths keep working if anything already links to the .html versions.
[[redirects]]
  from = "/index.html"
  to = "/"
  status = 301
  force = true

[[redirects]]
  from = "/about-us.html"
  to = "/about-us"
  status = 301
  force = true

[[redirects]]
  from = "/contact-us.html"
  to = "/contact-us"
  status = 301
  force = true

[[redirects]]
  from = "/application.html"
  to = "/application"
  status = 301
  force = true

[[redirects]]
  from = "/terms-and-conditions.html"
  to = "/terms-and-conditions"
  status = 301
  force = true

[[redirects]]
  from = "/privacy-policy.html"
  to = "/privacy-policy"
  status = 301
  force = true

[[redirects]]
  from = "/payment.html"
  to = "/payment"
  status = 301
  force = true

[[redirects]]
  from = "/resume.html"
  to = "/resume"
  status = 301
  force = true

[[redirects]]
  from = "/b1-b2-visitor-visa.html"
  to = "/b1-b2-visitor-visa"
  status = 301
  force = true

[[redirects]]
  from = "/ds-160-help.html"
  to = "/ds-160-help"
  status = 301
  force = true

[[redirects]]
  from = "/visa-interview-preparation.html"
  to = "/visa-interview-preparation"
  status = 301
  force = true

[[redirects]]
  from = "/us-visa-renewal.html"
  to = "/us-visa-renewal"
  status = 301
  force = true

[[redirects]]
  from = "/visiting-family-in-usa.html"
  to = "/visiting-family-in-usa"
  status = 301
  force = true

[[redirects]]
  from = "/business-visitor-visa.html"
  to = "/business-visitor-visa"
  status = 301
  force = true
""")

# ------------------------------------------------------------------- readme
open(os.path.join(OUT, "DEPLOY.md"), "w").write(
"""# Deploying to Netlify

## Drag and drop

Netlify home, then Sites, then drop this whole folder onto the drop zone. Do not
zip it first and do not drop the files individually: Netlify needs the folder so
the paths line up. It goes live in about twenty seconds on a random subdomain,
which is fine for review.

## Or connect a repository

If the code ends up in Git, point Netlify at the repo and use:

    Build command:      (leave empty)
    Publish directory:  .

There is no build step. These are plain files.

## Custom domain

Site configuration, then Domain management, then add `visajourneyusa.com`. Netlify
issues the certificate itself. Set one of www or the bare domain as primary and let
Netlify redirect the other, so you are not splitting link equity across both.

Point DNS at Netlify before you switch anything, and keep the current site up until
the new one resolves.

## What is in here

- Six pages plus a 404, at clean URLs. `/about-us`, not `/about-us.html`.
- `netlify.toml` sets security headers, cache headers and redirects from the old
  `.html` paths. Netlify reads it automatically.
- `robots.txt` and `sitemap.xml` are both live and pointing at the real domain.
- `favicon.svg` and `hero.svg`.

## Checking which build is live

Every page carries a build marker. View source and look near the top for:

    <meta name="vj-build" content="2026-09-10 1a2b3c4d5e">

`BUILD.txt` at the site root lists the same build id and each asset's hash. If the
id on the live page does not match `BUILD.txt` in the folder you uploaded, the new
deploy has not gone out yet.

Asset URLs carry a hash of the file's contents, like `/visa-application-form.js?v=...`.
A changed file gets a new URL on every deploy, so browsers cannot keep running a
stale copy. That was the reason a release could look unchanged for up to an hour.

## The hero illustration

`hero.svg` is a flat vector in the site's own palette: 4 KB, sharp at any size, no
external dependency. It replaced a photograph that was being hotlinked from the old
server and has since 404'd.

If you swap in a real photograph later, keep the file local, keep the `width` and
`height` attributes on the tag so the layout does not jump while it loads, and use a
4:3 image, since the frame crops to that ratio.

## Before you point the domain at it

- The application form and the payment step are already in this folder and wired
  up. Both run in demo mode: open `application.html` and `payment.html` and look for
  `var DEMO = true`. Flip it to false once the four API endpoints exist, and the
  fetch calls beside it take over.
- Wire the contact form. It currently validates and shows a success state without
  sending anything. Either add a Netlify Form (put `netlify` and `name="contact"` on
  the form tag and remove the preventDefault in `site.js`) or point it at your own
  endpoint.
- Search the folder for `EDIT:` for the three things only you can fill in: the legal
  entity name in the footer, the service fee figure, and the support hours.
- Update the date in `sitemap.xml` whenever you change the pages.
""")

# ---------------------------------------------------------------------- zip
zip_path = os.path.join(HERE, "..", "deploy.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for name in sorted(os.listdir(OUT)):
        z.write(os.path.join(OUT, name), name)

print("deploy folder:", sorted(os.listdir(OUT)))
print("zip:", zip_path, os.path.getsize(zip_path), "bytes")
