/* Answers that open follow-up questions on the DS-160. This class of bug came up
   on September 20 via status_error.docx: an answer the official form branches on,
   and ours silently did not. Each check here is one such branch. */
const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const DIR = process.argv[2] || (__dirname + '/../src/');
const BASE = process.argv[3] || 'http://localhost:8899/';
let pass=0, fail=0; const bad=[];
const ok=(n,c,d)=>{ if(c){pass++;console.log('  PASS  '+n);} else {fail++;bad.push(n);console.log('  FAIL  '+n+(d!==undefined?' -> '+d:''));} };
function open(f){return new Promise(res=>{const errs=[];const vc=new VirtualConsole();
 vc.on('jsdomError',e=>{const m=e.message||String(e);if(!/Not implemented|fonts\.googleapis|Could not load/.test(m))errs.push(m);});
 const dom=new JSDOM(fs.readFileSync(DIR+f.split('?')[0],'utf8'),
  {runScripts:'dangerously',resources:'usable',url:BASE+f,virtualConsole:vc,pretendToBeVisual:true});
 setTimeout(()=>res({dom,errs,d:dom.window.document,w:dom.window}),1400);});}
const btn=(r,re)=>[...r.querySelectorAll('button')].find(b=>re.test(b.textContent));

(async()=>{
 const {d,w,errs}=await open('application.html');
 const S=w.VJ_SCHEMA.STEPS;
 const idx=id=>S.findIndex(x=>x.id===id);
 const mk=(step,data)=>{const b=d.createElement('div');d.body.appendChild(b);
   w.VisaJourneyForm.mount(b,{initialStep:step,applicationId:'X',initialData:data||{}});return b;};
 console.log('\nFOLLOW-UP BRANCHES THE DS-160 OPENS');
 ok('page loads clean', errs.length===0, errs[0]);

 const fam = idx('family'), trip = idx('travel');

 console.log('\n  marital status');
 ok('legally separated asks about the current spouse', !!mk(fam,{maritalStatus:'Legally separated'}).querySelector('#spouseSurnames'));
 ok('married still does', !!mk(fam,{maritalStatus:'Married'}).querySelector('#spouseSurnames'));
 const single = mk(fam,{maritalStatus:'Single'});
 ok('single asks about no spouse at all',
    !single.querySelector('#spouseSurnames, #deceasedSpouseSurnames') && !/former spouse/i.test(single.textContent));

 const div = mk(fam,{maritalStatus:'Divorced'});
 ok('divorced opens the former spouse questions', /former spouse/i.test(div.textContent));
 ok('former spouse has a date of marriage', /Date of marriage/.test(div.textContent));
 ok('former spouse has the date it ended', /Date the marriage ended/.test(div.textContent));
 ok('former spouse has how it ended', /How the marriage ended/.test(div.textContent));
 ok('former spouse has where it ended', /where the marriage was ended/.test(div.textContent));
 ok('more than one former marriage can be added', !!btn(div,/Add another former spouse/));
 ok('divorced is not asked about a current spouse', !div.querySelector('#spouseSurnames'));
 btn(div,/Continue/).click();
 ok('divorced cannot skip the former spouse details', !!div.querySelector('.vj-err'));

 const wid = mk(fam,{maritalStatus:'Widowed'});
 ok('widowed opens the deceased spouse questions', !!wid.querySelector('#deceasedSpouseSurnames'));
 ok('the wording is gentle', /sorry for your loss/.test(wid.textContent));
 ok('an unknown birthplace can be marked', !!wid.querySelector('#deceasedSpouseCityOfBirth__na'));
 ok('widowed is not asked about former spouses', !/former spouse/i.test(wid.textContent));

 console.log('\n  who is paying');
 const org = mk(trip,{payer:'Other company or organization'});
 ok('a company paying is asked for its name', !!org.querySelector('#payerCompanyName'));
 ok('and its phone number', !!org.querySelector('#payerCompanyPhone'));
 ok('and its relationship to you', !!org.querySelector('#payerCompanyRelationship'));
 ok('and its address', !!org.querySelector('#payerCompanyStreet1') && !!org.querySelector('#payerCompanyCountry'));
 ok('it is not asked for a person\'s surname', !org.querySelector('#payerSurnames'));
 btn(org,/Continue/).click();
 ok('the company details cannot be skipped', org.querySelector('#payerCompanyName').classList.contains('vj-bad'));
 ok('paying yourself asks nothing more', !mk(trip,{payer:'Myself'}).querySelector('#payerCompanyName, #payerSurnames'));
 ok('a person paying is still asked about the person', !!mk(trip,{payer:'Other person'}).querySelector('#payerSurnames'));

 console.log('\n'+'='.repeat(60));
 console.log('  '+pass+' passed, '+fail+' failed');
 if(fail) bad.forEach(x=>console.log('  - '+x));
 console.log('='.repeat(60));
 process.exit(fail?1:0);
})();
